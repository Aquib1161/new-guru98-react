<?php 
include('include/config.php');
include('header.php'); 
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>User Wise Plus Minus</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item">
                <button onclick="change('<?= $userdata['user_id'] ?>','<?= $userdata['user_type'] ?>')" class="btn btn-md btn-success" style="float:right;">Back</buton>
                </li>
              <li class="breadcrumb-item active">User Plus Minus</li>

            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

   <span id="live_report_data">

   
  </div>
  <!-- /.content-wrapper -->

  <script type="text/javascript">
    var market_id="<?= $_GET['market_id'] ?>"

                function get_user_data(market_id,report_for,user_id='',user_type='')
            {   

                $.ajax({
                    url : "ajax/ajax_company_report",
                    type : "post",
                    data : {market_id:market_id,report_for:report_for,user_id:user_id,user_type:user_type},
                    success : function(res){
                        $("#live_report_data").html(res);
                    }
                });
            }

  function change(user_id,user_type)
  {
    
    get_user_data(market_id,'downline',user_id,user_type);
    
  }

get_user_data(market_id,'self')

</script>

  <?php  include('footer.php');  ?>