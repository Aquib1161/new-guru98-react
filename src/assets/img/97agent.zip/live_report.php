<?php
include('include/config.php');
$_GET = sanatize($_GET);
$_POST = sanatize($_POST);
$market_id = $_GET['market_id'];
if ($_SESSION['user_type'] == 'superagent') {
  $_SESSION['user_type'] = 'sa';
}
include('header.php');
$match_detail = get_data('upcoming_match', "market_id='" . $_GET['market_id'] . "' ", 's');
$team_data=json_decode($match_detail['team_data_array'],true);
$count = $match_detail['count'];
$team1_selection_id = $team_data[0]['selection_id'];
$team2_selection_id = $team_data[1]['selection_id'];
$team3_selection_id = '';
$team1_name = $team_data[0]['runner_name'];
$team2_name = $team_data[1]['runner_name'];
if ($count == 3) {
  $team3_selection_id = $team_data[2]['selection_id'];
  $team3_name = $team_data[2]['runner_name'];
}
$score_type=$match_detail['score_type'];
$sports_id=$match_detail['sports_id'];
$iframe_url='';
if($sports_id==4 OR $sports_id==0)
{
  $iframe_url=iframe_url['football'].$match_detail['market_id'];
}
else
{
  $iframe_url=iframe_url['football'].'/'.$sports_id.'/'.$match_detail['event_id'];
}
 $iframe_url=iframe_url['football'].'/'.$sports_id.'/'.$match_detail['event_id'];
if($score_type=='iframe_score_with_score_id')
{
  $score_type='iframe_score';
}
?>


<style type="text/css">
  .score_image {
    background-color: #3467A5 !important;
    width: 50px;
    height: 100px;
    text-align: center !important;
    font-family: bold !important;
    font-size: 15px !important;
    display: flex;
    padding: 0px;
  }

  .score_image img {
    height: 80px;
    width: 120px;
    margin: auto;
  }

  @media only screen and (max-width: 480px) {
    .score_image {
      height: 55px;
      margin-top: 4px;
    }

    .score_image img {
      height: 55px;
      width: 48px;
      margin: auto;
    }
  }
</style>

<script>
  
  function show_tv() 
{       
        if ($('#tvFrame').is(':hidden')) {
            $("#tvFrame").attr('hidden', false)
            $('#tvFrame').append('' +
                ' <iframe src="https://supertv.lotusbook9mm.com/tv2/?event_id=<?= $match_detail['event_id'] ?>" scrolling="no" title="demo" width="100%" height="190">\n' +
                '        </iframe>');
            '<iframe frameborder="0" style="height: 185px; overflow:scroll; width: 100%" src="http://www.cbox.ws/box/?boxid=439&boxtag=7868&sec=main" marginheight="1" marginwidth="1" name="cboxmain" id="cboxmain" seamless="seamless" scrolling="no" frameborder="0" allowtransparency="true"></iframe>'
            $('#tvBtn').empty();
            } else {
            $("#tvFrame").attr('hidden', true)
            $('#tvFrame').empty();
            $('#tvBtn').empty();
        }
    }

</script>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Match Position</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="dashboard?page_name=dashboard">Home</a></li>
            <li class="breadcrumb-item active"><a href="match_list?page_name=inplay&page_no=1">Inplay</a></li>
            <?php if($iframe_url!=''){?>
            <li class="breadcrumb-item active">
              <button onclick="set_score_height()" id='score_button' class="btn btn-sm btn-info">Full Score</button>
            </li>
           <?php }  ?>

            <li class="breadcrumb-item active">
              <button onclick="show_tv()" id='show_tv' class="btn btn-sm btn-success">Show Tv</button>
            </li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>



  <section class="content">
    <div class="container-fluid">
      <div class="row" style="margin-bottom:-20px;">
        <div class="col-12">
          <div class="card card-secondary text-center">
            <span  id="tvFrame" hidden> </span>
          </div>
        </div>
      </div>


      <div class="row">
        <div class="col-12">

          <div class="card card-secondary text-center">
            <?php  if($score_type=='iframe_score'){?>
              <iframe  id='iframe_url' height="135" src="<?= $iframe_url ?>"></iframe>
            <?php }else {?>
            <span id='score'></span>
            <?php  } ?>

            <div class="form-row">
              <div class="col-md-6">
                <table class="table table-bordered" id="mOdds">
                  <thead>
                    <tr>
                      <th>Team</th>
                      <th class="text-red" style="width: 40px">KHAI</th>
                      <th class="text-blue" style="width: 40px">LAGAI</th>
                      <th><b class="text-blue">PLUS</b>/<b class="text-red">MINUS</b></th>
                    </tr>
                  </thead>
                  <tbody id="match">

                  </tbody>
                </table>
              </div>

              <div class="col-md-6">
                <table class="table table-bordered" id="sOdds">
                  <thead>
                    <tr>
                      <th>Session</th>
                      <th class=" text-red">NOT</th>
                      <th class="text-blue">YES</th>
                    </tr>
                  </thead>
                  <tbody id="session"></tbody>
                  <tfoot id="no_comm_session"></tfoot>
                </table>
              </div>
            </div>

            <div class="row" id="match_bets">
              <div class="col-lg-12">
                <table class="table table-bordered table-striped table-hover table-responsive-md">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Rate</th>
                      <th>Amount</th>
                      <th>Mode</th>
                      <th>Team</th>
                      <th>Client</th>
                      <?php  foreach ($team_data as $key => $team) { ?>
                      <th><?= ucfirst($team['runner_name']) ?></th>
                      <?php } ?>
                      

                      <th>Date &amp; Time</th>
                    </tr>
                  </thead>
                  <tbody id="load_data">

                  </tbody>
                </table>
              </div>
            </div>

            <div class="row" style="display:none;" id="session_bets">
              <div class="col-lg-8">
                <table class="table table-bordered table-striped table-hover table-responsive-md" id="matchBetsTable">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Session</th>
                      <th>Runs</th>
                      <th>Rate</th>
                      <th>Mode</th>
                      <th>Amount</th>
                      <th>Client</th>
                      <th>Date & Time</th>
                    </tr>
                  </thead>
                  <tbody id="session_bets_slip">

                  </tbody>
                </table>
              </div>
              <div class="col-lg-4">
                <table class="table table-striped table-bordered table-hover">
                  <thead>
                    <th style="text-align: center;">Runs</th>
                    <th style="text-align: center;">Position</th>
                  </thead>
                  <tbody id="session_position">

                  </tbody>
                </table>
              </div>
            </div>



            <!-- /.card-body -->
          </div>
        </div>
      </div>
    </div>



    <!-- /.container-fluid -->
  </section>


</div>
<!-- /.content-wrapper -->
<!-- <div class="modal inmodal" id="myModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content animated bounceInRight">
      <div class="modal-header">
        <center>
          <b style="text-align:center !important; font-size:20px; color:green;" id="session_name"></b>
        </center>
      </div>
      <div class="modal-body">

        <table class="table table-striped table-bordered table-hover">

          <thead>
            <th style="text-align: center;">Runs</th>
            <th style="text-align: center;">Position</th>
          </thead>
          <tbody id="session_position">

          </tbody>
        </table>
      </div>
      <input type="hidden" id="market_id" value="" name="">
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div> -->

<script src="dist/js/socket.io.js"></script>
<script>
  function score(data)
  {
    // update_function(data);
    //console.log(data);
    var score = `
        <h5 class="card-header" id="scoreMsg">${data.Status}</h5>
                <div class="card-body">
                  <div class="row">
                    <div class="col-6 text-md">
                      <span class="text-secondary"><b id="localTeam">${data.p1_dtl}</b></span>
                      <br>
                      <span class="text-secondary"><b id="visitorTeam">${data.p2_dtl}</b>
                      </span>
                    </div>
                     <div class="col-6 text-md">
                      <span class="text-secondary"><b id="localTeam">${data.t1_dtl}</b></span>
                      <br>
                      <span class="text-secondary"><b id="visitorTeam">${data.t2_dtl}</b></span>
                      
                    </div>
                   
                  </div>
              
                </div>

                `
                if(score_type!='iframe_score')
                {
                  document.getElementById('score').innerHTML = score;
                }
  

  }
</script>


<?php
$count = $match_detail['count'];
$socket_perm = $match_detail['socket_perm'];
?>

<input type="hidden" value="on_load" id="total_match_bets">
<input type="hidden" value="on_load" id="total_session_bets">
<input type="hidden" value="1" id="match_time_interval">
<input type="hidden" value="0" id="session_time_interval">
<input type="hidden" value="135" id="score_height">
<input type="hidden" value="0.00" id="<?= $team1_selection_id ?>_pos">
<input type="hidden" value="0.00" id="<?= $team2_selection_id ?>_pos">
<?php if ($count == 3) { ?>
  <input type="hidden" value="0.00" id="<?= $team3_selection_id ?>_pos">
<?php   } ?>

<!-- 172.105.40.241:8080
172.105.56.95:8090 -->

<script type="text/javascript">
  var interval_time = 10000;
  var position_interval_time = 20000;
  var score_type="<?= $score_type ?>"


    var count = "<?= $count ?>";
    var team1_selection_id = "<?= $team1_selection_id ?>";
    var team2_selection_id = "<?= $team2_selection_id ?>";
    var team3_selection_id = "<?= $team3_selection_id ?>";

  <?php if ($socket_perm == 1) { ?>
    $(document).ready(function() {
      var market_id = "<?= $_GET['market_id'] ?>";
      var base_url = '';
     // var socket = io.connect('https://socket.sixpro.in:8080/');
		var socket_url="https://centralpanel.co.in?marketId="+market_id+"&type=matchOdd"
var socket = io.connect(socket_url);
      socket.on('connection', () => {
        console.log('connnected')
      });
     // socket.emit("join", market_id);

      socket.on('matchData', function(msg) {
        
        if (msg.result.market_id==market_id) {
          res = JSON.stringify(msg);
          update_function(res)
        }
      });
    });
  <?php } else { ?>

    function get_data() {
      var market_id = "<?= $_GET['market_id'] ?>";
      var api_url = "<?= api_url ?>";
      var hit_url = api_url + market_id;
      $.ajax({
        type: "get",
        dataType: "json",
        
        data: `{ "market_id": ${market_id} }`,
        url: hit_url,
        success: function(res) {
            //  console.log(res)
             
             res=JSON.stringify(res);
            update_function(res)
        }
      });

    }
    get_data();

    var teaminterval = setInterval(function() {
      get_data()

    }, 2000)

  <?php  } ?>


  function get_position() {
    var market_id = "<?= $_GET['market_id'] ?>";
    var betexch_id = "<?= $match_detail['betexch_id'] ?>";
    var count = "<?= $count ?>";
    var team1_selection_id = "<?= $team1_selection_id ?>";
    var team2_selection_id = "<?= $team2_selection_id ?>";
    if (count == 3) {
      var team3_selection_id = "<?= $team3_selection_id ?>";
      all_selection_id = {
        'team1_selection_id': team1_selection_id,
        'team2_selection_id': team2_selection_id,
        'team3_selection_id': team3_selection_id,
      };
    } else {

      all_selection_id = {
        'team1_selection_id': team1_selection_id,
        'team2_selection_id': team2_selection_id,
      };

    }



    sendData = {
      'market_id': market_id,
      'user_id': "<?= $_SESSION['user_id'] ?>",
      'user_type': "<?= $_SESSION['user_type'] ?>",
      'count': count,
      'all_selection_id': all_selection_id,
    };

    $.ajax({
      url: "ajax/match_position",
      type: "post",
      dataType: 'json',
      data: {
        'market_id': market_id,
        'user_id': "<?= $_SESSION['user_id'] ?>",
        'user_type': "<?= $_SESSION['user_type'] ?>",
        'count': count,
        'all_selection_id': all_selection_id,
      },
      success: function(res) {

         res.map(function(pos_data){
            $('#' + pos_data.selection_id + '_pos').val(pos_data.total_profit)
         })

       
      }
    });
    //return data = sendAjax('ajax/match_position',sendData);    
  }

  get_position();
  var position_interval = setInterval(function() {
    get_position()
  }, position_interval_time)


  function update_function($res) {
    var data = JSON.parse($res);
    var count = "<?= $count ?>";
    var result = (data.result);
    var session_data = result.session;
    var score_data = result.score;
    var match_data = result.team_data;
    var market_id = "<?= $_GET['market_id'] ?>";
    var fav_pos = data.fav_pos;
    var non_fav_pos = data.non_fav_pos;
    var draw_pos = data.draw_pos;

    var betexch_id = "<?= $match_detail['betexch_id'] ?>";

    $(document).ready(function() {
      $("#session").html('');
      $("#match").html('');
      session_data.forEach(function(value, i) {
        if (betexch_id != '') {
          value.Selection_id = value.Another_Selection_id
        }
      
   
        var comm_perm='';

        if(value.com_perm=='NO')
        {
          comm_perm='<span class="text-danger">(No Comm)</span>'
        }

        var str = `<tr>
                      <td> 
                          <a style='cursor:pointer;' id="${value.Selection_id}" onclick="show_bets('session',${value.Selection_id});session_position(${value.Selection_id});"  class="btn username">  ${value.session_name}  ${comm_perm} 
                          </a> 
                      </td>
                      <td>  <h6 class="text-red"> ${value.runsNo} </h6> <b class="badge badge-danger" style="padding: 2px">${value.oddsNo}</b>
                      </td>
                      <td>  <h6 class="text-blue"> ${value.runsYes} </h6><b class="badge badge-primary" style="padding: 2px">${value.oddsYes}</b>
                      </td>
                  </tr>
                  `;

                  if(comm_perm=='NO')
                  {
                    $("#no_comm_session").append(str);
                  }
                  else
                  {
                    $("#session").append(str);
                  }
        
      });


      $("#match").html('');
      match_data.forEach(function(match_value, i) {

        var pos = 0;
        pos = $('#' + match_value.selectionid + '_pos').val()

        if (pos < 0) {
          pos = "<span style='color:red'>" + pos + "</span>";
        } else {
          pos = "<span style='color:#007BFF'>" + pos + "</span>";
        }

        var str = `
                            <tr>
                                <td><a href="#" class="btn username" onclick="show_bets('match')"> ${match_value.team_name} </a></td>
                                <td><a href="#" class="btn text-red">${match_value.lgaai}</a></td>
                                <td><a href="#" class="btn text-blue">${match_value.khaai}</a></td>
                                <td> <a id="${match_value.selection_id}_position"  href="#" class="btn text-bold "> ${color(pos)} </a></td>
                            </tr>
                          `
        $("#match").append(str);
      });

      score(score_data)

    });

  }


  function color(value) {
    if (value < 0) {
      return `<span style="color:red">${value}</span>`;
    } else {
      return `<span style="color:#008000">${value}</span>`;
    }
  }


  function session_position(selection_id) {
    var market_id = "<?= $market_id ?>";
    var selection_id = selection_id;

    sendData = {
      'market_id': market_id,
      'selection_id': selection_id,
    };
    data = sendAjax('position/session_position', sendData);

    $("#session_position").html('');
    data.reverse().forEach(function(value, i) {
      var poss = `<tr class="gradeX">
                        <td>${value.run}</td>
                        <td>${color(value.pos)}</td>
                  </tr>`
      $("#session_position").append(poss);
    });

    document.getElementById("session_position").scrollIntoView();
  }


  function load_data() {
    var check = true;
    var match_type = 'match_odds';
    var bet_type = 'open';
    var client_id = '';
    var market_id = '<?php echo $market_id ?>';
    $.ajax({
      url: "ajax/match_bet",
      type: "post",
      dataType: 'json',
      data: {
        bet_type: bet_type,
        match_type: match_type,
        client_id: client_id,
        market_id: market_id
      },
      success: function(res) {
        var data = res.data;
        count = data.length
        match_bets = $('#total_match_bets').val()
        if (match_bets == 'on_load') {
          $('#total_match_bets').val(count)
        } else if (count == match_bets) {
          return false
        } else {
          $('#total_match_bets').val(count)
          notify('success', 'Total Match Bets =' + count)
        }
        $("#no_of_bets").html(count);
        $("#load_data tr").remove();
        var count = "<?= $count ?>";

        jQuery.each(data, function(i, bet_data) {
          var position_array=bet_data.position_array
          var share_amount_favour = (bet_data.my_share * bet_data.favor_amount / 100);
          var share_amount_unfavour = (bet_data.my_share * bet_data.unfavour_amount / 100);
          if(count==3)
          {
             var str = '<tr class=""><td>' + bet_data.serial_no + '</td><td>' + bet_data.bhav + '</time></td><td>' + bet_data.amount + '</td><td>' + bet_data.type + '</td><td>' + bet_data.team_name + '</td><td>' + bet_data.client + '</td><td>' + position_array.team1_amount + '</td> <td>' + position_array.team2_amount + '</td>  <td>' + position_array.team3_amount + '</td> <td>' + bet_data.time_inserted + '</td></tr>';
          }
          else
          {
            var str = '<tr class=""><td>' + bet_data.serial_no + '</td><td>' + bet_data.bhav + '</time></td><td>' + bet_data.amount + '</td><td>' + bet_data.type + '</td><td>' + bet_data.team_name + '</td><td>' + bet_data.client + '</td><td>' + position_array.team1_amount + '</td> <td>' + position_array.team2_amount + '</td><td>' + bet_data.time_inserted + '</td></tr>';
          }
          


          $("#load_data").append(str);
        });

      }
    });
  }
  load_data();
  var match_data = setInterval(function() {
    var match_interval_perm = document.getElementById('match_time_interval').value
    if (match_interval_perm == 1) {
      // load_data()
    }
  }, interval_time)


  $("#match_bets").css('display', '')

  function show_bets(type, selection_id = '') {
    if (type == 'match') {
      $('#match_time_interval').val(1);
      $('#session_time_interval').val(0);
      $("#match_bets").css('display', '');
      $("#session_bets").css('display', 'none')
    } else {
      $("#match_bets").css('display', 'none');
      session_load(selection_id)
      $('#match_time_interval').val(0);
      $('#session_time_interval').val(1);
      var session_data = setInterval(function() {
        var session_interval_perm = document.getElementById('session_time_interval').value
        if (session_interval_perm == 1) {
          //session_load(selection_id)
        }
      }, interval_time)
      $("#session_bets").css('display', '')
    }
  }

  function session_load(selection_id = '') {
    if (selection_id != '') {

    }
    var check = true;
    var client_id = '';
    var market_id = '<?php echo $market_id ?>';
    $.ajax({
      url: "ajax/session_bet",
      type: "post",
      dataType: 'json',
      data: {
        selection_id: selection_id,
        client_id: client_id,
        market_id: market_id,
        live_report: '1'
      },
      success: function(res) {
        var data = res.data;
        count = data.length
        session_bets = $('#total_session_bets').val()
        if (session_bets == 'on_load') {
          $('#total_session_bets').val(count)
        } else if (count == session_bets) {
          return false
        } else {
          $('#total_session_bets').val(count)
          //notify('success','Total Session Bets ='+count)
        }
        $("#session_bets_slip  tr").remove();
        $("#no_of_session_bets").html(count);
        jQuery.each(data, function(i, bet_data) {
          var share_amount_favour = (bet_data.my_share * bet_data.pass_amount / 100);
          var share_amount_unfavour = (bet_data.my_share * bet_data.fail_amount / 100);

          var str = '<tr class=""><td>' + bet_data.serial_no + '</td><td>' + bet_data.runner_name + '</td><td>' + bet_data.bet_run + '</td><td>' + bet_data.bhav + '</td><td>' + bet_data.type + '</td><td>' + bet_data.amount + '</td><td>' + bet_data.client_name + '</td><td>' + bet_data.time_inserted + '</td></tr>';
          $("#session_bets_slip").append(str);
        });


      }
    });

  }


function set_score_height()
{  
   var half=135
   var full=200
   var score_height=$('#score_height').val()
   var new_height=''
   if(score_height==half)
   {
    $('#score_height').val(full)
    $('#score_button').html('Half Score')
    new_height=full
   }
   else
   {
    $('#score_height').val(half)
    $('#score_button').html('Full Score')
    new_height=half
   }
   $('#iframe_url').attr('height',new_height)
}

</script>


<?php include('footer.php');  ?>