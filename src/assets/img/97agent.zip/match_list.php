<?php
include('include/config.php');
$inplay = true;
if (isset($_GET['page_no'])) {
  $page_no = $_GET['page_no'];
  if ($page_no <= 0) {
    $page_no = 1;
  }
} else {
  $page_no = 1;
}
if (isset($_GET['page_name']) AND $_GET['page_name'] == 'complete_match') 
{
  $where="(status='COMPLETED' OR status='ABONDED') AND game_type=''";
  $inplay = false;
} 
else if($_GET['page_name'] == 'inplay')
{
  $where="status!='REMOVE' AND status!='COMPLETED'";
}
else
{
  $where="1=1";
  $inplay = false;
}

// _dx($where);
$sports_id=4;
if(isset($_GET['sports_id']))
{
  $sports_id=$_GET['sports_id'];
}
$where=$where." AND sports_id='".$sports_id."'";

//_dx($where);

 $data = $data = cricket_pagination('upcoming_match',$where, $page_no,'match_name,status,market_id,event_id,won_team_name,match_type,uploading_date,sports_id,id,match_date');
$_GET['page_name'] = 'match';
$match_data = $data['data'];
$match_list=convert_key_array($match_data,'market_id');
$market_ids=$match_list['key_array'];
$match_data=$match_list['array_data'];
$total_pages = $data['total_pages'];
$old_company_report = 'company_report';
$user_type = $userdata['user_type'];
if ($user_type == 'superadmin' or $user_type == 'superagent' or $user_type == 'master' or $user_type == 'admin') {
  $old_company_report = $userdata['user_type'] . '_company_report';
}
$user_type = $_SESSION['user_type'] == 'superagent' ? 'sa' : $_SESSION['user_type'];
// if($inplay==false)
// {
//   $query="SELECT sum(total_".$user_type."_profit) total_amount,market_id FROM `md_client_position` WHERE   market_id IN ($market_ids) GROUP BY market_id";
//   $res=mysqli_query($con,$query);
//   $overall_ledger = mysqli_fetch_all($res, MYSQLI_ASSOC);
//   $overall_ledger=convert_key_array($overall_ledger,'market_id')['array_data'];
// }
include('header.php');
?>
<style type="text/css">
  
  table tbody td{
    color: black !important;
    font-weight: bolder;
  }

</style>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Games</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="dashboard?page_name=dashboard">Home</a></li>
            <li class="breadcrumb-item active"><?= ucfirst('match List') ?></li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <form action="#" method="post" id="demoForm">
              <div class="card-header">
                <h2 class="card-title">Sport Details</h2>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive">
                <table class="table table-bordered">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>SNo</th>
                      <th>Code</th>
                      <th>Name</th>
                      <th>Date Time</th>
                      <th>Match Type</th>
                      <?php if ($inplay == false) { ?>
                        <th>Declare</th>
                        <th>Won By</th>
                        <th>Plus Minus</th>
                      <?php } ?>
                    </tr>
                  </thead>
                  <tbody>

                    <?php $total_ledger = 0;
                    $no = 1;
                    foreach ($match_data as $key => $data) {
                      if ($_SESSION['user_type'] == 'superagent') {
                        $_SESSION['user_type'] = 'sa';
                        $id = 'sa_id';
                      } else {
                        $id = $_SESSION['user_type'] . '_id';
                      }

                      $where = "user_id='" . $_SESSION['user_id'] . "' AND market_id='" . $data['market_id'] . "' ";
                      $user_type = $_SESSION['user_type'] == 'superagent' ? 'sa' : $_SESSION['user_type'];

                    ?>

                      <tr>


                        <td>
                          <div align="center">
                            <div class="btn-group">
                              <?php if ($inplay == true) { ?>
                                <button type="button" class="btn  btn-outline-primary dropdown-toggle dropdown-hover dropdown-icon" data-toggle="dropdown">
                                  <span class="sr-only">Toggle Dropdown</span>
                                </button>
                              <?php } else { ?>
                                <button type="button" class="btn-sm btn  btn-primary dropdown-toggle dropdown-hover dropdown-icon" data-toggle="dropdown">
                                  <span class="sr-only">Toggle Dropdown</span>
                                </button>
                              <?php } ?>


                              <div class="dropdown-menu" role="menu">

                                


                                <?php if ($data['status'] != 'COMPLETED') { ?>

                                  <a class="dropdown-item btn" href="live_report?market_id=<?= $data['market_id'] ?>&page_name=match" class="dropdown-item btn">Match &amp; Session position</a>

                                <?php } ?>

                                 <a class="dropdown-item btn" href="new_company_report?market_id=<?= $data['market_id'] ?>&page_name=company_report&all=1" class="dropdown-item btn">Match Session plus minus UserWise</a>

                                <a class="dropdown-item btn" href="both_screen?market_id=<?= $data['market_id'] ?>&all=1&page_name=company_report">Match Session plus minus
                                </a>



                                <a class="dropdown-item btn" href="match_session_bets?market_id=<?= $data['market_id'] ?>&page_name=match">Display Match & Session Bets</a>
                                <a class="dropdown-item btn" href="client_match_bets?market_id=<?= $data['market_id'] ?>&page_name=match">Display Match bets</a>
                                <a class="dropdown-item btn" href="client_session_bets?market_id=<?= $data['market_id'] ?>&page_name=match" style="color:black;">Display Session Bets</a>

                              </div>


                            </div>
                          </div>
                        </td>
                        <td>
                          <label><?= $no++ ?></label>

                        </td>
                        <td>
                          <span><?= $data['id'] ?></span>
                        </td>
                        <td><?= strtoupper($data['match_name']) ?></td>
                        <td><?= $data['match_date'] ?></td>
                        <td><?= strtoupper($data['match_type']) ?></td>

                        <?php if ($inplay == false) 
                        { 
                          //_dx($overall_ledger);
                          // if(isset($overall_ledger[$data['market_id']]['total_amount']))
                          // {
                          //   $ledger=$overall_ledger[$data['market_id']]['total_amount'];
                          // }
                          // else
                          // {
                          //   $ledger=0;
                          // }
                          $ledger = get_data('md_client_position', user_where("market_id='" . $data['market_id'] . "'", 's'), 's', "sum(total_" . $user_type . "_profit) total_amount")['total_amount'];
                          $total_ledger += $ledger;
                        ?>
                          <td>YES</td>
                          <td><?= strtoupper($data['won_team_name']) ?></td>
                          <td class="font-weight-bold"><?= color(round($ledger, 2)) ?></td>

                        <?php } ?>

                      </tr>

                    <?php } ?>


                    <tr>
                      <th></th>
                      <th></th>
                      <th></th>
                      <th></th>
                      <th></th>
                      <th></th>
                      <?php if ($inplay == false) { ?>
                        <th></th>
                        <th></th>
                        <th><?= round($total_ledger, 2) ?></th>
                      <?php } ?>
                    </tr>

                  </tbody>
                  <tfoot>

                  </tfoot>
                </table>
              </div>
              <!-- /.card-body -->
              <?php if (isset($_GET['page_no'])) {
                $page_no = $_GET['page_no'];
                if ($page_no <= 0) {
                  $page_no = 1;
                }
              } else {
                $page_no = 2;
              }
              ?>
              <div class="card-footer clearfix">
                <ul class="pagination pagination-sm m-0 float-right" style="display: flex;flex-wrap: wrap;">
                  <?php for ($i = 1; $i <= $total_pages; $i++) {  ?>
                    <li class="page-item <?php if ($_GET['page_no'] == $i) echo 'active' ?>">
                      <a class="page-link" href="match_list?page_name=complete_match&page_no=<?= $i ?>"><?= $i ?></a>
                    </li>
                  <?php } ?>
                  <?php if ($page_no >= $total_pages) {
                    $page_no = $page_no - 1;
                  }
                  ?>

                  <div>
                    <li class="page-item"><a class="page-link" href="match_list?page_name=complete_match&page_no=<?= ($page_no + 1); ?>">»</a>
                    </li>
                  </div>

                </ul>
              </div>

            </form>
          </div>
          <!-- /.card -->


        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
  </section>





</div>
<!-- /.content-wrapper -->




<script>
  function alert_function($id, $for = '', $status) {
    var user_id = "<?php echo $_SESSION['user_id']; ?>";
    var market_id = $id;
    var status = $status;
    if ($for == 'match') {
      var show_status = 1;
      if (status == 1) {
        show_status = 'Disable';
      } else {
        $show_status = 'enable';
      }
      var text = "Are you sure you want to " + show_status + "This match !"
    }
    swal({
        title: "Are you sure?",
        text: text,
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Yes, change it!",
        cancelButtonText: "No, cancel it!",
        closeOnConfirm: false,
        closeOnCancel: false
      },
      function(isConfirm) {
        if (isConfirm) {
          $.ajax({
            url: "ajax/update.php",
            type: "post",
            dataType: 'json',
            data: {
              type: 'match_update',
              user_id: user_id,
              status: status,
              market_id: market_id
            },
            success: function(res) {
              var status = res.status;
              if (status == 'success') {
                swal("Updated!", res.data.msg, status);
                location.reload()
              } else {
                swal("Failed!", res.data.msg, status);
              }
            }
          });

        } else {
          swal("Cancelled", "Status do not updated", "error");
        }
      });
  }
</script>

<?php include('footer.php'); ?>