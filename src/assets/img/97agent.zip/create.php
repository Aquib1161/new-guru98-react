<?php
include('include/config.php');
$_GET = sanatize($_GET);
$return = check_role(trim($_GET['role']));
$role = $_GET['role'];
$edit = false;
$show_parent_label = 'My';
if ($return == 0) {
    invalid();
}
$code = get_code(trim($_GET['role']));

if ($code == '0') {
    invalid();
}
if (!isset($_GET['user_id'])) {
    $users = column_names('users_tbl')['table'];
    $users['username'] = $code;
    $users['user_match_comm'] = 0.00;
    $users['user_session_comm'] = 0.00;
} else {
    $users = get_user_list('', $_GET['user_id']);
    $edit = true;
    check_authority($_GET['user_id']);
}
$creater_priority = priority($role);
$user_priority = priority($_SESSION['user_type']);
$check_priority = $user_priority - $creater_priority;
if ($check_priority < 1) {
    invalid();
}

$priority_name = priority_name((priority($role) + 1));
if ($check_priority != 1) {
    $upline_data = get_data('users_tbl', user_where("user_type='" . $priority_name . "'"));
}

if (isset($_GET['user_id'])) {
    $parent_data = get_data('users_tbl', "user_id='" . $users['creater_id'] . "'", 's');
    $show_parent_label = $parent_data['username'];
} elseif (isset($_GET['parent_id'])) {
    $parent_data = get_data('users_tbl', "user_id='" . $_GET['parent_id'] . "'", 's');
    check_authority($_GET['parent_id']);
    $show_parent_label = $parent_data['username'];
} else {
    $parent_data = $userdata;
}

$users['parent_show_user_type']=$parent_show_user_type=$parent_data['user_type']=='superagent'?'sa':$parent_data['user_type'];


include('header.php');
?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1><?= ucfirst($_GET['page_name']) ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="list?page_name=<?= $_GET['page_name'] ?>&list_type=<?= $_GET['page_name'] ?>"><?= ucfirst($_GET['page_name']) ?></a></li>
                        <li class="breadcrumb-item active">New <?= ucfirst($_GET['page_name']) ?></li>
                    </ol>
                </div>
            </div>
        </div>
    </section>



    <section class="content">




        <form id="myForm" action="model/create_db" method="POST">
            <div class="row">
                <div class="col-md-6">
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">General</h3>

                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
                                    <i class="fas fa-minus"></i></button>
                            </div>
                        </div>
                        <div class="card-body">

                            <div class="form-group">

                                <label for="code">Code</label>
                                <input type="text" id="code" placeholder="" readonly="" class="form-control" value="<?= $users['username'] ?>">

                            </div>

                            <div class="form-group">
                                <label for="name">Name</label>
                                <input type="text" id="user_name" class="form-control" placeholder="Name" min="2" required="" name="user[name]" value="<?= $users['name'] ?>">

                            </div>

                            <div class="form-group">
                                <label for="name">Reference</label>
                                <input type="text" id="reference" class="form-control" placeholder="Reference" required="" name="user[reffrence]" value="<?= $users['reffrence'] ?>">
                            </div>


                            <div class="form-group">
                                <label for="password">Password</label>
                                <div class="input-group ">
                                    <input type="text" class="form-control" placeholder="Password" min="6" id="password" required="" name="user[password]" value="<?= $users['password'] ?>">
                                    <span class="input-group-append"><button type="button" class="btn btn-info btn-flat" onclick="generate_password()">Generate Password</button></span>
                                </div>
                            </div>
                            <div class="form-group">

                                <label for="mobile">Contact No</label>
                                <input type="number" class="form-control" id="mobile" placeholder="Mobile No" required="" name="user[mobile]" value="<?= $users['mobile'] ?>">
                            </div>


                            <?php if($_GET['list_type']=='agent'){?>
                                <div class="form-group">
                                    <label for="no_comm_perm">No Comm Session Play Perm</label>
                                    <select class="form-control" id="no_comm_perm" name="user[no_comm_perm]">
                                        <option <?php if ($users['no_comm_perm'] === '1') echo 'selected=selected' ?>value="1">YES</option>
                                        <option <?php if ($users['no_comm_perm'] === '0') echo 'selected=selected' ?>value="0">NO</option>
                                    </select>
                                </div> 
                            <?php }  ?>

                            <?php if ($edit == true) { ?>
                                <div class="form-group">
                                    <label for="user_share_type">Flat Share</label>
                                    <select class="form-control" id="user_share_type" name="user[user_share_type]">
                                        <option <?php if ($users['user_share_type'] === 'fixed') echo 'selected=selected' ?>value="fixed">YES</option>
                                        <option <?php if ($users['user_share_type'] === 'change') echo 'selected=selected' ?>value="change">NO</option>
                                    </select>
                                </div> 

                               
                            <?php } ?>



                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <div class="col-md-6">
                    <div class="card card-secondary">
                        <div class="card-header">
                            <h3 class="card-title">Share and Commission</h3>

                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
                                    <i class="fas fa-minus"></i></button>
                            </div>
                        </div>
                        <div class="card-body">

                            <?php if ($edit == false) { ?>
                                <div class="form-group row">
                                    <div class="form-group col-md-6">
                                        <label for="user_coins"><?= ucfirst($role) ?> Limit</label>
                                        <input type="number" max="<?= $parent_data['total_coins'] ?>" min="0" placeholder="Client Limit" class="form-control" step="0.01" required="" id="user_coins" name="user_coins" value="0.00">
                                    </div>

                                    <div class="form-group col-md-6">
                                        <label for="parent_coins"><?= $show_parent_label ?> Limit</label>
                                        <input type="number" placeholder="Limit" class="form-control" value="<?= round($parent_data['total_coins'], 1) ?>" id="parent_coins" readonly="">
                                    </div>

                                </div>
                            <?php  } ?>


                            <?php 
                               $col_md=$parent_data['user_share_type']=='change' && $edit == true?'col-md-4':'col-md-6';
                             ?>

                            <div class="form-group row">
                                <div class="form-group <?= $col_md ?>">
                                    <label for="user_share"><?= ucfirst($role) ?> Share</label>
                                    <input type="number" max="<?= $parent_data['user_share'] ?>" min="0" placeholder="Share" class="form-control" id="user_share" step="0.01" required="" name="user[user_share]" value="<?= $users['user_share'] ?>">
                                </div>


                                <?php if ($parent_data['user_share_type'] == 'change' AND $edit == true) { ?>

                                    <div class="form-group <?= $col_md ?>">
                                            <label for="sashare"><?= ucfirst($priority_name) ?> Match Share On <?= ucfirst($role) ?></label>
                                            <input type="number" max="<?= round($parent_data['user_share'], 1) ?>" min="<?= $users['user_share'] ?>" placeholder="Share" class="form-control" id="sashare" step="0.01" required="" name="user[flat_share_on]" value="<?= $users[$parent_show_user_type."_share"] ?>">
                                        </div>

                                <?php } ?>

                                <div class="form-group <?= $col_md ?>">
                                    <label for="parent_user_share"><?= $show_parent_label ?> Share</label>
                                    <input type="number" placeholder="Share" class="form-control" value="<?= round($parent_data['user_share'], 1) ?>" id="parent_user_share" readonly="">
                                </div>
                            </div>

                            <?php if (is_casino) { ?>
                                <div class="form-group row">
                                    <div class="form-group col-md-6">
                                        <label for="user_casino_share"><?= ucfirst($role) ?> Casino Share</label>
                                        <input type="number" max="<?= $parent_data['user_casino_share'] ?>" min="0" placeholder="Casino Share" class="form-control" id="user_casino_share" step="0.01" required="" name="user[user_casino_share]" value="<?= $users['user_casino_share'] ?>">
                                    </div>

                                    <div class="form-group col-md-6">
                                        <label for="parent_casino_user_share"><?= $show_parent_label ?> Share</label>
                                        <input type="number" placeholder="Share" class="form-control" value="<?= round($parent_data['user_casino_share'], 1) ?>" id="parent_casino_user_share" readonly="">
                                    </div>
                                </div>

                                <div class="form-group row" id="match_comm">
                                    <div class="form-group col-md-6">
                                        <label for="user_casino_comm">Casino Commision</label>
                                        <input type="number" value="<?= $users['user_casino_comm'] ?>" class="form-control" placeholder="Casino Commission (Only On Minus)" min="0" max="<?= $parent_data['user_casino_comm'] ?>" step="0.01" id="casino_commission" required="" name="user[user_casino_comm]">
                                    </div>

                                    <div class="form-group col-md-6">
                                        <label for="parent_user_casino_comm"><?= $show_parent_label ?> Casino Commission</label>
                                        <input id="parent_user_casino_comm" type="text" min="0" max="<?= $parent_data['user_casino_comm'] ?>" value="<?= number_format($parent_data['user_casino_comm'], 1) ?>" class="form-control" readonly="">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="user_casino_perm">Casino Status</label>
                                    <select id='user_casino_perm' name="user[user_casino_perm]" class="form-control">
                                        <option <?php if ($users['user_casino_perm'] == 0) echo 'selected=selected' ?> value='0'>OFF</option>
                                        <option <?php if ($users['user_casino_perm'] == 1) echo 'selected=selected' ?> value='1'>ON</option>

                                    </select>
                                </div>
                            <?php } ?>





                            <!--        <div class="form-group row">
                                    <div class="form-group col-md-6">
                                        <label for="user_mobile_share"> <?= ucfirst($role) ?> Mobile Share</label>
                                        <input type="number" min="0" placeholder="Mobile Share" class="form-control" max="<?= $parent_data['user_mobile_share'] ?>" step="0.01" id="user_mobile_share" required="" name="user[user_mobile_share]" value="<?= $users['user_mobile_share'] ?>">
                                    </div>

                                    <div class="form-group col-md-6">
                                        <label for="mobile_share"><?= $show_parent_label ?> Mobile Share</label>
                                        <input type="number" min="0" placeholder="Mobile Share" class="form-control" max="100" step="0.01" readonly="" required="" id="mobileshare" name="mobileshare" value="<?= $parent_data['user_mobile_share'] ?>">
                                    </div>
                                </div>

 -->
                            <input type="hidden" min="0" placeholder="Mobile Share" class="form-control" max="0" step="0.01" id="user_mobile_share" required="" name="user[user_mobile_share]" value="0">

                            <input type="hidden" min="0" placeholder="Mobile Share" class="form-control" max="100" step="0.01" readonly="" required="" id="mobileshare" name="mobileshare" value="0">




                            <div class="form-group">
                                <label for="user_comm_type">Commission Type</label>
                                <select id='user_comm_type' name="user[user_comm_type]" class="form-control" onchange="change_commission()">
                                    <option <?php if ($users['user_comm_type'] == 'No Comm') echo 'selected=selected' ?> value='No Comm'>No Comm</option>
                                    <!--  <option <?php if ($users['user_comm_type'] == 'Om') echo 'selected=selected' ?>value='OM'>Only On Minus</option> -->
                                    <option <?php if ($users['user_comm_type'] == 'BB') echo 'selected=selected' ?> value='BB'>Bet By Bet</option>
                                </select>
                            </div>

                            <div class="form-group row" id="match_comm">
                                <div class="form-group col-md-6">
                                    <label for="user_match_comm">Match Commision</label>
                                    <input type="number" value="<?= $users['user_match_comm'] ?>" class="form-control" placeholder="Match Commission" min="0" max="<?= $parent_data['user_match_comm'] ?>" step="0.01" id="match_commission" required="" name="user[user_match_comm]">
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="mc"><?= $show_parent_label ?> Match Commission</label>
                                    <input id="mc" type="text" min="0" max="<?= $parent_data['user_match_comm'] ?>" value="<?= number_format($parent_data['user_match_comm'], 1) ?>" class="form-control" readonly="">
                                </div>
                            </div>


                            <div class="form-group row" id="session_comm">

                                <div class="form-group col-md-6">
                                    <label for="user_session_comm">Session Commission</label>
                                    <input type="number" value="<?= $users['user_session_comm'] ?>" class="form-control" placeholder="Match" min="0" max="<?= $parent_data['user_session_comm'] ?>" step="0.01" id="user_session_comm" required="" name="user[user_session_comm]">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="mc"><?= $show_parent_label ?> Session Commission</label>
                                    <input type="number" value="<?= number_format($parent_data['user_session_comm'], 1) ?>" id="sc" class="form-control" placeholder="Session Commission" readonly="">
                                </div>
                            </div>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
            </div>
            <input type="hidden" name="user[user_id]" value="<?= $users['user_id'] ?>">
            <input type="hidden" name="user[role]" value="<?= $_GET['page_name'] ?>">
            <input type="hidden" name="user[page_name]" value="<?= $_GET['page_name'] ?>">
            <input type="hidden" name="user[user_type]" value="<?= $_GET['page_name'] ?>">
            <input type="hidden" name="user[creater_id]" value="<?= $parent_data['user_id'] ?>">
            <input type="hidden" name="parent_user_id" value="<?= $parent_data['user_id'] ?>">
            <div class="row">
                <div class="col-12">
                    <a href="#" class="btn btn-secondary">Cancel</a>
                    <?php if ($edit == false) { ?>

                        <button type="submit" class="btn btn-success float-right" id="submitBtn">Create New <?= ucfirst($role) ?></button>
                    <?php } else { ?>
                        <button type="submit" class="btn btn-success float-right" id="btn">Update <?= ucfirst($role) ?></button>

                    <?php } ?>
                </div>
            </div>

        </form>

        <br>

    </section>





</div>
<!-- /.content-wrapper -->

<script>
    jQuery("#myForm").on('submit', function () {
        $("#submitBtn").attr('disabled', 'disabled');
    });

    var parent_session_comm = "<?= $parent_data['user_session_comm'] ?>";
    var parent_match_comm = "<?= $parent_data['user_match_comm'] ?>";

    function change_commission() {

        var comm_type = $('#user_comm_type').val()

        if (comm_type == 'Bet By Bet') {
            comm_type = 'BB'
            $('#user_comm_type').val('BB')
        }


        if (comm_type == 'OM') {
            $("#match_comm").css('display', '');
            $("#session_comm").css('display', 'none');
        } else if (comm_type == 'BB') {
            $("#match_comm").css('display', '');
            $("#session_comm").css('display', '');


        } else {
            $("#match_comm").css('display', 'none');
            $("#session_comm").css('display', 'none');
        }


    }

    function generate_password() {
        var rand = Math.floor(Math.random() * (999999 - 111111)) + 111111
        $("#password").val(rand)

    }

    <?php if ($edit == false) { ?>
        $('#user_comm_type').val('BB')
        $("#user_session_comm").val(parent_session_comm);
        $("#match_commission").val(parent_match_comm);
    <?php } ?>

    <?php if ($edit == true) { ?>
        var comm_type = $('#user_comm_type').val()
        if (comm_type == 'No Comm') {
            $("#match_comm").css('display', 'none');
            $("#session_comm").css('display', 'none');
        }
    <?php } ?>
</script>

<?php include('footer.php');  ?>