<?php
include('../include/config.php');
$_POST = sanatize($_POST);
extract($_POST);
$market_id	= $market_id;
$marketid	= $market_id;
$session_id = $selection_id;
$sessionId  = $session_id;
$selectionid  = sha1($session_id . $market_id);
$user_type = $_SESSION['user_type'];
if ($_SESSION['user_type'] == 'superagent') {
	$user_type = 'super_agent';
}

if (isset($_POST['session_position']) and $_POST['session_position'] == true) {
	$selectionid = $session_id;
}

$query = "SELECT * FROM client_session_bat_tbl WHERE market_id = '$marketid'  AND selection_id = '$selectionid' AND " . $user_type . "_id=" . $_SESSION['user_id'] . "  ORDER BY bet_run ASC";
$prev_session_res = mysqli_query($con, $query);
$prev_session_bets = mysqli_fetch_all($prev_session_res, MYSQLI_ASSOC);

$runs = array_map(function ($el) {
	return $el['bet_run'];
}, $prev_session_bets);
$runs = array_unique($runs);

$uniqruns = [];
foreach ($runs as $run) {
	array_push($uniqruns, $run - 1, $run, $run + 1);
}

$finalarr = array_unique($uniqruns);
$array_insert = array();


$query = "SELECT * FROM shares WHERE market_id = '$marketid'";
$share_res = mysqli_query($con, $query);
$share_data = mysqli_fetch_all($share_res, MYSQLI_ASSOC);


$clientsShare = [];
foreach ($share_data as $share) {
	$clientsShare[$share['client_id']] = $share;
}

foreach ($finalarr as $fnr) {
	foreach ($prev_session_bets as $bet) {
		$share_data = $clientsShare[$bet['client_id']];
		if ($_SESSION['user_type'] == 'superagent') {
			$user_type = 'sa';
		}
		if ($user_type == 'agent') {
			$user_share = $share_data[$user_type . '_Share'];
		} else {
			$user_share = $share_data[$user_type . '_share'];
		}

		$user_commission_type = $share_data[$user_type . '_commission_type'];
		$user_match_commission = $share_data[$user_type . '_match_commission'];
		$user_session_commission = $share_data[$user_type . '_session_commission'];


		if ($fnr >= $bet['bet_run'] && $bet['type'] == "Y") {
			$commission_amount = floor($bet['amount']) * floatval($bet['bhav']);
			$amount_for_commmission = floor($bet['amount']);
			$user_position = floor($bet['amount']) * floatval($bet['bhav']);
			if ($user_commission_type == 'BB') {
				$user_session_commission1 = ($user_session_commission / 100);
				$user_overall_amount = ($commission_amount + (abs($amount_for_commmission) * $user_session_commission1));
				$user_position = ($user_share / 100) * $user_overall_amount;
			}
			if ($user_commission_type == 'OM' && $commission_amount < 0) {
				$user_session_commission = ($user_session_commission / 100);
				$user_overall_amount = ($commission_amount + (abs($amount_for_commmission) * $user_session_commission));
				$user_position = ($user_share / 100) * $user_overall_amount;
			}
			if ($user_commission_type == 'OM' && $commission_amount > 0) {
				$user_session_commission = ($user_session_commission / 100);
				$user_overall_amount = ($commission_amount);
				$user_position = ($user_share / 100) * $user_overall_amount;
			}
			if ($user_commission_type == 'No Comm') {
				$user_position = $commission_amount * ($user_share / 100);
			}



			$tmp = array(
				'run' 		=>  $fnr,
				'user_position'	=>	round($user_position, 2),

			);
		}


		if ($fnr >= $bet['bet_run']  && $bet['type'] == "N") {
			$client_id = $bet['client_id'];

			$commission_amount = -floatval($bet['amount']) * floatval($bet['bhav']);
			$amount_for_commmission = -floatval($bet['amount']);
			$user_position = -floatval($bet['amount']) * floatval($bet['bhav']);

			if ($user_commission_type == 'BB') {
				$user_session_commission1 = ($user_session_commission / 100);
				$user_overall_amount = ($commission_amount + (abs($amount_for_commmission) * $user_session_commission1));
				$user_position = ($user_share / 100) * $user_overall_amount;
			}
			if ($user_commission_type == 'OM' && $commission_amount < 0) {
				$user_session_commission = ($user_session_commission / 100);
				$user_overall_amount = ($commission_amount + (abs($amount_for_commmission) * $user_session_commission));
				$user_position = ($user_share / 100) * $user_overall_amount;
			}
			if ($user_commission_type == 'OM' && $commission_amount > 0) {
				$user_session_commission = ($user_session_commission / 100);
				$user_overall_amount = ($commission_amount);
				$user_position = ($user_share / 100) * $user_overall_amount;
			}
			if ($user_commission_type == 'No Comm') {
				$user_position = $commission_amount * ($user_share / 100);
			}

			$tmp = array(
				'run' 		=>  $fnr,
				'user_position'	=>	round($user_position, 2),

			);
		}

		if ($fnr < $bet['bet_run']  && $bet['type'] == "Y") {

			$commission_amount = -floatval($bet['amount']);
			$amount_for_commmission = -floatval($bet['amount']);
			$user_position = -floatval($bet['amount']);
			if ($user_commission_type == 'BB') {
				$user_session_commission1 = ($user_session_commission / 100);
				$user_overall_amount = ($commission_amount + (abs($amount_for_commmission) * $user_session_commission1));
				$user_position = ($user_share / 100) * $user_overall_amount;
			}
			if ($user_commission_type == 'OM' && $commission_amount < 0) {
				$user_session_commission = ($user_session_commission / 100);
				$user_overall_amount = ($commission_amount + (abs($amount_for_commmission) * $user_session_commission));
				$user_position = ($user_share / 100) * $user_overall_amount;
			}
			if ($user_commission_type == 'OM' && $commission_amount > 0) {
				$user_session_commission = ($user_session_commission / 100);
				$user_overall_amount = ($commission_amount);
				$user_position = ($user_share / 100) * $user_overall_amount;
			}
			if ($user_commission_type == 'No Comm') {
				$user_position = $commission_amount * ($user_share / 100);
			}

			$tmp = array(
				'run' 		=>  $fnr,
				'user_position'	=>	round($user_position, 2),

			);
		}

		if ($fnr  < $bet['bet_run'] && $bet['type'] == "N") {
			$client_id = $bet['client_id'];

			$commission_amount = floor($bet['amount']);
			$amount_for_commmission = floor($bet['amount']);
			$user_position = floor($bet['amount']);
			if ($user_commission_type == 'BB') {
				$user_session_commission1 = ($user_session_commission / 100);
				$user_overall_amount = ($commission_amount + (abs($amount_for_commmission) * $user_session_commission1));
				$user_position = ($user_share / 100) * $user_overall_amount;
			}
			if ($user_commission_type == 'OM' && $commission_amount < 0) {
				$user_session_commission = ($user_session_commission / 100);
				$user_overall_amount = ($commission_amount + (abs($amount_for_commmission) * $user_session_commission));
				$user_position = ($user_share / 100) * $user_overall_amount;
			}
			if ($user_commission_type == 'OM' && $commission_amount > 0) {
				$user_session_commission = ($user_session_commission / 100);
				$user_overall_amount = ($commission_amount);
				$user_position = ($user_share / 100) * $user_overall_amount;
			}
			if ($user_commission_type == 'No Comm') {
				$user_position = $commission_amount * ($user_share / 100);
			}


			$tmp = array(
				'run' 		=>  $fnr,
				'user_position'	=>	round($user_position, 2),

			);
		}
		$tmp['market_id'] 	 = $marketid;
		$tmp['selection_id'] = $selectionid;
		array_push($array_insert, $tmp);
	}
}


//_dx($array_insert);

$rundata = array();
foreach ($array_insert as $item) {
	$key = $item['run'];
	if (!array_key_exists($key, $rundata)) {
		$rundata[$key] = array(
			'run' => $item['run'],
			'pos' => ($item['user_position']),

		);
	} else {
		$rundata[$key]['pos'] = ($rundata[$key]['pos'] + $item['user_position']);
	}
}


$send_rundata = array();
asort($rundata);

foreach ($rundata as $key => $value) {

	if ($value['pos'] < 0) {
		$value['pos'] = round(abs($value['pos']), 2);
	} else {
		$value['pos'] = round(-1 * $value['pos'], 2);
	}

	$push_aaray = array(

		'run' => $value['run'],
		'pos' => $value['pos']
	);
	array_push($send_rundata, $push_aaray);
}

$data = json_encode($send_rundata);
echo $data;
