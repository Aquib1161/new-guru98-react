<?php
include('../include/config.php');
$_POST=sanatize($_POST);
$market_id=$_POST['market_id'];

if ($market_id == "") {
    $send_array=array(
     'msg'=>"Something went wrong"
    );

    $status='error';
    $data_to_send=array(
    'data'=>$send_array,
    'status'=>$status
);
    $data=json_encode($data_to_send);
    echo $data;
    exit();
}

$match_data=get_data('upcoming_match',"market_id='".$market_id."'",'s');
$match_name = $match_data['match_name'];

$team_data=get_data('match_team_tbl',"market_id='".$market_id."'");
$count=count($team_data);

$team1=$team1_selection_id=$team_data[0]['selection_id'];
$team1_name=$team_data[0]['runner_name'];

$team2= $team2_selection_id=$team_data[1]['selection_id'];
$team2_name=$team_data[1]['runner_name'];
if($count==3)
{
    $team3_selection_id=$team_data[2]['selection_id'];
    $team3_name=$team_data[2]['runner_name'];
}
$won_team_name=$match_data['won_team_name'];
$winner_team_id =$won_team_selection_id=$match_data['won_team_selection_id'];

if($won_team_name=='' || $won_team_selection_id=='')
{
   $send_array=array(
     'msg'=>"Please update match decision first"
    );

    $status='error';
    $data_to_send=array(
    'data'=>$send_array,
    'status'=>$status
);
    $data=json_encode($data_to_send);
    echo $data;
    exit();
}


$query="DELETE FROM user_ledger WHERE market_id='$market_id'";
mysqli_query($con,$query);

$query="DELETE FROM admin_ledger WHERE market_id='$market_id'";
mysqli_query($con,$query);

$query="DELETE FROM sa_ledger WHERE market_id='$market_id'";
mysqli_query($con,$query);

$query="DELETE FROM master_ledger WHERE market_id='$market_id'";
mysqli_query($con,$query);

$query="DELETE FROM ledger WHERE market_id='$market_id'";
mysqli_query($con,$query);

$query="DELETE FROM agent_ledger WHERE market_id='$market_id'";
mysqli_query($con,$query);



$query = "SELECT client_id FROM client_played_match WHERE market_id='$market_id'";
$res234 = mysqli_query($con, $query);
while ($client = mysqli_fetch_assoc($res234))
{
    $client_id = $client['client_id'];
    $query = "SELECT SUM(amount)  total_credit FROM transaction_log WHERE client_id = '$client_id' AND  transaction_type = 'C' AND match_id='$market_id'";
    $res = mysqli_query($con, $query);
    $credited = mysqli_fetch_assoc($res) ['total_credit'];

    $query = "SELECT SUM(amount) total_debit FROM transaction_log WHERE client_id = '$client_id' AND  transaction_type = 'D' AND match_id='$market_id'";
    $res = mysqli_query($con, $query);
    $debited = mysqli_fetch_assoc($res) ['total_debit'];
    $total_coins = $credited - $debited;

    $type = $total_coins > 0 ? 'C' : 'D';
    $remarks = $total_coins < 0 ? 'Agent Plus' : 'Agent Minus';
    date_default_timezone_set('Asia/Kolkata');
    $date = date('Y-m-d');

    if ($type == 'D')
    {
        $total_coins = -1 * $total_coins;
    }
   
   date_default_timezone_set('Asia/Kolkata');
   $date = date("Y-m-d H:i:s");
   
   $query = "INSERT INTO ledger (client_id,payment_type,remark,amount,minus_plus,market_id,won_team_name,match_name,s_date) VALUES ('$client_id','$type','$match_name','$total_coins','$remarks','$market_id','$won_team_name','$match_name','$date')";  
   $res = mysqli_query($con, $query);

    

$auto_query="SELECT * FROM autolimit_tbl where client_id=$client_id";
$autolimit_result=mysqli_query($con,$auto_query);
$auto_data=mysqli_fetch_assoc($autolimit_result);
$auto_limit=$auto_data['autolimit_status'];
if($auto_limit=='NO')
{
$max_auto_limit=$auto_data['max_autolimit'];    
$query = "SELECT SUM(amount)  total_credit FROM transaction_log WHERE client_id = '$client_id' AND  transaction_type = 'C'";
$res = mysqli_query($con, $query);
$credited = mysqli_fetch_assoc($res)['total_credit'];
$query = "SELECT SUM(amount) total_debit FROM transaction_log WHERE client_id = '$client_id' AND  transaction_type = 'D'";
$res = mysqli_query($con, $query);
$debited = mysqli_fetch_assoc($res)['total_debit'];
$total_coins = round($credited - $debited);

if($total_coins>$max_auto_limit)
{
  $amount=$total_coins-$max_auto_limit;
  $limit="INSERT INTO transaction_log (amount , user_type ,  transaction_type  , client_id , sa_id , master_id , agent_id , for_bet,overall_type,auto_market_id,autolimit_debit) VALUES ('$amount','CLIENT','D','$client_id','$sa_id','$master_id','$agent_id' ,'0','agent','$market_id','YES')";
mysqli_query($con,$limit);
}
}

}

$insert_user_array=array(
	'user_type'=>'',
	'user_id'=>'',
	'user_code'=>'',
	'creater_id'=>$_SESSION['user_id'],
	'create_date'=>_date_time(),
	'ledger_status'=>'1',
	'amount'=>'',
	'transaction_type'=>'',
	'market_id'=>'',
	'event_id'=>'',
	'match_name'=>'',
	'remark'=>'',
	'won_team_selection_id'=>'',
	'note'=>''
);


$query = "SELECT agent_id FROM client_played_match WHERE market_id='$market_id'group by agent_id";
$res234 = mysqli_query($con, $query);
while ($agent = mysqli_fetch_assoc($res234))
{
    $agent_id = $agent['agent_id'];
    $query="SELECT id FROM client where A_id='$agent_id'";
    $client_ag1=mysqli_query($con,$query);
    $total_net_given_Amount=0;

    while($client=mysqli_fetch_assoc($client_ag1)){
      
        
        $client_id=$client['id'];

    $query = "SELECT SUM(amount)  total_credit FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'MC' AND match_id='$market_id'";
    $res = mysqli_query($con, $query);
    $credited = mysqli_fetch_assoc($res) ['total_credit'];

    $query = "SELECT SUM(amount) total_debit FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'MD' AND match_id='$market_id'";
    $res = mysqli_query($con, $query);
    $debited = mysqli_fetch_assoc($res) ['total_debit'];
    $total_client_match_coins=$credited - $debited;

//_d($total_client_match_coins);
    $query = "SELECT SUM(amount)  total_credit FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'SC' AND match_id='$market_id'";
    $res = mysqli_query($con, $query);
    $credited = mysqli_fetch_assoc($res) ['total_credit'];

    $query = "SELECT SUM(amount) total_debit FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'SD' AND match_id='$market_id'";
    $res = mysqli_query($con, $query);
    $debited = mysqli_fetch_assoc($res) ['total_debit'];
    $total_client_session_coins=$credited - $debited;
//_d($total_client_session_coins);
    $total_client_coins=$total_client_session_coins+$total_client_match_coins;
//_d($total_client_coins);

    $query = "SELECT SUM(agent_amount)  total_credit FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'MCC' AND match_id='$market_id'";
    $res = mysqli_query($con, $query);
    $match_comm_credited = mysqli_fetch_assoc($res) ['total_credit'];
//_d($match_comm_credited );
     $query = "SELECT SUM(agent_amount)  total_credit FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'SCC' AND match_id='$market_id'";
    $res = mysqli_query($con, $query);
    $session_comm_credited = mysqli_fetch_assoc($res) ['total_credit'];
//_d($session_comm_credited );
    $total_commi_credited=$match_comm_credited+$session_comm_credited;
//_d($total_commi_credited);
//_d($total_commi_credited);
    $total_net_amount=$total_client_coins+$total_commi_credited;
//_d($total_net_amount);
    $query = "SELECT * FROM shares WHERE market_id='$market_id' AND client_id='$client_id'";
    $res = mysqli_query($con, $query);
    $share = mysqli_fetch_assoc($res);
    $agent_share = $share['agent_Share'];

    $total_agent_net_amount=($total_net_amount*( $agent_share/100));
    $total_amount= $total_net_amount-$total_agent_net_amount;
$total_net_given_Amount+=$total_amount;
}

//_dx($total_net_given_Amount);

   
    $type = $total_net_given_Amount < 0 ? 'C' : 'D';
    $remarks = $total_net_given_Amount < 0 ? 'Agent Plus' : 'Agent Minus';
    date_default_timezone_set('Asia/Kolkata');
    $date = date('Y-m-d H:i:s');
    if ($type == 'C')
    {
        $total_net_given_Amount=-1*$total_net_given_Amount;
        $total_net_given_Amount=round($total_net_given_Amount,2);
      
        
    }
    if ($type == 'D')
    {
        $total_net_given_Amount=$total_net_given_Amount;
        $total_net_given_Amount=round($total_net_given_Amount,2);
        
    }

    $insert_user_array=array(
	'user_type'=>'agent',
	'user_id'=>$agent_id,
	'user_code'=>'',
	'creater_id'=>$_SESSION['user_id'],
	'create_date'=>_date_time(),
	'ledger_date'=>_date(),
	'ledger_status'=>'1',
	'amount'=>$total_net_given_Amount,
	'transaction_type'=>$type,
	'market_id'=>$market_id,
	'event_id'=>'',
	'match_name'=>$match_name,
	'remark'=>$remarks,
	'won_team_selection_id'=>'',
	'note'=>''
);
    $insert=insert_array('user_ledger',$insert_user_array);

    $query = "INSERT INTO agent_ledger (agent_id,payment_type,remark,minus_plus,market_id,agent_amount,s_date,post_date) VALUES ('$agent_id','$type','$match_name','$remarks','$market_id','$total_net_given_Amount','$date','$date')";

    $res = mysqli_query($con, $query);
}


$query = "SELECT master_id FROM client_played_match WHERE market_id='$market_id' group by master_id";
$res2345 = mysqli_query($con, $query);

while ($master = mysqli_fetch_assoc($res2345))
{
    $master_id = $master['master_id'];

    $query="SELECT id FROM client where master_id='$master_id'";
    $client_ag1=mysqli_query($con,$query);
    $total_master_payable_amt=0;
    while($client=mysqli_fetch_assoc($client_ag1)){

        $client_id=$client['id'];

    $query = "SELECT SUM(amount)  total_credit FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'MC' AND match_id='$market_id'";
    $res = mysqli_query($con, $query);
    $credited = mysqli_fetch_assoc($res) ['total_credit'];

    $query = "SELECT SUM(amount) total_debit FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'MD' AND match_id='$market_id'";
    $res = mysqli_query($con, $query);
    $debited = mysqli_fetch_assoc($res) ['total_debit'];
    $total_client_match_coins=$credited - $debited;

    $query = "SELECT SUM(amount)  total_credit FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'SC' AND match_id='$market_id'";
    $res = mysqli_query($con, $query);
    $credited = mysqli_fetch_assoc($res) ['total_credit'];

    $query = "SELECT SUM(amount) total_debit FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'SD' AND match_id='$market_id'";
    $res = mysqli_query($con, $query);
    $debited = mysqli_fetch_assoc($res) ['total_debit'];
    $total_client_session_coins=$credited - $debited;

$total_client_coins=$total_client_session_coins+$total_client_match_coins;

     $query = "SELECT SUM(master_amount)  total_credit FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'MCC' AND match_id='$market_id'";
    $res = mysqli_query($con, $query);
    $match_comm_credited = mysqli_fetch_assoc($res) ['total_credit'];

     $query = "SELECT SUM(master_amount)  total_credit FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'SCC' AND match_id='$market_id'";
    $res = mysqli_query($con, $query);
    $session_comm_credited = mysqli_fetch_assoc($res) ['total_credit'];

    $total_commi_credited=$match_comm_credited+$session_comm_credited;

    $total_net_amount=$total_client_coins+$total_commi_credited;


    $query = "SELECT * FROM shares WHERE market_id='$market_id' AND client_id='$client_id'";
    $res = mysqli_query($con, $query);
    $share = mysqli_fetch_assoc($res);
    $agent_share=$share['agent_Share'];
    $sa_share=$share['sa_share'];
    $master_share = $share['master_share']+$sa_share+$agent_share;
   // _d($master_share);

    $total_agent_net_amount=($total_net_amount*(($master_share/100)));
    //_d($total_agent_net_amount);
    $total_coins= $total_net_amount-$total_agent_net_amount;

$total_master_payable_amt+=$total_coins;

}
//_dx($total_master_payable_amt);

    $type = $total_master_payable_amt < 0 ? 'C' : 'D';
    $remarks = $total_master_payable_amt < 0 ? 'Agent Plus' : 'Agent Minus';
    date_default_timezone_set('Asia/Kolkata');
    $date = date('Y-m-d H:i:s');
     if ($type == 'C')
    {
        $total_admin_coins=-1*$total_master_payable_amt;
       $total_admin_coins=round($total_admin_coins,2);
    }
    if ($type == 'D')
    {
        $total_admin_coins=$total_master_payable_amt;
        $total_admin_coins=round($total_admin_coins,2);
    }

    $insert_user_array=array(
	'user_type'=>'master',
	'user_id'=>$master_id,
	'user_code'=>'',
	'creater_id'=>$_SESSION['user_id'],
	'create_date'=>_date_time(),
	'ledger_date'=>_date(),
	'ledger_status'=>'1',
	'amount'=>$total_admin_coins,
	'transaction_type'=>$type,
	'market_id'=>$market_id,
	'event_id'=>'',
	'match_name'=>$match_name,
	'remark'=>$remarks,
	'won_team_selection_id'=>'',
	'note'=>''
);
    $insert=insert_array('user_ledger',$insert_user_array);
    $query = "INSERT INTO master_ledger (master_id,payment_type,remark,minus_plus,market_id,master_amount,s_date,post_date) VALUES ('$master_id','$type','$match_name','$remarks','$market_id','$total_admin_coins','$date','$date')";

    $res = mysqli_query($con, $query);
}



$query = "SELECT admin_id FROM client_played_match WHERE market_id='$market_id' group by admin_id";
$res23456 = mysqli_query($con, $query);

while ($admin = mysqli_fetch_assoc($res23456))
{
    $admin_id = $admin['admin_id'];

    $query="SELECT id FROM client where admin_id='$admin_id'";
    $client_ag1=mysqli_query($con,$query);
    $total_admin_payable_amt=0;
    while($client=mysqli_fetch_assoc($client_ag1)){

        $client_id=$client['id'];

    $query = "SELECT SUM(amount)  total_credit FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'MC' AND match_id='$market_id'";
    $res = mysqli_query($con, $query);
    $credited = mysqli_fetch_assoc($res) ['total_credit'];

    $query = "SELECT SUM(amount) total_debit FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'MD' AND match_id='$market_id'";
    $res = mysqli_query($con, $query);
    $debited = mysqli_fetch_assoc($res) ['total_debit'];
    $total_client_match_coins=$credited - $debited;

    $query = "SELECT SUM(amount)  total_credit FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'SC' AND match_id='$market_id'";
    $res = mysqli_query($con, $query);
    $credited = mysqli_fetch_assoc($res) ['total_credit'];

    $query = "SELECT SUM(amount) total_debit FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'SD' AND match_id='$market_id'";
    $res = mysqli_query($con, $query);
    $debited = mysqli_fetch_assoc($res) ['total_debit'];
    $total_client_session_coins=$credited - $debited;

$total_client_coins=$total_client_session_coins+$total_client_match_coins;

     $query = "SELECT SUM(admin_amount)  total_credit FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'MCC' AND match_id='$market_id'";
    $res = mysqli_query($con, $query);
    $match_comm_credited = mysqli_fetch_assoc($res) ['total_credit'];

     $query = "SELECT SUM(admin_amount)  total_credit FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'SCC' AND match_id='$market_id'";
    $res = mysqli_query($con, $query);
    $session_comm_credited = mysqli_fetch_assoc($res) ['total_credit'];

    $total_commi_credited=$match_comm_credited+$session_comm_credited;

    $total_net_amount=$total_client_coins+$total_commi_credited;


    $query = "SELECT * FROM shares WHERE market_id='$market_id' AND client_id='$client_id'";
    $res = mysqli_query($con, $query);
    $share = mysqli_fetch_assoc($res);
    $agent_share=$share['agent_Share'];
    $sa_share=$share['sa_share'];
    $master_share=$share['master_share'];
    $admin_share = $share['admin_share']+$sa_share+$agent_share+$master_share;
 

    $total_agent_net_amount=($total_net_amount*(($admin_share/100)));
    //_d($total_agent_net_amount);
    $total_coins= $total_net_amount-$total_agent_net_amount;

$total_admin_payable_amt+=$total_coins;

}
//_dx($total_admin_payable_amt);

    $type = $total_admin_payable_amt < 0 ? 'C' : 'D';
    $remarks = $total_admin_payable_amt < 0 ? 'Agent Plus' : 'Agent Minus';
    date_default_timezone_set('Asia/Kolkata');
    $date = date('Y-m-d H:i:s');
     if ($type == 'C')
    {
        $total_admin_coins=-1*$total_admin_payable_amt;
       $total_admin_coins=round($total_admin_coins,2);
    }
    if ($type == 'D')
    {
        $total_admin_coins=$total_admin_payable_amt;
        $total_admin_coins=round($total_admin_coins,2);
    }

    $insert_user_array=array(
	'user_type'=>'admin',
	'user_id'=>$admin_id,
	'user_code'=>'',
	'creater_id'=>$_SESSION['user_id'],
	'create_date'=>_date_time(),
	'ledger_date'=>_date(),
	'ledger_status'=>'1',
	'amount'=>$total_admin_coins,
	'transaction_type'=>$type,
	'market_id'=>$market_id,
	'event_id'=>'',
	'match_name'=>$match_name,
	'remark'=>$remarks,
	'won_team_selection_id'=>'',
	'note'=>''
);
    $insert=insert_array('user_ledger',$insert_user_array);
    $query = "INSERT INTO admin_ledger (admin_id,payment_type,remark,minus_plus,market_id,admin_amount,s_date,post_date) VALUES ('$admin_id','$type','$match_name','$remarks','$market_id','$total_admin_coins','$date','$date')";

    $res = mysqli_query($con, $query);
}




$query = "SELECT sa_id FROM client_played_match WHERE market_id='$market_id' group by sa_id";
$res234598 = mysqli_query($con, $query);
while ($sa = mysqli_fetch_assoc($res234598))
{
    $sa_id = $sa['sa_id'];

    $query="SELECT id FROM client where sa_id='$sa_id'";
    $client_ag1=mysqli_query($con,$query);
    $total_sa_payable_amt=0;
    while($client=mysqli_fetch_assoc($client_ag1)){

        $client_id=$client['id'];

    $query = "SELECT SUM(amount)  total_credit FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'MC' AND match_id='$market_id'";
    $res = mysqli_query($con, $query);
    $credited = mysqli_fetch_assoc($res) ['total_credit'];

    $query = "SELECT SUM(amount) total_debit FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'MD' AND match_id='$market_id'";
    $res = mysqli_query($con, $query);
    $debited = mysqli_fetch_assoc($res) ['total_debit'];
    $total_client_match_coins=$credited - $debited;

//_d($total_client_match_coins);
    $query = "SELECT SUM(amount)  total_credit FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'SC' AND match_id='$market_id'";
    $res = mysqli_query($con, $query);
    $credited = mysqli_fetch_assoc($res) ['total_credit'];

    $query = "SELECT SUM(amount) total_debit FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'SD' AND match_id='$market_id'";
    $res = mysqli_query($con, $query);
    $debited = mysqli_fetch_assoc($res) ['total_debit'];
    $total_client_session_coins=$credited - $debited;
//_d($total_client_session_coins);
$total_client_coins=$total_client_session_coins+$total_client_match_coins;
//_d($total_client_coins);

     $query = "SELECT SUM(sa_amount)  total_credit FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'MCC' AND match_id='$market_id'";
    $res = mysqli_query($con, $query);
    $match_comm_credited = mysqli_fetch_assoc($res) ['total_credit'];
//_d($match_comm_credited );
     $query = "SELECT SUM(sa_amount)  total_credit FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'SCC' AND match_id='$market_id'";
    $res = mysqli_query($con, $query);
    $session_comm_credited = mysqli_fetch_assoc($res) ['total_credit'];
//_d($session_comm_credited );
    $total_commi_credited=$match_comm_credited+$session_comm_credited;
//_d($total_commi_credited);
//_d($total_commi_credited);
    $total_net_amount=$total_client_coins+$total_commi_credited;
//_d($total_net_amount);
    $query = "SELECT * FROM shares WHERE market_id='$market_id' AND client_id='$client_id'";
    $res = mysqli_query($con, $query);
    $share = mysqli_fetch_assoc($res);
    $agent_share = $share['agent_Share'];
    $sa_share=$share['sa_share']+$agent_share;
   //_d($sa_share);

    $total_agent_net_amount=($total_net_amount*(($sa_share/100)));
   // _d($total_agent_net_amount);
    $total_amount= $total_net_amount-$total_agent_net_amount;
    //_d($total_amount);
    $total_sa_payable_amt+=$total_amount;

}
//_d($total_sa_payable_amt);

    $type = $total_sa_payable_amt < 0 ? 'C' : 'D';
    $remarks = $total_sa_payable_amt < 0 ? 'Agent Plus' : 'Agent Minus';
    date_default_timezone_set('Asia/Kolkata');
    $date = date('Y-m-d H:i:s');
    if ($type == 'C')
    {
        $total_sa_payable_amt=-1*$total_sa_payable_amt;
      $total_sa_payable_amt=round($total_sa_payable_amt,2);
        
    }
    if ($type == 'D')
    {
        $total_sa_payable_amt=$total_sa_payable_amt;
        $total_sa_payable_amt=round($total_sa_payable_amt,2);
              
    }

    $insert_user_array=array(
	'user_type'=>'superagent',
	'user_id'=>$sa_id,
	'user_code'=>'',
	'creater_id'=>$_SESSION['user_id'],
	'create_date'=>_date_time(),
	'ledger_date'=>_date(),
	'ledger_status'=>'1',
	'amount'=>$total_sa_payable_amt,
	'transaction_type'=>$type,
	'market_id'=>$market_id,
	'event_id'=>'',
	'match_name'=>$match_name,
	'remark'=>$remarks,
	'won_team_selection_id'=>'',
	'note'=>''
);
    $insert=insert_array('user_ledger',$insert_user_array);

    $query = "INSERT INTO sa_ledger (sa_id,payment_type,remark,minus_plus,market_id,sa_amount,s_date,post_date) VALUES ('$sa_id','$type','$match_name','$remarks','$market_id','$total_sa_payable_amt','$date','$date')";
    $res = mysqli_query($con, $query);
}




$total_superadmin_coins=0;
$query = "SELECT superadmin_id FROM client_played_match WHERE market_id='$market_id' group by superadmin_id";
$res234568989 = mysqli_query($con, $query);
$count_super=mysqli_num_rows($res234568989);
while ($superadmin = mysqli_fetch_assoc($res234568989))
{
	
    //_dx($superadmin);
    $superadmin_id =$superadmin['superadmin_id'];

    //$admin_id = $mid['master_id'];


    $query="SELECT id FROM client where superadmin_id='$superadmin_id'";
    $client_ag1=mysqli_query($con,$query);
    $total_superadmin_payable_amt=0;

    while($client=mysqli_fetch_assoc($client_ag1)){

        $client_id=$client['id'];

    $query = "SELECT SUM(amount)  total_credit FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'MC' AND match_id='$market_id'";
    $res = mysqli_query($con, $query);
    $credited = mysqli_fetch_assoc($res) ['total_credit'];

    $query = "SELECT SUM(amount) total_debit FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'MD' AND match_id='$market_id'";
    $res = mysqli_query($con, $query);
    $debited = mysqli_fetch_assoc($res) ['total_debit'];
    $total_client_match_coins=$credited - $debited;

    $query = "SELECT SUM(amount)  total_credit FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'SC' AND match_id='$market_id'";
    $res = mysqli_query($con, $query);
    $credited = mysqli_fetch_assoc($res) ['total_credit'];

    $query = "SELECT SUM(amount) total_debit FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'SD' AND match_id='$market_id'";
    $res = mysqli_query($con, $query);
    $debited = mysqli_fetch_assoc($res) ['total_debit'];
    $total_client_session_coins=$credited - $debited;

   $total_client_coins=$total_client_session_coins+$total_client_match_coins;


    $query = "SELECT SUM(superadmin_amount)  total_credit FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'MCC' AND match_id='$market_id'";
    $res = mysqli_query($con, $query);
    $match_comm_credited = mysqli_fetch_assoc($res)['total_credit'];

     $query = "SELECT SUM(superadmin_amount)  total_credit FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'SCC' AND match_id='$market_id'";
    $res = mysqli_query($con, $query);
    $session_comm_credited = mysqli_fetch_assoc($res) ['total_credit'];

    $total_commi_credited=$match_comm_credited+$session_comm_credited;
    $total_net_amount=$total_client_coins+$total_commi_credited;


    $query = "SELECT * FROM shares WHERE market_id='$market_id' AND client_id='$client_id'";
    $res = mysqli_query($con, $query);
    $share = mysqli_fetch_assoc($res);
    $agent_share=$share['agent_Share'];
    $sa_share=$share['sa_share'];
    $admin_share=$share['admin_share'];
    $master_share=$share['master_share'];
    $superadmin_share=$share['superadmin_share'];
    $superadmin_share = $superadmin_share+$admin_share+$master_share+$sa_share+$agent_share;
   

    $total_agent_net_amount=($total_net_amount*(($superadmin_share/100)));
    $total_coins= $total_net_amount-$total_agent_net_amount;

    $total_superadmin_payable_amt+=$total_coins;
//_d($total_admin_payable_amt);

}
//_d('dfg');
$total_superadmin_coins+=$total_admin_payable_amt;
}
    
    if($count_super!=0)
    {
    $type = $total_superadmin_coins < 0 ? 'C' : 'D';
    $remarks = $total_superadmin_coins < 0 ? 'Superadmin Plus' : 'Superadmin Minus';
    date_default_timezone_set('Asia/Kolkata');
    $date = date('Y-m-d H:i:s');
     if ($type == 'C')
    {
        $total_superadmin_coins=-1*$total_superadmin_coins;
       $total_superadmin_coins=round($total_superadmin_coins,2);
    }
    if ($type == 'D')
    {
        $total_superadmin_coins=$total_superadmin_coins;
        $total_superadmin_coins=round($total_superadmin_coins,2);
    }

    $insert_user_array=array(
	'user_type'=>'superadmin',
	'user_id'=>$superadmin_id,
	'user_code'=>'',
	'creater_id'=>$_SESSION['user_id'],
	'create_date'=>_date_time(),
	'ledger_date'=>_date(),
	'ledger_status'=>'1',
	'amount'=>$total_superadmin_coins,
	'transaction_type'=>$type,
	'market_id'=>$market_id,
	'event_id'=>'',
	'match_name'=>$match_name,
	'remark'=>$remarks,
	'won_team_selection_id'=>'',
	'note'=>''
);
//_dx($insert_user_array);
$insert=insert_array('user_ledger',$insert_user_array);

}


$query = "UPDATE transaction_log SET match_declare='1',is_declare='1'WHERE match_id='$market_id'";
$res = mysqli_query($con, $query);

$query = "UPDATE client_played_match SET desicion_status='1' WHERE market_id='$market_id'";
$res = mysqli_query($con, $query);

$query = "UPDATE upcoming_match SET ledger_status='1' , status='COMPLETED' WHERE market_id='$market_id'";
$res = mysqli_query($con, $query);

$send_array=array(
     'msg'=>"Ledger has been update Please Update Position"
    );
    $status='success';
   $data_to_send=array(
	'data'=>$send_array,
	'status'=>$status
);
$data=json_encode($data_to_send);
echo $data;
exit();
die;


?>