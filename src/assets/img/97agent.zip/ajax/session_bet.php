<?php
include('config.php');
$post_data=sanatize($_POST);
$get_data=sanatize($_GET);
extract($post_data);

if(!isset($user_type) OR !isset($user_id))
{
	$user_type=$_SESSION['user_type'];
	$user_id=$_SESSION['user_id'];
  $show_user_type=$_SESSION['user_type'];
}
if($_SESSION['user_type']=='superagent')
{
  $user_type='sa';
  $show_user_type='superagent';
}
$where="market_id='".$market_id."' AND ".$show_user_type."_id='".$user_id."'";
if($_SESSION['user_type']=='owner')
{

  $where="market_id='".$market_id."'";
}
if(isset($_POST['deleted_status']))
{
  $where=$where." AND deleted_status='".$_POST['deleted_status']."'";
}

if(!empty($client_id) AND empty($selection_id))
{
   $where=$where." AND client_id='".$client_id."'";
}
if(!empty($selection_id) and empty($client_id))
{
   
   if(isset($post_data['live_report']))
   {
    $where="$where"." AND selection_id='".sha1($selection_id.$market_id)."'";
   }
   else
   {
    $where="$where"." AND selection_id='".$selection_id."'";
   }
   //_dx($where);   
}
if( !empty($client_id) AND !empty($selection_id))
{
  $where="$where"." AND client_id='".$client_id."' AND selection_id='".$selection_id."'";
}
$where="$where"." order by client_session_bat_id desc";

 $specific="client_name,amount,bhav,type,bet_run,decision_run,time_inserted,runner_name,pass_amount,fail_amount,comm_perm,deleted_status,".$user_type."_share";



$session_data=get_data('client_session_bat_tbl',$where,'',$specific);

$send_array=array();
$no=1;
foreach ($session_data as $key => $value) 
{ 

   $win=false;
   // _dx($value);
   if($value['type']=='Y')
   {
    if($value['bet_run']<=$value['decision_run'])
    {
      $win=true;
    }
   }

   if($value['type']=='N')
   {
    if($value['bet_run']>$value['decision_run'])
    {
      $win=true;
    }
   }

   
  if($_SESSION['user_type']=='owner')
  {
   $value['my_share']=0;
  }
  else
  {
  $value['my_share']=$value[$user_type.'_share'];   
  }
 if(empty($value['decision_run'])){$desicion= '<span style="color:red">unsettle</span>';}else{$desicion= '<span style="color:green">settle</span>';};
                                  $value['decision']=$desicion; 
                                  $value['win']=$win; 
                                  $value['serial_no']=$no++;  
	array_push($send_array,$value);

}
 
//_dx($session_data);
$data_to_send=array(
	'data'=>$send_array,
	'status'=>'success'
);
$data=json_encode($data_to_send);
echo $data;
?>