<?php
include('config.php');
$post_data=sanatize($_POST);
$get_data=sanatize($_GET);
extract($post_data);
//_dx($post_data);
if(!isset($user_type) OR !isset($user_id))
{
	$user_type=$_SESSION['user_type'];
	$user_id=$_SESSION['user_id'];
}
if($_SESSION['user_type']=='superagent')
{
	
  $user_type='sa';
}
$where=" market_id='".$market_id."' AND ".$_SESSION['user_type']."_id= '".$user_id."' AND deleted_status='".$bet_type."' ";
if($_SESSION['user_type']=='owner')
{
 $where=" market_id='".$market_id."' AND deleted_status='".$bet_type."' ";
}
if(!empty($client_id))
{
   $where=$where." AND client_id='".$client_id."'";
}

$where=$where." order by client_match_bet_id desc";
$team_data=get_data('match_team_tbl','market_id='.$market_id,'','selection_id,runner_name');
$count=count($team_data);
$team1_selection_id=$team_data[0]['selection_id'];
$team1_name=$team_data[0]['runner_name'];
$team2_selection_id=$team_data[1]['selection_id'];
$team2_name=$team_data[1]['runner_name'];
if($count==3)
{
$team3_selection_id=$team_data[2]['selection_id'];
$team3_name=$team_data[2]['runner_name'];
}

$match_data=get_data('client_match_bet_tbl',$where,'',"client_name,bhav,team_name,profit,profit2,type,amount,time_inserted,ip,selection_id,".$user_type.'_share'."");
//_dx($match_data);
$send_array=array();
$no=1;
foreach ($match_data as $key => $value) 
{   
    $value['client']=$value['client_name'];
  

    if($value['type']=='L')
    {
      $value['type']='KHAI';
    } 
    else
    {
    $value['type']='LAGAI';
    }

	$match_bet_selection_id=$value['selection_id'];

  $position_array=[];
  $draw_selection_id=55;
  $value['draw_amount']=0;

                                  if($match_bet_selection_id==$team1_selection_id)
                                  {
                                    $value['favor_amount']=-1*$value['profit'];
                                    $value['unfavour_amount']=-1*$value['profit2'];
                                    $value['draw_amount']=-1*$value['profit2'];
                                  } 
                                  elseif($match_bet_selection_id==$team2_selection_id)
                                  {
                                    $value['favor_amount']=-1*$value['profit2'];
                                    $value['unfavour_amount']=-1*$value['profit'];
                                    $value['draw_amount']=-1*$value['profit2'];
                                    
                                  }
                                  elseif($match_bet_selection_id==$team3_selection_id)
                                  {
                                    $value['draw_amount']=-1*$value['profit'];
                                    $value['favor_amount']=-1*$value['profit2'];
                                    $value['unfavour_amount']=-1*$value['profit2'];
                                  }
                                 

                                  $position_array=[
                                      'team1_selection_id'=>$team1_selection_id,
                                      'team1_amount'=>$value['favor_amount'],
                                      'team2_selection_id'=>$team2_selection_id,
                                      'team2_amount'=>$value['unfavour_amount'],
                                      'team3_selection_id'=>$draw_selection_id,
                                      'team3_amount'=>$value['draw_amount'],
                                    ];


                                  
                                  if($_SESSION['user_type']=='owner')
                                  {
                                    $value['my_share']=0;
                                  }
                                  else
                                  {
                                    $value['my_share']=$value[$user_type.'_share'];
                                  }




                                   if(empty($value['decision_selection_id'])){$desicion= '<span style="color:red">unsettle</span>';}else{$desicion= '<span style="color:green">settle</span>';};
                                  $value['decision']=$desicion;
                                  $value['serial_no']=$no++;
                                  $value['position_array']=$position_array;

	array_push($send_array,$value);
}
 

$data_to_send=array(
	'data'=>$send_array,
	'status'=>'success'
);
$data=json_encode($data_to_send);
echo $data;
?>