<?php
include('../include/config.php');
extract($_POST);
$all_selection_id = $_POST['all_selection_id'];
$fav_selection_id = $all_selection_id['team1_selection_id'];
$non_fav_selection_id = $all_selection_id['team2_selection_id'];
$user_id = $userdata['user_id'];
$draw_selection_id=3;
  if(isset($all_selection_id['team3_selection_id']))
  {
    $draw_selection_id = $all_selection_id['team3_selection_id'];
  }
if ($_SESSION['user_type'] == 'superagent') {
	$usertype = 'sa';
} else {
	$usertype = $_SESSION['user_type'];
}

if ($client_id != '') {
	$query = "SELECT a.random_id, b.random_id, b.selection_id, SUM(b.profit) total_profit FROM match_bet_calculation b, client_match_bet_tbl a WHERE a.market_id = '" . $market_id . "' AND b." . $usertype . "_id='" . $user_id . "' AND a.client_id='" . $client_id . "' AND a.random_id = b.random_id and a.deleted_status = 0 group by selection_id";
} else {
	$query = "SELECT a.random_id, b.random_id, b.selection_id, SUM(b.profit) total_profit FROM match_bet_calculation b, client_match_bet_tbl a WHERE a.market_id = '" . $market_id . "' AND b." . $usertype . "_id='" . $user_id . "' AND a.random_id = b.random_id and a.deleted_status = 0 group by selection_id";
}

$data = mysqli_query($con, $query);


$fav_pos = 0;
$non_fav_pos = 0;
$draw_pos = 0;


while ($res = mysqli_fetch_assoc($data)) {


	if ($res['selection_id'] == $fav_selection_id) {
		$fav_pos = round($res['total_profit'], 2);
	} else if ($res['selection_id'] == '60443' or $res['selection_id'] ==  $draw_selection_id) {

		$draw_pos = round($res['total_profit'], 2);
		$draw_selection_id = $res['selection_id'];
	} else {
		$non_fav_pos = round($res['total_profit'], 2);
	}
}


if ($count == 2) {
	$team_data = array(
		'team1_selection_id' => $fav_selection_id,
		'team1_position' => ($fav_pos),
		'team2_selection_id' => $non_fav_selection_id,
		'team2_position' => ($non_fav_pos)

	);
}

if ($count == 3) {

	$team_data = array(
		'team1_selection_id' => $fav_selection_id,
		'team1_position' => ($fav_pos),
		'team2_selection_id' => $non_fav_selection_id,
		'team2_position' => ($non_fav_pos),
		'team3_selection_id' => $draw_selection_id,
		'team3_position' => ($draw_pos)
	);
}

//_dx($team_data);

$data = json_encode($team_data);
echo $data;
