<?php 
include('../include/config.php'); 
$_POST=sanatize($_POST);
$_GET=sanatize($_GET);
extract($_POST);

$client_data=get_data('client',"id='".$client_id."'",'s','share_array')['share_array'];
$user_data=json_decode($client_data,true);
// _dx($user_data);

// $send_data=[
//     'client'=>$user_data,

// ];

// foreach ($user_data as $key => $data)
// {    
//     _d($Key);
//     _d($data);
//    }



// _dx('ok');

if($user_type=='admin')
{
    unset($user_data['superadmin_share_array']);
}
elseif($user_type=='master')
{
    unset($user_data['superadmin_share_array']);
    unset($user_data['admin_share_array']);
}
elseif($user_type=='superagent')
{
    unset($user_data['superadmin_share_array']);
    unset($user_data['admin_share_array']);
    unset($user_data['master_share_array']);
}
elseif($user_type=='agent')
{
    unset($user_data['superadmin_share_array']);
    unset($user_data['admin_share_array']);
    unset($user_data['master_share_array']);
    unset($user_data['superagent_share_array']);
}
else
{
    unset($user_data['superadmin_share_array']);
}

unset($user_data['client_share_array']);

echo json_encode($user_data);

?>