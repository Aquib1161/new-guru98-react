<?php include('../include/config.php'); 
 $_POST=sanatize($_POST);
 $_GET=sanatize($_GET);

 $casino_id=$_POST['casino_id'];
 unset($_POST['casino_id']);

  if(isset($_POST['casino_status']) || $_POST['casino_status']==true)
{    unset($_POST['casino_status']);
    $update=update_array('casino_tbl',$_POST,"casino_id='".$casino_id."'");
}

if($update['error']==0)
{
$send_array=array('msg'=>'Status Updated');
$status='success';
$data_to_send=array(
    'data'=>$send_array,
    'status'=>$status
);
$data=json_encode($data_to_send);
echo $data;
}
else
{
$send_array=array('msg'=>'Something Went Wrong');
$status='error';
$data_to_send=array(
    'data'=>$send_array,
    'status'=>$status
);
$data=json_encode($data_to_send);
echo $data;
}
?>