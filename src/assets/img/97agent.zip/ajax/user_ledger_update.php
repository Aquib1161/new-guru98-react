<?php
include('config.php');
$post_data=sanatize($_POST);
$get_data=sanatize($_GET);
extract($post_data);
extract($get_data);
if($transaction_type=='D')
{
	$mark='Pay cash';
}
else
{
	$mark='Recieve cash';
}
$user_result=get_user_list('',$user_id);
$insert_array=array(
	'transaction_type'=>$transaction_type,
	'amount'=>$amount,
	'note'=>$note,
	'user_id'=>$user_id,
	'match_name'=>$mark.' by '.$collection_type,
	'create_date'=>_date_time(),
	'ledger_date'=>$date,
	'creater_id'=>$_SESSION['user_id'],
	'ledger_type'=>'cash',
	'user_type'=>$user_result['user_type']
);

$insert=insert_array('user_ledger',$insert_array);
if($insert['error']==0)
{
$status='success';	
}
else
{
	$staus='error';
}
$send_array=array('msg'=>'Ledger has been updated successfully');
$data_to_send=array(
	'data'=>$send_array,
	'status'=>$status
);
$data=json_encode($data_to_send);
echo $data;
?>