<?php
include('../include/config.php');
//$_POST=sanatize($_POST);
extract($_POST);
$all_selection_id = $_POST['all_selection_id'];
$fav_selection_id = $all_selection_id['team1_selection_id'];
$non_fav_selection_id = $all_selection_id['team2_selection_id'];
if ($_SESSION['user_type'] == 'superagent') {
	$usertype = 'sa';
} else {
	$usertype = $_SESSION['user_type'];
}


$query = "SELECT a.random_id, b.random_id, b.selection_id, SUM(b." . $user_type . "_amount) total_profit FROM match_bet_calculation b, client_match_bet_tbl a WHERE a.market_id = '" . $market_id . "' AND b." . $usertype . "_id='" . $user_id . "' AND a.random_id = b.random_id and a.deleted_status = 0 group by selection_id";
$res = mysqli_query($con, $query);
$rows = mysqli_fetch_all($res, MYSQLI_ASSOC);
$final_data=$rows;
if(empty($rows))
{    
	$final_data=[];
	foreach ($all_selection_id as $key => $selection_data) 
	{
		 $push_array=['selection_id'=>$selection_data,'total_profit'=>0.00];
		 if($selection_data['selection_id']!='')
		 {
		 	array_push($final_data,$push_array);
		 }
		 array_push($final_data,$push_array);
	}
}
else
{

	 $final_data=[];
	foreach ($rows as $key => $position_data) 
	{    
		 $push_array=['selection_id'=>$position_data['selection_id'],'total_profit'=>round(-1*$position_data['total_profit'],2)];
		 if($position_data['selection_id']!='')
		 {
		 	array_push($final_data,$push_array);
		 }
	}
}

$data = json_encode($final_data);
echo $data;
