<?php
include('config.php');
$post_data=sanatize($_POST);
$get_data=sanatize($_GET);
extract($post_data);
if(!isset($user_type) OR !isset($user_id))
{
   $user_type=$_SESSION['user_type'];
   $user_id=$_SESSION['user_id'];
}

if($market_id=='today')
{
   $where="".$_SESSION['user_type']."_id= '".$user_id."' AND deleted_status='0' AND casino_type='".$game_type."' AND  date='"._date()."'  ";
}
else
{

   $where="".$_SESSION['user_type']."_id= '".$user_id."' AND deleted_status='0' AND casino_type='".$game_type."' AND  game_id='".$market_id."'  ";
}

if($_SESSION['user_type']=='owner')
{
 $where="game_id='".$market_id."' AND deleted_status='".$bet_type."' ";
}
if(!empty($client_id))
{
   $where=$where." AND client_id='".$client_id."'";
}
$where=$where." order by casino_bet_id desc";

 //$specific="client_id,casino_type,client_detail_array,profit,loss,amount,decision,market_id,bhav,player_name,date_time,date,bet_for";
$specific='';
$total_bet=get_data('casino_bet_tbl',$where,'',$specific);
//_dx($total_bet);
$send_array=array();
$no=1;
$client_data=[];
foreach ($total_bet as $key => $value) 
{ 
 $share_array=get_share_array($value['client_detail_array']);
 $client_data=json_decode($value['client_detail_array'],true);
 $client_name=$client_data['ClientName'].'('.$client_data['username'].')';
 $value['client_name']=$client_name;
 $user_share_array=$share_array[$user_type.'_share_array'];
 $user_share=$user_share_array[$user_type.'_self_casino_share'];
 //_dx($share_array[$user_type.'_share_array']);
 $user_amount=0;
  if($value['decision']!='')
  {
     if($value['decision']==$value['key'])
     {
      $user_amount=$value['loss']*$user_share/100;
     }
     else
     {
      $user_amount=$value['profit']*$user_share/100;
     }
  }
  $value['user_amount']=$user_amount;

if($value['event_id']==2226)
{
   $value['decision']=trim($value['decision']);
   if($value['decision']=='High Card')
   {
      $value['decision']=2;
   }
   elseif($value['decision']=='Low Card')
   {
      $value['decision']=1;
   }
   elseif($value['decision']=='Tie')
   {
      $value['decision']=3;
   }
   else
   {
      $value['decision']=$value['decision'];
   }

}



  unset($value['client_detail_array']);
  unset($value['admin_id']);
  unset($value['agent_id']);
  unset($value['superagent_id']);
  unset($value['superadmin_id']);
  unset($value['master_id']);
  unset($value['random_id']);
  unset($value['casino_bet_id']);
  array_push($send_array,$value);
}
$data_to_send=array(
   'data'=>$send_array,
   'status'=>'success'
);
$data=json_encode($data_to_send);
echo $data;
?>