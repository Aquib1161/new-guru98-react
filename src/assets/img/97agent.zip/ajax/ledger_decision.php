<?php
include('../include/config.php');
$_POST=sanatize($_POST);
$market_id=$_POST['market_id'];

if ($market_id == "") {
    $send_array=array(
     'msg'=>"Something went wrong"
    );

    $status='error';
    $data_to_send=array(
    'data'=>$send_array,
    'status'=>$status
);
    $data=json_encode($data_to_send);
    echo $data;
    exit();
}

$match_data=get_data('upcoming_match',"market_id='".$market_id."'",'s');
$match_name = $match_data['match_name'];

$team_data=get_data('match_team_tbl',"market_id='".$market_id."'");
$count=count($team_data);

$team1=$team1_selection_id=$team_data[0]['selection_id'];
$team1_name=$team_data[0]['runner_name'];

$team2= $team2_selection_id=$team_data[1]['selection_id'];
$team2_name=$team_data[1]['runner_name'];
if($count==3)
{
    $team3_selection_id=$team_data[2]['selection_id'];
    $team3_name=$team_data[2]['runner_name'];
}
$won_team_name=$match_data['won_team_name'];
$winner_team_id =$won_team_selection_id=$match_data['won_team_selection_id'];

if($won_team_name=='' || $won_team_selection_id=='')
{
   $send_array=array(
     'msg'=>"Please update match decision first"
    );

    $status='error';
    $data_to_send=array(
    'data'=>$send_array,
    'status'=>$status
);
    $data=json_encode($data_to_send);
    echo $data;
    exit();
}


$query="DELETE FROM user_ledger WHERE market_id='$market_id'";
mysqli_query($con,$query);


$query="DELETE FROM ledger WHERE market_id='$market_id'";
mysqli_query($con,$query);


$query="DELETE FROM session_ran_positon WHERE market_id='$market_id'";
mysqli_query($con,$query);



$data=get_data('client_played_match',"market_id='".$market_id."'",'',"client_id");
//_dx($data);

$query = "SELECT client_id FROM client_played_match WHERE market_id='$market_id'";
$res234 = mysqli_query($con, $query);
while ($client = mysqli_fetch_assoc($res234))
{
    $client_id = $client['client_id'];
   /* $query = "SELECT SUM(amount)  total_credit FROM transaction_log WHERE client_id = '$c' AND  transaction_type = 'C' AND match_id='$market_id'";
    $res = mysqli_query($con, $query);
    $credited = mysqli_fetch_assoc($res) ['total_credit'];

    $query = "SELECT SUM(amount) total_debit FROM transaction_log WHERE client_id = '$client_id' AND  transaction_type = 'D' AND match_id='$market_id'";
    $res = mysqli_query($con, $query);
    $debited = mysqli_fetch_assoc($res) ['total_debit'];
    $total_coins = $credited - $debited;*/

     $client_data=get_data('md_client_position',"client_id='".$client_id."' AND market_id='".$market_id."'",'1',"client_match_coins,client_session_coins,client_session_commission,client_match_commission,client_mobile_charge");

     $total_coins=(-1*$client_data['client_match_coins'])+(-1*$client_data['client_session_coins'])+$client_data['client_session_commission']+$client_data['client_match_commission']+$client_data['client_mobile_charge'];

    $type = $total_coins > 0 ? 'C' : 'D';
    $remarks = $total_coins < 0 ? 'Agent Plus' : 'Agent Minus';
    date_default_timezone_set('Asia/Kolkata');
    $date = date('Y-m-d');

    if ($type == 'D')
    {
        $total_coins = -1 * $total_coins;
    }
   
   date_default_timezone_set('Asia/Kolkata');
   $date = date("Y-m-d H:i:s");


   $insert_ledger=array(
    'client_id'=>$client_id,
    'payment_type'=>$type,
    'remark'=>$match_name,
    'amount'=>$total_coins,
    'minus_plus'=>$remarks,
    'market_id'=>$market_id,
    'won_team_name'=>$won_team_name,
    'match_name'=>$match_name,
    's_date'=>_date_time(),
   );

   $insert=insert_array('ledger',$insert_ledger);
   
/*   $query = "INSERT INTO ledger (client_id,payment_type,remark,amount,minus_plus,market_id,won_team_name,match_name,s_date) VALUES ('$client_id','$type','$match_name','$total_coins','$remarks','$market_id','$won_team_name','$match_name','$date')";  

   $res = mysqli_query($con, $query);*/


/*$auto_query="SELECT * FROM autolimit_tbl where client_id=$client_id";
$autolimit_result=mysqli_query($con,$auto_query);
$auto_data=mysqli_fetch_assoc($autolimit_result);
$auto_limit=$auto_data['autolimit_status'];
if($auto_limit=='NO')
{
$max_auto_limit=$auto_data['max_autolimit'];    
$query = "SELECT SUM(amount)  total_credit FROM transaction_log WHERE client_id = '$client_id' AND  transaction_type = 'C'";
$res = mysqli_query($con, $query);
$credited = mysqli_fetch_assoc($res)['total_credit'];
$query = "SELECT SUM(amount) total_debit FROM transaction_log WHERE client_id = '$client_id' AND  transaction_type = 'D'";
$res = mysqli_query($con, $query);
$debited = mysqli_fetch_assoc($res)['total_debit'];
$total_coins = round($credited - $debited);

if($total_coins>$max_auto_limit)
{
  $amount=$total_coins-$max_auto_limit;
  $limit="INSERT INTO transaction_log (amount , user_type ,  transaction_type  , client_id , sa_id , master_id , agent_id , for_bet,overall_type,auto_market_id,autolimit_debit) VALUES ('$amount','CLIENT','D','$client_id','$sa_id','$master_id','$agent_id' ,'0','agent','$market_id','YES')";
mysqli_query($con,$limit);
}
}*/

}

$insert_user_array=array(
    'user_type'=>'',
    'user_id'=>'',
    'user_code'=>'',
    'creater_id'=>$_SESSION['user_id'],
    'create_date'=>_date_time(),
    'ledger_status'=>'1',
    'amount'=>'',
    'transaction_type'=>'',
    'market_id'=>'',
    'event_id'=>'',
    'match_name'=>'',
    'remark'=>'',
    'won_team_selection_id'=>'',
    'note'=>''
);

// generate agent ledger

$query = "SELECT agent_id FROM client_played_match WHERE market_id='$market_id'group by agent_id";
$res234 = mysqli_query($con, $query);
while ($agent = mysqli_fetch_assoc($res234))
{
    $agent_id = $agent['agent_id'];
    $agent_data=get_data('md_client_position',"agent_id='".$agent_id."' AND market_id='".$market_id."'",'1',"SUM(agent_share_amount) agent_amount,SUM(agent_total_amount) agent_total_amount");
    $total_agent_amount=$agent_data['agent_amount'];
    $type = $total_agent_amount > 0 ? 'C' : 'D';
    $remarks = $total_agent_amount > 0 ? 'Agent Plus' : 'Agent Minus';
    if ($type == 'C')
    {
        $total_agent_amount=$total_agent_amount;
        $total_agent_amount=round($total_agent_amount,2); 
    }
    if ($type == 'D')
    {
        $total_agent_amount=-1*$total_agent_amount;
        $total_agent_amount=round($total_agent_amount,2);
    }

     $insert_user_array=array(
    'user_type'=>'agent',
    'user_id'=>$agent_id,
    'user_code'=>'',
    'creater_id'=>$_SESSION['user_id'],
    'create_date'=>_date_time(),
    'ledger_date'=>_date(),
    'ledger_status'=>'1',
    'amount'=>abs($total_agent_amount),
    'transaction_type'=>$type,
    'market_id'=>$market_id,
    'event_id'=>'',
    'match_name'=>$match_name,
    'remark'=>$remarks,
    'won_team_selection_id'=>'',
    'note'=>''
);
    $insert=insert_array('user_ledger',$insert_user_array);
}


// generate superagent ledger
$total_sa_amount=0;
$query = "SELECT sa_id FROM client_played_match WHERE market_id='$market_id' group by sa_id";
$res234598 = mysqli_query($con, $query);
while ($sa = mysqli_fetch_assoc($res234598))
{
    $sa_id = $sa['sa_id'];
    $sa_data=get_data('md_client_position',"sa_id='".$sa_id." 'AND market_id='".$market_id."'",'1',"SUM(sa_share_amount) sa_amount,SUM(sa_total_amount) sa_total_amount");
    $total_sa_amount=$sa_data['sa_amount'];
    $type = $total_sa_amount > 0 ? 'C' : 'D';
    $remarks = $total_sa_amount > 0 ? 'Agent Plus' : 'Agent Minus';
    if ($type == 'C')
    {
        $total_sa_amount=$total_sa_amount;
      $total_sa_amount=round($total_sa_amount,2);
        
    }
    if ($type == 'D')
    {
        $total_sa_amount=-1*$total_sa_amount;
        $total_sa_amount=round($total_sa_amount,2);
              
    }
    $insert_user_array=array(
    'user_type'=>'superagent',
    'user_id'=>$sa_id,
    'user_code'=>'',
    'creater_id'=>$_SESSION['user_id'],
    'create_date'=>_date_time(),
    'ledger_date'=>_date(),
    'ledger_status'=>'1',
    'amount'=>abs($total_sa_amount),
    'transaction_type'=>$type,
    'market_id'=>$market_id,
    'event_id'=>'',
    'match_name'=>$match_name,
    'remark'=>$remarks,
    'won_team_selection_id'=>'',
    'note'=>''
);
    $insert=insert_array('user_ledger',$insert_user_array);
}

// generate master ledger


$query = "SELECT master_id FROM client_played_match WHERE market_id='$market_id' group by master_id";
$res2345 = mysqli_query($con, $query);

while ($master = mysqli_fetch_assoc($res2345))
{
    $master_id = $master['master_id'];

    $master_data=get_data('md_client_position',"master_id='".$master_id."' AND market_id='".$market_id."'",'1',"SUM(master_share_amount) master_amount,SUM(master_total_amount) master_total_amount");
    $total_master_amount=$master_data['master_amount'];
    $type = $total_master_amount > 0 ? 'C' : 'D';
    $remarks = $total_master_amount > 0 ? 'Agent Plus' : 'Agent Minus';
     if ($type == 'C')
    {
       $total_master_amount=$total_master_amount;
       $total_master_amount=round($total_master_amount,2);
    }
    if ($type == 'D')
    {
        $total_master_amount=-1*$total_master_amount;
        $total_master_amount=round($total_master_amount,2);
    }

    $insert_user_array=array(
    'user_type'=>'master',
    'user_id'=>$master_id,
    'user_code'=>'',
    'creater_id'=>$_SESSION['user_id'],
    'create_date'=>_date_time(),
    'ledger_date'=>_date(),
    'ledger_status'=>'1',
    'amount'=>abs($total_master_amount),
    'transaction_type'=>$type,
    'market_id'=>$market_id,
    'event_id'=>'',
    'match_name'=>$match_name,
    'remark'=>$remarks,
    'won_team_selection_id'=>'',
    'note'=>''
);
    $insert=insert_array('user_ledger',$insert_user_array);
}



// generate admin ledger
$total_admin_amount=0;
$query = "SELECT admin_id FROM client_played_match WHERE market_id='$market_id' group by admin_id";
$res23456 = mysqli_query($con, $query);
while ($admin = mysqli_fetch_assoc($res23456))
{
    $admin_id = $admin['admin_id'];
    $admin_data=get_data('md_client_position',"admin_id='".$admin_id."' AND market_id='".$market_id."'",'1',"SUM(admin_share_value) admin_amount,SUM(admin_total_amount) admin_total_amount");
    $total_admin_amount=$admin_data['admin_amount'];
    $type = $total_admin_amount > 0 ? 'C' : 'D';
    $remarks = $total_admin_amount > 0 ? 'Agent Plus' : 'Agent Minus';
     if ($type == 'C')
    {
        $total_admin_coins=$total_admin_amount;
       $total_admin_coins=round($total_admin_coins,2);
    }
    if ($type == 'D')
    {
        $total_admin_coins=-1*$total_admin_amount;
        $total_admin_coins=round($total_admin_coins,2);
    }
        $insert_user_array=array(
    'user_type'=>'admin',
    'user_id'=>$admin_id,
    'user_code'=>'',
    'creater_id'=>$_SESSION['user_id'],
    'create_date'=>_date_time(),
    'ledger_date'=>_date(),
    'ledger_status'=>'1',
    'amount'=>abs($total_admin_coins),
    'transaction_type'=>$type,
    'market_id'=>$market_id,
    'event_id'=>'',
    'match_name'=>$match_name,
    'remark'=>$remarks,
    'won_team_selection_id'=>'',
    'note'=>''
);
        //_d($insert_user_array);
    $insert=insert_array('user_ledger',$insert_user_array);
}


// generate superadmin ledger
$total_superadmin_amount=0;
$query = "SELECT superadmin_id FROM client_played_match WHERE market_id='$market_id' group by superadmin_id";
$res234568989 = mysqli_query($con, $query);
$count_super=mysqli_num_rows($res234568989);
while ($superadmin = mysqli_fetch_assoc($res234568989))
{
    $superadmin_id =$superadmin['superadmin_id'];
    $superadmin_data=get_data('md_client_position',"superadmin_id='".$superadmin_id."' AND market_id='".$market_id."'",'1',"SUM(superadmin_share_value) superadmin_amount,SUM(superadmin_total_amount) superadmin_total_amount");
    $total_superadmin_amount=$superadmin_data['superadmin_amount'];
    $type = $total_superadmin_amount > 0 ? 'C' : 'D';
    $remarks = $total_superadmin_amount > 0 ? 'Superadmin Plus' : 'Superadmin Minus';
     if ($type == 'C')
    {
        $total_superadmin_amount=$total_superadmin_amount;
       $total_superadmin_amount=round($total_superadmin_amount,2);
    }
    if ($type == 'D')
    {
        $total_superadmin_amount=-1*$total_superadmin_amount;
        $total_superadmin_amount=round($total_superadmin_amount,2);
    }

    $insert_user_array=array(
    'user_type'=>'superadmin',
    'user_id'=>$superadmin_id,
    'user_code'=>'',
    'creater_id'=>$_SESSION['user_id'],
    'create_date'=>_date_time(),
    'ledger_date'=>_date(),
    'ledger_status'=>'1',
    'amount'=>abs($total_superadmin_amount),
    'transaction_type'=>$type,
    'market_id'=>$market_id,
    'event_id'=>'',
    'match_name'=>$match_name,
    'remark'=>$remarks,
    'won_team_selection_id'=>'',
    'note'=>''
);
$insert=insert_array('user_ledger',$insert_user_array);
}
    
    

$query = "UPDATE transaction_log SET match_declare='1',is_declare='1'WHERE match_id='$market_id'";
$res = mysqli_query($con, $query);

$query = "UPDATE client_played_match SET desicion_status='1' WHERE market_id='$market_id'";
$res = mysqli_query($con, $query);

$query = "UPDATE upcoming_match SET ledger_status='1' , status='COMPLETED' WHERE market_id='$market_id'";
$res = mysqli_query($con, $query);

$send_array=array(
     'msg'=>"Ledger has been update Please Update Position"
    );
    $status='success';
   $data_to_send=array(
    'data'=>$send_array,
    'status'=>$status
);
$data=json_encode($data_to_send);
echo $data;
exit();
die;


?>