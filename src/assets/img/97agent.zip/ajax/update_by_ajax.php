<?php include('../include/config.php'); 
 $_POST=sanatize($_POST);
 $_GET=sanatize($_GET);
 extract($_POST);
 extract($_GET);



 if(isset($_POST['login_details']) AND $_POST['login_details']=true)
 {
   $client='';
   $msg='';
   if(isset($_POST['client']))
   {
   	$client=true;
   }
 	$update=update_login_details($user_id,$msg,$client);
 	$send_array=array('msg'=>'Credential send Successfully');
		$status='success';
		$data_to_send=array(
			'data'=>$send_array,
			'status'=>$status
		);
		$data=json_encode($data_to_send);
		echo $data;
		exit();
		die;
 }

 if(isset($_POST['update_status']))
 {   
 	 $return=user_status($user_id,$update_status);
 	 $_SESSION['notify']=['type'=>'warning','msg'=>'User status has been updated successfuly'];
    $send_array=array('msg'=>'Status has been changed successfuly');
		$status='success';
		$data_to_send=array(
			'data'=>$send_array,
			'status'=>$status
		);
		$data=json_encode($data_to_send);
		echo $data;
		exit();
		die;
 }

 
 if(isset($_POST['update_status_client']))
 {  

 	  $return=client_status($user_id,$update_status_client);	
 	  $_SESSION['notify']=['type'=>'warning','msg'=>'Client status has been updated successfuly'];
     $send_array=array('msg'=>'Client status updated successfuly');
		$status='success';
		$data_to_send=array(
			'data'=>$send_array,
			'status'=>$status
		);
		$data=json_encode($data_to_send);
		echo $data;
		exit();
		die;


 }


 

if(isset($_POST['fav_selection_id'])){
	$query="SELECT * FROM match_team_tbl WHERE market_id=".$market_id."";
	$res=mysqli_query($con,$query);
	while($team_data=mysqli_fetch_assoc($res))
	{
     
     if($fav_selection_id!=$team_data['selection_id'])
     {
     	$non_fav_selection_id=$team_data['selection_id'];
     }
      
	}

	$query = "UPDATE market_price SET non_fav_team_selection_id='$non_fav_selection_id',fav_team_selection_id='$fav_selection_id' WHERE market_id = '$market_id'";
    $data_res=mysqli_query($con,$query);

    $send_array=array('msg'=>'Favorite Team Updated Successfully');
	$status='success';
	$data_to_send=array(
		'data'=>$send_array,
		'status'=>$status
	);
	$data=json_encode($data_to_send);
	echo $data;
	exit();
	die;
}


?>