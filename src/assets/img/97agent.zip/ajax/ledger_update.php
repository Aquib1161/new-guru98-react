<?php
include('config.php');
$post_data=sanatize($_POST);
$get_data=sanatize($_GET);
extract($post_data);
extract($get_data);
$client_id=$_POST['id'];

if($transaction_type=='D')
{
	$mark='Pay cash';
}
else
{
	$mark='Recieve cash';
}

$insert_array=array(
	'payment_type'=>$transaction_type,
	'amount'=>$amount,
	'note'=>$note,
	'client_id'=>$client_id,
	'match_name'=>$mark.' by '.$collection_type,
	's_date'=>_date_time(),
	'post_date'=>_date(),
	'ledger_type'=>'cash'
);

$insert=insert_array('ledger',$insert_array);


$status='success';
$send_array=array('msg'=>'Ledger has been updated successfully','coins'=>$amount);
$data_to_send=array(
	'data'=>$send_array,
	'status'=>$status
);
$data=json_encode($data_to_send);
echo $data;


?>