<?php
include('../include/config.php');
$_POST=sanatize($_POST);
$market_id=$_POST['market_id'];

if ($market_id == "") {
    $send_array=array(
     'msg'=>"Something went wrong"
    );

    $status='error';
    $data_to_send=array(
    'data'=>$send_array,
    'status'=>$status
);
    $data=json_encode($data_to_send);
    echo $data;
    exit();
}
$array=array();
$match_data=get_data('upcoming_match',"market_id='".$market_id."'",'s');
$match_name = $match_data['match_name'];

$team_data=get_data('match_team_tbl',"market_id='".$market_id."'");
$count=count($team_data);

$team1=$team1_selection_id=$team_data[0]['selection_id'];
$team1_name=$team_data[0]['runner_name'];

$team2= $team2_selection_id=$team_data[1]['selection_id'];
$team2_name=$team_data[1]['runner_name'];
if($count==3)
{
    $team3_selection_id=$team_data[2]['selection_id'];
    $team3_name=$team_data[2]['runner_name'];
}
$won_team_name=$match_data['won_team_name'];
$winner_team_id =$won_team_selection_id=$match_data['won_team_selection_id'];

 $series_id=$match_data['event_id'];
 $match_name=$match_data['match_name'];
 $match_date=$match_data['match_date'];

if($won_team_name=='' || $won_team_selection_id=='')
{
   $send_array=array(
     'msg'=>"Please update match decision first"
    );

    $status='error';
    $data_to_send=array(
    'data'=>$send_array,
    'status'=>$status
);
    $data=json_encode($data_to_send);
    echo $data;
    exit();
}



if(!isset($market_id))
{
   $send_array=array(
     'msg'=>"Something went wrong"
    );

    $status='error';
    $data_to_send=array(
    'data'=>$send_array,
    'status'=>$status
);
    $data=json_encode($data_to_send);
    echo $data;
    exit();
}

$query="DELETE FROM md_client_position WHERE market_id='$market_id'";
mysqli_query($con,$query);


//$client_data=get_data('client_played_match',"market_id='".$market_id."'");



$query="SELECT * FROM client_played_match WHERE market_id='$market_id'";
$client_res=mysqli_query($con,$query);
while ($client_data=mysqli_fetch_assoc($client_res))
{
$old_agent_company_amt=0;
$old_sa_company_amt=0;
$old_master_company_amt=0;
$old_admin_company_amt=0;
$old_superadmin_company_amt=0;

$session_commission_credited=0;
$total_session_coins=0;

$client_id=$client_data['client_id'];
$agent_id=$client_data['agent_id'];
$master_id=$client_data['master_id'];
$superagent_id=$sa_id=$client_data['sa_id'];
$admin_id=$client_data['admin_id'];
$superadmin_id=$client_data['superadmin_id'];

$array['id_array']=array(
'client_id'=>$client_data['client_id'],
'agent_id'=>$client_data['agent_id'],
'master_id'=>$client_data['master_id'],
'superagent_id'=>$client_data['sa_id'],
'admin_id'=>$client_data['admin_id'],
'superadmin_id'=>$client_data['superadmin_id']
);

/*_d($array);*/
$superadmin_data=get_data('users_tbl',"user_id='".$superadmin_id."'",'s',"username,name");
$superadmin_name=$superadmin_data['name'];
$superadmin_username=$superadmin_data['username'];

$admin_data=get_data('users_tbl',"user_id='".$admin_id."'",'s',"username,name");
$admin_name=$admin_data['name'];
$admin_username=$admin_data['username'];


$master_data=get_data('users_tbl',"user_id='".$master_id."'",'s',"username,name");
$master_name=$master_data['name'];
$master_username=$master_data['username'];

$superagent_data=get_data('users_tbl',"user_id='".$superagent_id."'",'s',"username,name");
$superagent_name=$superagent_data['name'];
$superagent_username=$superagent_data['username'];

$agent_data=get_data('users_tbl',"user_id='".$agent_id."'",'s',"username,name");
$agent_name=$agent_data['name'];
$agent_username=$agent_data['username'];

$query2="SELECT ClientName , username  , MatchShare FROM client WHERE id='$client_id'";
$res2=mysqli_query($con,$query2);
$clientt=mysqli_fetch_assoc($res2);
$client_name=$clientt['ClientName'];
$client_code=$clientt['username'];

// client match coins credit
$query = "SELECT SUM(amount)  total_credit FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'MC' AND match_id='$market_id' AND is_declare='1'"; 
$res = mysqli_query($con, $query);
$credited = mysqli_fetch_assoc($res)['total_credit'];
$query = "SELECT SUM(amount) total_debit FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'MD' AND match_id='$market_id'AND is_declare='1'";
$res = mysqli_query($con, $query);
$debited = mysqli_fetch_assoc($res)['total_debit'];
$total_client_match_coins=$total_match_coins = -1*($credited - $debited);


// client match coins end

// client session coins 
$query = "SELECT SUM(amount)  total_credit FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'SC' AND match_id='$market_id'AND is_declare='1'"; 
$res = mysqli_query($con, $query);
$credited = mysqli_fetch_assoc($res)['total_credit'];
$query = "SELECT SUM(amount) total_debit FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'SD' AND match_id='$market_id'AND is_declare='1'";
$res = mysqli_query($con, $query);
$debited = mysqli_fetch_assoc($res)['total_debit'];
$total_client_session_coins=$total_session_coins = -1*($credited - $debited);



// client session coins end

// client commission start
$query = "SELECT SUM(amount)  total_credit  FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'MCC' AND match_id='$market_id'"; 
$res = mysqli_query($con, $query);
$match_commission_credited = mysqli_fetch_assoc($res)['total_credit'];
$query = "SELECT SUM(amount)  total_credit  FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'SCC' AND match_id='$market_id'";
$res = mysqli_query($con, $query);
$session_commission_credited = mysqli_fetch_assoc($res)['total_credit'];
// client commission end

// mobile_charge_calculation
  $query = "SELECT SUM(amount)  mobile  FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'APP' AND match_id='$market_id'";
  $res = mysqli_query($con, $query);
  $mobile_charge=mysqli_fetch_assoc($res)['mobile'];
// mobile_charge_calcultion_end

$total_client_session_match_amt=$total_session_coins+$total_match_coins;
$total_client_commission=$match_commission_credited+$session_commission_credited;
$total_net_amt_client=($total_client_session_match_amt-$total_client_commission);



$client_array=array(
'client_match_amt'=>$total_client_match_coins,
'client_session_amt'=>$total_client_session_coins,
'client_match_session_amt'=>($total_client_match_coins+$total_client_session_coins),
'client_match_comm'=>$match_commission_credited,
'client_session_comm'=>$session_commission_credited,
'client_total_comm'=>($match_commission_credited+$session_commission_credited),
'client_mobile_charge'=>$mobile_charge,
'client_net_amt'=>($total_client_match_coins+$total_client_session_coins-($match_commission_credited+$session_commission_credited))
);

$array['client_array']=$client_array;

$query="SELECT * FROM `shares` where client_id='$client_id' AND agent_id='$agent_id' AND market_id='$market_id'";
$res=mysqli_query($con,$query);
$share=$agent_share=mysqli_fetch_Assoc($res);
 if(empty($share))
  {   
        $client_share_data=get_data('client',"id=".$client_id."",'s');
        update_share_tbl($client_share_data,$market_id);
  }
$superadmin_cut_share=$share['superadmin_share']/100;
$admin_cut_share=$share['admin_share']/100;
$master_cut_share=$share['master_share']/100;
$sa_cut_share=$share['sa_share']/100;
$agent_cut_share=$share['agent_Share']/100;





$agent_match_share1=$agent_share['agent_Share'];
$agent_match_share=($agent_match_share1/100);

$sa_match_share1=$agent_share['sa_share'];
$sa_match_share=$agent_match_share+($sa_match_share1/100);

$master_match_share1=$agent_share['master_share'];
$master_match_share=($sa_match_share+($master_match_share1/100));

$admin_match_share1=$agent_share['admin_share'];
$admin_match_share=($master_match_share+($admin_match_share1/100));

$superadmin_match_share1=$agent_share['superadmin_share'];
$superadmin_match_share=($admin_match_share+($superadmin_match_share1/100));

$share_array=array(
'agent_share'=>($share['agent_Share']/100),
'sa_share'=>($share['sa_share']/100),
'master_share'=>($share['master_share']/100),
'admin_share'=>($share['admin_share']/100),
'superadmin_share'=>($share['superadmin_share']/100),
'total_agent_share'=>$agent_match_share,
'total_sa_share'=>$sa_match_share,
'total_master_share'=>$master_match_share,
'total_admin_share'=>$admin_match_share,
'total_superadmin_share'=>$superadmin_match_share
);

$array['share_array']=$share_array;
// user_type match_session_amt_without_comm
$admin_match_amount=($total_client_match_coins*$admin_cut_share);
$superadmin_match_amount=($total_client_match_coins*$superadmin_cut_share);
$master_match_amount=($total_client_match_coins*$master_cut_share);
$sa_match_amount=($total_client_match_coins*$sa_cut_share);
$agent_match_amount=($total_client_match_coins*$agent_cut_share);


$admin_session_amount=($total_client_session_coins*$admin_cut_share);
$superadmin_session_amount=($total_client_session_coins*$superadmin_cut_share);
$master_session_amount=($total_client_session_coins*$master_cut_share);
$sa_session_amount=($total_client_session_coins*$sa_cut_share);
$agent_session_amount=($total_client_session_coins*$agent_cut_share);
// user_type match_session_amt_without_comm_end   





  //usertype_commission_cal_start
  // agent commision
  $query = "SELECT SUM(agent_amount)  total_credit  FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'MCC' AND match_id='$market_id'AND is_declare='1'"; 
  $res = mysqli_query($con, $query);
  $agent_match_commission_credited = mysqli_fetch_assoc($res)['total_credit'];
  $query = "SELECT SUM(agent_amount)  total_credit  FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'SCC' AND match_id='$market_id'AND is_declare='1'";
  $res = mysqli_query($con, $query);
  $agent_session_commission_credited = mysqli_fetch_assoc($res)['total_credit'];
  $super_total_agent_commission_value= $total_agent_commission=$agent_match_commission_credited+$agent_session_commission_credited;
  // agent commission end


  // sa commission
  $query = "SELECT SUM(sa_amount)  total_credit  FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'MCC' AND match_id='$market_id'AND is_declare='1'"; 
  $res = mysqli_query($con, $query);
  $sa_match_commission_value = mysqli_fetch_assoc($res)['total_credit'];
  $query = "SELECT SUM(sa_amount)  total_credit  FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'SCC' AND match_id='$market_id'AND is_declare='1'";
  $res = mysqli_query($con, $query);
  $sa_session_commission_value= mysqli_fetch_assoc($res)['total_credit'];
  $super_total_sa_commission_value=$sa_session_commission_value+$sa_match_commission_value;
  // sa commission end

  $total_sa_net_amt_client=$total_client_session_match_amt-$super_total_sa_commission_value;

  $share_sa_amount=($sa_match_share*$total_sa_net_amt_client);
  $master_pay_amount=$total_sa_net_amt_client-$share_sa_amount;


  // master commission end 
  $query = "SELECT SUM(master_amount)  total_credit  FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'MCC' AND match_id='$market_id'AND is_declare='1'"; 
  $res = mysqli_query($con, $query);
  $master_match_commission_value = mysqli_fetch_assoc($res)['total_credit'];
  $query = "SELECT SUM(master_amount)  total_credit  FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'SCC' AND match_id='$market_id'AND is_declare='1'";
  $res = mysqli_query($con, $query);
  $master_session_commission_value= mysqli_fetch_assoc($res)['total_credit'];
  $super_total_master_commission_value=$master_session_commission_value+$master_match_commission_value;
  // master commission end

  $total_master_net_amt_client=$total_client_session_match_amt-$super_total_master_commission_value;
  $share_master_amount=($master_match_share*$total_master_net_amt_client);
  $admin_pay_amount=$total_master_net_amt_client-$share_master_amount;



 // admin commission 
  $query = "SELECT SUM(admin_amount)  total_credit  FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'MCC' AND match_id='$market_id'AND is_declare='1'"; 
  $res = mysqli_query($con, $query);
  $admin_match_commission_value = mysqli_fetch_assoc($res)['total_credit'];
  $query = "SELECT SUM(admin_amount)  total_credit  FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'SCC' AND match_id='$market_id'AND is_declare='1'";
  $res = mysqli_query($con, $query);
  $admin_session_commission_value= mysqli_fetch_assoc($res)['total_credit'];
  $super_total_admin_commission_value=$admin_session_commission_value+$admin_match_commission_value;
  // admin commission end 
       
  $total_admin_net_amt_client=$total_client_session_match_amt-$super_total_admin_commission_value;
  $share_admin_amount=($admin_match_share*$total_admin_net_amt_client);
  $superadmin_pay_amount=$total_admin_net_amt_client-$share_admin_amount;

   // superadmin commission start
  $query = "SELECT SUM(superadmin_amount)  total_credit  FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'MCC' AND match_id='$market_id'AND is_declare='1'"; 
  $res = mysqli_query($con, $query);
  $superadmin_match_commission_value = mysqli_fetch_assoc($res)['total_credit'];
  $query = "SELECT SUM(superadmin_amount)  total_credit  FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'SCC' AND match_id='$market_id'AND is_declare='1'";
  $res = mysqli_query($con, $query);
  $superadmin_session_commission_value= mysqli_fetch_assoc($res)['total_credit'];
  $super_total_superadmin_commission_value=$superadmin_session_commission_value+$superadmin_match_commission_value;
  // superadmin commisssion end

//usertype_commission_cal_end

  $user_comm_without_share=array(
    'total_share_agent_comm'=>round($super_total_agent_commission_value,2),
    'total_share_sa_comm'=>round($super_total_sa_commission_value,2),
    'total_share_master_comm'=>round($super_total_master_commission_value,2),
    'total_share_admin_comm'=>round($super_total_admin_commission_value,2),
    'total_share_superadmin_comm'=>round($super_total_superadmin_commission_value,2)

  );

 $user_comm_array=$user_type_share_commission_array=array
  (
    'total_share_agent_comm'=>round($super_total_agent_commission_value*$agent_cut_share,2),
    'total_share_sa_comm'=>round($super_total_sa_commission_value*$sa_cut_share,2),
    'total_share_master_comm'=>round($super_total_master_commission_value*$master_cut_share,2),
    'total_share_admin_comm'=>round($super_total_admin_commission_value*$admin_cut_share,2),
    'total_share_superadmin_comm'=>round($super_total_superadmin_commission_value*$superadmin_cut_share,2)
  );

  $array['user_comm_array_withour_share']=$user_comm_without_share;
  $array['user_comm_array']=$user_comm_array;
//_d($client_array['client_net_amt']*$share_array['agent_share']);

  //$agent_net_amount=($client_array['client_match_session_amt']-$super_total_agent_commission_value);  // without share cutting

  


  $agent_total_amount=($client_array['client_net_amt']*$share_array['agent_share'])+($client_array['client_total_comm']*$share_array['agent_share'])-$user_comm_array['total_share_agent_comm'];

  $agent_share_amt=($client_array['client_match_session_amt']*(1-$share_array['agent_share']))-$user_comm_array['total_share_agent_comm'];

  $sa_total_amount=($client_array['client_net_amt']*$share_array['sa_share'])+($user_comm_array['total_share_sa_comm'])-$user_comm_array['total_share_agent_comm'];

  $sa_share_amt=($client_array['client_match_session_amt']*(1-$share_array['total_sa_share']))-$user_comm_array['total_share_agent_comm']+$user_comm_array['total_share_sa_comm'];

  $master_total_amount=($client_array['client_net_amt']*$share_array['master_share'])+($user_comm_array['total_share_master_comm'])-$user_comm_array['total_share_sa_comm'];

  $master_share_amt=($client_array['client_match_session_amt']*(1-$share_array['total_master_share']))-$user_comm_array['total_share_sa_comm']+$user_comm_array['total_share_master_comm'];

  $admin_total_amount=($client_array['client_net_amt']*$share_array['admin_share'])+($user_comm_array['total_share_admin_comm'])-$user_comm_array['total_share_master_comm'];

  $admin_share_amt=($client_array['client_match_session_amt']*(1-$share_array['total_admin_share']))-$user_comm_array['total_share_master_comm']+$user_comm_array['total_share_admin_comm'];

  $superadmin_total_amount=($client_array['client_net_amt']*$share_array['superadmin_share'])+($user_comm_array['total_share_superadmin_comm'])-$user_comm_array['total_share_admin_comm'];

  $superadmin_share_amt=0;
    $user_self_amount=array
  (
    'agent_total_amount'=>$agent_total_amount,
    'agent_share_amount'=>$agent_share_amt,
    'sa_total_amount'=>$sa_total_amount,
    'sa_share_amount'=>$sa_share_amt,
    'master_total_amount'=>$master_total_amount,
    'master_share_amount'=>$master_share_amt,
    'admin_total_amount'=>$admin_total_amount,
    'admin_share_amount'=>$admin_share_amt,
    'superadmin_total_amount'=>$superadmin_total_amount,
    'superadmin_share_amount'=>$superadmin_share_amt,
  );

$array['user_self_amount']=$user_self_amount;
$old_agent_net_amount=($client_array['client_match_session_amt']-$user_comm_without_share['total_share_agent_comm']);
$old_agent_share_amount=$old_agent_net_amount*$share_array['total_agent_share'];
$old_agent_company_amt=$old_agent_net_amount-$old_agent_share_amount;

$old_sa_net_amount=($client_array['client_match_session_amt']-$user_comm_without_share['total_share_sa_comm']);
$old_sa_share_amount=$old_sa_net_amount*$share_array['total_sa_share'];
$old_sa_company_amt=$old_sa_net_amount-$old_sa_share_amount;

$old_master_net_amount=($client_array['client_match_session_amt']-$user_comm_without_share['total_share_master_comm']);
$old_master_share_amount=$old_master_net_amount*$share_array['total_master_share'];
$old_master_company_amt=$old_master_net_amount-$old_master_share_amount;

$old_admin_net_amount=($client_array['client_match_session_amt']-$user_comm_without_share['total_share_admin_comm']);
$old_admin_share_amount=$old_admin_net_amount*$share_array['total_admin_share'];
$old_admin_company_amt=$old_admin_net_amount-$old_admin_share_amount;

$old_superadmin_net_amount=($client_array['client_match_session_amt']-$user_comm_without_share['total_share_superadmin_comm']);
$old_superadmin_share_amount=$old_superadmin_net_amount*$share_array['superadmin_share'];
$old_superadmin_company_amt=$old_superadmin_net_amount-$old_superadmin_share_amount;

  $old_user_amount=array(
    'agent_net_amount'=>round($old_agent_net_amount,2),
    'agent_share_amount'=>round($old_agent_share_amount,2),
    'agent_final_amount'=>round($old_agent_company_amt,2),
    'sa_net_amount'=>round($old_sa_net_amount,2),
    'sa_share_amount'=>round($old_sa_share_amount,2),
    'sa_final_amount'=>round($old_sa_company_amt,2),
    'master_net_amount'=>round($old_master_net_amount,2),
    'master_share_amount'=>round($old_master_share_amount,2),
    'master_final_amount'=>round($old_master_company_amt,2),
    'admin_net_amount'=>round($old_admin_net_amount,2),
    'admin_share_amount'=>round($old_admin_share_amount,2),
    'admin_final_amount'=>round($old_admin_company_amt,2),
    'superadmin_net_amount'=>round($old_superadmin_net_amount,2),
    'superadmin_share_amount'=>round($old_superadmin_share_amount,2),
    'superadmin_final_amount'=>round($old_superadmin_company_amt,2),
  );

  $array['user_amount_old_type']=$old_user_amount;

  $admin_lena=$old_master_company_amt;
  $master_lena=$old_sa_company_amt;
  $sa_lena=$old_agent_company_amt;
  $agent_lena=$total_net_amt_client+$mobile_charge;

  if($master_id==0)
  {
    $admin_lena=$old_sa_company_amt;
    if($sa_id==0)
  {
    $admin_lena=$old_agent_company_amt;
    if($agent_id==0)
  {
    $admin_lena=$total_net_amt_client+$mobile_charge;
  }
  }
  }

  if($sa_id==0)
  {
    
    $master_lena=$old_agent_company_amt;
    if($agent_id==0)
  {
    
    $master_lena=$total_net_amt_client+$mobile_charge;
  }
  }

  if($agent_id==0)
  {
    $sa_lena=$total_net_amt_client+$mobile_charge;
  }

$lena=array(
'admin_lena'=>$admin_lena,
'master_lena'=>$master_lena,
'sa_lena'=>$sa_lena,
'agent_lena'=>$agent_lena,
'agent_id'=>$agent_id,
'master_id'=>$master_id,
'sa_id'=>$sa_id,
'admin_id'=>$admin_id,
'client_id'=>$client_id
);


$total_superadmin_profit=$old_admin_company_amt;
$total_admin_profit=$admin_lena-$old_admin_company_amt;
$total_master_profit=$master_lena-$old_master_company_amt;
$total_sa_profit=$sa_lena-$old_sa_company_amt;
$total_agent_profit=$agent_lena-$old_agent_company_amt;
  


 $profit_loss_array=array(
    'total_superadmin_profit'=>$total_superadmin_profit,
    'total_admin_profit'=>$total_admin_profit,
    'total_master_profit'=>$total_master_profit,
    'total_sa_profit'=>$total_sa_profit,
    'total_agent_profit'=>$total_agent_profit,
    'total_client_profit'=>$total_net_amt_client+$mobile_charge,
 );

$array['profit_loss_array']=$profit_loss_array;


   $insert_array=array(
             'market_id'=>$market_id,
             'client_id'=>$client_id,
             'client_name'=>$client_name,
             'client_code'=>$client_code,
             'agent_id'=>$agent_id,
             'sa_id'=>$sa_id,
             'master_id'=>$master_id,
             'admin_id'=>$admin_id,
             'superadmin_id'=>$superadmin_id,
             'agent_share'=>$agent_match_share1,
             'superagent_share'=>$sa_match_share1,
             'master_share'=>$master_match_share1,
             'admin_share'=>$admin_match_share1,
             'superadmin_share'=>$superadmin_match_share1,
             'client_match_coins'=>$total_match_coins,
             'client_session_coins'=>$total_session_coins,
             'client_match_commission'=>$match_commission_credited,
             'client_session_commission'=>$session_commission_credited,
             'client_total_amount'=>$total_net_amt_client,
             'client_mobile_charge'=>$mobile_charge,
             'agent_match_commission'=>($agent_match_commission_credited),
             'agent_session_commission'=>($agent_session_commission_credited),
             'agent_total_amount'=>$user_self_amount['agent_total_amount'],
             'agent_share_amount'=>$old_agent_company_amt,
             'agent_name'=>$agent_name.' ('.$agent_username.')',
             'sa_match_commission'=>($sa_match_commission_value),
             'sa_session_commission'=>($sa_session_commission_value),
             'sa_total_amount'=>$user_self_amount['sa_total_amount'],
             'sa_share_amount'=>$old_sa_company_amt,
             'sa_name'=>$superagent_name.' ('.$superagent_username.')',
             'master_match_commission'=>($master_match_commission_value),
             'master_session_commission'=>($master_session_commission_value),
             'master_total_amount'=>$user_self_amount['master_total_amount'],
             'master_share_amount'=>$old_master_company_amt,
             'master_name'=>$master_name.' ('.$master_username.')',
             'admin_match_commission'=>($admin_match_commission_value),
             'admin_session_commission'=>($admin_session_commission_value),
             'admin_total_amount'=>$user_self_amount['admin_total_amount'],
             'admin_share_value'=>$old_admin_company_amt,
             'admin_name'=>$admin_name.' ('.$admin_username.')',
             'superadmin_match_commission'=>($superadmin_match_commission_value),
             'superadmin_session_commission'=>($superadmin_session_commission_value),
             'superadmin_total_amount'=>$user_self_amount['superadmin_total_amount'],
             'superadmin_share_value'=>0,
             'superadmin_name'=>$superadmin_name.' ('.$superadmin_username.')',
             'decision_status'=>1,
             'ledger_update_date'=>_date(),
             'match_name'=>$match_name,
             'series_id'=>$series_id,
             'update_date'=>_date_time(),
             'superadmin_session_amount'=>$superadmin_session_amount,
             'admin_session_amount'=>$admin_session_amount,
             'master_session_amount'=>$master_session_amount,
             'sa_session_amount'=>$sa_session_amount,
             'agent_session_amount'=>$agent_session_amount,
             'superadmin_match_amount'=>$superadmin_match_amount,
             'admin_match_amount'=>$admin_match_amount,
             'master_match_amount'=>$master_match_amount,
             'sa_match_amount'=>$sa_match_amount,
             'agent_match_amount'=>$agent_match_amount,
             'total_admin_profit'=>$total_admin_profit,
             'total_superadmin_profit'=>$total_superadmin_profit,
             'total_master_profit'=>$total_master_profit,
             'total_sa_profit'=>$total_sa_profit,
             'total_agent_profit'=>$total_agent_profit,
             'array_data'=>json_encode($array)
             );
  $insert=insert_array('md_client_position',$insert_array);

 }

$query="UPDATE upcoming_match SET position_status=1 , position_view=1 WHERE market_id=$market_id";
mysqli_query($con,$query);
$send_array=array(
     'msg'=>"Position has been updated successfully"
    );
    $status='success';
   $data_to_send=array(
    'data'=>$send_array,
    'status'=>$status
);
$data=json_encode($data_to_send);
echo $data;
exit();
die;




?>