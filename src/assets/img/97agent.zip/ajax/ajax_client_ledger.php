<?php include('../include/config.php');
$_POST = sanatize($_POST);
$_GET = sanatize($_GET);
$id = $_POST['id'];
$client_result = get_data('client', "id='" . $id . "'", 's');
$where = "client_id='" . $_POST['id'] . "'";

if (isset($_POST['statement_type']) && $_POST['statement_type'] == 1) {
    $where = $where . " AND ledger_type='CASH'";
}

if (isset($_POST['statement_type']) && $_POST['statement_type'] == 2) {
    $where = $where . " AND ledger_type!='CASH' AND ledger_type!=''";
}

if (isset($_POST['statement_type']) && $_POST['statement_type'] == 3) {
    $where = $where . " AND ledger_type!='CASH' AND ledger_type=''";
}

$where = $where . " order by ledger_id desc";
$ledger_data = get_data('ledger', $where);


if(!isset($_POST['statement_type']))
{
    $_POST['statement_type']=0;
}

$amount = get_client_ledger($id, '', $_POST['statement_type']);

$total = $amount['total_balance'];
$debit_balance = $amount['credit_balance'];
$credit_balance = $amount['debit_balance'];

?>
<?php if (!empty($ledger_data)) { ?>

    <div class="card-body">
        <div>

            <table id="example1" class="table table-bordered table-striped">
                <thead>

                    <tr>
                        <th>#</th>
                        <th> Date</th>
                        <th>Collection Name</th>
                        <th>Debit</th>
                        <th>Credit</th>
                        <th>Balance</th>
                        <th>Payment Type</th>
                        <th>Remark</th>
                    </tr>

                    <tr>
                        <th></th>
                        <th></th>
                        <th class="text-blue">Total Amount</th>
                        <th><?= number_format($debit_balance, 2) ?></th>
                        <th><?= number_format($credit_balance, 2) ?></th>
                        <th class="text-blue"><?= color(number_format($credit_balance - $debit_balance, 2)) ?></th>
                        <th></th>
                        <th></th>
                    </tr>

                </thead>
                <tbody>
                    <?php $no = 1;
                    $total_calculate_amount = 0;
                    $debit = 0;
                    $total_credit = 0;
                    $total_debit = 0;
                    $balance = 0;
                    foreach ($ledger_data as $key => $value) {  ?>

                        <?php if ($value['payment_type'] == 'D') {
                            $amount = (-1 * $value['amount']);
                            $debit_show = round($value['amount'],2);
                            $credit_show = '-';
                        } else {
                            $amount = $value['amount'];
                            $debit_show = '-';
                            $credit_show = round($value['amount'],2);
                        }

                        $balance = ($total - $total_calculate_amount);
                        $total_calculate_amount += $amount;


                        ?>
                        <tr <?php if ($value['ledger_type'] == 'cash') {
                                echo  'style="background-color: pink;"';
                            } ?>>
                            <td><?= $no++ ?></td>
                            <td><?= $value['s_date'] ?></td>
                            <td class="text-uppercase"><?= $value['match_name'] ?></td>
                            <th class="text-primary"><?= $debit_show ?></th>
                            <th class="text-danger"><?= $credit_show ?></th>
                            <td><?= round((abs($balance)), 2) ?></td>
                            <td> <?php if ($value['ledger_type'] == 'cash') 
                                       {
                                        if ($value['payment_type'] == 'C') {
                                            echo 'LIYA';
                                        } else {
                                            echo 'DIYA';
                                        }
                                    }
                                    else
                                    {
                                        if ($value['payment_type'] == 'C') {
                                            echo '<span style="color:red;">AGENT MINUS</span>';
                                        } else {
                                            echo '<span style="color:blue;">AGENT PLUS</span>';
                                        }
                                    }
                                    ?>
                            </td> 
                            
                            <td class="text-uppercase">
                                

                                <?php if ($value['ledger_type'] == 'cash') 
                                       {
                                        echo $value['note'];
                                       }
                                    else
                                    {
                                        echo $value['won_team_name'];
                                    }
                                    ?>
                                    


                                </td>
                        </tr>
                    <?php } ?>

                </tbody>
                <tfoot>

                </tfoot>
            </table>

        </div>


    </div>

<?php } else { ?>

    <div class="card-body">

        <div class="alert alert-warning">
            <h6>No Record Found</h6>
        </div>

    </div>

<?php } ?>