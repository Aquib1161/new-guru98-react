<?php include('../include/config.php');
$_POST=sanatize($_POST);
$_GET=sanatize($_GET);
//_d($_POST);
$market_id = $_POST['market_id'];
$selection_id = $_POST['selection_id'];
$decision_run =$_POST['decision_run'];
if($decision_run=='' OR $selection_id=='' OR $market_id=='')
{
    $send_array=array(
     'msg'=>"Something went wrong"
    );
    $status='error';
    $data_to_send=array(
    'data'=>$send_array,
    'status'=>$status
);
$data=json_encode($data_to_send);
echo $data;
}

$query= "DELETE FROM transaction_log WHERE overall_type='SC' AND match_id='$market_id' AND selection_id='$selection_id'";
mysqli_query($con,$query);
$query= "DELETE FROM transaction_log WHERE overall_type='SCC' AND match_id='$market_id' AND selection_id='$selection_id'";
mysqli_query($con,$query);  

$decision1 = "UPDATE session_crick_tbl SET decision_run = '$decision_run' , api_active='0' , insert_date='"._date()."' WHERE  market_id = '$market_id' AND  selection_id = '$selection_id' ";
$res1 = mysqli_query($con,$decision1);
    

$decision = "UPDATE client_session_bat_tbl SET decision_run = '$decision_run'  WHERE  market_id = '$market_id' AND  selection_id = '$selection_id' ";
$res = mysqli_query($con,$decision);
    
$qurey = "SELECT * FROM client_session_bat_tbl WHERE  market_id = $market_id AND selection_id = '$selection_id' AND deleted_status=0";
$res = mysqli_query($con,$qurey);   

$qurey = "SELECT commission_permission FROM session_crick_tbl WHERE  market_id = '$market_id' AND selection_id = '$selection_id' ";
$sess_res = mysqli_query($con,$qurey);
$commission_permission=mysqli_fetch_assoc($sess_res)['commission_permission'];

$decision = array();
$client_wise = array();

while ($data = mysqli_fetch_assoc($res))
{
    if(!array_key_exists($data['client_id'], $client_wise)){
        $client_wise[$data['client_id']] = array(
            "debit" => 0, 
            "credit"=>0, 
            "bet_commission" => 0,
            "commission_type" => $data['commission_type'],
            "agent_id"=>$data['agent_id'],
            "super_agent_id"=>$data['super_agent_id'],
            "master_id"=>$data['master_id'],
            "admin_id"=>$data['admin_id'],
            "superadmin_id"=>$data['superadmin_id'],
            "runner_name"=>$data['runner_name'],
            "admin_share"=>$data['admin_share'],
            "superadmin_share"=>$data['superadmin_share'],
            "master_share"=>$data['master_share'],
            "sa_share"=>$data['sa_share'],
            "agent_share"=>$data['agent_share'],
            "auto_limit"=>$data['auto_limit']
        );
    }

    if ($data['type']  == 'Y' && $data['decision_run'] >=  $data['bet_run']){
        $client_wise[$data['client_id']]['credit'] += floatval($data['pass_amount']);
        $client_wise[$data['client_id']]['bet_commission'] += floatval($data['commission']/100)*(int)$data['amount'];


        
    }

    if ($data['type']  == 'N' && $data['decision_run'] <  $data['bet_run']){
        $client_wise[$data['client_id']]['credit'] += floatval($data['pass_amount']);
        $client_wise[$data['client_id']]['bet_commission'] += floatval($data['commission']/100)*(int)$data['amount'];

    }



    if ($data['type']  == 'Y' && $data['decision_run'] <  $data['bet_run'])
  {
        $client_wise[$data['client_id']]['debit'] += floatval($data['fail_amount']);
        $client_wise[$data['client_id']]['bet_commission'] += floatval($data['commission']/100)*$data['amount'];    
    }


    if ($data['type']  == 'N' && $data['decision_run'] >=  $data['bet_run'])
  {
        $client_wise[$data['client_id']]['debit'] += floatval($data['fail_amount']);
        $client_wise[$data['client_id']]['bet_commission'] += floatval($data['commission']/100)*(int)$data['amount'];

    }
    
}





foreach ($client_wise as $clid => $crdb) {
    $debit = $crdb['debit'];
    $credit = $crdb['credit'];
    $runner_name = $crdb['runner_name'];
    $agent_id = $crdb['agent_id'];
    $sa_id = $crdb['super_agent_id'];
    $master_id = $crdb['master_id'];
    $admin_id = $crdb['admin_id'];
    $superadmin_id = $crdb['superadmin_id'];
    $superadmin_share = $crdb['superadmin_share'];
    $admin_share = $crdb['admin_share'];
    $master_share = $crdb['master_share'];
    $sa_share = $crdb['sa_share'];
    $agent_share = $crdb['agent_share'];
    $auto_limit = $crdb['auto_limit'];

    

$query="SELECT * FROM shares WHERE market_id='$market_id' AND client_id='$clid'";
    $res=mysqli_query($con,$query);
    $share=mysqli_fetch_assoc($res);

    $superadmin_share=$share['superadmin_share'];
    $admin_share=$share['admin_share'];
    $master_share=$share['master_share'];
    $sa_share=$share['sa_share'];
    $agent_share=$share['agent_Share'];

    $agent_commission_type=$share['agent_commission_type'];
    $sa_commission_type=$share['sa_commission_type'];
    $master_commission_type=$share['master_commission_type'];
    $admin_commission_type=$share['admin_commission_type'];
    $superadmin_commission_type=$share['superadmin_commission_type'];

    $agent_match_commission=$share['agent_match_commission'];
    $sa_match_commission=$share['sa_match_commission'];
    $master_match_commission=$share['master_match_commission'];
    $admin_match_commission=$share['admin_match_commission'];
    $superadmin_match_commission=$share['superadmin_match_commission'];

    $agent_session_commission=$share['agent_session_commission'];
    $sa_session_commission=$share['sa_session_commission'];
    $master_session_commission=$share['master_session_commission'];
    $admin_session_commission=$share['admin_session_commission'];
    $superadmin_session_commission=$share['superadmin_session_commission'];


    $admin_amount = ($admin_share / 100) * $debit;
    $admin_amount=round($admin_amount,2);
    $superadmin_amount = ($superadmin_share / 100) * $debit;
    $superadmin_amount=round($superadmin_amount,2);
    $master_amount = ($master_share / 100) * $debit;
    $master_amount=round($master_amount,2);
    $sa_amount = ($sa_share / 100) * $debit;
    $sa_amount=round($sa_amount,2);
    $agent_amount = ($agent_share / 100) * $debit;
    $agent_amount=round($agent_amount,2);


    $query="SELECT * FROM transaction_log WHERE client_id = '$clid' AND  selection_id = '$selection_id'   AND overall_type = 'SD' ";
    $c_res=mysqli_query($con,$query);
    $count_res=mysqli_num_rows($c_res);   
    if($count_res==0)
    {
     $updatequery = "INSERT INTO  transaction_log  (amount,user_type,transaction_type,client_id,admin_id,sa_id,master_id,agent_id,remark,for_bet,selection_id,match_id,overall_type, is_declare,admin_share,master_share,sa_share,agent_share,auto_limit,admin_amount,master_amount,sa_amount,agent_amount,superadmin_amount,superadmin_id)  VALUE  ($debit,'CLIENT','C','$clid','$admin_id','$sa_id','$master_id','$agent_id','$runner_name','1','$selection_id','$market_id','SD', '1','$admin_share','$master_share','$sa_share','$agent_share','$auto_limit','$admin_amount','$master_amount','$sa_amount','$agent_amount','$superadmin_amount','$superadmin_id')";
    }
    else
    {
    $updatequery = "UPDATE transaction_log SET amount = $debit, admin_amount='$admin_amount', master_amount='$master_amount',sa_amount='$sa_amount',agent_amount='$agent_amount', for_bet = '1', remark ='$runner_name', is_declare='1',superadmin_amount='$superadmin_amount',admin_id='$admin_id'  WHERE  client_id = '$clid' AND  selection_id = '$selection_id'   AND overall_type = 'SD'";
    }
   // _dx($updatequery);
    $res= mysqli_query($con,$updatequery);

    $admin_amount = ($admin_share / 100) * $credit;
    $admin_amount=round($admin_amount,2);
    $superadmin_amount = ($superadmin_share / 100) * $credit;
    $superadmin_amount=round($superadmin_amount,2);
    $master_amount = ($master_share / 100) * $credit;
    $master_amount=round($master_amount,2);
    $sa_amount = ($sa_share / 100) * $credit;
    $sa_amount=round($sa_amount,2);
    $agent_amount = ($agent_share / 100) * $credit;
    $agent_amount=round($agent_amount,2);

$insertquery = "INSERT INTO  transaction_log  (amount,user_type,transaction_type,client_id,admin_id,sa_id,master_id,agent_id,remark,for_bet,selection_id,match_id,overall_type, is_declare,admin_share,master_share,sa_share,agent_share,auto_limit,admin_amount,master_amount,sa_amount,agent_amount,superadmin_amount,superadmin_id)  VALUE  ($credit,'CLIENT','C','$clid','$admin_id','$sa_id','$master_id','$agent_id','$runner_name','1','$selection_id','$market_id','SC', '1','$admin_share','$master_share','$sa_share','$agent_share','$auto_limit','$admin_amount','$master_amount','$sa_amount','$agent_amount','$superadmin_amount','$superadmin_id')";

$res= mysqli_query($con,$insertquery);

    $commission = 0;
    $agent_amount=0;
    $sa_amount=0;
    $master_amount=0;
    $admin_amount=0;
    $superadmin_amount=0;
if ($crdb['commission_type'] == 'BB') {
    $commission = $crdb['bet_commission'];

}

if ($crdb['commission_type'] == 'OM' && $crdb['debit'] >  $crdb['credit']) {
    $commission = $crdb['bet_commission'];
    $commission = ($crdb['debit']-$crdb['credit'])*($share['client_session_commission']/100);
}




        if($agent_commission_type=='BB')
        {

            $query = "SELECT SUM(amount)  total_bet_amount FROM client_session_bat_tbl WHERE  client_id = '$clid' AND market_id='$market_id' AND selection_id='$selection_id' "; 
            $res = mysqli_query($con, $query);
            $total_bet_amount = mysqli_fetch_assoc($res)['total_bet_amount'];
            $agent_session_commission=($agent_session_commission/100);
 
          $agent_amount=($total_bet_amount*$agent_session_commission);
          $agent_amount=round($agent_amount,2);
        }

         if($agent_commission_type=='OM' && $crdb['debit'] >  $crdb['credit'])
        {
             $agent_session_commission=($agent_session_commission/100);

          $agent_amount=(($crdb['debit']-$crdb['credit'])*$agent_session_commission);
          $agent_amount=round($agent_amount,2);

        }

        if($sa_commission_type=='BB')
        {

            $query = "SELECT SUM(amount)  total_bet_amount FROM client_session_bat_tbl WHERE  client_id = '$clid' AND market_id='$market_id' AND selection_id='$selection_id' "; 
            $res = mysqli_query($con, $query);
            $total_bet_amount = mysqli_fetch_assoc($res)['total_bet_amount'];
            $sa_session_commission=($sa_session_commission/100);
 
          $sa_amount=($total_bet_amount*$sa_session_commission);
          $sa_amount=round($sa_amount,2);
        }

        if($sa_commission_type=='OM' && $crdb['debit'] >  $crdb['credit'])
        {
             $sa_session_commission=($sa_session_commission/100);

          $sa_amount=(($crdb['debit']-$crdb['credit'])*$sa_session_commission);
          $sa_amount=round($sa_amount,2);

        }


        if($master_commission_type=='BB')
        {

            $query = "SELECT SUM(amount)  total_bet_amount FROM client_session_bat_tbl WHERE  client_id = '$clid' AND market_id='$market_id' AND selection_id='$selection_id' "; 
            $res = mysqli_query($con, $query);
            $total_bet_amount = mysqli_fetch_assoc($res)['total_bet_amount'];
            $master_session_commission=($master_session_commission/100);
 
          $master_amount=($total_bet_amount*$master_session_commission);
          $master_amount=round($master_amount,2);
          }

        if($master_commission_type=='OM' && $crdb['debit'] >  $crdb['credit'])
        {
             $master_session_commission=($master_session_commission/100);

          $master_amount=(($crdb['debit']-$crdb['credit'])*$master_session_commission);
          $master_amount=round($master_amount,2);

        }

        if($admin_commission_type=='BB')
        {

            $query = "SELECT SUM(amount)  total_bet_amount FROM client_session_bat_tbl WHERE  client_id = '$clid' AND market_id='$market_id' AND selection_id='$selection_id' "; 
            $res = mysqli_query($con, $query);
            $total_bet_amount = mysqli_fetch_assoc($res)['total_bet_amount'];
            $admin_session_commission=($admin_session_commission/100);
 
            $admin_amount=($total_bet_amount*$admin_session_commission);
            $admin_amount=round($admin_amount,2);
          }

           if($admin_commission_type=='OM' && $crdb['debit'] >  $crdb['credit'])
        {
             $admin_session_commission=($admin_session_commission/100);

          $admin_amount=(($crdb['debit']-$crdb['credit'])*$admin_session_commission);
          $admin_amount=round($admin_amount,2);

        }

        if($superadmin_commission_type=='BB'){

            $query = "SELECT SUM(amount)  total_bet_amount FROM client_session_bat_tbl WHERE  client_id = '$clid' AND market_id='$market_id' AND selection_id='$selection_id' "; 
            $res = mysqli_query($con, $query);
            $total_bet_amount = mysqli_fetch_assoc($res)['total_bet_amount'];
            $superadmin_session_commission=($superadmin_session_commission/100);
 
          $superadmin_amount=($total_bet_amount*$superadmin_session_commission);
          $superadmin_amount=round($superadmin_amount,2);
          }

           if($superadmin_commission_type=='OM' && $crdb['debit'] >  $crdb['credit']){
             $superadmin_session_commission=($superadmin_session_commission/100);

          $superadmin_amount=(($crdb['debit']-$crdb['credit'])*$superadmin_session_commission);
          $superadmin_amount=round($superadmin_amount,2);

        }



     if(isset($commission_permission) AND $commission_permission==0)
     {
      $admin_amount=0;
      $commission=0;
      $master_amount=0;
      $sa_amount=0;
      $agent_amount=0;
      $superadmin_amount=0;
     }

$insertquery = "INSERT INTO  transaction_log  (amount,user_type,transaction_type,client_id,admin_id,sa_id,master_id,agent_id,remark,for_bet,selection_id,match_id,overall_type, is_declare,admin_share,master_share,sa_share,agent_share,auto_limit,admin_amount,master_amount,sa_amount,agent_amount,superadmin_amount,superadmin_id)  VALUE  ('$commission','CLIENT','C','$clid','$admin_id','$sa_id','$master_id','$agent_id','$runner_name','1','$selection_id','$market_id','SCC', '1','$admin_share','$master_share','$sa_share','$agent_share','$auto_limit','$admin_amount','$master_amount','$sa_amount','$agent_amount','$superadmin_amount','$superadmin_id')";
$res= mysqli_query($con,$insertquery);  

$client_id=$clid;

$query = "SELECT SUM(amount)  total_credit FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'SC' AND match_id='$market_id'AND is_declare='1'"; 
$res = mysqli_query($con, $query);
$credited = mysqli_fetch_assoc($res)['total_credit'];
$query = "SELECT SUM(amount) total_debit FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'SD' AND match_id='$market_id'AND is_declare='1'";
$res = mysqli_query($con, $query);
$debited = mysqli_fetch_assoc($res)['total_debit'];
$total_session_coins = -1*($credited - $debited);


$admin_session_amount=($total_session_coins*$admin_share/100);
$superadmin_session_amount=($total_session_coins*$superadmin_share/100);
$master_session_amount=($total_session_coins*$master_share/100);
$sa_session_amount=($total_session_coins*$sa_share/100);
$agent_session_amount=($total_session_coins*$agent_share/100);


$query = "SELECT SUM(amount)  total_credit  FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'MCC' AND match_id='$market_id'AND is_declare='1'"; 
$res = mysqli_query($con, $query);
$match_commission_credited = mysqli_fetch_assoc($res)['total_credit'];

$query = "SELECT SUM(amount)  total_credit  FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'SCC' AND match_id='$market_id'AND is_declare='1'";
$res = mysqli_query($con, $query);
$session_commission_credited = mysqli_fetch_assoc($res)['total_credit'];

$query = "SELECT SUM(agent_amount)  total_credit  FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'SCC' AND match_id='$market_id'AND is_declare='1'";
  $res = mysqli_query($con, $query);
  $agent_session_commission_credited = mysqli_fetch_assoc($res)['total_credit'];


$query = "SELECT SUM(sa_amount)  total_credit  FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'SCC' AND match_id='$market_id'AND is_declare='1'";
  $res = mysqli_query($con, $query);
  $sa_session_commission_value= mysqli_fetch_assoc($res)['total_credit'];

$query = "SELECT SUM(master_amount)  total_credit  FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'SCC' AND match_id='$market_id'AND is_declare='1'";
$res = mysqli_query($con, $query);
$master_session_commission_value= mysqli_fetch_assoc($res)['total_credit'];

$query = "SELECT SUM(admin_amount)  total_credit  FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'SCC' AND match_id='$market_id'AND is_declare='1'";
$res = mysqli_query($con, $query);
$admin_session_commission_value= mysqli_fetch_assoc($res)['total_credit'];

$query = "SELECT SUM(superadmin_amount)  total_credit  FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'SCC' AND match_id='$market_id'AND is_declare='1'";
$res = mysqli_query($con, $query);
$superadmin_session_commission_value= mysqli_fetch_assoc($res)['total_credit'];


$insert_array=array(
    'market_id'=>$market_id,
    'client_id'=>$client_id,
    'agent_id'=>$agent_id,
    'sa_id'=>$sa_id,
    'master_id'=>$master_id,
    'admin_id'=>$admin_id,
    'agent_share'=>$agent_share,
    'admin_share'=>$admin_share,
    'master_share'=>$master_share,
    'superagent_share'=>$sa_share,
    'superadmin_share'=>$superadmin_share,
    'superadmin_id'=>$superadmin_id,
    'client_session_coins'=>$total_session_coins,
    'client_session_commission'=>$session_commission_credited,
    'agent_session_commission'=>$agent_session_commission_credited,
    'sa_session_commission'=>$sa_session_commission_value,
    'admin_session_commission'=>$admin_session_commission_value,
    'superadmin_session_commission'=>$superadmin_session_commission_value,
    'superadmin_session_amount'=>$superadmin_session_amount,
    'admin_session_amount'=>$admin_session_amount,
    'master_session_amount'=>$master_session_amount,
    'sa_session_amount'=>$sa_session_amount,
    'agent_session_amount'=>$agent_session_amount
);

 client_tbl_update_coins($client_id);


$query2="SELECT * FROM md_client_position WHERE client_id='$client_id' AND market_id=$market_id";
$md_res=mysqli_query($con,$query2);
$count=mysqli_num_rows($md_res);

if($count==0)
{  
    $query2="SELECT ClientName , username FROM client WHERE id='$client_id'";
    $res2=mysqli_query($con,$query2);
    $clientt=mysqli_fetch_assoc($res2);
    $insert_array['client_name']=$client_name=$clientt['ClientName'];
    $insert_array['client_code']=$client_code=$clientt['username'];
    $insert=insert_array('md_client_position',$insert_array);

}
else
{  
   $update=update_array('md_client_position',$insert_array,"client_id='".$client_id."' AND market_id='".$market_id."'");
}
}

$send_array=array(
     'msg'=>"Decision has been updated successfuly"
    );


$status='success';
    $data_to_send=array(
    'data'=>$send_array,
    'status'=>$status
);
$data=json_encode($data_to_send);
echo $data;


?>




