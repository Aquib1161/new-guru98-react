<?php 
include('include/config.php');
include('header.php');
sanatize($_POST);
$match_data=match_details($_POST['market_id'],'event_id,market_id,match_name');
$declared_session=get_data('session_crick_tbl',"market_id='".$_POST['market_id']."' AND decision_run!=' '",'','session_name,selection_id,market_id,decision_run,insert_date ');
$old_company_report='company_report';
$user_type=$userdata['user_type'];
if($user_type=='superadmin' OR $user_type=='superagent' OR $user_type=='master' OR $user_type=='admin')
 {
    $old_company_report=$userdata['user_type'].'_company_report';
 }
$user_type=$_SESSION['user_type']=='superagent'?'sa':$_SESSION['user_type'];

$old_company_report='all_company_report';


if($user_type!='agent')
{
$priority_name=priority_name($userdata['add_priority']-1);
$priority_name=$priority_name=='superagent'?'sa':$priority_name;
$usertype=$userdata['user_type']=='superagent'?'sa':$userdata['user_type'];

$where="market_id='".$_POST['market_id']."' AND ".$usertype."_id='".$userdata['user_id']."' group by ".$priority_name."_id";
$user_data=get_data('md_client_position',$where);
$downline_data=array();
   foreach ($user_data as $key => $user) 
   {

    $push_array=array(
      'name'=>'',
      'username'=>$user[$priority_name.'_name'],
      'user_id'=>$user[$priority_name.'_id'],
    );

    array_push($downline_data,$push_array);
   }
   
}
else
{ 
  $priority_name='client';
  $usertype=$userdata['user_type']=='superagent'?'sa':$userdata['user_type'];
  $where="market_id='".$_POST['market_id']."' AND ".$usertype."_id='".$userdata['user_id']."'";
  $client_data=get_data('md_client_position',$where);
   $downline_data=array();
   foreach ($client_data as $key => $client) 
   {

    $push_array=array(
      'name'=>$client['client_name'],
      'username'=>$client['client_code'],
      'user_id'=>$client['client_id']
    );

    array_push($downline_data,$push_array);
   }        
}

/* if($userdata['user_type']=='agent')
 {
    $downline_data=downline_data($priority_name);
 }*/


?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Match & Session Plus Minus Report</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="dashboard?page_name=dashboard">Home</a></li>
              <li class="breadcrumb-item active">Match & Session Plus Minus Report</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">

                        <div class="card">
                            <form action="<?= $old_company_report ?>" method="POST" id="demoForm">
                              <input type="hidden" name="market_id" value="<?= $_POST['market_id'] ?>">
                              <input type="hidden" name="page_name" value="match">
                              <input type="hidden" name="type" value="<?= $_POST['type'] ?>">

                                <input type="hidden" name="type" value="b">
                                <div class="card-header text-center">
                                    <div class="container">
                                        <div class="row">

                                            <div class="col">
                                                <h5><b><?= strtoupper($userdata['user_type']) ?> OF :- <?= strtoupper($match_data['match_name']) ?> (<?= strtoupper($match_data['match_type']) ?>)</b></h5>
                                            </div>

                                            <div class="col">
                                                <button type="submit" class="btn btn-primary">Show</button>
                                            </div>
                                        </div>

                                    </div>


                                </div>
                                <!-- /.card-header -->
                                <div class="card-body">


                                    <div class="form-row">

                                        <div class="col-md-8">
                                            <table align="left" id="sessionsTable" class="table table-striped  table-hover table-bordered">
                                                <thead>
                                                <tr>
                                                    <th width="15%">
                                                        <div align="center">
                                                            <input type="checkbox" id="allSessions" value="1" checked="">
                                                        </div>
                                                    </th>
                                                    <th>
                                                        SESSION (POST DATE)
                                                    </th>
                                                    <th>
                                                        DECLARE
                                                    </th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                              <?php foreach ($declared_session as $key => $session) { ?>
                                                   
                                                <tr>
                                                    <td>
                                                        <div align="center">
                                                            <input checked type="checkbox" class="custom-checkbox" value="<?= $session['selection_id'] ?>" id="<?= $session['selection_id'] ?>" name="session_array[]">

                                                        </div>
                                                    </td>
                                                    <td><?= strtoupper($session['session_name'])?> (<?= strtoupper($session['insert_date'])?> )</td>

                                                    <td><?= strtoupper($session['decision_run'])?></td>
                                                </tr>

                                              <?php } ?>
                                                
                                                
                                                </tbody>
                                            </table>
                                        </div>

                                        <div class="col-md-4">
                                            <table align="left" id="clientTable" class="table table-striped  table-hover table-bordered">
                                                <thead>
                                                <tr>
                                                    <th width="15%">
                                                        <div align="center">
                                                            <input onclick="click()" type="checkbox" id="allClient" value="1" checked="">
                                                        </div>
                                                    </th>
                                                    <th>
                                                        <?= strtoupper($priority_name=='sa'?'superagent':$priority_name) ?> (CODE NAME)
                                                    </th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                  <?php foreach ($downline_data as $key => $value) { ?>
                                                   
                                                <tr>

                                                    <td>
                                                        <div align="center">
                                                            <input checked type="checkbox" class="custom-checkbox checkbox" value="<?= $value['user_id'] ?>" id="<?= $value['user_id'] ?>_user_id" name="downline_array[]">
                                                        </div>
                                                    </td>
                                                    <td><?= strtoupper($value['username']) ?> 
                                                    <?= strtoupper($value['name']) ?></td>

                                                </tr>

                                              <?php  } ?>
                                                
                                                </tbody>
                                            </table>
                                        </div>


                                    </div>

                                </div>
                                <!-- /.card-body -->

                            </form>
                        </div>
                        <!-- /.card -->


                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </section>
   

   
  </div>
  <!-- /.content-wrapper -->

  <script type="text/javascript">
    function click()
    {
      alert()
    }
  </script>

  <?php  include('footer.php');  ?>