<?php
include('include/config.php');
if (isset($_GET['page_no'])) {
    $page_no = $_GET['page_no'];
    if ($page_no <= 0) {
        $page_no = 1;
    }
} else {
    $page_no = 1;
}
$_GET = sanatize($_GET);
$game_type = $_GET['game_type'];
$data = $data = cricket_pagination('upcoming_match', "status='COMPLETED' AND game_type='" . $_GET['game_type'] . "'", $page_no);

$_GET['page_name'] = 'match';
$match_data = $data['data'];
$final_data=[];
foreach ($match_data as $key => $value) 
{
   array_push($final_data,"'".$value['market_id']."'");
}
$market_ids=implode(',',$final_data);
$total_pages = $data['total_pages'];
$old_company_report = 'company_report';
$user_type = $userdata['user_type'];
if ($user_type == 'superadmin' or $user_type == 'superagent' or $user_type == 'master' or $user_type == 'admin') {
    $old_company_report = $userdata['user_type'] . '_company_report';
}
$user_type = $_SESSION['user_type'] == 'superagent' ? 'sa' : $_SESSION['user_type'];
$query="SELECT sum(total_".$user_type."_profit) total_amount,market_id FROM `md_client_position` WHERE   market_id IN ($market_ids) AND ".$user_type."_id=".$_SESSION['user_id']." GROUP BY market_id";
$res=mysqli_query($con,$query);
$overall_ledger = mysqli_fetch_all($res, MYSQLI_ASSOC);
$overall_ledger=convert_key_array($overall_ledger,'market_id')['array_data'];
include('header.php');
?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class='text-uppercase'><?= $_GET['game_type'] ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="dashboard?page_name=dashboard">Home</a></li>
                        <li class="breadcrumb-item active text-uppercase">casino List</li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <form action="#" method="post" id="demoForm">
                            <div class="card-header">
                                <h2 class="card-title">Sport Details</h2>
                            </div>
                            <!-- /.card-header -->
                            <div class="card-body">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>SNo</th>
                                            <th>Code</th>
                                            <th>Game Name</th>
                                            <th>Date Time</th>
                                            <th>Plus Minus</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <tr>

                                            <td>
                                                <div align="center">
                                                    <div class="btn-group">
                                                        <button type="button" class="btn-sm btn  btn-primary dropdown-toggle dropdown-hover dropdown-icon" data-toggle="dropdown">
                                                            <span class="sr-only">Toggle Dropdown</span>
                                                        </button>
                                                        <div class="dropdown-menu" role="menu">
                                                            <a class="dropdown-item btn" href="casino_bets?market_id=today&page_name=match&game_type=<?= $game_type ?>" class="dropdown-item btn text-uppercase"><?= $game_type ?> BETS </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <label>1</label>
                                            </td>
                                            <td>
                                                <span><?= count($match_data) + 1 ?></span>
                                            </td>
                                            <td class="text-uppercase"><?= $_GET['game_type'] . ' (' . _date() . ')' ?> <img src="dist/img/live.webp" height="40"></td>
                                            <td><?= _date_time() ?></td>
                                            <td>0.00</td>
                                        </tr>

                                        <?php $total_ledger = 0;
                                        $no = 2;
                                        foreach ($match_data as $key => $data) {
                                            if ($_SESSION['user_type'] == 'superagent') {
                                                $_SESSION['user_type'] = 'sa';
                                                $id = 'sa_id';
                                            } else {
                                                $id = $_SESSION['user_type'] . '_id';
                                            }

                                            $where = "user_id='" . $_SESSION['user_id'] . "' AND market_id='" . $data['market_id'] . "' ";
                                            $user_type = $_SESSION['user_type'] == 'superagent' ? 'sa' : $_SESSION['user_type'];

                                        ?>
                                            <tr>
                                                <td>
                                                    <div align="center">
                                                        <div class="btn-group">
                                                            <button type="button" class="btn-sm btn  btn-primary dropdown-toggle dropdown-hover dropdown-icon" data-toggle="dropdown">
                                                                <span class="sr-only">Toggle Dropdown</span>
                                                            </button>
                                                            <div class="dropdown-menu" role="menu">
                                                                <a class="dropdown-item btn" href="casino_bets?market_id=<?= $data['market_id'] ?>&page_name=match&game_type=<?= $game_type ?>" class="dropdown-item btn text-uppercase"><?= $game_type ?> BETS</a>
                                                                <a class="dropdown-item btn" href="casino_plus_minus?market_id=<?= $data['market_id'] ?>&page_name=match&game_type=<?= $game_type ?>" class="dropdown-item btn text-uppercase"><?= $game_type ?> PLUS MINUS</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <label><?= $no++ ?></label>
                                                </td>
                                                <td>
                                                    <span><?= $data['id'] ?></span>
                                                </td>
                                                <td><?= strtoupper($data['match_name']) ?></td>
                                                <td><?= $data['match_date'] ?></td>
                                                <?php
                                                if(isset($overall_ledger[$data['market_id']]['total_amount']))
                                                  {
                                                    $ledger=$overall_ledger[$data['market_id']]['total_amount'];
                                                  }
                                                  else
                                                  {
                                                    $ledger=0;
                                                  }
                                                // $ledger = get_data('md_client_position', user_where("market_id='" . $data['market_id'] . "'", 's'), 's', "sum(total_" . $user_type . "_profit) total_amount")['total_amount'];
                                                $ledger = -1 * $ledger;
                                                $total_ledger += $ledger;
                                                ?>
                                                <td class="<?= $ledger > 0 ? 'text-primary' : 'text-danger' ?>"><?= round($ledger, 2) ?></td>
                                            </tr>
                                        <?php } ?>
                                        <tr>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                            <th><?= round($total_ledger, 2) ?></th>
                                        </tr>
                                    </tbody>
                                    <tfoot>

                                    </tfoot>
                                </table>
                            </div>
                            <!-- /.card-body -->
                            <?php if (isset($_GET['page_no'])) {
                                $page_no = $_GET['page_no'];
                                if ($page_no <= 0) {
                                    $page_no = 1;
                                }
                            } else {
                                $page_no = 2;
                            }
                            ?>
                            <div class="card-footer clearfix">
                                <ul class="pagination pagination-sm m-0 float-right">
                                    <?php for ($i = 1; $i <= $total_pages; $i++) {  ?>

                                        <div>
                                            <li class="page-item <?php if ($_GET['page_no'] == $i) echo 'active' ?>">
                                                <a class="page-link" href="casino_list?page_name=casino_list&game_type=<?= $game_type ?>&page_no=<?= $i ?>"><?= $i ?></a>
                                            </li>
                                        </div>
                                    <?php } ?>
                                    <?php if ($page_no >= $total_pages) {
                                        $page_no = $page_no - 1;
                                    }
                                    ?>

                                    <div>
                                        <li class="page-item"><a class="page-link" href="casino_list?page_name=casino_list&game_type=<?= $game_type ?>&page_no=<?= ($page_no + 1); ?>">»</a>
                                        </li>
                                    </div>

                                </ul>
                            </div>

                        </form>
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
</div>

<?php include('footer.php'); ?>