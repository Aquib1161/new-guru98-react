<?php  
   header('location:logout');
?>