<?php
include('include/config.php');
$_GET=sanatize($_GET);
extract($_GET);
if(isset($_GET['page_no']))
{
    $page_no=$_GET['page_no'];
    if($page_no<=0)
    {
    $page_no=1;
    }
}
else
{
    $page_no=1;
}
if(isset($_GET['list_type']) AND !isset($_GET['parent_user_id']))
{
   $user_data=$data=get_data_pagination('users_tbl',user_where("user_type='".$_GET['list_type']."'"),$page_no,"order by user_id desc");

   $fetch_data=$user_data['data'];
   if(isset($_GET['id']))
   {
    $fetch_data=get_data('users_tbl',user_where("user_id='".$_GET['id']."'"));
    $data['total_pages']=1;
   }
}
else
{ 
  $parent_data=get_data('users_tbl',"user_id='".$parent_user_id."'",'s');
  $parent_user_type=$parent_data['user_type'];
  $user_data=$data=get_data_pagination('users_tbl',"user_type='".$_GET['list_type']."' AND ".$parent_user_type."_id='".$parent_user_id."'",$page_no,"order by user_id desc"); 
   $fetch_data=$user_data['data'];
}
$list_type=$_GET['list_type'];
$list_type_priority=priority($list_type);
$total_pages=$data['total_pages']; 
$down_priority_name=priority_name((priority($_GET['list_type'])-1));
$label_name=ucfirst(label_name($_GET['list_type']));



$role=$_GET['page_name'];
$creater_priority=priority($role);
$user_priority=priority($_SESSION['user_type']);
$check_priority=$user_priority-$creater_priority;
if($check_priority<1)
{
    invalid();
}
$priority_name=priority_name((priority($role)+1));

if($check_priority!=1)
{
    $upline_data=get_data('users_tbl',user_where("user_type='".$priority_name."'"));
}

include('header.php');
?>
 <?php if($check_priority!=1 AND !isset($_GET['user_id'])){?>
  <div class="modal fade" id="modal-default">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Select <?= ucfirst($priority_name) ?></h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
                                <select id="parent_id" class="form-control select2" required="">
                                  <?php foreach ($upline_data as $key => $upline) { ?>
                                    <option value="<?= $upline['user_id'] ?>"><?= $upline['username'] ?> <?= $upline['name'] ?></option>
                                  <?php } ?>
                                </select>
                            </div>
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              <button onclick="submit()" type="button" class="btn btn-primary">Continue</button>
            </div>
          </div>
        </div>
      </div>
    <?php } ?>

     



<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1><?= ucfirst($list_type)?> Details</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="dashboard?page_name=dashboard">Home</a></li>
              <li class="breadcrumb-item active"><?= ucfirst($list_type)?></li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>


    <section class="content">
       <div class="card">
            <div class="card-header">
              <div class="form-group">
                 <?php if($check_priority!=1 AND !isset($_GET['user_id'])){?>
                 <a href="" data-toggle="modal" data-target="#modal-default" class="btn btn-primary">
                  New <i class="fa fa-plus-circle"></i>
                </a>
              <?php } else{?>

                <a href="create?role=<?= $list_type ?>&page_name=<?= $list_type ?>&list_type=<?= $list_type ?>" class="btn btn-primary">
                  New <i class="fa fa-plus-circle"></i>
                </a>
              <?php } ?>
                <button class="btn btn-success" onclick="bulk_status('active')"  type="submit" name="check" value="1">All Active
                </button>
                <button class="btn btn-danger" id="allInActive" type="submit" name="check" onclick="bulk_status('inactive')">All DeActivate <i class="fa fa-ban"></i></button>
                <a href="limit?page_name=<?= $_GET['page_name'] ?>" class="btn btn-primary"> Limit Update </a>
              </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="example1" class="table table-bordered table-striped">


                <thead>
                <tr>
                  <th><input type="checkbox" id=all_check name="checkbox[]" value=''></th>
                  <th>#</th>
                  <th>CODE</th>
                  <th>Name</th>
                  <th>Mobile</th>
                  <th>Password</th>
                  <th>Limit</th>
                  <th>Match</th>
                  <th>Session</th>
                  <th>Share</th>
                  <th>Status</th>
                </tr>
                </thead>
                <tbody>
                 <?php $s_no=1; foreach ($fetch_data as $key => $user) { extract($user); ?>
                <tr>
                  <td><input id="user_id" class='checkbox' type="checkbox" name="user_id" value=<?= $user['user_id']; ?> > </td>
                  <td>
                      <label><?= $s_no++ ?></label>
                        <div class="btn-group">
                            <button type="button" class="btn btn-xs btn-outline-secondary dropdown-toggle dropdown-hover dropdown-icon" data-toggle="dropdown">
                             <span class="sr-only">Toggle Dropdown</span>
                            </button>
                           <div class="dropdown-menu" role="menu">
                            <a class="dropdown-item" href="create?role=<?= $list_type ?>&page_name=<?= $list_type ?>&list_type=<?= $list_type ?>&user_id=<?= $user['user_id'] ?>">Edit</a>
                             <a class="dropdown-item" onclick="status(<?= $user['user_id'] ?>)" id="user_status_<?= $user['user_id'] ?>" href="#"><?php if($user['status']==1){ echo 'Inactive';}else{echo 'Active';}  ?></a>

                              <span>
                               
                               <!--  <a class="dropdown-item" href="#">Agent Limit</a> -->

                                 <?php if($down_priority_name=='client'){?>
                                  <a class="dropdown-item" href="client_limit?page_name=client&list_type=client&parent_user_id=<?= $user['user_id'] ?>" >Client Limit</a>
                                 <?php } else {?>
                                 <a class="dropdown-item" href="limit?page_name=<?= $down_priority_name ?>&parent_user_id=<?= $user['user_id'] ?>"><?= ucfirst($down_priority_name) ?> Limit</a>

                                <?php } ?>

                                   <?php if($down_priority_name=='client'){?>
                          
                            <a class="dropdown-item"  href="client_list?page_name=<?= $down_priority_name ?>&list_type=<?= $down_priority_name ?>&parent_user_id=<?= $user['user_id'] ?>">Downline</a>
                           <?php } else {?>
                              <a class="dropdown-item"  href="list?page_name=<?= $down_priority_name ?>&list_type=<?= $down_priority_name ?>&parent_user_id=<?= $user['user_id'] ?>">Downline</a>
                           <?php } ?>
                                <a class="dropdown-item" onclick="send_login_details('<?= $user['user_id'] ?>')" href="#">Send Login Details(SMS)</a>
                                <a class="dropdown-item" href="#">Super Emergency</a>
                              </span>

                            </div>
                        </div>
                    </td>
                  <td><?= $user['username'] ?></td>
                  <td><?= $user['name'] ?></td>
                  <td><?= $user['mobile'] ?></td>
                  <td><?= $user['password'] ?></td>
                  <td><?= number_format($total_coins,1) ?></td>
                  <td><?= number_format($user_match_comm,1) ?></td>
                  <td><?= number_format($user_session_comm,1) ?></td>
                  <td><?= number_format($user_share,1) ?></td>
                  <td>
                    <div>
                        <span class="float-center badge bg-<?= $status==1?'success':'danger' ?>"><?= $status==1?'Active':'InActive' ?></span>
                    </div>
                  </td>
                </tr>
              <?php } ?>
                
                </tfoot>
              </table>
            </div>
            <!-- /.card-body -->
          </div>

    </section>
    <!-- /.content -->
</div>
<script>  

  $("#all_check").click(function()
{
   if($("#all_check").prop('checked') == true)
   {
      $('.checkbox').attr('checked', true);
   }
   else
   {
    $('.checkbox').attr('checked', false);
   }
});


      function submit()
      {
        var parent_id=$('#parent_id').val()
        var role="<?= $_GET['list_type'] ?>"
        window.location.href='create?role='+role+'&page_name='+role+'&parent_id='+parent_id+'&list_type='+role
      }

      function bulk_status(status)
   {       


           if(status=='inactive')
           {
              var answer = window.confirm("INACTIVE KARNE PAR SAARI DOWNLINEKILIMIT ZERO HO JAYEGI")
                    if (answer) 
                    {
                        //some code
                    }
                    else 
                    {
                       return false;
                    }
           }


            id_array=[];
            $("input:checkbox[name=user_id]:checked").each(function(){
                        id_array.push($(this).val());
            });

            const count=id_array.length
            if(count==0)
            {
              alert('Please select atleast one client');
              return false;
            }


           sendData={
            'id_array':id_array,
            'status':status
           }
           data = sendAjax('ajax/status_update',sendData);
           if(data.status=='success')
           {
            location.reload()
           }
   }



function update_coins()
{
    var user_id=$("#user_id").val()
    var current_coins=parseInt($('#current_coins').val())
    var operation_type=$("#type").html()
    var update_coins=parseInt($("#update_coins").val())   
    var coins_to_updated='';
    if(operation_type=='withdraw')
    {
        coins_to_updated=current_coins-update_coins
    }
    else
    {
        coins_to_updated=current_coins+update_coins
    }

              $.ajax({
                    url : "ajax/update_limit",
                    type : "post",
                    dataType: 'json',
                    data : {type:'fix_limit',user_id:user_id,fix_limit:update_coins,update_limit:update_coins,is_client:false,operation_type:operation_type},
                    success : function(res){
                       var status=res.status;    
                       if(status=='success')
                       {
                        swal("Updated!",res.data.msg, status);
                        $("#myModal").modal('hide');
                        $("#update_coins").val('')
                        $('#user_coins_'+user_id).html(coins_to_updated);
                       }
                       else
                       {
                        swal("Failed!",res.data.msg, status);
                        $("#myModal").modal('hide');
                        $("#update_coins").val('')
                       }   
                    }
                });        
    
}

function send_login_details(user_id)
{
                   sendData={
                          'login_details':true,
                          'user_id':user_id,
                         }

                       data = sendAjax('ajax/update_by_ajax',sendData);

                       notify("success","Credential Send Successfully");
}


function status(user_id)
{
  var status=$("#user_status_"+user_id).html();
  var status_to_be_update=0;
  var show_status='Inactive';
  var show_change_status='Active';
  if(status=='Active')
  {
   status_to_be_update=1;
   show_status='Active'
   show_change_status='Inactive';
  }
  

                        sendData={
                          'update_status':status_to_be_update,
                          'user_id':user_id,
                         }
                       data = sendAjax('ajax/update_by_ajax',sendData);
                       if(data.status=='success')
                       {
                       $("#show_status_"+user_id).html(show_status);
                       $("#user_status_"+user_id).html(show_change_status);
                       window.location.reload()
                       }
}




$(document).ready(function call(){
     
     var user_user_id="<?= $_GET['list_type'] ?>";
     var page_name="<?= $_GET['page_name'] ?>";


            $(".select").change(function(){
               var user_id = $("#change_id").val();
               var location="list?page_name="+page_name+"&list_type="+user_type+"&page_no=1"

              if(user_id=='all')
              { 
                window.location.href =location ;
                //location.href = location.href + "?var1=command_column"
              }
              else
              {
               window.location.href = location+'&id='+user_id;
              }
            });
        });

</script>
         
<?php include('footer.php'); ?>