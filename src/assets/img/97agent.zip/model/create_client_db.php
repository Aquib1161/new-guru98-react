<?php
include('../include/config.php');

if(!isset($_POST))
{
	invalid();
}
$post_array=sanatize($_POST['user']);
$parent_user_id=$_POST['parent_user_id'];
$page_name=$post_array['page_name'];
$role=$post_array['role'];
unset($post_array['page_name']);
unset($post_array['role']);
$parent_result=get_user_list('',$_POST['parent_user_id']);
if($parent_result['user_share_type']=='fixed')
{
    $_POST['shareagent']=$parent_result['user_share'];
    $_POST['user_casino_share']=$parent_result['user_casino_share'];
}

if(isset($_POST['user_casino_share']))
{
    unset($_POST['user_casino_share']);
}


if(isset($_POST['shareagent']) AND ($_POST['shareagent']<=$parent_result['user_share']))
{
  $_POST['MatchShare']=$post_array['MatchShare']=$_POST['shareagent'];
}
else
{
$_POST['MatchShare']=$post_array['MatchShare']=$parent_result['user_share'];
}



if($post_array['ClientName']=="" ||  $post_array['password']=="")
			{
				$_SESSION['notify']=['type'=>'error','msg'=>'Something went wrong!'];
				header("location:../create_client?role=".$role."&page_name=".$page_name."&parent_id=".$parent_user_id."");
				exit();
			}


			if(($post_array['MatchCommissionClient'] > $parent_result['user_match_comm']) OR ($post_array['SessionCommissionClient'] > $parent_result['user_session_comm']))
			{
				
				$_SESSION['notify']=['type'=>'error','msg'=>'Client commission can not be greather than user commission'];
				header("location:../create_client?role=".$role."&page_name=".$page_name."&parent_id=".$parent_user_id."");
				exit();
			}

        

            if($post_array['ClientMobileCharge']>$parent_result['user_mobile_share'])

            {
                $_SESSION['notify']=['type'=>'error','msg'=>'Client mobile charge can not be grather than user mobile charge'];
                header("location:../create_client?role=".$role."&page_name=".$page_name."&parent_id=".$parent_user_id."");
                exit();
            }


       if($post_array['SessionCommissionTypeClient']=='OM')
       {
        $post_array['SessionCommissionClient']=$post_array['MatchCommissionClient'];
       }

       if($post_array['SessionCommissionTypeClient']=='No Comm')
       {
        $post_array['SessionCommissionClient']=0;
        $post_array['MatchCommissionClient']=0;
       }


if($post_array['id']=='')
{
unset($post_array['id']);
$post_array['ClientCode']=$post_array['username']=get_code('client');
$post_array['doj']=_date_time();
$post_array['rate']='0.01';
$post_array['AutoLimit']='YES';
$post_array['auto_limit']='YES';
$post_array['operator']=$_POST['parent_user_id'];
$post_array['MobApp']='YES';
$post_array['agent_share']=$parent_result['user_share'];
$post_array['operator_role']=$parent_result['user_type'];
$post_array['creater_id']=$parent_result['user_id'];
$post_array['created_by_id']=$_SESSION['user_id'];
$post_array['FixLimit']=$_POST['client_update_limit'];
$post_array['user_type']='client';
$result=insert_array('client',$post_array,'');

$insert_id=$result['insert_id'];

$return_post=update_details($insert_id,$post_array,$parent_result);
$return_post['no_comm_perm']=$parent_result['no_comm_perm'];
$data= update_array('client', $return_post,'id='.$insert_id.'');



$share_update=client_share_array_update($insert_id);



    $data_array=array(
                    'client'=>$post_array['ClientName'].'('.$post_array['ClientCode'].')',
                    'old'=>'',
                    'new'=>'',
                    'user'=>$userdata['username'],
                    'note'=>'Client Created By '.$userdata['name'],
                    'type'=>'create',
                    'date'=>_date(),
                    'time'=>_time(),
                    'date_time'=>_date_time()
                );


$task_array=array(
	'client_id'=>$insert_id,
    'user_type'=>$post_array['user_type'],
    'user_match_comm'=>$post_array['MatchCommissionClient'],
    'user_session_comm'=>$post_array['SessionCommissionClient'],
    'user_share'=>$post_array['MatchShare'],
    'task_name'=>'Client Created',
    'creater_id'=>$_SESSION['user_id'],
    'creater_type'=>$_SESSION['user_type'],
    'creater_name'=>$_SESSION['name'],
    'ip'=>ip(),
    'date'=>_date(),
    'date_time'=>_date_time(),
    'user_name'=>$post_array['ClientName'],
    'data_array'=>json_encode($data_array)
);
$result=insert_array('user_history_log',$task_array,'');

if($_POST['client_update_limit']!=0)
{
$update_status=update_client_coins($insert_id,$_POST['client_update_limit'],'deposit');
$coins_status=$update_status['status'];
}

$coins_array=array(
    'client_id'=>$insert_id,
    'total_coins'=>$_POST['client_update_limit'],
    'user_type'=>'client'
);
//insert_array('coins_management',$coins_array);
$_SESSION['notify']=['type'=>'success','msg'=>'client created successfully'];
header("location:../client_list?list_type=client&page_name=client");
}
else
{   

    
    $post_array['SessionCommissionTypeClient']=$post_array['SessionCommissionTypeClient']=='Bet By Bet'?'BB':$post_array['SessionCommissionTypeClient'];


    $client_data=get_data('client',"id='".$post_array['id']."'",'s');
    $parent_result=get_data('users_tbl',"user_id='".$client_data['creater_id']."'",'s');
    $parent_show_type=$parent_result['user_type']=='superagent'?'sa':$parent_result['user_type'];

    if(($post_array['MatchCommissionClient'] > $parent_result['user_match_comm']) OR ($post_array['SessionCommissionClient'] > $parent_result['user_session_comm']))
            {  
                $_SESSION['notify']=['type'=>'error','msg'=>'Client commission can not be greather than user commission'];
                header("location:../create_client?list_type=client&page_name=client&role=client&user_id=".$client_data['id']."&parent_id=".$parent_user_id."");
                exit();
            }

            if($post_array['ClientMobileCharge']>$parent_result['user_mobile_share'])
            {
                $_SESSION['notify']=['type'=>'error','msg'=>'Client mobile charge can not be grather than user mobile charge'];
                 header("location:../create_client?list_type=client&page_name=client&role=client&user_id=".$post_array['id']."&parent_id=".$parent_user_id."");
                exit();
            }
            unset($post_array['user_type']);
            unset($post_array['MatchShare']);

            if($client_data['SessionCommissionTypeClient']=='No Co')
            {
                $client_data['SessionCommissionTypeClient']='No Comm';
            }


            if($post_array['SessionCommissionTypeClient']!=$client_data['SessionCommissionTypeClient'])
            {
                if($post_array['SessionCommissionTypeClient']=='No Comm')
                {
                    $post_array['MatchCommissionClient']=0;
                    $post_array['SessionCommissionClient']=0;
                }
                if($post_array['SessionCommissionTypeClient']=='OM')
                {
                    $post_array['SessionCommissionClient']=$post_array['MatchCommissionClient'];
                }

                $update_array=array(
                    'MatchCommissionClient'=>$post_array['MatchCommissionClient'],
                    'SessionCommissionClient'=>$post_array['SessionCommissionClient'],
                    'SessionCommissionTypeClient'=>$post_array['SessionCommissionTypeClient']
                );

                update_array('client',$update_array,"id='".$client_data['id']."'");

                $data_array=array(
                    'client'=>'('.$client_data['ClientCode'].') '.$client_data['ClientName'].'',
                    'old'=>$client_data['agent_share'],
                    'new'=>$_POST['shareagent'],
                    'user'=>$userdata['username'],
                    'note'=>'Client ('.$client_data['ClientCode'].') '.$client_data['ClientName'].' Commission Type change from '.$client_data['SessionCommissionTypeClient'].' To '.$_POST['SessionCommissionTypeClient'],
                    'type'=>'commission_type'
                );
                $task_array=array(
                    'client_id'=>$post_array['id'],
                    'task_name'=>'Client ('.$client_data['ClientCode'].') '.$client_data['ClientName'].' Commission Type change from '.$client_data['SessionCommissionTypeClient'].' To '.$_POST['SessionCommissionTypeClient'],
                    'user_type'=>'client',
                    'creater_id'=>$_SESSION['user_id'],
                    'creater_type'=>$_SESSION['user_type'],
                    'creater_name'=>$_SESSION['name'],
                    'ip'=>ip(),
                    'date'=>_date(),
                    'date_time'=>_date_time(),
                    'user_name'=>$post_array['ClientName'],
                    'history_type'=>'commission_type',
                    'data_array'=>json_encode($data_array),
                    'agent_id'=>$client_data['A_id'],
                    'sa_id'=>$client_data['sa_id'],
                    'master_id'=>$client_data['master_id'],
                    'admin_id'=>$client_data['admin_id'],
                    'superadmin_id'=>$client_data['superadmin_id'],
                );
                $result=insert_array('user_history_log',$task_array);
            }





            if(isset($_POST['shareagent']) AND ($_POST['shareagent']!=$client_data['agent_share']))
            {   
                if($_POST['shareagent']> $parent_result['user_share'])
                {

                    $_SESSION['notify']=['type'=>'error','msg'=>'Client share can not be grather than your share'];
                    header("location:../create_client?list_type=client&page_name=client&role=client&user_id=".$post_array['id']."");
                    exit();

                }

            
                $upper_share_total=$parent_result['user_share']-$_POST['shareagent'];
                $post_array['MatchShare']=$_POST['shareagent'];
                $post_array['MatchShare2']=$_POST['shareagent'];
                $post_array['agent_share']=$_POST['shareagent'];
                $post_array['agent_share_total_value']=$_POST['shareagent'];
                $post_array['sa_share']=$parent_result['sa_share']-$_POST['shareagent'];
                $data_array=array(
                    'client'=>'('.$client_data['ClientCode'].') '.$client_data['ClientName'].'',
                    'old'=>$client_data['agent_share'],
                    'new'=>$_POST['shareagent'],
                    'user'=>$userdata['username'],
                    'note'=>'Client ('.$client_data['ClientCode'].') '.$client_data['ClientName'].' share change from '.$client_data['agent_share'].' To '.$_POST['shareagent'],
                    'type'=>'shares'
                );
                $task_array=array(
                    'client_id'=>$post_array['id'],
                    'task_name'=>'Client ('.$client_data['ClientCode'].') '.$client_data['ClientName'].' share change from '.$client_data['MatchShare'].' To '.$_POST['shareagent'],
                    'user_type'=>'client',
                    'creater_id'=>$_SESSION['user_id'],
                    'creater_type'=>$_SESSION['user_type'],
                    'creater_name'=>$_SESSION['name'],
                    'ip'=>ip(),
                    'date'=>_date(),
                    'date_time'=>_date_time(),
                    'user_name'=>$post_array['ClientName'],
                    'history_type'=>'match_share',
                    'data_array'=>json_encode($data_array),
                    'agent_id'=>$client_data['A_id'],
                    'sa_id'=>$client_data['sa_id'],
                    'master_id'=>$client_data['master_id'],
                    'admin_id'=>$client_data['admin_id'],
                    'superadmin_id'=>$client_data['superadmin_id'],
                );
                $result=insert_array('user_history_log',$task_array);
                client_share_array_update($post_array['id']);
                unset($_POST['shareagent']); 
            }

           

             if($post_array['MatchCommissionClient']!=$client_data['MatchCommissionClient'])
             {
                 
                 $update_array=array(
                    'MatchCommissionClient'=>$post_array['MatchCommissionClient']
                 );
                 $data= update_array('client', $update_array,'id='.$post_array['id']);
                 
                 $data_array=array(
                    'client'=>'('.$client_data['ClientCode'].') '.$client_data['ClientName'].'',
                    'old'=>$client_data['MatchCommissionClient'],
                    'new'=>$post_array['MatchCommissionClient'],
                    'user'=>$userdata['username'],
                    'note'=>'Client ('.$client_data['ClientCode'].') '.$client_data['ClientName'].' Match Commission change from '.$client_data['MatchCommissionClient'].' To '.$post_array['MatchCommissionClient'],
                    'type'=>'match_commission'
                );
                $task_array=array(
                    'client_id'=>$post_array['id'],
                    'task_name'=>'Client ('.$client_data['ClientCode'].') '.$client_data['ClientName'].' Match Commission change from '.$client_data['MatchCommissionClient'].' To '.$post_array['MatchCommissionClient'],
                    'user_type'=>'client',
                    'creater_id'=>$_SESSION['user_id'],
                    'creater_type'=>$_SESSION['user_type'],
                    'creater_name'=>$_SESSION['name'],
                    'ip'=>ip(),
                    'date'=>_date(),
                    'date_time'=>_date_time(),
                    'user_name'=>$post_array['ClientName'],
                    'history_type'=>'match_commission',
                    'data_array'=>json_encode($data_array),
                    'agent_id'=>$client_data['A_id'],
                    'sa_id'=>$client_data['sa_id'],
                    'master_id'=>$client_data['master_id'],
                    'admin_id'=>$client_data['admin_id'],
                    'superadmin_id'=>$client_data['superadmin_id'],
                );
                $result=insert_array('user_history_log',$task_array);

                unset($post_array['MatchCommissionClient']);
             }

             if(is_casino)
            {
                if($post_array['casino_bet_status']!=$client_data['casino_bet_status'])
                {   

                    $return=client_casino_bet_status($client_data['id'],$post_array['casino_bet_status'],$client_data);
                    $_SESSION['notify']=['type'=>'success','msg'=>'casino permission changed successfully'];
                }
            }

             if($post_array['SessionCommissionClient']!=$client_data['SessionCommissionClient'])
             {
                 
                 $update_array=array(
                    'SessionCommissionClient'=>$post_array['SessionCommissionClient']
                 );
                 $data= update_array('client', $update_array,'id='.$post_array['id']);
                 
                 $data_array=array(
                    'client'=>'('.$client_data['ClientCode'].') '.$client_data['ClientName'].'',
                    'old'=>$client_data['SessionCommissionClient'],
                    'new'=>$post_array['SessionCommissionClient'],
                    'user'=>$userdata['username'],
                    'note'=>'Client ('.$client_data['ClientCode'].') '.$client_data['ClientName'].' Session Commission change from '.$client_data['SessionCommissionClient'].' To '.$post_array['SessionCommissionClient'],
                    'type'=>'match_commission'
                );
                $task_array=array(
                    'client_id'=>$post_array['id'],
                    'task_name'=>'Client ('.$client_data['ClientCode'].') '.$client_data['ClientName'].' Session Commission change from '.$client_data['SessionCommissionClient'].' To '.$post_array['SessionCommissionClient'],
                    'user_type'=>'client',
                    'creater_id'=>$_SESSION['user_id'],
                    'creater_type'=>$_SESSION['user_type'],
                    'creater_name'=>$_SESSION['name'],
                    'ip'=>ip(),
                    'date'=>_date(),
                    'date_time'=>_date_time(),
                    'user_name'=>$post_array['ClientName'],
                    'history_type'=>'session_commission',
                    'data_array'=>json_encode($data_array),
                    'agent_id'=>$client_data['A_id'],
                    'sa_id'=>$client_data['sa_id'],
                    'master_id'=>$client_data['master_id'],
                    'admin_id'=>$client_data['admin_id'],
                    'superadmin_id'=>$client_data['superadmin_id'],
                );
                $result=insert_array('user_history_log',$task_array);

                unset($post_array['SessionCommissionClient']);
             }



    $post_array['update_date']=_date_time();
	$data= update_array('client', $post_array,'id='.$post_array['id']);
    $share_update=client_share_array_update($post_array['id']);
	$_SESSION['notify']=['type'=>'success','msg'=>'Client '.$client_data['ClientCode'].' Updated Successfully'];
    header("location:../create_client?list_type=client&page_name=client&role=client&user_id=".$post_array['id']."");
}

?>
