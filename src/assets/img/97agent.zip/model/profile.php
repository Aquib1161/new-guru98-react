<?php 
include('include/config.php');
include('header.php');
$total_coins_given=call_total_coins($_SESSION['user_type'],$_SESSION['user_id']);
//$total_used_coins=used_coins($_SESSION['user_id'],$_SESSION['user_type']);
$total_coins=$total_coins_given;  
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <br>
    <section class="content">
            <div class="container-fluid">
                <div class="row">


                    <div class="col-lg-4">
                        <!-- Profile Image -->
                        <div class="card card-primary card-outline">
                            <div class="card-body box-profile">
                                <div class="text-center">
                                    <img class="profile-user-img img-fluid img-circle" src="dist/img/user4.jpg" alt="User profile picture">
                                </div>

                                <h3 class="profile-username text-center"><?= $userdata['username']?> <?= $userdata['name']?></h3>

                                <p class="text-muted text-center"><?= $userdata['user_type']?> Agent</p>

                                <ul class="list-group list-group-unbordered mb-3">
                                    <li class="list-group-item">
                                        <b>Share</b> <a class="float-right"><?= number_format($userdata['user_share'],1)?></a>
                                    </li>
                                    <li class="list-group-item">
                                        <b>Match Commission</b> <a class="float-right"><?= number_format($userdata['user_match_comm'],1)?></a>
                                    </li>
                                    <li class="list-group-item">
                                        <b>Session Commission</b> <a class="float-right"><?= number_format($userdata['user_session_comm'],1)?></a>
                                    </li>
                                    <li class="list-group-item">
                                        <b>Mobile Share</b> <a class="float-right"><?= number_format($userdata['user_mobile_share'],1)?></a>
                                    </li>
                                </ul>

                                <a href="password?all" class="btn btn-primary btn-block"><b>Change Password</b></a>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>


                    <!-- About Me Box -->
                    <div class="card card-primary col-lg-4">
                        <div class="card-header">
                            <h3 class="card-title">About Me</h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <strong><i class="fas fa-id-card"></i> Profile</strong>

                            <p class="text-muted"><?= $userdata['username'] ?> <?= $userdata['name'] ?></p>

                            <hr>

                            <strong><i class="fas fa-coins"></i> <label>Current Limit : <?= number_format($total_coins,1); ?></label></strong>


                            <hr>

                            <strong><i class="fas fa-pencil-alt mr-1"></i> Contact No</strong>

                            <p class="text-muted">
                                <span class="tag tag-danger"><?= $userdata['mobile'] ?></span>
                            </p>

                            <hr>

                            <strong><i class="far fa-file-alt mr-1"></i> Date Of Joining</strong>

                            <p class="text-muted"><?= $userdata['insert_date_time'] ?></p>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->


                </div>
            </div>
        </section>
  </div>
  <!-- /.content-wrapper -->

  <?php  include('footer.php');  ?>