<?php 
include('include/config.php');
include('header.php');
sanatize($_GET);
extract($_GET);
extract($_POST);
if(!isset($login_report_type))
{
  invalid();
}

$user_data=downline_data($login_report_type);
if(isset($_POST['submit']))
{
  $_POST['to_date']=date_convert($_POST['to_date']);
  $_POST['from_date']=date_convert($_POST['from_date']);
  $page_name=$_POST['page_name'];
  if($_POST['to_date']=='13-03-2022')
  {
    $_POST['to_date']=_date();
  }
  extract($_POST);
  $where="date BETWEEN '".$from_date."' AND '".$to_date."'";
  if($user_id!='all')
  {
    $where=$where." AND user_id='".$user_id."'";
  }
  else
  {
    $where=$where." AND creater_id='".$userdata['user_id']."'";
  }

  if($_POST['login_report_type']!='client')
  {
    $data=get_data('user_login_details',$where);
  }
  else
  { 
        $where="insert_time BETWEEN '".$from_date."' AND '".$to_date."' AND client_id='".$_POST['user_id']."'";
        $client_data=get_data('login_details',$where);
        $data=array();
        foreach ($client_data as $key => $value) 
        {   
           $send_array=array(
            'user_code'=>$value['client_details'],
            'name'=>$value['client_details'],
            'ip_address'=>$value['ip_address'],
            'date_time'=>$value['insert_time']
           );

           array_push($data,$send_array);
            
        }


  }
}
else
{
  $_POST['from_date']='dd-mm-yyyy';
  $_POST['to_date']='dd-mm-yyyy';
  $_POST['user_id']='';
  $page_name=$_GET['page_name'];
  $data=array();
}

?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Login Report</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="dashboard?page_name=dashboard">Home</a></li>
              <li class="breadcrumb-item active">Login Report</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">

                        <!-- /.card -->

                        <div class="card">


                            <form action="login_report" method="post">
                                <div class="card-header bg-gradient-purple">
                                  <input type="hidden" value="<?= $login_report_type ?>" name="login_report_type">
                                  <input type="hidden" value="<?= $page_name ?>" name="page_name">
                                  
                                    <div class="form-row">
                                        <div class="form-group col-md-3">
                                            <label for="name"><?= ucfirst($login_report_type)?></label>
                                           <select   class="form-control select2" required="" id="user_id" placeholder="Select ...." name="user_id" >
                                              <option value="">Select ...</option>
                                                <?php foreach ($user_data as $key => $user) { ?>
                                                 <option <?php if($_POST['user_id']==$user['user_id']) echo 'selected'; ?> value="<?= $user['user_id']?>"><?= $user['name']?> (<?= $user['username']?>)</option>
                                                 <?php  }  ?>
                                                
                                            </select>
                                        </div>

                                        <div class="form-group col-md-2">
                                            <div class="form-group">
                                                <label for="from_date">Date From</label>
                                                <div >

                                                    <input type="date" class="form-control" id="from_date"  name="from_date" value="<?= $_POST['from_date'] ?>">

                                                    <div class="input-group-append" data-target="#reservationdateTo" data-toggle="datetimepicker">
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group col-md-2">
                                            <div class="form-group">
                                                <label for="to_date">Date To</label>
                                                <div >

                                                    <input type="date" class="form-control" id="to_date"  name="to_date" value="<?= $_POST['to_date'] ?>">

                                                    <div class="input-group-append" data-target="#reservationdateTo" data-toggle="datetimepicker">
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group col-md-3">

                                            <label class="control-label text-purple" for="btn">`</label>
                                            <input type="submit" class="form-control btn-primary" id="btn" name="submit" value="Sumbit">

                                        </div>


                                    </div>


                                </div>
                                <!-- /.card-header -->

                                <div class="card-body">
                                    <table  class="table table-bordered table-striped">
                                        <thead class="bg-gradient-yellow">
                                        <tr>

                                            <th>#</th>
                                            <th>Code</th>
                                            <th>Login Name</th>
                                            <th>IPAddress</th>
                                            <th>DateTime</th>
                                            <th>Last Activity</th>

                                        </tr>
                                        </thead>
                                        <tbody>

                                          <?php $no=1; foreach ($data as $key => $value) { ?>
                                         


                                        <tr>
                                            <td><?= $no++ ?></td>
                                            <td><?= $value['user_code'] ?></td>
                                            <td><?= strtoupper($value['name']) ?></td>
                                            <td><?= $value['ip_address'] ?></td>
                                            <td><?= $value['date_time'] ?></td>
                                            <td><?= $value['date_time'] ?></td>
                                        </tr>

                                      <?php } ?>


                                       


                                        </tbody>
                                        <tfoot>

                                        </tfoot>
                                    </table>
                                </div>


                           
                                <!-- /.card-body -->
                            </form>

                        </div>
                        <!-- /.card -->


                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </section>

   

   
  </div>
  <!-- /.content-wrapper -->

  <?php  include('footer.php');  ?>