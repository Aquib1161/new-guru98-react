<?php include('../include/config.php');

$_POST=sanatize($_POST);
$_GET=sanatize($_GET);

$market_id = $_POST['market_id'];
$selection_id = $_POST['selection_id'];
$decision_run =$_POST['desicion_run'];
/*echo $decision_run;
die;*/


$query= "DELETE FROM transaction_log WHERE overall_type='SC' AND match_id='$market_id' AND selection_id='$selection_id'";
   mysqli_query($con,$query);
   $query= "DELETE FROM transaction_log WHERE overall_type='SCC' AND match_id='$market_id' AND selection_id='$selection_id'";
   mysqli_query($con,$query);	

$decision1 = "UPDATE session_crick_tbl SET decision_run = '$decision_run' , api_active='0'  WHERE  market_id = '$market_id' AND  selection_id = '$selection_id' ";
$res1 = mysqli_query($con,$decision1);
	

$decision = "UPDATE client_session_bat_tbl SET decision_run = '$decision_run'  WHERE  market_id = '$market_id' AND  selection_id = '$selection_id' ";
$res = mysqli_query($con,$decision);
	
$qurey = "SELECT * FROM client_session_bat_tbl WHERE  market_id = $market_id AND selection_id = '$selection_id' ";
$res = mysqli_query($con,$qurey);	

$qurey = "SELECT commission_permission FROM session_crick_tbl WHERE  market_id = $market_id AND selection_id = '$selection_id' ";
$sess_res = mysqli_query($con,$qurey);
$commission_permission=mysqli_fetch_assoc($sess_res)['commission_permission'];

$decision = array();
$client_wise = array();

while ($data = mysqli_fetch_assoc($res)) {

	//_dx($data);

	

	if(!array_key_exists($data['client_id'], $client_wise)){
		$client_wise[$data['client_id']] = array(
			"debit" => 0, 
			"credit"=>0, 
			"bet_commission" => 0,
			"commission_type" => $data['commission_type'],
			"agent_id"=>$data['agent_id'],
			"runner_name"=>$data['runner_name'],
			"super_agent_id"=>$data['super_agent_id'],
			"master_id"=>$data['master_id'],
			"admin_share"=>$data['admin_share'],
			"master_share"=>$data['master_share'],
			"sa_share"=>$data['sa_share'],
			"agent_share"=>$data['agent_share'],
			"auto_limit"=>$data['auto_limit']

		);
	}

	if ($data['type']  == 'Y' && $data['decision_run'] >=  $data['bet_run']){
		$client_wise[$data['client_id']]['credit'] += floatval($data['pass_amount']);
		$client_wise[$data['client_id']]['bet_commission'] += floatval($data['commission']/100)*(int)$data['amount'];


		
	}

	if ($data['type']  == 'N' && $data['decision_run'] <  $data['bet_run']){
		$client_wise[$data['client_id']]['credit'] += floatval($data['pass_amount']);
		$client_wise[$data['client_id']]['bet_commission'] += floatval($data['commission']/100)*(int)$data['amount'];

	}



	if ($data['type']  == 'Y' && $data['decision_run'] <  $data['bet_run'])
  {
		$client_wise[$data['client_id']]['debit'] += floatval($data['fail_amount']);
		$client_wise[$data['client_id']]['bet_commission'] += floatval($data['commission']/100)*$data['amount'];	
	}
//_d($client_wise[$data['client_id']]['bet_commission']);

	if ($data['type']  == 'N' && $data['decision_run'] >=  $data['bet_run'])
  {
		$client_wise[$data['client_id']]['debit'] += floatval($data['fail_amount']);
		$client_wise[$data['client_id']]['bet_commission'] += floatval($data['commission']/100)*(int)$data['amount'];

	}


	
}





foreach ($client_wise as $clid => $crdb) {
	$debit = $crdb['debit'];
	$credit = $crdb['credit'];
	$agent_id = $crdb['agent_id'];
	$runner_name = $crdb['runner_name'];
	$sa_id = $crdb['super_agent_id'];
	$master_id = $crdb['master_id'];
	$admin_share = $crdb['admin_share'];
	$master_share = $crdb['master_share'];
	$sa_share = $crdb['sa_share'];
	$agent_share = $crdb['agent_share'];
	$auto_limit = $crdb['auto_limit'];

	

$query="SELECT * FROM shares WHERE market_id='$market_id' AND client_id='$clid'";
	$res=mysqli_query($con,$query);
	$share=mysqli_fetch_assoc($res);

	$admin_share=$share['admin_share'];
	$master_share=$share['master_share'];
	$sa_share=$share['sa_share'];
	$agent_share=$share['agent_Share'];
	$agent_commission_type=$share['agent_commission_type'];
    $sa_commission_type=$share['sa_commission_type'];
    $master_commission_type=$share['master_commission_type'];
    $agent_match_commission=$share['agent_match_commission'];
    $sa_match_commission=$share['sa_match_commission'];
    $master_match_commission=$share['master_match_commission'];
    $agent_session_commission=$share['agent_session_commission'];
    $sa_session_commission=$share['sa_session_commission'];
    $master_session_commission=$share['master_session_commission'];


	  $admin_amount = ($admin_share / 100) * $debit;
    $admin_amount=round($admin_amount,2);
    $master_amount = ($master_share / 100) * $debit;
    $master_amount=round($master_amount,2);
    $sa_amount = ($sa_share / 100) * $debit;
    $sa_amount=round($sa_amount,2);
    $agent_amount = ($agent_share / 100) * $debit;
    $agent_amount=round($agent_amount,2);


    $query="SELECT * FROM transaction_log WHERE client_id = '$clid' AND  selection_id = '$selection_id'   AND overall_type = 'SD' ";
    $c_res=mysqli_query($con,$query);
    $count_res=mysqli_num_rows($c_res);

    
    if($count_res==0)
    {
   $updatequery = "INSERT INTO  transaction_log  (amount,user_type,transaction_type,client_id,admin_id,sa_id,master_id,agent_id,remark,for_bet,selection_id,match_id,overall_type, is_declare,admin_share,master_share,sa_share,agent_share,auto_limit,admin_amount,master_amount,sa_amount,agent_amount)  VALUE  ($debit,'CLIENT','C','$clid','1','$sa_id','$master_id','$agent_id','$runner_name','1','$selection_id','$market_id','SD', '1','$admin_share','$master_share','$sa_share','$agent_share','$auto_limit','$admin_amount','$master_amount','$sa_amount','$agent_amount')";
    }
    else
    {

  $updatequery = "UPDATE transaction_log SET amount = $debit, admin_amount='$admin_amount', master_amount='$master_amount',sa_amount='$sa_amount',agent_amount='$agent_amount', for_bet = '1', remark ='$runner_name', is_declare='1'  WHERE  client_id = '$clid' AND  selection_id = '$selection_id'   AND overall_type = 'SD' ";

    }
   // _dx($updatequery);
    $res= mysqli_query($con,$updatequery);


   


    




    $admin_amount = ($admin_share / 100) * $credit;
    $admin_amount=round($admin_amount,2);
    $master_amount = ($master_share / 100) * $credit;
    $master_amount=round($master_amount,2);
    $sa_amount = ($sa_share / 100) * $credit;
    $sa_amount=round($sa_amount,2);
    $agent_amount = ($agent_share / 100) * $credit;
    $agent_amount=round($agent_amount,2);

$insertquery = "INSERT INTO  transaction_log  (amount,user_type,transaction_type,client_id,admin_id,sa_id,master_id,agent_id,remark,for_bet,selection_id,match_id,overall_type, is_declare,admin_share,master_share,sa_share,agent_share,auto_limit,admin_amount,master_amount,sa_amount,agent_amount)  VALUE  ($credit,'CLIENT','C','$clid','1','$sa_id','$master_id','$agent_id','$runner_name','1','$selection_id','$market_id','SC', '1','$admin_share','$master_share','$sa_share','$agent_share','$auto_limit','$admin_amount','$master_amount','$sa_amount','$agent_amount')";

$res= mysqli_query($con,$insertquery);

	$commission = 0;
	$agent_amount=0;
	$sa_amount=0;
	$master_amount=0;
	$admin_amount=0;
if ($crdb['commission_type'] == 'BB') {
	$commission = $crdb['bet_commission'];

}

if ($crdb['commission_type'] == 'OM' && $crdb['debit'] >  $crdb['credit']) {
	$commission = $crdb['bet_commission'];

}




        if($agent_commission_type=='BB'){

            $query = "SELECT SUM(amount)  total_bet_amount FROM client_session_bat_tbl WHERE  client_id = '$clid' AND market_id='$market_id' AND selection_id='$selection_id' "; 
            $res = mysqli_query($con, $query);
            $total_bet_amount = mysqli_fetch_assoc($res)['total_bet_amount'];
            $agent_session_commission=($agent_session_commission/100);
 
          $agent_amount=($total_bet_amount*$agent_session_commission);
          $agent_amount=round($agent_amount,2);
          }

           if($agent_commission_type=='OM' && $crdb['debit'] >  $crdb['credit']){
	         $agent_session_commission=($agent_session_commission/100);

          $agent_amount=(($crdb['debit']-$crdb['credit'])*$agent_session_commission);
          $agent_amount=round($agent_amount,2);

        }

        if($sa_commission_type=='BB'){

            $query = "SELECT SUM(amount)  total_bet_amount FROM client_session_bat_tbl WHERE  client_id = '$clid' AND market_id='$market_id' AND selection_id='$selection_id' "; 
            $res = mysqli_query($con, $query);
            $total_bet_amount = mysqli_fetch_assoc($res)['total_bet_amount'];
            $sa_session_commission=($sa_session_commission/100);
 
          $sa_amount=($total_bet_amount*$sa_session_commission);
          $sa_amount=round($sa_amount,2);
          }

           if($sa_commission_type=='OM' && $crdb['debit'] >  $crdb['credit']){
	         $sa_session_commission=($sa_session_commission/100);

          $sa_amount=(($crdb['debit']-$crdb['credit'])*$sa_session_commission);
          $sa_amount=round($sa_amount,2);

        }


        if($master_commission_type=='BB'){

            $query = "SELECT SUM(amount)  total_bet_amount FROM client_session_bat_tbl WHERE  client_id = '$clid' AND market_id='$market_id' AND selection_id='$selection_id' "; 
            $res = mysqli_query($con, $query);
            $total_bet_amount = mysqli_fetch_assoc($res)['total_bet_amount'];
            $master_session_commission=($master_session_commission/100);
 
          $master_amount=($total_bet_amount*$master_session_commission);
          $master_amount=round($master_amount,2);
          }

           if($master_commission_type=='OM' && $crdb['debit'] >  $crdb['credit']){
	         $master_session_commission=($master_session_commission/100);

          $master_amount=(($crdb['debit']-$crdb['credit'])*$master_session_commission);
          $master_amount=round($master_amount,2);

        }
        if($master_commission_type=='BB'){

            $query = "SELECT SUM(amount)  total_bet_amount FROM client_session_bat_tbl WHERE  client_id = '$clid' AND market_id='$market_id' AND selection_id='$selection_id' "; 
            $res = mysqli_query($con, $query);
            $total_bet_amount = mysqli_fetch_assoc($res)['total_bet_amount'];
            $master_session_commission=($master_session_commission/100);
 
          $admin_amount=($total_bet_amount*$master_session_commission);
          $admin_amount=round($admin_amount,2);
          }

           if($master_commission_type=='OM' && $crdb['debit'] >  $crdb['credit']){
	         $master_session_commission=($master_session_commission/100);

          $admin_amount=(($crdb['debit']-$crdb['credit'])*$master_session_commission);
          $admin_amount=round($admin_amount,2);

        }



     if(isset($commission_permission) AND $commission_permission=0)
     {
      $admin_amount=0;
      $commission=0;
      $master_amount=0;
      $sa_amount=0;
      $agent_amount=0;
     }

$insertquery = "INSERT INTO  transaction_log  (amount,user_type,transaction_type,client_id,admin_id,sa_id,master_id,agent_id,remark,for_bet,selection_id,match_id,overall_type, is_declare,admin_share,master_share,sa_share,agent_share,auto_limit,admin_amount,master_amount,sa_amount,agent_amount)  VALUE  ('$commission','CLIENT','C','$clid','1','$sa_id','$master_id','$agent_id','$runner_name','1','$selection_id','$market_id','SCC', '1','$admin_share','$master_share','$sa_share','$agent_share','$auto_limit','$admin_amount','$master_amount','$sa_amount','$agent_amount')";
$res= mysqli_query($con,$insertquery);	

$client_id=$clid;

$query2="SELECT * FROM md_client_position WHERE client_id='$client_id' AND market_id=$market_id";
$md_res=mysqli_query($con,$query2);
$count=mysqli_num_rows($md_res);



$query = "SELECT SUM(amount)  total_credit FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'SC' AND match_id='$market_id'AND is_declare='1'"; 
$res = mysqli_query($con, $query);
$credited = mysqli_fetch_assoc($res)['total_credit'];
$query = "SELECT SUM(amount) total_debit FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'SD' AND match_id='$market_id'AND is_declare='1'";
$res = mysqli_query($con, $query);
$debited = mysqli_fetch_assoc($res)['total_debit'];
$total_session_coins = -1*($credited - $debited);


$query = "SELECT SUM(amount)  total_credit  FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'MCC' AND match_id='$market_id'AND is_declare='1'"; 
$res = mysqli_query($con, $query);
$match_commission_credited = mysqli_fetch_assoc($res)['total_credit'];

$query = "SELECT SUM(amount)  total_credit  FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'SCC' AND match_id='$market_id'AND is_declare='1'";
$res = mysqli_query($con, $query);
$session_commission_credited = mysqli_fetch_assoc($res)['total_credit'];

$query = "SELECT SUM(agent_amount)  total_credit  FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'SCC' AND match_id='$market_id'AND is_declare='1'";
  $res = mysqli_query($con, $query);
  $agent_session_commission_credited = mysqli_fetch_assoc($res)['total_credit'];


$query = "SELECT SUM(sa_amount)  total_credit  FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'SCC' AND match_id='$market_id'AND is_declare='1'";
  $res = mysqli_query($con, $query);
  $sa_session_commission_value= mysqli_fetch_assoc($res)['total_credit'];

$query = "SELECT SUM(master_amount)  total_credit  FROM transaction_log WHERE client_id = '$client_id' AND  overall_type = 'SCC' AND match_id='$market_id'AND is_declare='1'";
  $res = mysqli_query($con, $query);
  $master_session_commission_value= mysqli_fetch_assoc($res)['total_credit'];

if($count==0)
{  
    $query2="SELECT ClientName , username FROM client WHERE id='$client_id'";
    $res2=mysqli_query($con,$query2);
    $clientt=mysqli_fetch_assoc($res2);
    $client_name=$clientt['ClientName'];
    $client_code=$clientt['username'];
   $query="INSERT INTO md_client_position (market_id,client_id,agent_id,sa_id,master_id,client_session_coins,client_session_commission,client_name,client_code,agent_session_commission,sa_session_commission,master_session_commission) VALUES ('$market_id','$client_id','$agent_id','$sa_id','$master_id','$total_session_coins','$session_commission_credited','$client_name','$client_code','$agent_session_commission_credited','$sa_session_commission_value','$master_session_commission_value')";
   $res=mysqli_query($con,$query);
}
else
{
   $query="UPDATE md_client_position SET client_session_coins=$total_session_coins , client_session_commission=$session_commission_credited ,agent_session_commission=$agent_session_commission_credited ,sa_session_commission=$sa_session_commission_value ,master_session_commission=$master_session_commission_value WHERE client_id=$client_id AND market_id=$market_id";
   mysqli_query($con,$query);
}


	}

//_dx($load_url);
$_SESSION['update_msg']="Your Desicion Has Been Updated";
header('location:desicion_session.php?id=<?php echo $market_id ?>');

?>




