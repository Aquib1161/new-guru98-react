<?php
include('../include/config.php');
if(!isset($_POST))
{
	invalid();
}
$post_array=sanatize($_POST);
$user_result=get_user_list('',$post_array['user_id']);
$return=check_id($post_array['user_id']);
extract($post_array);
if($_SESSION['user_type']!='superadmin')
{
   $parent_amount=call_total_coins($_SESSION['user_type'],$_SESSION['user_id']);
   if($amount>$parent_amount)
   {
   	$_SESSION['notify']=['type'=>'error','msg'=>'Invalid Amount!'];
	header("location:../cash.php?cash_type=".$cash_type."&page_name=".$page_name."&id=".$user_id."");
	exit();
   }

}
$rest_amount=call_total_coins($user_result['user_type'],$user_result['user_id']);
//_dx($rest_amount);
if(($rest_amount+$amount)>$user_result['fix_limit']){
  $_SESSION['notify']=['type'=>'error','msg'=>'total coins can not be greathe than fix limit !'];
  header("location:../cash.php?cash_type=".$cash_type."&page_name=".$page_name."&id=".$user_id."");
  exit(); 
}

if($transaction_type=='C'){$mark='receive cash';}else{$mark='pay cash';}

$transaction_array=array(
	'transaction_type'=>$transaction_type,
	'amount'=>$amount,
	'user_type'=>$user_result['user_type'],
	'admin_id'=>$user_result['admin_id'],
	'superadmin_id'=>$user_result['superadmin_id'],
	'master_id'=>$user_result['master_id'],
	'agent_id'=>$user_result['agent_id'],
	'sa_id'=>$user_result['superagent_id'],
	'for_bet'=>'0',
	'remark'=>$mark.' '.$user_result['user_type'],
	'note'=>$note,
	'overall_type'=>overall_type($user_result['user_type'])
);
$result=insert_array('transaction_log',$transaction_array,'');

$task_array=array(
	'user_id'=>$user_id,
	'note'=>$note,
	'amount'=>$amount,
    'user_type'=>$user_result['user_type'],
    'user_match_comm'=>$user_result['user_match_comm'],
    'user_session_comm'=>$user_result['user_session_comm'],
    'user_share'=>$user_result['user_share'],
    'task_name'=>$mark.' '.$user_result['user_type'],
    'creater_id'=>$_SESSION['user_id'],
    'creater_type'=>$_SESSION['user_type'],
    'creater_name'=>$_SESSION['name'],
    'ip'=>ip(),
    'date'=>_date(),
    'date_time'=>_date_time(),
    'user_name'=>$post_array['name']
);

$result=insert_array('user_history_log',$task_array,'');
$_SESSION['notify']=['type'=>'success','msg'=>''.$page_name.' coins updated successfully'];
header("location:../cash?cash_type=".$cash_type."&page_name=".$page_name."&id=".$user_id."");
?>