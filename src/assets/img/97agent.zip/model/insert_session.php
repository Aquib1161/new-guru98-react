<?php
include('../include/config.php');
$_POST=sanatize($_POST);
$_GET=sanatize($_GET); 
extract($_POST);


?>