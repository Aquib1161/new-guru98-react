<?php 
include('include/config.php');
$_GET=sanatize($_GET);
$_POST=sanatize($_POST);
$market_id=$_GET['market_id'];
$match_data=get_data('upcoming_match','market_id='.$market_id,'single');
$team_data=get_data('match_team_tbl','market_id='.$market_id,'','runner_name,selection_id');
$count=count($team_data);
$team1_selection_id=$team_data[0]['selection_id'];
$team1_name=$team_data[0]['runner_name'];
$team2_selection_id=$team_data[1]['selection_id'];
$team2_name=$team_data[1]['runner_name'];
$team3_selection_id='';
$team3_name='';
if($count==3)
{
$team3_selection_id=$team_data[2]['selection_id'];
$team3_name=$team_data[2]['runner_name'];
}
$client_data=market_id_client_data($market_id);
$all_selection_id=[
    'team1_selection_id'=>$team1_selection_id,
    'team2_selection_id'=>$team2_selection_id,
    'team3_selection_id'=>$team3_selection_id,
];
$position_array=[
   'all_selection_id'=>$all_selection_id,
   'market_id'=>$market_id,
   'user_id'=>$userdata['user_id'],
   'count'=>$match_data['count'],
   'user_type'=>$userdata['user_type']
];

$position=user_position($position_array);
$team_array=[];
foreach ($team_data as $key => $team)
{
    if($team['selection_id']==$position['team'.($key+1).'_selection_id'])
    {
       $team['position']=$position['team'.($key+1).'_position'];
    }
    array_push($team_array,$team);
}


include('header.php');
?>
 
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Match Bet Details</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="dashboard?page_name=dashboard">Home</a></li>
              <li class="breadcrumb-item active">Match Bet Details</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">

                        <!-- /.card -->

                        <div class="card">


                            <form action="/game/i/2124/viewMatchReport" id="myForm" method="post"><input type="hidden" name="_csrf" value="36452e6a-d80b-4485-9d76-2519cc7343f9">

                                <div class="card-header ">


                                    <div class="form-row col-md-6">

                                        <table class="table table-bordered table-striped" data-select2-id="5">
                                            <thead class="text-bold">
                                              <?php foreach ($team_array as $key => $team) {   ?>
                                            <tr>
                                                <th><?= $team['runner_name']?></th>
                                            <th class="text-blue" id="<?= $team['selection_id'] ?>">
                                                <?= color($team['position']) ?>
                                            </th>
                                            </tr>

                                          <?php } ?>
                                         

                                            <tr>
                                                <th>Client</th>
                                                <th data-select2-id="4">
                                                  <select class="form-control select2" required="" onchange="Selectid()" id="client_id" placeholder="Select Client" name="client" >
                                                <option value="">Select Client...</option>
                                                <?php foreach ($client_data as $key => $value) { ?>
                                                <option value="<?= $value['id'] ?>"><?= $value['ClientCode'] ?> <?= $value['ClientName'] ?></option>
                                              <?php } ?>
                                                
                                            </select>
                                              </th>
                                            </tr>
                                            </thead>
                                        </table>
                                      


                                    </div>


                                </div>
                                <!-- /.card-header -->


                                <div class="card-body">
                                    <div>

                                        <div class="row">

                                            <div class="col-md-12">
                                                <table class="table table-striped table-bordered">

                                                    <thead>

                                                    <tr>
                                                        <th>#</th>
                                                        <th>Client</th>
                                                        <th>Rate</th>
                                                        <th>Team</th>
                                                        <th>Mode</th>
                                                        <th>Amount</th>
                                                        <th>Date &amp; Time</th>
                                                        <?php foreach ($team_data as $key => $team) { ?>
                                                        <th id="<?= $team_name['selection_id'] ?>"><?= $team['runner_name'] ?></th>
                                                      <?php } ?>

                                                      <th>IP</th>
                                                       
                                                    </tr>
                                                    </thead>

                                                    <tbody id="match_bets">
                                                    
                                                    
                                                    </tbody>

                                                    <tfoot>
                                                    <tr>
                                                        <th class="text-center" colspan="6"></th>
                                                        <th class="text-center">Total Amount</th>


                                                    <?php foreach ($team_data as $key => $team) { ?>
                                                        <th class="<?= $team['selection_id']?>"></th>
                                                      <?php } ?>
                                                    </tr>
                                                    </tfoot>

                                                </table>
                                            </div>

                                        </div>

                                    </div>
                                    

                                </div>
                                <!-- /.card-body -->
                            </form>

                        </div>
                        <!-- /.card -->


                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </section>

   

   
  </div>
  <!-- /.content-wrapper -->

  <script type="text/javascript">
      
    
      var market_id ='<?php echo $market_id ?>';
      var team1_selection_id="<?= $team1_selection_id ?>";
      var team2_selection_id="<?= $team2_selection_id ?>";
      var team3_selection_id="<?= $team3_selection_id ?>";
      all_selection_id={
         'team1_selection_id':team1_selection_id,
         'team2_selection_id':team2_selection_id,
         'team3_selection_id':team3_selection_id,
      };

            function Selectid()
            {
               
                var client_id=$('#client_id').val()
                if(client_id==0)
                {   
                    $("#match_bets").html('');
                    $('#match_total').html('')
                    $('#session_bet').html('')
                    $('#session_total').html('')
                    return false;
                }
                match_bet(client_id)
                get_position(client_id)
            }

 

       match_bet('')
       function match_bet(client_id)
     {
          
                $("#match_bets tr").remove();
                $('#match_total').html('')
                var check=true;
                var match_type ='match_odds'
                var bet_type = 0;
                var client_id = client_id
               
                $.ajax({
                    url : "ajax/match_bet",
                    type : "post",
                    dataType: 'json',
                    data : {bet_type:bet_type,match_type:match_type,client_id :client_id,market_id:market_id},
                    success : function(res){
                        var data=res.data;
                        var no=1;
                        var total_favour_amount=0
                        var total_amount=0
                        var total_unfavour_amount=0
                            jQuery.each(data, function(i,bet_data) 
                            {   
                                total_amount+=parseInt(bet_data.amount)
                                total_favour_amount+=parseInt(bet_data.favor_amount)
                                total_unfavour_amount+=parseInt(bet_data.unfavour_amount)
                          var share_amount_favour=(bet_data.my_share*bet_data.favor_amount/100);
                          var share_amount_unfavour=(bet_data.my_share*bet_data.unfavour_amount/100);
                          var str=`<tr class="">
                                    <td>${no++}</td>
                                    <td>${bet_data.client_name}</td>
                                    <td>${bet_data.bhav}</td>
                                    <td>${bet_data.team_name}</td>
                                    <td>${bet_data.type}</td>
                                    <td>${bet_data.amount}</td>
                                    <td>${bet_data.time_inserted}</td>
                                    <td>${bet_data.favor_amount}</td>
                                    <td>${bet_data.unfavour_amount}</td>
                            
                                     <td>${bet_data.ip}</td>
                                  </tr>
                          `;
                         
                          $("#match_bets").append(str);
                    });


                            var total=`<tr>
                                                        <th class="text-center" colspan="2"> </th>
                                                        <th class="text-center">Total </th>
                                                        <th class="text-red"></th>
                                                        <th class="text-red">${color(total_amount)}</th>
                                                        <th class="text-red">${color(total_favour_amount)}</th>
                                                        <th class="text-red">${color(total_unfavour_amount)}</th>
                                                        <th></th>
                                                    </tr>`
                                $('#match_total').append(total)
                            
                    }
                });
            
     }


get_position('')

function get_position(client_id='')
   {  
      var market_id="<?= $_GET['market_id'] ?>";
     
      var count="<?= $count ?>";
      var team1_selection_id="<?= $team1_selection_id ?>";
      var team2_selection_id="<?= $team2_selection_id ?>";
      var team3_selection_id="<?= $team3_selection_id ?>";
      all_selection_id={
         'team1_selection_id':team1_selection_id,
         'team2_selection_id':team2_selection_id,
         'team3_selection_id':team3_selection_id,
      };

                 $.ajax({
                    url : "ajax/client_match_position",
                    type : "post",
                    dataType: 'json',
                    data : {'market_id':market_id,
                            'client_id':client_id,
                            'count':count,
                            'all_selection_id':all_selection_id,},
                    success : function(res){
                     $('.'+res.team1_selection_id).html(color(-1*(res.team1_position)))
                     $('.'+res.team2_selection_id).html(color(-1*(res.team2_position)))
                     $('.'+res.team3_selection_id).html(color(-1*(res.team3_position)))
                    }
                 });
       //return data = sendAjax('ajax/match_position',sendData);    
   }



     
</script>

  <?php  include('footer.php');  ?>