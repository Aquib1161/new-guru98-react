<?php
include('include/config.php');
include('header.php');
sanatize($_GET);
if (isset($_GET['parent_user_id'])) {
  extract($_GET);
  $count = count_data('users_tbl', user_where("user_id='" . $parent_user_id . "'"));
  if ($count != 1) {
    invalid();
  }

  $parent_data = get_data('users_tbl', user_where("user_id='" . $parent_user_id . "'"), 's', 'user_type,total_coins');
  $downline_data = get_data('users_tbl', "user_type='" . $_GET['page_name'] . "' AND " . $parent_data['user_type'] . "_id='" . $parent_user_id . "'");
  /*$total_coins_given=call_total_coins($parent_data['user_type'],$parent_user_id);*/
  $total_coins_given = $parent_data['total_coins'];
} else {
  $downline_data = get_data('users_tbl', user_where("user_type='" . $_GET['page_name'] . "'"));
  $total_coins_given = call_total_coins($_SESSION['user_type'], $_SESSION['user_id']);
}



?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1><?= ucfirst($_GET['page_name']) ?></h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="dashboard?page_name=dashboard">Home</a></li>
            <li class="breadcrumb-item active"><?= ucfirst($_GET['page_name']) ?></li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div>

          <!-- /.card -->

          <div class="card card-indigo">

            <div class="card-header">
              <h4><?= ucfirst($_GET['page_name']) ?> Coin Details</h4>
            </div>

            <div class="card-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>S No</th>
                    <th><?= ucfirst($_GET['page_name']) ?> Name</th>
                    <th>Limit</th>
                    <th>Enter Limit</th>
                    <th>My Limit : <?= round($total_coins_given, 1); ?></th>
                  </tr>
                </thead>
                <tbody>
                  <?php $s_no = 1;
                  foreach ($downline_data as $key => $value) { ?>
                    <tr role="row" class="odd">
                      <input type="hidden" name="" value="<?= $value['user_id'] ?>">
                      <input required="" type="hidden" class="form-control" step="0.01" name="user_limit" value="<?= $value['total_coins'] ?>" id="<?= $value['user_id'] ?>_current_coins">
                      <td><?= $s_no++; ?></td>
                      <td><?= $value['username'] ?> <?= $value['name'] ?></td>
                      <td id="show_limit_<?= $value['user_id'] ?>"><?= round($value['total_coins'], 1) ?></td>
                      <td class="col-lg-4" style="min-width: 120px">
                        <input min="0" required="" type="number" class="form-control" step="0.01" name="user_limit" id="<?= $value['user_id'] ?>_coins">
                      </td>
                      <td style="min-width: 150px">
                        <button class="btn-sm btn-primary" type="submit" name="type" value="Add" onclick="update_coins('<?= $value['user_id'] ?>','deposit', this)">
                          Add
                        </button>
                        <button class="btn-sm btn-danger" type="submit" name="type" value="Minus" onclick="update_coins('<?= $value['user_id'] ?>','withdraw', this)"> Minus
                        </button>

                      </td>
                    </tr>
                  <?php } ?>

                </tbody>
              </table>

            </div>
            <!-- /.card-body -->


          </div>
          <!-- /.card -->


        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
  </section>
</div>
<!-- /.content-wrapper -->

<script type="text/javascript">
  function update_coins(user_id, operation_type, btn) {
    $(btn).attr('disabled', 'disabled');
    var current_coins = parseInt($('#' + user_id + '_current_coins').val())
    var update_coins = parseInt($('#' + user_id + '_coins').val());

    if (update_coins < 0) {
      notify('error', 'Value must be positive');
      return;
    }

    var coins_to_updated = '';
    if (operation_type == 'withdraw') {
      coins_to_updated = current_coins - update_coins
    } else {
      coins_to_updated = current_coins + update_coins
    }
    $.ajax({
      url: "ajax/update_limit.php",
      type: "post",
      dataType: 'json',
      data: {
        type: 'fix_limit',
        user_id: user_id,
        fix_limit: update_coins,
        update_limit: update_coins,
        is_client: false,
        operation_type: operation_type
      },
      success: function(res) {
        var status = res.status;
        if (status == 'success') {
          notify("success", res.data.msg);
          $('#show_limit_' + user_id + '').html(coins_to_updated)
          $('#' + user_id + '_coins').val('')
          location.reload()
        } else {
          notify("error", res.data.msg);
          $(btn).removeAttr('disabled');
        }
      }
    });
  }
</script>

<?php include('footer.php');  ?>