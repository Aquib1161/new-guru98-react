<?php 
include('include/config.php');
include('header.php');
$code=collection_code();
$edit=false;
if(!isset($_GET['collection_id']))
{
$users=column_names('collection')['table'];
$users['code']=$code;   
}
else
{
$users=get_data('collection',"collection_id='".$_GET['collection_id']."'",'s');   
$edit=true;
}

?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Collection Details</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="dashboard?page_name=dashboard">Home</a></li>
              <li class="breadcrumb-item active">New Collection</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <section class="content">
            <form action="model/create_collection" method="POST">
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="card card-primary">
                            <div class="card-header">
                                <h3 class="card-title">Edit Collection</h3>

                                <div class="card-tools">
                                    <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
                                        <i class="fas fa-minus"></i></button>
                                </div>
                            </div>
                            <div class="card-body">

                                <div class="form-group">

                                    <label for="code">code</label>
                                    <input type="text" id="code" placeholder="" readonly="" class="form-control" name="code" value="<?= $users['code'] ?>">

                                </div>

                                <div class="form-group">
                                    <label for="name">Name</label>
                                    <input type="text" id="name" class="form-control" placeholder="Name" required="" name="name" value="<?= $users['name'] ?>">

                                </div>


                                <div class="form-group">
                                    <label for="reffrence">Refrence</label>
                                    <div class="input-group ">
                                        <input type="text" class="form-control" placeholder="reffrence" id="reffrence" name="reffrence" value="<?= $users['reffrence'] ?>">
                                    </div>
                                </div>


                                <div class="form-group">

                                    <label for="contact_no">Contact No</label>
                                    <input type="number" class="form-control" id="contact_no" placeholder="Mobile No" required="" name="contact_no" value="<?= $users['contact_no'] ?>">
                                </div>

                                <div class="form-group">

                                    <label for="account_no">account_no No</label>
                                    <input type="number" class="form-control" id="account_no" placeholder="Account No" required="" name="account_no" value="<?= $users['account_no'] ?>">
                                </div>

                                <div class="form-group">
                                    <label for="collection_type">Collectiom collection_type</label>
                                    <select class="form-control" id="collection_type" name="collection_type">
                                        <option <?php if($users['collection_type']=='BANK'){echo 'selected';} ?> value="BANK" selected="selected">BANK</option>
                                        <option <?php if($users['collection_type']=='COLLECTION'){echo 'selected';} ?> value="COLLECTION">COLLECTION</option>
                                    </select>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <a href="create_collection" class="btn btn-secondary">Cancel</a>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                          <?php if($edit==true){?>
                                            <input type="hidden" name="collection_id" value="<?= $users['collection_id']?>">
                                            <button type="submit" class="btn btn-warning float-right">
                                              Update Collection
                                            </button>
                                          <?php } else{?>

                                            <button type="submit" class="btn btn-primary float-right">Create New
                                                Collection
                                            </button>
                                          <?php  } ?>
                                        </div>

                                    </div>
                                </div>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">

                    </div>
                </div>

            </form>


        </section>
  </div>
  <!-- /.content-wrapper -->

  <?php  include('footer.php');  ?>