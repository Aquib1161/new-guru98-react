<?php
include('include/config.php');
include('header.php');
extract($_GET);
if (isset($_GET['page_no']))
{
  $page_no = $_GET['page_no'];
  if ($page_no <= 0) {
    $page_no = 1;
  }
} 
else 
{
  $page_no = 1;
}

$specific="used_coins,share_array,total_coins,created_by_id,creater_id,doj,status,SessionCommissionClient,MatchCommissionClient,MatchShare,ClientMobileCharge,ClientName,ClientCode,username,password,FixLimit,A_id,id,ContactNo";
if(isset($_GET['list_type']) and !isset($_GET['parent_user_id'])) 
{
  $status = isset($_GET['block']) ? 0 : 1;
  if (isset($_GET['id'])) 
  {
    $fetch_data = get_data('client', user_where("id='" . $_GET['id'] . "'", 's'),'',$specific);
    $data['total_pages'] = 1;
    $total_pages =  1;
  } 
  else 
  {
    $client_data = $data = get_data_pagination('client', user_where('', 's'), $page_no, "order by id desc",$specific);
    $fetch_data = $client_data['data'];
    $total_pages = $client_data['total_pages'];
  }
} 
else 
{
  $status = isset($_GET['block']) ? 0 : 1;
  $parent_data = get_data('users_tbl', "user_id='" . $parent_user_id . "'", 's');
  $parent_user_type = $parent_data['user_type'];
  $client_data = $data = get_data_pagination('client', "A_id='" . $parent_user_id . "'", $page_no, "order by id desc",$specific);
  $fetch_data = $client_data['data'];
  $total_pages = $client_data['total_pages'];
}

$client_data = get_data('client', user_where('', 's'), '', "username,ClientName,id");
if ($_SESSION['user_type'] != 'agent') 
{
  $upline_data = get_data("users_tbl", user_where("user_type='agent'"),'','user_id,username,name');
}

$user_coin = get_data('users_tbl', "user_id='" . $userdata['user_id'] . "'", 's', 'total_coins')['total_coins'];
?>

<?php if ($_SESSION['user_type'] != 'agent') { ?>
  <div class="modal fade" id="modal-default">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Select <?= ucfirst('agent') ?></h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <select id="parent_id" class="form-control select2" required="">
            <?php foreach ($upline_data as $key => $upline) { ?>
              <option value="<?= $upline['user_id'] ?>"><?= $upline['username'] ?> <?= $upline['name'] ?></option>
            <?php } ?>
          </select>
        </div>
        <div class="modal-footer justify-content-between">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          <button onclick="submit()" type="button" class="btn btn-primary">Continue</button>
        </div>
      </div>
    </div>
  </div>
<?php } ?>


<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Client</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="dashboard?page_name=dashboard">Home</a></li>
            <li class="breadcrumb-item active">Client</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>


  <section class="content">
    <div class="card">
      <div class="card-header">
        <div class="form-group">
          <?php if ($_SESSION['user_type'] != 'agent') { ?>
            <a href="" data-toggle="modal" data-target="#modal-default" class="btn btn-primary">
              New <i class="fa fa-plus-circle"></i>
            </a>
          <?php } else { ?>

            <a href="create_client?role=<?= $list_type ?>&page_name=<?= $list_type ?>&list_type=<?= $list_type ?>" class="btn btn-primary">
              New <i class="fa fa-plus-circle"></i>
            </a>
          <?php } ?>
          <button class="btn btn-success" onclick="bulk_status('active')" type="submit" name="check" value="1">All Active
          </button>
          <button class="btn btn-danger" id="allInActive" type="submit" name="check" onclick="bulk_status('inactive')">All DeActivate <i class="fa fa-ban"></i></button>
          <a href="client_limit?page_name=client&list_type=client" class="btn btn-primary"> Limit Update </a>
        </div>
      </div>
      <!-- /.card-header -->
      <div class="card-body">

        <div class="form-group col-md-6">
                                    <!-- <label for="name" class="text-capitalize">Search Client</label> -->
                                    <select onchange="change()" class="form-control select2" required="" id="user_id" placeholder="Select Client" name="user_id" data-select2-id="name" tabindex="-1" aria-hidden="true">
                                        <option value="0">Select Client</option>
                                        <?php foreach ($client_data as $key => $client) { ?>
                                            <option <?php  if(isset($_GET['id']) AND $_GET['id']==$client['id']) echo 'selected'  ?> value="<?= $client['id'] ?>"><?= $client['ClientName'] ?> (<?= $client['username'] ?>)</option>
                                        <?php  }  ?>

                                    </select>
                                </div>


        <table id="no_datatable" class="table table-bordered table-striped">
        <!-- <table id="" class="table table-bordered table-striped"> -->


          <thead>
            <tr>
              <th><input type="checkbox" id="all_check" name="all_check" value='1'></th>
              <th>#</th>
              <th>CODE</th>
              <th>Name</th>
              <th>Agent</th>
              <th>Mobile</th>
              <th>Password</th>
              <th>Limit</th>
              <th>Used Limit</th>
              <th>Match</th>
              <th>Session</th>
              <th>Doj</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            <?php $s_no = 1;
            foreach ($fetch_data as $key => $user) {
              extract($user);
              $share_data = json_decode($user['share_array'], true);
              $agent_data = $share_data['agent_share_array'];
              $used_limit=$user['used_coins'];
            ?>
              <tr style="text-decoration: <?= $user['status'] ? 'white' : 'line-through' ?>; text-decoration-color: red;">
                <td>
                  <input type="checkbox" class="checkbox" name="client_id" value=<?= $user['id']; ?>>
                </td>
                <td>

                  <label><?= $s_no++ ?></label>
                  <div class="btn-group">
                    <?php  if($user_type!='agent'){?>
                    <button type="button" onclick="details_modal('<?= $user['id'] ?>')" class="btn btn-block btn-outline-info btn-sm">+</button>
                    <?php  } ?>
                    <button type="button" class="btn btn-xs btn-outline-secondary dropdown-toggle dropdown-hover dropdown-icon" data-toggle="dropdown">
                      <span class="sr-only">Toggle Dropdown</span>
                    </button>
                    <div class="dropdown-menu" role="menu">
                      <a class="dropdown-item" href="create_client?role=client&page_name=client&list_type=client&user_id=<?= $user['id'] ?>">Edit</a>
                      <a class="dropdown-item" onclick="status(<?= $user['id'] ?>)" id="user_status_<?= $user['id'] ?>" href="#">
                        <?php if ($user['status'] == 1) {
                          echo 'Inactive';
                        } else {
                          echo 'Active';
                        }  
                      ?></a>
               <span>
                        <a class="dropdown-item" onclick="limit_update('<?= $user['id'] ?>')" href="#">Limit Update</a>
                        <a class="dropdown-item" onclick="send_login_details('<?= $user['id'] ?>')" href="#">Send Login Details(SMS)</a>
                      </span>

                    </div>
                  </div>
                </td>
                <td id="client_code_<?= $user['id'] ?>"><?= $user['ClientCode'] ?></td>
                <td id="client_name_<?= $user['id'] ?>"><?= $user['ClientName'] ?></td>
                <td><?= $agent_data['agent_name'] ?></td>
                <td><?= $user['ContactNo'] ?></td>
                <td><?= $user['password'] ?></td>
                <td id="client_current_limit_<?= $user['id'] ?>"><?= round($total_coins, 1) ?></td>
                <td id="client_used_limit_<?= $user['id'] ?>">
                  <a>
                    <?php echo $used_limit=isset($used_limit)?$used_limit:0 ?>
                  </a>
                </td>
                <td><?= number_format($MatchCommissionClient, 1) ?></td>
                <td><?= number_format($SessionCommissionClient, 1) ?></td>
                <td><?= $doj ?></td>
                <td>
                  <div>
                    <span class="float-center badge bg-<?= $status == 1 ? 'success' : 'danger' ?>"><?= $status == 1 ? 'Active' : 'InActive' ?></span>
                  </div>
                </td>
              </tr>
            <?php } ?>
            </tfoot>
        </table>


          <!-- Pagination Start -->
              <?php if (isset($_GET['page_no'])) {
                $page_no = $_GET['page_no'];
                if ($page_no <= 0) {
                  $page_no = 1;
                }
              } else {
                $page_no = 1;
              }

              $redirect_url='client_list?list_type=client&all=true&';
              ?>
              <div class="card-footer clearfix">
                <ul class="pagination pagination-sm m-0 float-right" style="display: flex;flex-wrap: wrap;">
                  <?php for ($i = 1; $i <= $total_pages; $i++) {  ?>
                    <li class="page-item <?php if ($_GET['page_no'] == $i) echo 'active' ?>">
                      <a class="page-link" href="<?= $redirect_url ?>page_no=<?= $i ?>"><?= $i ?></a>
                    </li>
                  <?php } ?>
                  <?php if ($page_no >= $total_pages) {
                    $page_no = $page_no - 1;
                  }
                  ?>

                  <div>
                    <li class="page-item"><a class="page-link" href="<?= $redirect_url ?>page_no=<?= ($page_no + 1); ?>">»</a>
                    </li>
                  </div>

                </ul>
              </div>

            </form>
          </div>
    <!-- Pagination End -->
      </div>
      <!-- /.card-body -->
    </div>

  </section>
  <!-- /.content -->


  <input type="hidden" id="coin_client_id">
</div>
<!-- /.content-wrapper -->
<div class="modal fade" id="coin_modal">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="modelTitle"></h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">

        <div class="form-group">
          <label for="formALimit"> My Current Limit</label>
          <input type="text" id="user_current_limit" value="" placeholder="" readonly="" class="form-control">
        </div>

        <div class="form-group">
          <label for="formCLimit"> Client Current Limit</label>
          <input type="text" id="client_current_limit" placeholder="" readonly="" class="form-control">
        </div>

        <div class="form-group">

          <label for="limit"> Enter Limit</label>
          <input type="number" id="update_amount" placeholder="Limit" name="limit" class="form-control" step="0.01">
        </div>

        <input type="text" name="check" value="1" hidden="hidden">
      </div>
      <div class="modal-footer">
        <div align="left">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
        <button onclick="update_coins('deposit')" type="submit" class="btn btn-success btn-limit" name="type">Add Limit</button>
        <button onclick="update_coins('withdraw')" type="submit" class="btn btn-danger btn-limit" name="type"> Minus Limit
        </button>
      </div>
    </div>
  </div>
</div>


<div class="modal fade" id="details_modal">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <center><h4 class="modal-title" id="modelTitle">Client Upline Details</h4></center>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">

        <table class="table table-bordered">
          <thead>
            <tr>
              <th>User Code</th>
              <th>Sports Share</th>
              <th>Match Comm</th>
              <th>Sess Comm</th>
              <th>Casino Shr</th>
              <th>Casino Comm</th>
            </tr>
          </thead>
          <tbody id='client_detail_body'>
          </tbody>
      </table>

         
      </div>
     
      <div class="modal-footer">
        <div align="left">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>
        
      </div>
    </div>
  </div>
</div>



<script type="text/javascript">
  var user_current_limit = "<?= $user_coin ?>";
  var user_type="<?= $userdata['user_type']  ?>"

  function details_modal(user_id)
  {
    sendData = {
      'is_client': true,
      'client_id': user_id,
    }
    data = sendAjax('ajax/client_details', sendData);
    $("#client_detail_body").html('')
    
     jQuery.each(data, function(key, userdata) { 
       
       var username='';
       var name='';
       var match_share='';
       var match_comm='';
       var session_comm='';
       var casino_share='';
       var casino_comm='';
       if(key=='agent_share_array')
       {
            username=userdata.agent_code
            name=userdata.agent_name
            match_share=userdata.agent_match_total_share
            match_comm=userdata.agent_match_comm
            session_comm=userdata.agent_session_comm
            casino_share=userdata.agent_casino_share
            casino_comm=userdata.agent_casino_comm
       }
       else if(key=='superagent_share_array')
       {
            username=userdata.superagent_code
            name=userdata.superagent_name
            match_share=userdata.superagent_match_total_share
            match_comm=userdata.superagent_match_comm
            session_comm=userdata.superagent_session_comm
            casino_share=userdata.superagent_casino_share
            casino_comm=userdata.superagent_casino_comm
       }
       else if(key=='master_share_array')
       {
            username=userdata.master_code
            name=userdata.master_name
            match_share=userdata.master_match_total_share
            match_comm=userdata.master_match_comm
            session_comm=userdata.master_session_comm
            casino_share=userdata.master_casino_share
            casino_comm=userdata.master_casino_comm
       }
       else if(key=='admin_share_array')
       {
            username=userdata.admin_code
            name=userdata.admin_name
            match_share=userdata.admin_match_total_share
            match_comm=userdata.admin_match_comm
            session_comm=userdata.admin_session_comm
            casino_share=userdata.admin_casino_share
            casino_comm=userdata.admin_casino_comm
       }

       var body=` 
                  <tr>
                    <td>(${name}) ${username}</td>
                    <td>${match_share}</td>
                    <td>${match_comm}</td>
                    <td>${session_comm}</td>
                    <td>${casino_share}</td>  
                    <td>${casino_comm}</td>
                 </tr>     
              `;

    $("#client_detail_body").append(body)
   })


    
     // $("#client_detail_body").html(body)
  
    $('#details_modal').modal('show');

  }



  $("#all_check").click(function() {
    if ($("#all_check").prop('checked') == true) {
      $('.checkbox').attr('checked', true);
    } else {
      $('.checkbox').attr('checked', false);
    }
  });


  function bulk_status(status) {
    if (status == 'inactive') {
      var answer = window.confirm("INACTIVE KARNE PAR SAARI DOWNLINEKILIMIT ZERO HO JAYEGI")
      if (answer) {
        //some code
      } else {
        return false;
      }
    }


    id_array = [];
    $("input:checkbox[name=client_id]:checked").each(function() {
      id_array.push($(this).val());
    });

    const count = id_array.length

    if (count == 0) {
      alert('Please select atleast one client');
      return false;
    }



    sendData = {
      'is_client': true,
      'id_array': id_array,
      'status': status
    }
    data = sendAjax('ajax/status_update', sendData);
    if (data.status == 'success') {
      location.reload()
    }
  }

  function submit() {
    var parent_id = $('#parent_id').val()
    var role = "agent"
    window.location.href = 'create_client?list_type=client&role=' + role + '&page_name=' + role + '&parent_id=' + parent_id
  }

  function limit_update(user_id) {
    $('#coin_client_id').val(user_id)
    var name = $('#client_name_' + user_id).html()
    var code = $('#client_code_' + user_id).html()
    var current_limit = $('#client_current_limit_' + user_id).html()
    $('#modelTitle').html(code + ' ' + name)
    $('#user_current_limit').val(user_current_limit)
    $('#client_current_limit').val(current_limit)
    $('#update_amount').val('')
    $('#coin_modal').modal('show')
  }

  function clear_modal() 
  {
    $('#coin_modal').modal('hide');
    setTimeout(() => {
      $("#client_current_limit").html('');
      $("#coin_client_id").val('');
      $("#update_amount").val('');
      $('.btn-limit').removeAttr('disabled', '');
    }, 200);
  }

  function coins(user_id, type = '') 
  {
    var user_coin = $('#user_coins_' + user_id).html();
    $("#show_current_coins").html(user_coin);
    $("#current_coins").val(user_coin);
    $("#type").html(type);
    $("#user_id").val(user_id);

  }


  function status(user_id) {
    var status = $("#user_status_" + user_id).html();
    var status_to_be_update = 0;
    var show_status = 'Inactive';
    var show_change_status = 'Active';
    if (status == 'Active') {
      status_to_be_update = 1;
      show_status = 'Active'
      show_change_status = 'Inactive';
    }

    if (show_change_status == 'Active') {
      var answer = window.confirm("INACTIVE KARNE PAR SAARI DOWNLINEKILIMIT ZERO HO JAYEGI")
      if (answer) {
        //some code
      } else {
        return false;
      }
    }



    sendData = {
      'update_status_client': status_to_be_update,
      'user_id': user_id,
    }
    data = sendAjax('ajax/update_by_ajax', sendData);
    if (data.status == 'success') {
      $("#show_status_" + user_id).html(show_status);
      $("#user_status_" + user_id).html(show_change_status);
      //notify(data.status,data.data.msg);
      location.reload()
    }
  }



  function update_coins(operation_type) {
    $('.btn-limit').attr('disabled', '');
    var client_id = $("#coin_client_id").val()
    var current_coins = parseInt($('#client_current_limit').val())
    var update_coins = parseInt($("#update_amount").val())
    var coins_to_updated = '';
    if (operation_type == 'withdraw') {
      coins_to_updated = current_coins - update_coins
    } else {
      coins_to_updated = current_coins + update_coins
    }

    if (update_coins < 0) {
      notify("error", 'Negative Value is not allowed');
      $('.btn-limit').removeAttr('disabled', '');
      return;
    }

    $.ajax({
      url: "ajax/update_limit",
      type: "post",
      dataType: 'json',
      data: {
        type: 'fix_limit',
        client_id: client_id,
        fix_limit: coins_to_updated,
        update_limit: coins_to_updated,
        is_client: true,
        real_update_coins: update_coins,
        deposit_type: operation_type
      },
      success: function(res) {
        var status = res.status;
        if (status == 'success') {
          notify("success", res.data.msg);
          clear_modal();
          $('#client_current_limit_' + client_id).html(coins_to_updated);
          // location.reload()
        } else {
          notify("error", res.data.msg);
          clear_modal()
        }
      }
    });

  }


  function send_login_details(user_id) {
    sendData = {
      'login_details': true,
      'user_id': user_id,
      'client': true,
    }

    data = sendAjax('ajax/update_by_ajax', sendData);
    notify("success", "Client Details Send Successfully");
  }

  function change() 
  {
    var client_id = $("#user_id").val();
    window.location.href='client_list?list_type=client&all=true&id='+client_id
  }
</script>

<?php include('footer.php');  ?>