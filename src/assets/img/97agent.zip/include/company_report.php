<?php
include('include/config.php');
$_GET=sanatize($_GET);
$_POST=sanatize($_POST);

extract($_GET);
include('header.php');
$check_array=array();
$where=$_SESSION['user_type']."_id='".$_SESSION['user_id']."' AND market_id='".$_GET['market_id']."'";
$match_data=get_data('upcoming_match',"market_id='".$_GET['market_id']."'",'s','match_name');
$match_name=$match_data['match_name'];
$user_priority=$_SESSION['user_priority'];
$role=$_SESSION['user_type'];
                              
  if($user_priority>=priority('superadmin'))
  {
      $superadmin_list=get_data('md_client_position',user_where("market_id='".$market_id."' group by superadmin_id"));
  }
  if($user_priority>=priority('admin'))
  {
    $admin_list=get_data('md_client_position',user_where("market_id='".$market_id."' group by admin_id"));
  }
  if($user_priority>=priority('master'))
  {
     $master_list=get_data('md_client_position',user_where("market_id='".$market_id."' group by master_id"));
  }


  if($user_priority>=priority('agent'))
  {    
      $agent_list=array();
      $query="SELECT agent_id FROM md_client_position WHERE ".user_where('','1')." AND market_id='".$market_id."' group by agent_id";
      $res=mysqli_query($con,$query);
            while ($data=mysqli_fetch_assoc($res)) {
                $agent_value=array('agent_id'=>$data['agent_id']);
               array_push($agent_list,$agent_value);
            } 
  }

?>

<style type="text/css">
table, th, td {
  background-color: white !important;
  border: 2px solid black !important;
}

</style>

            <div style="background-color:white;" class="row wrapper border-bottom white-bg page-heading">

                <div class="col-sm-4">
                    <h2><?= ucfirst('company repoort');?></h2>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="dashboard?page_name=dashboard">Dashboard</a>
                        </li>
                        <li class="breadcrumb-item active">
                            <strong><?= $_SESSION['name']; ?> (<?= $_SESSION['usercode']?>)</strong>
                        </li>
                        <li class="breadcrumb-item active">
                            <strong style="color:green"><?= ucfirst($match_name) ?></strong>
                        </li>
                    </ol>
                </div>
            </div> 
            <br>
            <br>



<?php foreach ($agent_list as $key => $agent) { 

                              $total_client_match_coins=0;
                              $total_client_session_coins=0;
                              $total_client_match_commission=0;
                              $total_client_session_commission=0;
                              $total_match_session_total=0;
                              $total_match_session_total=0;
                              $total_match_session_commm_total=0;
                              $total_client_total=0;
                              $total_other=0;
                              $total_final=0;
                              $total_agent_amount=0;
                              $total_agent_match_comm=0;
                              $total_agent_session_comm=0;
                              $total_superagent_amount=0;
                              $total_superagent_match_comm=0;
                              $total_superagent_session_comm=0;
                              $total_master_amount=0;
                              $total_master_match_comm=0;
                              $total_master_session_comm=0;
                              $total_admin_amount=0;
                              $total_admin_match_comm=0;
                              $total_admin_session_comm=0;
                              $total_superadmin_amount=0;
                              $total_superadmin_match_comm=0;
                              $total_superadmin_session_comm=0;
                              $total_company_amount=0;

                              $total_agent_session_match_comm=0;
                              $total_agent_net_amt=0;

                              $total_sa_session_match_comm=0;
                              $total_sa_net_amt=0;


    $report=get_data('md_client_position',user_where("market_id='".$market_id."' AND agent_id='".$agent['agent_id']."'",'1'));
     $agent_data=get_data('users_tbl',"user_id='".$agent['agent_id']."'",'s');
           $agent_name=$agent_data['name'];   
           $agent_code=$agent_data['username'];
    ?>
    <center style="color:blue; background-color: white;">
        <strong style="color:blue; background-color: white;">
        <?php echo ucfirst('AGENT '.$agent_name.' ('.$agent_code.')')?>
        </strong>
    </center>
<div  class="white-bg px-0 px-md-2 mx-0 row">
    <div class="col-container company_report_table col">
        <div class="infinite-scroll-component__outerdiv">
            
            
            <div class="infinite-scroll-component" style="height: auto; overflow: auto;">
                <div class="table-responsive">
                    <table class="mt-3 betslip table table-bordered table-striped ">
                        <thead>
                            <tr>
                                <th colspan="1"></th>
                                <!-- <th colspan="3" class="text-center">Plus / Minus</th> -->
                                <!-- <th colspan="3" class="text-center">COMMISSION</th> -->
                                <!-- <th colspan="2" class="text-center">OTHERS</th> -->
                                 <?php if($user_priority>=priority('agent')){?>
                                <th colspan="8" class="text-center ag-bg-color">AGENT P/L</th>
                                <?php } if($user_priority>=priority('superagent')){?>
                                <th colspan="6" class="text-center sa-bg-color">SUPERAGENT</th>
                                <?php } ?>
                                <?php if($user_priority>=priority('master')){?>
                                <th colspan="4" class="text-center ss-bg-color">MASTER</th>
                                <?php } if($user_priority>=priority('admin')){?>
                                <th colspan="4" class="text-center mas-bg-color">ADMIN</th>
                                <?php } if($user_priority>=priority('superadmin')){?>
                                <th colspan="4" class="text-center adm-bg-color">S. ADMIN</th>
                            <?php  } ?>
                               <!--  <th colspan="6" class="text-center company-bg-color">COMPANY</th> -->
                            </tr>
                            <tr>
                                <th>Client Name</th>
                                <th>M Amt.</th>
                                <th>S. Amt.</th>
                                <th>Tot Amt.</th>
                               <!--  <th>Match comm</th>
                                <th>Session comm</th>
                                <th>Total comm</th>
                                <th>System P/M</th> -->
                                <!-- <th>Mobile charge</th>
                                <th>Final</th> -->
                                <?php if($user_priority>=priority('agent')){?>
                                <!-- <th>MY SHE</th> -->
                                <th>M.Com</th>
                                <th>S.Com</th>
                                <th>Tot.Com</th>
                                <th>Net Amt.</th>
                                <th>Share Amt.</th>
                                <th><b>Final Amt</b></th>
                               <?php } if($user_priority>=priority('superagent')){?>
                                <th class="sub-bg-color">MY SHE</th>
                                <th>M.Com</th>
                                <th>S.Com</th>
                                <th>Tot.Com</th>
                                <th>Sa Amt</th>
                                 <th>Final Amt</th>
                               
                                <?php } if($user_priority>=priority('master')){?>
                                <th class="sub-bg-color">MY SHE</th>
                                <th>M.Com</th>
                                <th>S.Com</th>
                                <th>AMOUNT</th>
                                
                                <?php } if($user_priority>=priority('admin')){?>
                                <th class="sub-bg-color">MY SHE</th>
                                <th>M.Com</th>
                                <th>S.Com</th>
                                <th>AMOUNT</th>
                                
                                <?php } ?>

                             <?php  if($user_priority>=priority('superadmin')){?>

                                <th class="sub-bg-color">MY SHE</th>
                                <th>M.Com</th>
                                <th>S.Com</th>
                                <th>AMOUNT</th>
                                
                            <?php } ?>
                               <!--  <th class="sub-bg-color">MY SHE</th>
                                <th>Upper Amt</th> -->
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php   foreach ($report as $key => $report_value) 
                            { 
                                extract($report_value);
                            $array_data=json_decode($report_value['array_data'],true);
                            $user_data=$array_data['user_amount_old_type'];
                            extract($user_data);
                        /*_dx($array_data);*/
                            $client_data=get_data('client',"id='".$report_value['client_id']."'",'s','ClientName,ClientCode');

                            $share_data=get_data('shares',"market_id='".$_GET['market_id']."' AND client_id='".$report_value['client_id']."'",'s');

                            $match_session_total=$report_value['client_match_coins']+$report_value['client_session_coins'];

                            $match_session_commm_total=$report_value['client_match_commission']+$report_value['client_session_commission'];

                            $client_total=$match_session_total-$match_session_commm_total;

                            $other=$client_mobile_charge;
                            $final=$client_total-$other;


                            $agent_net_amount=$agent_net_amount;
                            $agent_amount=$agent_share_amount;


                            $agent_total_comm=$agent_match_commission+$agent_session_commission;
                            $sa_total_comm=$sa_match_commission+$sa_session_commission;
                           

                            $sa_net_amount=($agent_net_amount-$agent_amount);

                            

                            $agent_match_comm=$agent_match_commission;
                            $agent_session_comm=$agent_session_commission;

                            $superagent_amount=($sa_total_amount);
                            $superagent_match_comm=$sa_match_commission;
                            $superagent_session_comm=$sa_session_commission;


                            $master_amount=($master_total_amount-$sa_total_amount);
                            $master_match_comm=$master_match_commission;
                            $master_session_comm=$master_session_commission;
                            

                            $admin_amount=($admin_total_amount-$master_total_amount);
                            $admin_match_comm=$admin_match_commission;
                            $admin_session_comm=$admin_session_commission;

                            $superadmin_amount=($superadmin_total_amount-$admin_total_amount);
                            $superadmin_match_comm=$superadmin_match_commission;
                            $superadmin_session_comm=$superadmin_session_commission;
                             
                             $overall_superadmin_share=100;
                             $overall_admin_share=$overall_superadmin_share-$admin_share;
                             $overall_master_share=$overall_admin_share-$master_share;
                             $overall_superagent_share=$overall_master_share-$superagent_share;
                             $overall_agent_share=$overall_superagent_share-$agent_share;

                             $company_share=0;
                             $company_amount=0;
                            /* _d($report_value);*/

                             if($user_priority>=priority('agent'))
                             {
                                $company_share=100-$agent_share;
                                $company_amount=$agent_final_amount;
                             }
                             if($user_priority>=priority('superagent'))
                             {
                                $company_share=100-($agent_share+$superagent_share);
                                $company_amount=$sa_share_amount;
                             }
                             if($user_priority>=priority('master'))
                             {
                                $company_share=100-($agent_share+$superagent_share+$master_share);
                                $company_amount=$master_share_amount;
                             }
                             if($user_priority>=priority('admin'))
                             {
                                $company_share=100-$agent_share+$superagent_share+$master_share+$admin_share;
                                $company_amount=$admin_share_value;
                             }

                             if($user_priority>=priority('superadmin'))
                             {
                                $company_share=0;
                                $company_amount=0;
                             }
                             

                              $total_client_match_coins+=$report_value['client_match_coins'];
                              $total_client_session_coins+=$report_value['client_session_coins'];
                              $total_client_match_commission+=$report_value['client_match_commission'];
                              $total_client_session_commission+=$report_value['client_session_commission'];

                              $total_match_session_total+=$match_session_total;
                              //$total_match_session_total+=$match_session_total;
                              $total_match_session_commm_total+=$match_session_commm_total;
                              $total_client_total+=$client_total;
                              $total_other+=$other;
                              $total_final+=$final;


                              $total_agent_amount+=$agent_amount;
                              $total_agent_match_comm+=$agent_match_comm;
                              $total_agent_session_comm+=$agent_session_comm;
                              $total_agent_session_match_comm+=$agent_total_comm;
                              $total_agent_net_amt+=$agent_net_amount;
                             




                              $total_superagent_amount+=$superagent_amount;
                              $total_master_amount+=$master_amount;
                              $total_admin_amount+=$admin_amount;
                              $total_superadmin_amount+=$superadmin_amount;
                              $total_company_amount+=$company_amount;

                              $total_superagent_match_comm+=$superagent_match_comm;
                              $total_superagent_session_comm+=$superagent_session_comm;
                              $total_sa_session_match_comm+=$sa_total_comm;
                              $total_sa_net_amt+=$sa_net_amount;

                              $total_master_match_comm+=$master_match_comm;
                              $total_master_session_comm+=$master_session_comm;

                              $total_admin_match_comm+=$admin_match_comm;
                              $total_admin_session_comm+=$admin_session_comm;

                              $total_superadmin_match_comm+=$superadmin_match_comm;
                              $total_superadmin_session_comm+=$superadmin_session_comm;

                            ?>
                            <tr>
                                <td><?= $client_data['ClientName'] ?> (<?= $client_data['ClientCode'] ?>) (<?= $agent_id ?>)</td>
                                <td><?= color(number_format($report_value['client_match_coins'],2)) ?></td>
                                <td><?= color(number_format($report_value['client_session_coins'],2)) ?></td>
                                <td><?= color(number_format($match_session_total,2)) ?></td>
                                <!-- <td><?= color(number_format($report_value['client_match_commission'],2)) ?></td>
                                <td><?= color(number_format($report_value['client_session_commission'],2)) ?></td> -->
                               <!--  <td><?= color(number_format($match_session_commm_total,2)) ?></td> -->
                               <!--  <td><?= color(number_format($client_total,2)) ?></td>
                                <td><?= color(number_format($other,2)) ?></td>
                                <td><?= color(number_format($final,2)) ?></td> -->
                                 <?php if($user_priority>=priority('agent')){?>
                                <!-- <td class="sub-bg-color"><?= color(number_format($report_value['agent_share'],2)) ?></td> -->
                                <td class="sub-bg-color"><?= color(number_format(-1*$agent_match_comm,2)) ?></td>
                                <td class="sub-bg-color"><?= color(number_format(-1*$agent_session_comm,2)) ?></td>
                                <td class="sub-bg-color"><?= color(number_format(-1*($agent_session_comm+$agent_match_comm),2)) ?></td>
                                <td class="sub-bg-color"><?= color(number_format($agent_net_amount,2)) ?></td>
                                <td><?= color(number_format($agent_amount,2)) ?></td>
                                <td><?= color(number_format($company_amount,2)) ?></td>

                                    <?php } if($user_priority>=priority('superagent')){?>
                                <td class="sub-bg-color"><?= color(number_format($superagent_share,2)) ?></td>
                                <td class="sub-bg-color"><?= color(number_format($superagent_match_comm,2)) ?></td>
                                <td class="sub-bg-color"><?= color(number_format($superagent_session_comm,2)) ?></td>
                                <td class="sub-bg-color"><?= color(number_format($superagent_session_comm+$superagent_match_comm,2)) ?></td>
                                <td class="sub-bg-color"><?= color(number_format($sa_net_amount,2)) ?></td>
                                <td><?= color(number_format($superagent_amount,2)) ?></td>
                                 
                                  <?php } if($user_priority>=priority('master')){?>
                                <td><?= color(number_format($master_share,2)) ?></td>
                                <td class="sub-bg-color"><?= color(number_format($master_match_comm,2)) ?></td>
                                <td class="sub-bg-color"><?= color(number_format($master_session_comm,2)) ?></td>
                                <td><?= color(number_format($master_amount,2)) ?></td>
                                
                                <?php } if($user_priority>=priority('admin')){?>
                                <td class="sub-bg-color"><?= color(number_format($admin_share,2)) ?></td>
                                <td class="sub-bg-color"><?= color(number_format($admin_match_comm,2)) ?></td>
                                <td class="sub-bg-color"><?= color(number_format($admin_session_comm,2)) ?></td>
                                <td><?= color(number_format($admin_amount,2)) ?></td>
                                
                                 <?php } if($user_priority>=priority('superadmin')){?>
                                <td class="sub-bg-color"><?= color(number_format($superadmin_share,2)) ?></td>
                                <td class="sub-bg-color"><?= color(number_format($superadmin_match_comm,2)) ?></td>
                                <td class="sub-bg-color"><?= color(number_format($superadmin_session_comm,2)) ?></td>
                                <td><?= color(number_format($superadmin_amount,2)) ?></td>
                                

                                  <?php } ?>



                               <!--  <td><?= color(number_format($company_share,2)) ?></td>
                                <td><?= color(number_format($company_amount,2)) ?></td> -->
                               
                            </tr>

                        <?php } ?>
                                
                        </tbody>
                        <style type="text/css">
                            tfoot, tr, th {
                                              background-color: background-color: pink !important;;
                                            }
                            
                        </style>
                        <tfoot>
                           
                            <tr style="">
                                <th style="background-color: pink !important;">Agent Total</th>
                                <th style="background-color: pink !important; color:black !important"><?= color(number_format($total_client_match_coins,2)) ?></th>
                                <th style="background-color: pink !important; color:black !important"><?= color(number_format($total_client_session_coins,2)) ?></th>
                                <th style="background-color: pink !important; color:black !important"><?= color(number_format($total_match_session_total,2)) ?></th>
                                <!-- <th style="background-color: pink !important; color:black !important"><?= color(number_format($total_client_match_commission,2)) ?></th>
                                <th style="background-color: pink !important; color:black !important"><?= color(number_format($total_client_session_commission,2)) ?></th>
                                <th style="background-color: pink !important; color:black !important"><?= color(number_format($total_match_session_commm_total,2)) ?></th>
                                <th style="background-color: pink !important; color:black !important"><?= color(number_format($total_client_total,2)) ?></th>
                                <th style="background-color: pink !important; color:black !important"><?= color(number_format($total_other,2)) ?></th>
                                <th style="background-color: pink !important; color:black !important"><?= color(number_format($total_final,2)) ?></th>  --> 
                                <!-- <th class="sub-bg-color"></th> -->
                                <th style="background-color: pink !important; color:black !important"><?= color(number_format(-1*$total_agent_match_comm,2)) ?></th>  
                                <th style="background-color: pink !important; color:black !important"><?= color(number_format(-1*$total_agent_session_comm,2)) ?></th>  
                                <th style="background-color: pink !important; color:black !important"><?= color(number_format(-1*$total_agent_session_match_comm,2)) ?></th>  
                                <th style="background-color: pink !important; color:black !important"><?= color(number_format($total_agent_net_amt,2)) ?></th>  
                                <th style="background-color: pink !important; color:black !important"><?= color(number_format($total_agent_amount,2)) ?></th> 
                                 <th style="background-color: pink !important; color:black !important"><?= color(number_format($total_company_amount,2)) ?></th>



                                <?php  if($user_priority>=priority('superagent')){?>
                                <th class="sub-bg-color"></th>
                                    <th><?= color(number_format($total_superagent_match_comm,2)) ?></th>  
                                <th><?= color(number_format($total_superagent_session_comm,2)) ?></th>

                                <th><?= color(number_format($total_sa_session_match_comm,2)) ?></th>
                                <th><?= color(number_format($total_sa_net_amt,2)) ?></th>

                                <th><?= color(number_format($total_superagent_amount,2)) ?></th>  
                                  
                                <th class="sub-bg-color"></th>
                            
                        <?php } if($user_priority>=priority('master')){?>
                            <th><?= color(number_format($total_master_match_comm,2)) ?></th>  
                                <th><?= color(number_format($total_master_session_comm,2)) ?></th>
                                <th><?= color(number_format($total_master_amount,2)) ?></th>  
                                <th></th>
                                
                                <?php } if($user_priority>=priority('admin')){?>
                                    <th><?= color(number_format($total_admin_match_comm,2)) ?></th>  
                                <th><?= color(number_format($total_admin_session_comm,2)) ?></th>
                                <th><?= color(number_format($total_admin_amount,2)) ?></th>  
                                <th></th>
                                
                            <?php } if($user_priority>=priority('superadmin')){?>
                                <th><?= color(number_format($total_superadmin_match_comm,2)) ?></th>  
                                <th><?= color(number_format($total_superadmin_session_comm,2)) ?></th>
                                <th><?= color(number_format($total_superadmin_amount,2)) ?></th> 
                                
                            <?php  } ?>
                                <!-- <th></th> -->
                                
                                <!-- <th><?= color(number_format($total_company_amount,2)) ?></th> -->
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php  


                             




} ?>

<br>
<br>

<script type="text/javascript">
    var market_id="<?= $_GET['market_id'] ?>"

                function get_user_data(market_id,report_for,user_id='',user_type='')
            {   

                $.ajax({
                    url : "ajax/old_company_report",
                    type : "post",
                    data : {market_id:market_id,agent_id:agent_id},
                    success : function(res){
                        $("#live_report_data").html(res);
                    }
                });
            }

  function change(user_id,user_type)
  {
    
    get_user_data(market_id,'downline',user_id,user_type);
    
  }

get_user_data(market_id,'self')

</script>
         
<?php include('footer.php'); ?>