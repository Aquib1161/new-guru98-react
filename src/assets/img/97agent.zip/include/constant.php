<?php
define('site_name', '11EXCH');
define('client_url', 'http://11exch.in');
define('admin_url', 'http://admin.11exch.in/');
define('api_url', 'https://centerpanel.11exch.in/Matchapi?market_id=');
define('domain', client_url . '/');
define('series_api', 'http://128.199.24.35/v3-api/match/getCompetitions?sportId=4');
define('match_api', 'http://128.199.24.35/v3-api/match/getMatches?competitionId=');
define('session_api', 'http://128.199.24.35/v3-api/fancy/getAllFancies/');
define('base_url', client_url . '');
define('socket_url', 'http://65.0.21.59:8080/');
define('central_match_api', client_url . '/match_list');
define('diamond_api', 'http://betsexchange.in/api/diamond_odds.php?market_id=');
define('redcrick_api', 'http://royalold.com/api/MatchOdds/GetOddslite/4/');
define('another_odds_api', 'https://api.hypexone.com/api/v1/common-feed/list-event/4/11365612/30458779');
define('11hub_api', 'http://65.2.110.40/api/v2/');
define('betexch_api', 'http://13.233.25.134:1234/api/v2/');
define('login_for', 'all');    // all for all login panels
define('logo_path', './img/logo.png');
//Casino api result

define('teen_patti_t20', 'http://3.6.94.71:3000/getresult/teen20');  
define('captcha', false);
define('bookmaker', 'http://139.177.188.73:3000/getBM?eventId=');
define('worldindia_bookmaker', "https://worldindia.bet/GameData/");
define('coins_merge', false);

define('max_match_comm', 5);
define('max_session_comm', 5);
define('max_casino_comm', 5);
define('transaction_password', 'ilu30495@S');
define('environment', 'development');
define('is_casino', true);
define('is_football', true);
define('is_tennis', true);

// DB Constants


$iframe_url=[
    'cricket1'=>'https://scoretemplate.wb4.in/?eid=',  // pass event_id
    'football'=>'https://internal-consumer-apis.jmk888.com/go-score/template/',
];

define('iframe_url',$iframe_url);


$casino_api=[
'teen_patti_t20'=>"http://api.betguru.bet/api?ApiType=teenpatti_t20_data",
'teenpatti_t20_result'=>"http://api.betguru.bet/api?ApiType=teenpatti_t20_result",
'lucky7_data'=>"http://api.betguru.bet/api?ApiType=lucky7_data",
'lucky7_result'=>"http://api.betguru.bet/api?ApiType=lucky7_result",
'dragon_tiger_data'=>"http://api.betguru.bet/api?ApiType=dragon_tiger_data",
'dragon_tiger_result'=>"http://api.betguru.bet/api?ApiType=dragon_tiger_result",
'aaa_data'=>"http://api.betguru.bet/api?ApiType=aaa_data",
'aaa_result'=>"http://api.betguru.bet/api?ApiType=aaa_result",
'all_casino_api'=>'http://api.betguru.bet/api?ApiType=all_casino_result?market_id='
];
define('casino_api',$casino_api);
$user_list_strat=['superadmin'=>1, 'admin'=>51 , 'master'=>101 , 'superagent'=>121 , 'agent'=>201 ,'client'=>1000];
define('user_list_strat',$user_list_strat);
define('owner_api',true);
define('redis',false);
define('logo',true);
define('oneex',false);