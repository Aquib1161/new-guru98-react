<?php  


function agent_flat_share($flat_share,$user_id,$parent_data='')
{
  $send_data=['status'=>'error','msg'=>'Flat share can not be greather than your assign share OR Flat share can not be less than agent share'];
  $userdata=get_data('users_tbl',"user_id='".$user_id."'",'s');
  $parent_data=get_data('users_tbl',"user_id='".$userdata['creater_id']."'",'s');
  $parent_show_type=$parent_data['user_type']=='superagent'?'sa':$parent_data['user_type'];
  if($flat_share>$parent_data['user_share'] || $flat_share<$userdata['user_share'])
  {
     return $send_data;
     die();
     exit(); 
  }
   
  $user_data_update=['sa_share'=>$flat_share];
  $update=update_array('users_tbl',$user_data_update,"user_id='".$user_id."'");
  $master_share=$parent_data['master_share']-$flat_share;
  $update_array=[
      'sa_share'=>$flat_share-$userdata['user_share'],
      'sa_share_total_value'=>$flat_share,
      'master_share'=>$master_share,
    ];
   // _d($update_array);
  $update=update_array('client',$update_array,"A_id='".$userdata['user_id']."'");

  $client_data=get_data('client',"A_id='".$user_id."'");

  foreach ($client_data as $key => $client) 
  {
      flate_share_client_share_update($client['id'],$client);
  }


     $data_array=array(
                    'client'=>'('.$userdata['name'].') '.$userdata['username'].'',
                    'old'=>$userdata[$parent_show_type.'_share'],
                    'new'=>$flat_share,
                    'user'=>$userdata['username'],
                    'note'=>'SUPERAGENT ('.$parent_data['username'].' '.$parent_data['name'].') FLAT SHARE  change from '.$userdata[$parent_show_type.'_share'].' To '.$flat_share. ' IN agent ('. $userdata['username'].' '. $userdata['name'].')',
                    'type'=>'share_change_on',
                );

                $task_array=array(
                    'user_id'=>$parent_data['user_id'],
                    'user_type'=>$parent_data['user_type'],
                    'note'=>'SUPERAGENT ('.$parent_data['username'].' '.$parent_data['name'].') FLAT SHARE  change from '.$userdata[$parent_show_type.'_share'].' To '.$flat_share. ' IN agent ('. $userdata['username'].' '. $userdata['name'].')',
                    'user_type'=>'agent',
                    'creater_id'=>$_SESSION['user_id'],
                    'creater_type'=>$_SESSION['user_type'],
                    'creater_name'=>$_SESSION['name'],
                    'ip'=>ip(),
                    'date'=>_date(),
                    'date_time'=>_date_time(),
                    'user_name'=>$userdata['name'],
                    'history_type'=>'share_change_on',
                    'data_array'=>json_encode($data_array),
                    'agent_id'=>$userdata['agent_id'],
                    'sa_id'=>$userdata['sa_id'],
                    'master_id'=>$userdata['master_id'],
                    'admin_id'=>$userdata['admin_id'],
                    'superadmin_id'=>$userdata['superadmin_id'],
                );
            $result=insert_array('user_history_log',$task_array);
            return $send_data=['status'=>'success','msg'=>'Flat Share Changed Successfully'];


}



function superagent_flat_share($flat_share,$user_id,$user_type)
{

  $send_data=['status'=>'error','msg'=>'Flat share can not be greather than your assign share OR Flat share can not be less than agent share'];
  $userdata=get_data('users_tbl',"user_id='".$user_id."'",'s');
  $parent_data=get_data('users_tbl',"user_id='".$userdata['creater_id']."'",'s');
  $parent_show_type=$parent_data['user_type']=='superagent'?'sa':$parent_data['user_type'];
  if($flat_share>$parent_data['user_share'] || $flat_share<$userdata['user_share'])
  {
     return $send_data;
     die();
     exit(); 
  }
   
  $user_data_update=['master_share'=>$flat_share];
  $update=update_array('users_tbl',$user_data_update,"user_id='".$user_id."'");
  $admin_share=$parent_data['admin_share']-$flat_share;
  $update_array=[
      'master_share'=>$flat_share-$userdata['user_share'],
      'master_share_total_value'=>$flat_share,
      'admin_share'=>$admin_share,
    ];
  $update=update_array('client',$update_array,"sa_id='".$userdata['user_id']."'");
  $client_data=get_data('client',"sa_id='".$user_id."'");
  foreach ($client_data as $key => $client) 
  {
      flate_share_client_share_update($client['id'],$client);
  }


     $data_array=array(
                    'client'=>'('.$userdata['name'].') '.$userdata['username'].'',
                    'old'=>$userdata[$parent_show_type.'_share'],
                    'new'=>$flat_share,
                    'user'=>$userdata['username'],
                    'note'=>'SUPERAGENT ('.$parent_data['username'].' '.$parent_data['name'].') FLAT SHARE  change from '.$userdata[$parent_show_type.'_share'].' To '.$flat_share. ' IN agent ('. $userdata['username'].' '. $userdata['name'].')',
                    'type'=>'share_change_on',
                );

                $task_array=array(
                    'user_id'=>$parent_data['user_id'],
                    'user_type'=>$parent_data['user_type'],
                    'note'=>'SUPERAGENT ('.$parent_data['username'].' '.$parent_data['name'].') FLAT SHARE  change from '.$userdata[$parent_show_type.'_share'].' To '.$flat_share. ' IN agent ('. $userdata['username'].' '. $userdata['name'].')',
                    'user_type'=>'agent',
                    'creater_id'=>$_SESSION['user_id'],
                    'creater_type'=>$_SESSION['user_type'],
                    'creater_name'=>$_SESSION['name'],
                    'ip'=>ip(),
                    'date'=>_date(),
                    'date_time'=>_date_time(),
                    'user_name'=>$userdata['name'],
                    'history_type'=>'share_change_on',
                    'data_array'=>json_encode($data_array),
                    'agent_id'=>$userdata['agent_id'],
                    'sa_id'=>$userdata['sa_id'],
                    'master_id'=>$userdata['master_id'],
                    'admin_id'=>$userdata['admin_id'],
                    'superadmin_id'=>$userdata['superadmin_id'],
                );
            $result=insert_array('user_history_log',$task_array);
            return $send_data=['status'=>'success','msg'=>'Flat Share Changed Successfully'];

}


function master_flat_share($flat_share,$user_id,$user_type)
{


  $send_data=['status'=>'error','msg'=>'Flat share can not be greather than your assign share OR Flat share can not be less than agent share'];
  $userdata=get_data('users_tbl',"user_id='".$user_id."'",'s');
  $parent_data=get_data('users_tbl',"user_id='".$userdata['creater_id']."'",'s');
  $parent_show_type=$parent_data['user_type']=='superagent'?'sa':$parent_data['user_type'];
  if($flat_share>$parent_data['user_share'] || $flat_share<$userdata['user_share'])
  {
     return $send_data;
     die();
     exit(); 
  }
   
  $user_data_update=['admin_share'=>$flat_share];
  $update=update_array('users_tbl',$user_data_update,"user_id='".$user_id."'");
  $superadmin_share=$parent_data['superadmin_share']-$flat_share;
  $update_array=[
      'admin_share'=>$flat_share-$userdata['user_share'],
      'admin_share_total_value'=>$flat_share,
      'superadmin_share'=>$superadmin_share,
    ];
  $update=update_array('client',$update_array,"master_id='".$userdata['user_id']."'");
  $client_data=get_data('client',"master_id='".$user_id."'");
  foreach ($client_data as $key => $client) 
  {
      flate_share_client_share_update($client['id'],$client);
  }


     $data_array=array(
                    'client'=>'('.$userdata['name'].') '.$userdata['username'].'',
                    'old'=>$userdata[$parent_show_type.'_share'],
                    'new'=>$flat_share,
                    'user'=>$userdata['username'],
                    'note'=>'SUPERAGENT ('.$parent_data['username'].' '.$parent_data['name'].') FLAT SHARE  change from '.$userdata[$parent_show_type.'_share'].' To '.$flat_share. ' IN agent ('. $userdata['username'].' '. $userdata['name'].')',
                    'type'=>'share_change_on',
                );

                $task_array=array(
                    'user_id'=>$parent_data['user_id'],
                    'user_type'=>$parent_data['user_type'],
                    'note'=>'SUPERAGENT ('.$parent_data['username'].' '.$parent_data['name'].') FLAT SHARE  change from '.$userdata[$parent_show_type.'_share'].' To '.$flat_share. ' IN agent ('. $userdata['username'].' '. $userdata['name'].')',
                    'user_type'=>'agent',
                    'creater_id'=>$_SESSION['user_id'],
                    'creater_type'=>$_SESSION['user_type'],
                    'creater_name'=>$_SESSION['name'],
                    'ip'=>ip(),
                    'date'=>_date(),
                    'date_time'=>_date_time(),
                    'user_name'=>$userdata['name'],
                    'history_type'=>'share_change_on',
                    'data_array'=>json_encode($data_array),
                    'agent_id'=>$userdata['agent_id'],
                    'sa_id'=>$userdata['sa_id'],
                    'master_id'=>$userdata['master_id'],
                    'admin_id'=>$userdata['admin_id'],
                    'superadmin_id'=>$userdata['superadmin_id'],
                );
            $result=insert_array('user_history_log',$task_array);
            return $send_data=['status'=>'success','msg'=>'Flat Share Changed Successfully'];



}



function change_flat_share($flat_share,$user_id,$user_type)
{
  if($user_type=='agent')
  {
  	$return=agent_flat_share($flat_share,$user_id,$user_type);
  }
  else if($user_type=='superagent')
  {
    $return=superagent_flat_share($flat_share,$user_id,$user_type);
  }
  else if($user_type=='master')
  {
    $return=master_flat_share($flat_share,$user_id,$user_type);
  }
  else
  {
    $return = ['status'=>'error','msg'=>'Something Went Wrong'];
  }

  return $return;
}


?>