<?php
$con = mysqli_connect("localhost","admin_11exch","ilu30495@SI$@SS","admin_11exch");
//$con = mysqli_connect("dbonexlive.cq82uvd5jmwu.ap-south-1.rds.amazonaws.com","admin","we7neVoQ3b44iv","admin_6pro");
$read_con = $con;
if (!$con) {
  die("Connection failed: " . mysqli_connect_error());
}
