<?php

function admin_session_position($market_id,$session_id)
{
global $con;
$market_id	= $market_id;
$marketid	= $market_id;
$sessionId  = $session_id;
$selectionid  = $session_id;

$query = "SELECT * FROM client_session_bat_tbl WHERE market_id = '$marketid'  AND selection_id = '$selectionid'  ORDER BY bet_run ASC";		
$prev_session_res = mysqli_query($con,$query);

$prev_session_bets=array();
		while($prev_session = mysqli_fetch_assoc($prev_session_res))
		{
              array_push($prev_session_bets, $prev_session);
		}

		$runs = array_map(function($el)
		{	
				return $el['bet_run'];
		}, $prev_session_bets);


		$runs = array_unique($runs);

		$uniqruns = array_map(function($el)
		{
			return [$el-1,$el,$el+1];
		}, $runs);

   
		$finalarr = array();
		foreach ($uniqruns as $r) {
			foreach ($r as $rn) {
				array_push($finalarr, $rn);
			}
		}

		$finalarr = array_unique($finalarr);
		$array_insert = array();


		foreach ($finalarr as $fnr) {
			 foreach ($prev_session_bets as $bet) {	
			    $client_id = $bet['client_id'];
			    $query = "SELECT * FROM shares WHERE market_id = '$marketid' AND client_id='$client_id' ";		
                $share_res = mysqli_query($con,$query);
                $share_data=mysqli_fetch_assoc($share_res);
                //_dx($share_data);
                $admin_share=$share_data['admin_share'];
                $master_commission_type=$share_data['master_commission_type'];
                $master_match_commission=$share_data['master_match_commission'];
                $master_session_commission=$share_data['master_session_commission'];


				 if( $fnr >= $bet['bet_run'] && $bet['type'] == "Y"){
                  $commission_amount=floor($bet['amount'])*floatval($bet['bhav']);
                  $amount_for_commmission=floor($bet['amount']);
                   $admin_position=floor($bet['amount'])*floatval($bet['bhav']);
				if($master_commission_type=='BB'){
		          $master_session_commission1=($master_session_commission/100);
		          $master_overall_amount=($commission_amount+(abs($amount_for_commmission)*$master_session_commission1));
		          $admin_position=($admin_share/100)*$master_overall_amount;
		          }
		          if($master_commission_type=='OM' && $commission_amount<0){
		          $master_session_commission=($master_session_commission/100);
		          $master_overall_amount=($commission_amount+(abs($amount_for_commmission)*$master_session_commission));
		          $admin_position=($admin_share/100)*$master_overall_amount;
		         }
		         if($master_commission_type=='OM' && $commission_amount>0){
		          $master_session_commission=($master_session_commission/100);
		          $master_overall_amount=($commission_amount);
		          $admin_position=($admin_share/100)*$master_overall_amount;
		         }
		         if($master_commission_type=='No Comm'){
		         	 $admin_position=$commission_amount*($admin_share/100);
		         }


			
				 		$tmp = array(
	                  		'run' 		=>  $fnr,
				 			'admin_position'	=>	round($admin_position,2),
				 			
				 		);

				 	}

          
				if($fnr >= $bet['bet_run']  && $bet['type'] == "N"){
					$client_id = $bet['client_id'];
                 
					  $commission_amount=-floatval($bet['amount'])*floatval($bet['bhav']);
					  $amount_for_commmission=-floatval($bet['amount']);
					  $admin_position=-floatval($bet['amount'])*floatval($bet['bhav']);

				if($master_commission_type=='BB'){
		          $master_session_commission1=($master_session_commission/100);
		          $master_overall_amount=($commission_amount+(abs($amount_for_commmission)*$master_session_commission1));
		          $admin_position=($admin_share/100)*$master_overall_amount;
		          }
		          if($master_commission_type=='OM' && $commission_amount<0){
		          $master_session_commission=($master_session_commission/100);
		          $master_overall_amount=($commission_amount+(abs($amount_for_commmission)*$master_session_commission));
		          $admin_position=($admin_share/100)*$master_overall_amount;
		         }
		         if($master_commission_type=='OM' && $commission_amount>0){
		          $master_session_commission=($master_session_commission/100);
		          $master_overall_amount=($commission_amount);
		          $admin_position=($admin_share/100)*$master_overall_amount;
		         }
		         if($master_commission_type=='No Comm'){
		         	 $admin_position=$commission_amount*($admin_share/100);
		         }

			 		$tmp = array(
			 			'run' 		=>  $fnr,
			 			'admin_position'	=>	round($admin_position,2),
			 			
			 		);
			 	}

			 	if(  $fnr < $bet['bet_run']  && $bet['type'] == "Y"){
			 			 
			 			  $commission_amount=-floatval($bet['amount']);
			 			  $amount_for_commmission=-floatval($bet['amount']);
			 			  $admin_position=-floatval($bet['amount']);
				if($master_commission_type=='BB'){
		          $master_session_commission1=($master_session_commission/100);
		          $master_overall_amount=($commission_amount+(abs($amount_for_commmission)*$master_session_commission1));
		          $admin_position=($admin_share/100)*$master_overall_amount;
		          }
		          if($master_commission_type=='OM' && $commission_amount<0){
		          $master_session_commission=($master_session_commission/100);
		          $master_overall_amount=($commission_amount+(abs($amount_for_commmission)*$master_session_commission));
		          $admin_position=($admin_share/100)*$master_overall_amount;
		         }
		         if($master_commission_type=='OM' && $commission_amount>0){
		          $master_session_commission=($master_session_commission/100);
		          $master_overall_amount=($commission_amount);
		          $admin_position=($admin_share/100)*$master_overall_amount;
		         }
		         if($master_commission_type=='No Comm'){
		         	 $admin_position=$commission_amount*($admin_share/100);
		         }

				 		$tmp = array(
			 			'run' 		=>  $fnr,
			 			'admin_position'	=>	round($admin_position,2),
			 			
			 		);
			 	}

			 	if($fnr  < $bet['bet_run'] && $bet['type'] == "N"){
			 		$client_id = $bet['client_id'];
                
			 		  $commission_amount=floor($bet['amount']);
			 		  $amount_for_commmission=floor($bet['amount']);
			 		  $admin_position=floor($bet['amount']);
				if($master_commission_type=='BB'){
		          $master_session_commission1=($master_session_commission/100);
		          $master_overall_amount=($commission_amount+(abs($amount_for_commmission)*$master_session_commission1));
		          $admin_position=($admin_share/100)*$master_overall_amount;
		          }
		          if($master_commission_type=='OM' && $commission_amount<0){
		          $master_session_commission=($master_session_commission/100);
		          $master_overall_amount=($commission_amount+(abs($amount_for_commmission)*$master_session_commission));
		          $admin_position=($admin_share/100)*$master_overall_amount;
		         }
		         if($master_commission_type=='OM' && $commission_amount>0){
		          $master_session_commission=($master_session_commission/100);
		          $master_overall_amount=($commission_amount);
		          $admin_position=($admin_share/100)*$master_overall_amount;
		         }
		         if($master_commission_type=='No Comm'){
		         	 $admin_position=$commission_amount*($admin_share/100);
		         }


	 					$tmp = array(             
                        'run' 		=>  $fnr,
			 			'admin_position'	=>	round($admin_position,2),
			 			
			 		);
			 	}			 	
			 	$tmp['market_id'] 	 = $marketid;
			 	$tmp['selection_id'] = $selectionid;
			 	array_push($array_insert, $tmp);
			 }		 
		}

    $rundata= array();
    foreach ($array_insert as $item) 
    {
        $key = $item['run'];
        if (!array_key_exists($key, $rundata)) 
        {
            $rundata[$key] = array(
                'run' => $item['run'],
                'pos' => $item['admin_position'],
                
            );
        } 
        else 
        {
            $rundata[$key]['pos'] = ($rundata[$key]['pos'] + $item['admin_position']);
            
        }
    }

    $send_rundata=array();
    asort($rundata);

foreach ($rundata as $key => $value) 
{
     	
     	if($value['pos']<0)
     	{
     		$value['pos']=round(abs($value['pos']),2);
     	}
     	else
     	{
     		$value['pos'] = round(-1*$value['pos'],2);
     	}
        
        $push_aaray=array(
            
            'run'=>$value['run'],
            'pos'=>$value['pos']
        );
     	array_push($send_rundata, $push_aaray);
 }

return $send_rundata;

}

?>