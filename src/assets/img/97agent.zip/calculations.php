<?php
$market_id = '1.203021080';
// $con = mysqli_connect('newhub-in-database.croppyszcv0r.ap-south-1.rds.amazonaws.com', 'admin', '7E:]1E?%(m$k,8-d', 'admin_6pro');
$con = mysqli_connect("sixpro-in-database.ccznoslw4379.ap-south-1.rds.amazonaws.com", "admin", "we7neVoQ3b44iv", "admin_6pro");


echo "<pre>";
if (!$con) {
    echo "DB Error";
} else {
    // Teams
    $teams_query = "SELECT * FROM match_team_tbl WHERE market_id='$market_id'";
    $teams_result = mysqli_query($con, $teams_query);
    $runners = mysqli_fetch_all($teams_result, MYSQLI_ASSOC);
    // print_r($runners);
    $query = "SELECT * FROM client_match_bet_tbl WHERE market_id = $market_id";

    $updatesQueries = [];
    $result = mysqli_query($con, $query);
    if (!$result) {
        echo "error";
    } else {
        $rows = mysqli_fetch_all($result, MYSQLI_ASSOC);
        // print_r($rows);
        // echo  . "\n";
        $i = 1;
        foreach ($rows as $bet) {
            $a = 1;
            foreach ($runners as $run) {
                // echo $i . "-" .$a . "\n";
                //if fav team will win in case of k		
                $selection_id = $run['selection_id'];
                // echo ($run['selection_id'] . ", " . $bet['selection_id']) . ", " . $bet['client_match_bet_id'] .", ", $bet['selection_id'] . "\n";

                $betAutoLimit = empty($bet['auto_limit']) ? "'No'" : "'$bet[auto_limit]'";
                if ($run['selection_id'] == $bet['selection_id']  && $bet['type'] == "K") {
                    // echo ("1") . "\n";
                    $profit = -1 * ($bet['amount'] * $bet['bhav']);
                    // die($profit);
                    $agent_amount    = ($bet['agent_share'] / 100) * $profit;
                    $master_amount     = ($bet['master_share'] / 100) * $profit;
                    $sa_amount           = ($bet['sa_share'] / 100) * $profit;
                    $admin_amount    = ($bet['admin_share'] / 100) * $profit;
                    $superadmin_amount    = ($bet['superadmin_share'] / 100) * $profit;

                    $updatesQueries[$i + $a] = "INSERT INTO admin_6pro.match_bet_calculation (selection_id, bat_id, market_id, profit, client_id, sa_id, master_id, agent_id, match_name ,admin_share,master_share,sa_share,agent_share,auto_limit,admin_amount,master_amount,sa_amount,agent_amount,superadmin_id,superadmin_amount,superadmin_share,admin_id,random_id)
                                    VALUES (
                                        '$selection_id',
                                        '1',
                                        '$bet[market_id]',
                                        $profit,
                                        $bet[client_id],
                                        $bet[super_agent_id],
                                        $bet[master_id],
                                        $bet[agent_id],
                                        '$bet[team_name]',
                                        $bet[admin_share],
                                        $bet[master_share],
                                        $bet[sa_share],
                                        $bet[agent_share],
                                        $betAutoLimit,
                                        $admin_amount,
                                        $master_amount,
                                        $sa_amount,
                                        $agent_amount,
                                        $bet[superadmin_id],
                                        $superadmin_amount,
                                        $bet[superadmin_share],
                                        $bet[admin_id],
                                        '$bet[random_id]'
                                    );";
                    //_dx($query1);
                    // $this->db->query($query1);
                }

                if ($selection_id == $bet['selection_id']  && $bet['type'] == "L") {
                    // echo ("2") . "\n";
                    $profit = $bet['amount'] * $bet['bhav'];
                    $agent_amount = ($bet['agent_share'] / 100) * $profit;
                    $master_amount     = ($bet['master_share'] / 100) * $profit;
                    $sa_amount           = ($bet['sa_share'] / 100) * $profit;
                    $admin_amount    = ($bet['admin_share'] / 100) * $profit;
                    $superadmin_amount    = ($bet['superadmin_share'] / 100) * $profit;

                    $updatesQueries[$i + $a] = "INSERT INTO admin_6pro.match_bet_calculation (selection_id, bat_id, market_id, profit, client_id, sa_id, master_id, agent_id, match_name ,admin_share,master_share,sa_share,agent_share,auto_limit,admin_amount,master_amount,sa_amount,agent_amount,superadmin_id,superadmin_amount,superadmin_share,admin_id,random_id)
                                    VALUES (
                                        '$selection_id',
                                        '1',
                                        '$bet[market_id]',
                                        $profit,
                                        $bet[client_id],
                                        $bet[super_agent_id],
                                        $bet[master_id],
                                        $bet[agent_id],
                                        '$bet[team_name]',
                                        $bet[admin_share],
                                        $bet[master_share],
                                        $bet[sa_share],
                                        $bet[agent_share],
                                        $betAutoLimit,
                                        $admin_amount,
                                        $master_amount,
                                        $sa_amount,
                                        $agent_amount,
                                        $bet[superadmin_id],
                                        $superadmin_amount,
                                        $bet[superadmin_share],
                                        $bet[admin_id],
                                        '$bet[random_id]'
                                    );";
                }

                //if non fav team will win in case of :L
                if ($selection_id != $bet['selection_id']  && $bet['type'] == "L") {
                    // echo ("3") . "\n";
                    $profit = -1 * $bet['amount'];
                    $agent_amount = ($bet['agent_share'] / 100) * $profit;
                    $master_amount     = ($bet['master_share'] / 100) * $profit;
                    $sa_amount           = ($bet['sa_share'] / 100) * $profit;
                    $admin_amount    = ($bet['admin_share'] / 100) * $profit;
                    $superadmin_amount    = ($bet['superadmin_share'] / 100) * $profit;

                    $updatesQueries[$i + $a] = "INSERT INTO admin_6pro.match_bet_calculation (selection_id, bat_id, market_id, profit, client_id, sa_id, master_id, agent_id, match_name ,admin_share,master_share,sa_share,agent_share,auto_limit,admin_amount,master_amount,sa_amount,agent_amount,superadmin_id,superadmin_amount,superadmin_share,admin_id,random_id)
                                    VALUES (
                                        '$selection_id',
                                        '1',
                                        '$bet[market_id]',
                                        $profit,
                                        $bet[client_id],
                                        $bet[super_agent_id],
                                        $bet[master_id],
                                        $bet[agent_id],
                                        '$bet[team_name]',
                                        $bet[admin_share],
                                        $bet[master_share],
                                        $bet[sa_share],
                                        $bet[agent_share],
                                        $betAutoLimit,
                                        $admin_amount,
                                        $master_amount,
                                        $sa_amount,
                                        $agent_amount,
                                        $bet[superadmin_id],
                                        $superadmin_amount,
                                        $bet[superadmin_share],
                                        $bet[admin_id],
                                        '$bet[random_id]'
                                    );";

                    // $res = $this->db->query($query1);
                }

                //if non fav team will win in case of :K
                if ($selection_id != $bet['selection_id']  && $bet['type'] == "K") {
                    // echo ("4") . "\n";
                    $profit = $bet['amount'];
                    $agent_amount = ($bet['agent_share'] / 100) * $profit;
                    $master_amount     = ($bet['master_share'] / 100) * $profit;
                    $sa_amount           = ($bet['sa_share'] / 100) * $profit;
                    $admin_amount    = ($bet['admin_share'] / 100) * $profit;
                    $superadmin_amount    = ($bet['superadmin_share'] / 100) * $profit;

                    $updatesQueries[$i + $a] = "INSERT INTO admin_6pro.match_bet_calculation (selection_id, bat_id, market_id, profit, client_id, sa_id, master_id, agent_id, match_name ,admin_share,master_share,sa_share,agent_share,auto_limit,admin_amount,master_amount,sa_amount,agent_amount,superadmin_id,superadmin_amount,superadmin_share,admin_id,random_id)
                                    VALUES (
                                        '$selection_id',
                                        '1',
                                        '$bet[market_id]',
                                        $profit,
                                        $bet[client_id],
                                        $bet[super_agent_id],
                                        $bet[master_id],
                                        $bet[agent_id],
                                        '$bet[team_name]',
                                        $bet[admin_share],
                                        $bet[master_share],
                                        $bet[sa_share],
                                        $bet[agent_share],
                                        $betAutoLimit,
                                        $admin_amount,
                                        $master_amount,
                                        $sa_amount,
                                        $agent_amount,
                                        $bet[superadmin_id],
                                        $superadmin_amount,
                                        $bet[superadmin_share],
                                        $bet[admin_id],
                                        '$bet[random_id]'
                                    );";
                }

                $i += $a;
                $a++;
            }
            // $i++;
        }

        echo implode("<br>", $updatesQueries);
    }
}
