<?php 
include('include/config.php');
include('header.php');
$client_data=get_user_list('client','','client','1');
$position=array();
if(isset($_POST['submit']))
{ 
  $page_name=$_POST['page_name'];  
  $_POST['to_date']=date_convert($_POST['to_date']);
  $_POST['from_date']=date_convert($_POST['from_date']);
  $position=get_data('md_client_position',"client_id='".$_POST['client_id']."' AND ledger_update_date BETWEEN '".$_POST['from_date']."' AND '".$_POST['to_date']."'");

  $_POST['to_date']=date_convert($_POST['to_date'],'c');
  $_POST['from_date']=date_convert($_POST['from_date'],'c');
}
else
{
  $_POST['from_date']=date_convert('','c');
  $_POST['to_date']=date_convert('','c');
  $_POST['client_id']='';
  if(!isset($_GET['page_name']))
  {
    $_GET['page_name']='client';
  }
  $page_name=$_GET['page_name'];
}
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Plus Minus</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="dashboard?page_name=dashboard">Home</a></li>
              <li class="breadcrumb-item active">Client Plus Minus</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">

                        <!-- /.card -->

                        <div class="card">


                            <form action="client_plus_minus" method="post">
                                <input type="hidden" name="page_name" value="<?= $page_name ?>">
                                <div class="card-header bg-gradient-purple">
                                    <h4>Client Report</h4>
                                    <div class="form-row">
                                        <div class="form-group col-md-3">
                                            <label for="name">Client</label>
                                           <select   class="form-control select2" required="" id="client_id" placeholder="Select ...." name="client_id" aria-hidden="true">
                                              <option value="">Select ...</option>
                                                <?php foreach ($client_data as $key => $client) { ?>
                                                 <option <?php if($_POST['client_id']==$client['id']) echo 'selected'; ?> value="<?= $client['id']?>"><?= $client['ClientName']?> (<?= $client['username']?>)</option>
                                                 <?php  }  ?>
                                                
                                            </select>
                                        </div>

                                        <div class="form-group col-md-2">
                                            <div class="form-group">
                                                <label for="from_date">Date From</label>
                                                <div >

                                                    <input type="date" class="form-control" id="from_date"  name="from_date" value="<?= $_POST['from_date'] ?>">

                                                    <div class="input-group-append" data-target="#reservationdateTo" data-toggle="datetimepicker">
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group col-md-2">
                                            <div class="form-group">
                                                <label for="to_date">Date To</label>
                                                <div >

                                                    <input type="date" class="form-control" id="to_date"  name="to_date" value="<?= $_POST['to_date'] ?>">

                                                    <div class="input-group-append" data-target="#reservationdateTo" data-toggle="datetimepicker">
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group col-md-3">

                                            <label class="control-label text-purple" for="btn">`</label>
                                            <input type="submit" class="form-control btn-primary" id="btn" name="submit" value="Sumbit">

                                        </div>


                                    </div>


                                </div>
                                <!-- /.card-header -->


                                <div class="card-body">
                                    <div>

                                        <table class="table table-bordered table-striped">
                                            <thead>
                                            <tr>

                                                <th colspan="2"></th>
                                                <th colspan="3">Match</th>
                                                <th colspan="3">Session</th>
                                                <th colspan="2">Other Amount</th>
                                                <th></th>
                                            </tr>

                                            <tr>

                                                <th> Date</th>
                                                <th>Match Name</th>
                                                <th>Match</th>
                                                <th>Session</th>
                                                <th>Total</th>
                                                <th>Match</th>
                                                <th>Session</th>
                                                <th>Total</th>
                                                <th>Mob</th>
                                                <th>Final</th>
                                                <th>Balance</th>
                                            </tr>

                                            <tr>

                                                <th class="text-right" colspan="10">Opening Balance</th>

                                                <th></th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                              <?php 
                                                $total_client_match_coins=0;
                                                $total_client_session_coins=0;
                                                $total_client_match_comm=0;
                                                $total_client_session_comm=0;
                                                $total_mobile_charge=0;
                                                $total_match_session=0;
                                               
                                                $total_client_mobile_charge=0;
                                                $total_final=0;
                                                $total_match_session_comm=0;
                                                $final=0;

                                                  foreach ($position as $key => $value) 
                                              { 

                                                $total_client_match_coins+=$value['client_match_coins'];
                                                $total_client_session_coins+=$value['client_session_coins'];

                                                $match_session=$value['client_match_coins']+$value['client_session_coins'];
                                                $total_client_match_comm+=$value['client_match_commission'];
                                                $total_client_session_comm+=$value['client_session_commission'];
                                               
                                                $total_client_mobile_charge+=$value['client_mobile_charge'];

                                                $final=$value['client_match_coins']+$value['client_session_coins']+$value['client_match_commission']+$value['client_session_commission']-$value['client_mobile_charge'];

                                                $total_final+=$final;
                                                $total_final+=$final;
                                                $total_match_session+=$match_session;
                                                $total_mobile_charge=$value['client_mobile_charge'];
                                                $total_match_session_comm+=$value['client_session_commission']+$value['client_match_commission'];


                                              ?>
                                                
                                             

 
                                            <tr>
                                                <td><?= $value['ledger_update_date'] ?></td>
                                                <td><?= strtoupper($value['match_name']) ?></td>
                                                <td><?= round($value['client_match_coins'],2) ?></td>
                                                <td><?= round($value['client_session_coins'],2) ?></td>
                                                <td><?= round(($value['client_session_coins']+$value['client_match_coins']),2) ?></td>
                                                <td><?= round(($value['client_match_commission']),2) ?></td>
                                                 <td><?= round(($value['client_session_commission']),2) ?></td>
                                                 <td><?= round(($value['client_match_commission']+$value['client_session_commission']),2) ?></td>
                                                <td><?= round(($value['client_mobile_charge']),2) ?></td>
                                                <td><?= round($final,2) ?></td>
                                                <td><?= round($final,2) ?></td>
                                               

                                            </tr>

                                          <?php }  ?>

                                         

                                            <tr class="text text-lg text-bold">
                                                <td>Total</td>
                                                <td></td>
                                                <td><?= round($total_client_match_coins,2) ?></td>
                                                <td><?= round($total_client_session_coins,2) ?></td>
                                                <td><?= round($total_match_session,2) ?></td>
                                                
                                                <td><?= round($total_client_match_comm,2) ?></td>
                                                <td><?= round($total_client_session_comm,2) ?></td>
                                                <td><?= round($total_match_session_comm,2)?></td>
                                                <td><?= round($total_mobile_charge,2)?></td>
                                                <td><?= round($final,2) ?></td>
                                                <td></td>

                                            </tr>


                                            </tbody>
                                            <tfoot>

                                            </tfoot>
                                        </table>

                                    </div>
                                    

                                </div>
                                <!-- /.card-body -->
                            </form>

                        </div>
                        <!-- /.card -->


                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </section>

   

   
  </div>
  <!-- /.content-wrapper -->

  <?php  include('footer.php');  ?>