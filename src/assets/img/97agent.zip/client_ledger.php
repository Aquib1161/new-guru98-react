<?php
include('include/config.php');
$_GET = sanatize($_GET);
$_POST = sanatize($_POST);
extract($_GET);
$client_data = get_data('client', user_where('', 's'),'','ClientName,username,id');
include('header.php');
?>
<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Cash Transaction</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="dashboard?page_name=dashboard">Home</a></li>
                        <li class="breadcrumb-item active">Cash Transaction</li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">

                    <!-- /.card -->

                    <div class="card">
                        <div class="card-header ">
                            <h4 class="text-capitalize">client Ledger</h4>
                            <div class="form-row col-md-9">
                                <div class="form-group col-md-4">
                                    <label for="name" class="text-capitalize">client</label>
                                    <select onchange="change()" class="form-control select2" required="" id="user_id" placeholder="Select ...." name="user_id" data-select2-id="name" tabindex="-1" aria-hidden="true">
                                        <option value="0">Select ...</option>
                                        <?php foreach ($client_data as $key => $client) { ?>
                                            <option value="<?= $client['id'] ?>"><?= $client['ClientName'] ?> (<?= $client['username'] ?>)</option>
                                        <?php  }  ?>

                                    </select>
                                </div>

                              <!--   <div class="form-group col-md-4">
                                    <label for="collection">Statement Type</label>
                                    <select onchange="change()" class="form-control custom-select" required="" name="collection_type" id='collection_type' placeholder="Select Collection" name="collection">
                                        <option value="0">ALL</option>
                                        <option value="3">MATCH</option>
                                        <option value="2">CASINO</option>
                                        <option value="1">CASH</option>
                                    </select>
                                </div> -->

                                <div class="form-group col-md-4">
                                    <label for="collection">Collection</label>
                                    <select onchange="change()" class="form-control custom-select" required="" name="collection_type" id='collection_type' placeholder="Select Collection" name="collection">
                                        <option value="0">CA1 CASH</option>
                                       
                                    </select>
                                </div>

                                <div class="form-group col-md-4">

                                    <label for="amount">Amount</label>
                                    <input type="number" class="form-control " value="" step="any" type="number" name="amount" id="amount" placeholder="Amount">

                                </div>


                                <div class="form-group col-md-4">

                                    <label for="type">Payment Type</label>
                                    <select name="transaction_type" id='transaction_type' class="form-control custom-select">
                                        <option value="D">PAYMENT - DENA</option>
                                        <option value="C">RECEIPT - LENA</option>

                                    </select>

                                </div>


                                <div class="form-group col-md-4">
                                    <label for="remark">Remark</label>
                                    <input type="text" class="form-control " type="text" name="remark" id="remark" placeholder="Remark" value="">
                                </div>


                                <div class="form-group col-md-4">
                                    <label class="control-label text-purple" for="btn">`</label>
                                    <input type="submit" class="form-control btn-primary" id="submit" onclick="submit()" name="submit" value="Sumbit">
                                </div>


                            </div>


                        </div>
                        <!-- /.card-header -->
                        <span id="client_ledger"></span>







                        <!-- /.card-body -->


                    </div>
                    <!-- /.card -->


                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>




</div>
<!-- /.content-wrapper -->

<script type="text/javascript">
    function submit() {
        var user_id = $("#user_id").val();
        var transaction_type = $("#transaction_type").val();
        //var date=$("#date").val();
        var amount = $("#amount").val();
        var collection_type = 1;
        var statement_type = $("#collection_type").val();
        var remark = $("#remark").val();
        if (user_id == '') {
            alert('Please Select user first');
            return false;
        }
        if (transaction_type == '') {
            alert('Please Select transaction type');
            return false;
        }
        if (amount == 0 || amount == '') {
            alert('Please enter amount');
            return false;
        }


        sendData = {
            'id': user_id,
            'transaction_type': transaction_type,
            //'date':date,
            'amount': amount,
            'collection_type': collection_type,
            'note': remark,
            'statement_type': statement_type
        }
        data = sendAjax('ajax/ledger_update', sendData);
        if (data.status == 'success') {
            get_user_data(user_id);
            $("#amount").val('');
            $("#remark").val('');
        }
        swal(data.status, data.data.msg, data.status);




    }

    function get_user_data(client_id, statement_type) {
        $.ajax({
            url: "ajax/ajax_client_ledger",
            type: "post",
            data: {
                id: client_id,
                statement_type: statement_type
            },
            success: function(res) {
                /*alert(res);*/
                $("#client_ledger").html(res);
            }
        });
    }

    function change() {
        var client_id = $("#user_id").val();
        var statement_type = $("#collection_type").val();
        get_user_data(client_id, statement_type);

    }
</script>

<?php include('footer.php');  ?>