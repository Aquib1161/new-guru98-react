<?php 
$page_id='login';
include('include/config.php');
if(isset($_SESSION['is_verify_logged_in']))
{ 
    if($_SESSION['user_type']=='owner')
    {
     header("location:home");
    }
    else
    {
     header("location:dashboard?page_name=dashboard");   
    }
  die;
  exit();
}
else
{
$random_number=rand(1000,9999);
unset($_SESSION['verify_captcha']);
$_SESSION['verify_captcha']=$random_number;
}
$subdomain=subdomain();
if($subdomain=='')
{
  $subdomain='all';
}



/*echo subdomain();*/

?>  
<!DOCTYPE html>
<html>
<meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?= site_name ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="../../../../../code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- icheck bootstrap -->
  <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>
<body class="hold-transition login-page">
<div class="login-box">
  <div class="login-logo text-uppercase">
    <a style="color:#002775" href="index"><b><?= site_name ?> 
    
      <?php 
        if($subdomain=='agent')
        {
          echo 'Agent';
        }
        elseif($subdomain=='super')
        {
          echo 'Super Agent';
        }
        elseif($subdomain=='master')
        {
          echo 'Master Agent';
        }
        elseif($subdomain=='sub')
        {
           echo 'Sub Admin';
        }
        elseif($subdomain=='superadmin')
        {
          echo 'SuperAdmin Agent';
        }
        else
        {
          echo 'All Agent';
        }
      
        ?>
        </b>
    </a>
  </div>
  <!-- /.login-logo -->
  <div class="card">
    <?php if(logo){?>
    <center>
      <img src="dist/img/logo.jpg" height="100" width="100" ></center>
    <?php } ?>
    <div class="card-body login-card-body">
      <p style="color:#B38003" class="login-box-msg">WELCOME TO <?= site_name ?></p>
           <?= msg(); ?>
       <form action="login" name="login-form"class="BetPlayer-login-form" id="new_user"  method="post">
        <div class="input-group mb-3">
          <input required type="text" name="username" id='username'  class="form-control bg-white text-uppercase" placeholder="username">
          <div class="input-group-append">
            <div class="input-group-text">
              <span style="color:#022378" class="fas fa-envelope"></span>
            </div>
          </div>
        </div>
        <div class="input-group mb-3">
          <input required type="password" name="password" id='passsword' class="form-control" placeholder="PASSWORD">
          <div class="input-group-append">
            <div class="input-group-text">
              <span style="color:#022378" class="fas fa-lock"></span>
            </div>
          </div>
        </div>
        <div class="row">
          <!-- <div class="col-8">
            <div class="icheck-primary">
              <input type="checkbox" id="remember">
              <label for="remember">
                Remember Me
              </label>
            </div>
          </div> -->
        
        </div>
     <div class="social-auth-links text-center mb-3">
        <button style="background-color:#FF911F !important; border-color: #FF911F;" type="submit" name="submit" class="form-control btn btn-info btn-block">Login
                 </button>
      </div>
      </form>

      <!-- /.social-auth-links -->

     
    </div>
    <!-- /.login-card-body -->
  </div>
</div>
<!-- /.login-box -->

<script src="plugins/jquery/jquery.min.js"></script>
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="dist/js/adminlte.min.js"></script>

</body>
</html>

<script type="text/javascript">
  var iframe_name=window.name;
  console.log(iframe_name)
</script>
