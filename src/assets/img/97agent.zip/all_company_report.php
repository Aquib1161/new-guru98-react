<?php
include('include/config.php');
$_GET=sanatize($_GET);
extract($_GET);
extract($_POST);
$_POST['downline_array']=sanatize($_POST['downline_array']);
$_POST['session_array']=sanatize($_POST['session_array']);
$user_priority=$userdata['add_priority'];
$downline_user_type=priority_name($userdata['add_priority']-1);
$match_data=get_data('upcoming_match',"market_id='".$_POST['market_id']."'",'s','match_name,event_id,match_type,status,ledger_status');
if(redis && $match_data['status']=='COMPLETED' && $match_data['ledger_status']==1)
{
    $client_data=$redis->get('client_data_'.$market_id.'_'.$_SESSION['user_id']);
    if(!$client_data)
    {
        $where="".$downline_user_type."_id IN (".implode(',',$_POST['downline_array']).") AND market_id='".$market_id."'";
        $client_data=get_data('md_client_position',$where);
        $redis->set('client_data_'.$market_id.'_'.$_SESSION['user_id'],json_encode($client_data));
        $redis->expire('client_data_'.$market_id.'_'.$_SESSION['user_id'],60*1*60*24);     
    }
    else
    {
        $client_data=json_decode($client_data,true);
    }
}
else
{
   $downline_user_type=$downline_user_type=='superagent'?'sa':$downline_user_type;
   $where="".$downline_user_type."_id IN (".implode(',',$_POST['downline_array']).") AND market_id='".$market_id."'";
   //_dx($where);
   $client_data=get_data('md_client_position',$where);
}

$superadmin_array=[];
$admin_array=[];
$master_array=[];
$sa_array=[];
$agent_array=[];
$client_admin_data=[];
$client_master_data=[];
$client_sa_data=[];
$client_agent_data=[];

foreach ($client_data as $key => $data)
{  

   $array_data=json_decode($data['array_data'],true);
   $share_array=$array_data['share_array'];
   $user_data=$array_data['user_amount_old_type'];
   if(!array_key_exists($data['superadmin_id'],$superadmin_array))
   {
      $superadmin_array[$data['superadmin_id']]=$data['superadmin_name'];
      $superadmin_array[$data['superadmin_id']]=[
        'superadmin_name'=>$data['superadmin_name'],
        'total_agent_match_coins'=>$data['client_match_coins'],
        'total_agent_session_coins'=>$data['client_session_coins'],
        'total_agent_match_session_coins'=>$data['client_match_coins']+$data['client_session_coins'],

        'total_agent_match_comm'=>$data['agent_match_commission'],
        'total_agent_session_comm'=>$data['agent_session_commission'],
        'total_agent_match_session_comm'=>$data['agent_match_commission']+$data['agent_session_commission'],
        'total_agent_total_amount'=>$data['agent_total_amount'],
        'total_agent_share_amount'=>$user_data['agent_share_amount'],
        'total_agent_net_amount'=>$user_data['agent_net_amount'],
        'total_agent_company_amount'=>$user_data['agent_final_amount'],

        'total_sa_match_comm'=>$data['sa_match_commission'],
        'total_sa_session_comm'=>$data['sa_session_commission'],
        'total_sa_match_session_comm'=>$data['sa_match_commission']+$data['sa_session_commission'],
        'total_sa_share_amount'=>$user_data['sa_share_amount'],
        'total_sa_net_amount'=>$user_data['sa_net_amount'],
        'total_sa_company_amount'=>$user_data['sa_final_amount'],


        'total_master_match_comm'=>$data['master_match_commission'],
        'total_master_session_comm'=>$data['master_session_commission'],
        'total_master_match_session_comm'=>$data['master_match_commission']+$data['master_session_commission'],
        'total_master_share_amount'=>$user_data['master_share_amount'],
        'total_master_net_amount'=>$user_data['master_net_amount'],
        'total_master_company_amount'=>$user_data['master_final_amount'],


        'total_admin_match_comm'=>$data['admin_match_commission'],
        'total_admin_session_comm'=>$data['admin_session_commission'],
        'total_admin_match_session_comm'=>$data['admin_match_commission']+$data['admin_session_commission'],
        'total_admin_share_amount'=>$user_data['admin_share_amount'],
        'total_admin_net_amount'=>$user_data['admin_net_amount'],
        'total_admin_company_amount'=>$user_data['admin_final_amount'],

        'total_superadmin_match_comm'=>$data['superadmin_match_commission'],
        'total_superadmin_session_comm'=>$data['superadmin_session_commission'],
        'total_superadmin_match_session_comm'=>$data['superadmin_match_commission']+$data['superadmin_session_commission'],
        'total_superadmin_share_amount'=>$user_data['superadmin_share_amount'],
        'total_superadmin_net_amount'=>$user_data['superadmin_net_amount'],
        'total_superadmin_company_amount'=>$user_data['superadmin_final_amount']

     ];
   }
   else
   {

     $superadmin_array[$data['superadmin_id']]['total_agent_match_coins']+=$data['client_match_coins'];
     $superadmin_array[$data['superadmin_id']]['total_agent_session_coins']+=$data['client_session_coins'];
     $superadmin_array[$data['superadmin_id']]['total_agent_match_session_coins']+=$data['client_session_coins']+$data['client_match_coins'];
     $superadmin_array[$data['superadmin_id']]['total_agent_match_comm']+=$data['agent_match_commission'];
     $superadmin_array[$data['superadmin_id']]['total_agent_session_comm']+=$data['agent_session_commission'];
     $superadmin_array[$data['superadmin_id']]['total_agent_match_session_comm']+=$data['agent_session_commission']+$data['agent_match_commission'];
     $superadmin_array[$data['superadmin_id']]['total_agent_total_amount']+=$data['agent_total_amount'];
     $superadmin_array[$data['superadmin_id']]['total_agent_net_amount']+=$user_data['agent_net_amount'];
     $superadmin_array[$data['superadmin_id']]['total_agent_share_amount']+=$user_data['agent_share_amount'];
     $superadmin_array[$data['superadmin_id']]['total_agent_company_amount']+=$user_data['agent_final_amount'];

     $superadmin_array[$data['superadmin_id']]['total_sa_match_comm']+=$data['sa_match_commission'];
     $superadmin_array[$data['superadmin_id']]['total_sa_session_comm']+=$data['sa_session_commission'];
     $superadmin_array[$data['superadmin_id']]['total_sa_match_session_comm']+=$data['sa_session_commission']+$data['sa_match_commission'];
     $superadmin_array[$data['superadmin_id']]['total_sa_net_amount']+=$user_data['sa_net_amount'];
     $superadmin_array[$data['superadmin_id']]['total_sa_share_amount']+=$user_data['sa_share_amount'];
     $superadmin_array[$data['superadmin_id']]['total_sa_company_amount']+=$user_data['sa_final_amount'];

     $superadmin_array[$data['superadmin_id']]['total_master_match_comm']+=$data['master_match_commission'];
     $superadmin_array[$data['superadmin_id']]['total_master_session_comm']+=$data['master_session_commission'];
     $superadmin_array[$data['superadmin_id']]['total_master_match_session_comm']+=$data['master_session_commission']+$data['master_match_commission'];
     $superadmin_array[$data['superadmin_id']]['total_master_net_amount']+=$user_data['master_net_amount'];
     $superadmin_array[$data['superadmin_id']]['total_master_share_amount']+=$user_data['master_share_amount'];
     $superadmin_array[$data['superadmin_id']]['total_master_company_amount']+=$user_data['master_final_amount'];


     $superadmin_array[$data['superadmin_id']]['total_admin_match_comm']+=$data['admin_match_commission'];
     $superadmin_array[$data['superadmin_id']]['total_admin_session_comm']+=$data['admin_session_commission'];
     $superadmin_array[$data['superadmin_id']]['total_admin_match_session_comm']+=$data['admin_session_commission']+$data['admin_match_commission'];
     $superadmin_array[$data['superadmin_id']]['total_admin_net_amount']+=$user_data['admin_net_amount'];
     $superadmin_array[$data['superadmin_id']]['total_admin_share_amount']+=$user_data['admin_share_amount'];
     $superadmin_array[$data['superadmin_id']]['total_admin_company_amount']+=$user_data['admin_final_amount'];


     $superadmin_array[$data['superadmin_id']]['total_superadmin_match_comm']+=$data['superadmin_match_commission'];
     $superadmin_array[$data['superadmin_id']]['total_superadmin_session_comm']+=$data['superadmin_session_commission'];
     $superadmin_array[$data['superadmin_id']]['total_superadmin_match_session_comm']+=$data['superadmin_session_commission']+$data['superadmin_match_commission'];
     $superadmin_array[$data['superadmin_id']]['total_superadmin_net_amount']+=$user_data['superadmin_net_amount'];
     $superadmin_array[$data['superadmin_id']]['total_superadmin_share_amount']+=$user_data['superadmin_share_amount'];
     $superadmin_array[$data['superadmin_id']]['total_superadmin_company_amount']+=$user_data['superadmin_final_amount'];

   }

   if(!array_key_exists($data['admin_id'], $admin_array))
   {
     $client_admin_data[$data['admin_id']][$data['master_id']]=$data['master_name'];
     $admin_array[$data['admin_id']]=[
        'admin_name'=>$data['admin_name'],
        'total_agent_match_coins'=>$data['client_match_coins'],
        'total_agent_session_coins'=>$data['client_session_coins'],
        'total_agent_match_session_coins'=>$data['client_match_coins']+$data['client_session_coins'],

        'total_agent_match_comm'=>$data['agent_match_commission'],
        'total_agent_session_comm'=>$data['agent_session_commission'],
        'total_agent_match_session_comm'=>$data['agent_match_commission']+$data['agent_session_commission'],
        'total_agent_total_amount'=>$data['agent_total_amount'],
        'total_agent_share_amount'=>$user_data['agent_share_amount'],
        'total_agent_net_amount'=>$user_data['agent_net_amount'],
        'total_agent_company_amount'=>$user_data['agent_final_amount'],

        'total_sa_match_comm'=>$data['sa_match_commission'],
        'total_sa_session_comm'=>$data['sa_session_commission'],
        'total_sa_match_session_comm'=>$data['sa_match_commission']+$data['sa_session_commission'],
        'total_sa_share_amount'=>$user_data['sa_share_amount'],
        'total_sa_net_amount'=>$user_data['sa_net_amount'],
        'total_sa_company_amount'=>$user_data['sa_final_amount'],


        'total_master_match_comm'=>$data['master_match_commission'],
        'total_master_session_comm'=>$data['master_session_commission'],
        'total_master_match_session_comm'=>$data['master_match_commission']+$data['master_session_commission'],
        'total_master_share_amount'=>$user_data['master_share_amount'],
        'total_master_net_amount'=>$user_data['master_net_amount'],
        'total_master_company_amount'=>$user_data['master_final_amount'],


        'total_admin_match_comm'=>$data['admin_match_commission'],
        'total_admin_session_comm'=>$data['admin_session_commission'],
        'total_admin_match_session_comm'=>$data['admin_match_commission']+$data['admin_session_commission'],
        'total_admin_share_amount'=>$user_data['admin_share_amount'],
        'total_admin_net_amount'=>$user_data['admin_net_amount'],
        'total_admin_company_amount'=>$user_data['admin_final_amount'],

        'total_superadmin_match_comm'=>$data['superadmin_match_commission'],
        'total_superadmin_session_comm'=>$data['superadmin_session_commission'],
        'total_superadmin_match_session_comm'=>$data['superadmin_match_commission']+$data['superadmin_session_commission'],
        'total_superadmin_share_amount'=>$user_data['superadmin_share_amount'],
        'total_superadmin_net_amount'=>$user_data['superadmin_net_amount'],
        'total_superadmin_company_amount'=>$user_data['superadmin_final_amount']

     ];
   }
   else
   {
     if(!array_key_exists($data['master_id'],$client_admin_data[$data['admin_id']]))
     {
        $client_admin_data[$data['admin_id']][$data['master_id']]=$data['master_name'];
     }
     $admin_array[$data['admin_id']]['total_agent_match_coins']+=$data['client_match_coins'];
     $admin_array[$data['admin_id']]['total_agent_session_coins']+=$data['client_session_coins'];
     $admin_array[$data['admin_id']]['total_agent_match_session_coins']+=$data['client_session_coins']+$data['client_match_coins'];
     $admin_array[$data['admin_id']]['total_agent_match_comm']+=$data['agent_match_commission'];
     $admin_array[$data['admin_id']]['total_agent_session_comm']+=$data['agent_session_commission'];
     $admin_array[$data['admin_id']]['total_agent_match_session_comm']+=$data['agent_session_commission']+$data['agent_match_commission'];
     $admin_array[$data['admin_id']]['total_agent_total_amount']+=$data['agent_total_amount'];
     $admin_array[$data['admin_id']]['total_agent_net_amount']+=$user_data['agent_net_amount'];
     $admin_array[$data['admin_id']]['total_agent_share_amount']+=$user_data['agent_share_amount'];
     $admin_array[$data['admin_id']]['total_agent_company_amount']+=$user_data['agent_final_amount'];

     $admin_array[$data['admin_id']]['total_sa_match_comm']+=$data['sa_match_commission'];
     $admin_array[$data['admin_id']]['total_sa_session_comm']+=$data['sa_session_commission'];
     $admin_array[$data['admin_id']]['total_sa_match_session_comm']+=$data['sa_session_commission']+$data['sa_match_commission'];
     $admin_array[$data['admin_id']]['total_sa_net_amount']+=$user_data['sa_net_amount'];
     $admin_array[$data['admin_id']]['total_sa_share_amount']+=$user_data['sa_share_amount'];
     $admin_array[$data['admin_id']]['total_sa_company_amount']+=$user_data['sa_final_amount'];

     $admin_array[$data['admin_id']]['total_master_match_comm']+=$data['master_match_commission'];
     $admin_array[$data['admin_id']]['total_master_session_comm']+=$data['master_session_commission'];
     $admin_array[$data['admin_id']]['total_master_match_session_comm']+=$data['master_session_commission']+$data['master_match_commission'];
     $admin_array[$data['admin_id']]['total_master_net_amount']+=$user_data['master_net_amount'];
     $admin_array[$data['admin_id']]['total_master_share_amount']+=$user_data['master_share_amount'];
     $admin_array[$data['admin_id']]['total_master_company_amount']+=$user_data['master_final_amount'];


     $admin_array[$data['admin_id']]['total_admin_match_comm']+=$data['admin_match_commission'];
     $admin_array[$data['admin_id']]['total_admin_session_comm']+=$data['admin_session_commission'];
     $admin_array[$data['admin_id']]['total_admin_match_session_comm']+=$data['admin_session_commission']+$data['admin_match_commission'];
     $admin_array[$data['admin_id']]['total_admin_net_amount']+=$user_data['admin_net_amount'];
     $admin_array[$data['admin_id']]['total_admin_share_amount']+=$user_data['admin_share_amount'];
     $admin_array[$data['admin_id']]['total_admin_company_amount']+=$user_data['admin_final_amount'];


     $admin_array[$data['admin_id']]['total_superadmin_match_comm']+=$data['superadmin_match_commission'];
     $admin_array[$data['admin_id']]['total_superadmin_session_comm']+=$data['superadmin_session_commission'];
     $admin_array[$data['admin_id']]['total_superadmin_match_session_comm']+=$data['superadmin_session_commission']+$data['superadmin_match_commission'];
     $admin_array[$data['admin_id']]['total_superadmin_net_amount']+=$user_data['superadmin_net_amount'];
     $admin_array[$data['admin_id']]['total_superadmin_share_amount']+=$user_data['superadmin_share_amount'];
     $admin_array[$data['admin_id']]['total_superadmin_company_amount']+=$user_data['superadmin_final_amount'];
   }

   if(!array_key_exists($data['master_id'], $master_array))
   {
     $client_master_data[$data['master_id']][$data['sa_id']]=$data['sa_name'];
     $master_array[$data['master_id']]=[
        'master_name'=>$data['master_name'],
        'total_agent_match_coins'=>$data['client_match_coins'],
        'total_agent_session_coins'=>$data['client_session_coins'],
        'total_agent_match_session_coins'=>$data['client_match_coins']+$data['client_session_coins'],

        'total_agent_match_comm'=>$data['agent_match_commission'],
        'total_agent_session_comm'=>$data['agent_session_commission'],
        'total_agent_match_session_comm'=>$data['agent_match_commission']+$data['agent_session_commission'],
        'total_agent_total_amount'=>$data['agent_total_amount'],
        'total_agent_share_amount'=>$user_data['agent_share_amount'],
        'total_agent_net_amount'=>$user_data['agent_net_amount'],
        'total_agent_company_amount'=>$user_data['agent_final_amount'],

        'total_sa_match_comm'=>$data['sa_match_commission'],
        'total_sa_session_comm'=>$data['sa_session_commission'],
        'total_sa_match_session_comm'=>$data['sa_match_commission']+$data['sa_session_commission'],
        'total_sa_share_amount'=>$user_data['sa_share_amount'],
        'total_sa_net_amount'=>$user_data['sa_net_amount'],
        'total_sa_company_amount'=>$user_data['sa_final_amount'],


        'total_master_match_comm'=>$data['master_match_commission'],
        'total_master_session_comm'=>$data['master_session_commission'],
        'total_master_match_session_comm'=>$data['master_match_commission']+$data['master_session_commission'],
        'total_master_share_amount'=>$user_data['master_share_amount'],
        'total_master_net_amount'=>$user_data['master_net_amount'],
        'total_master_company_amount'=>$user_data['master_final_amount'],


        'total_admin_match_comm'=>$data['admin_match_commission'],
        'total_admin_session_comm'=>$data['admin_session_commission'],
        'total_admin_match_session_comm'=>$data['admin_match_commission']+$data['admin_session_commission'],
        'total_admin_share_amount'=>$user_data['admin_share_amount'],
        'total_admin_net_amount'=>$user_data['admin_net_amount'],
        'total_admin_company_amount'=>$user_data['admin_final_amount'],

        'total_superadmin_match_comm'=>$data['superadmin_match_commission'],
        'total_superadmin_session_comm'=>$data['superadmin_session_commission'],
        'total_superadmin_match_session_comm'=>$data['superadmin_match_commission']+$data['superadmin_session_commission'],
        'total_superadmin_share_amount'=>$user_data['superadmin_share_amount'],
        'total_superadmin_net_amount'=>$user_data['superadmin_net_amount'],
        'total_superadmin_company_amount'=>$user_data['superadmin_final_amount']

     ];
   }
   else
   {
     if(!array_key_exists($data['sa_id'],$client_master_data[$data['master_id']]))
     {
        $client_master_data[$data['master_id']][$data['sa_id']]=$data['sa_name'];
     }
     $master_array[$data['master_id']]['total_agent_match_coins']+=$data['client_match_coins'];
     $master_array[$data['master_id']]['total_agent_session_coins']+=$data['client_session_coins'];
     $master_array[$data['master_id']]['total_agent_match_session_coins']+=$data['client_session_coins']+$data['client_match_coins'];
     $master_array[$data['master_id']]['total_agent_match_comm']+=$data['agent_match_commission'];
     $master_array[$data['master_id']]['total_agent_session_comm']+=$data['agent_session_commission'];
     $master_array[$data['master_id']]['total_agent_match_session_comm']+=$data['agent_session_commission']+$data['agent_match_commission'];
     $master_array[$data['master_id']]['total_agent_total_amount']+=$data['agent_total_amount'];
     $master_array[$data['master_id']]['total_agent_net_amount']+=$user_data['agent_net_amount'];
     $master_array[$data['master_id']]['total_agent_share_amount']+=$user_data['agent_share_amount'];
     $master_array[$data['master_id']]['total_agent_company_amount']+=$user_data['agent_final_amount'];

     $master_array[$data['master_id']]['total_sa_match_comm']+=$data['sa_match_commission'];
     $master_array[$data['master_id']]['total_sa_session_comm']+=$data['sa_session_commission'];
     $master_array[$data['master_id']]['total_sa_match_session_comm']+=$data['sa_session_commission']+$data['sa_match_commission'];
     $master_array[$data['master_id']]['total_sa_net_amount']+=$user_data['sa_net_amount'];
     $master_array[$data['master_id']]['total_sa_share_amount']+=$user_data['sa_share_amount'];
     $master_array[$data['master_id']]['total_sa_company_amount']+=$user_data['sa_final_amount'];

     $master_array[$data['master_id']]['total_master_match_comm']+=$data['master_match_commission'];
     $master_array[$data['master_id']]['total_master_session_comm']+=$data['master_session_commission'];
     $master_array[$data['master_id']]['total_master_match_session_comm']+=$data['master_session_commission']+$data['master_match_commission'];
     $master_array[$data['master_id']]['total_master_net_amount']+=$user_data['master_net_amount'];
     $master_array[$data['master_id']]['total_master_share_amount']+=$user_data['master_share_amount'];
     $master_array[$data['master_id']]['total_master_company_amount']+=$user_data['master_final_amount'];


     $master_array[$data['master_id']]['total_admin_match_comm']+=$data['admin_match_commission'];
     $master_array[$data['master_id']]['total_admin_session_comm']+=$data['admin_session_commission'];
     $master_array[$data['master_id']]['total_admin_match_session_comm']+=$data['admin_session_commission']+$data['admin_match_commission'];
     $master_array[$data['master_id']]['total_admin_net_amount']+=$user_data['admin_net_amount'];
     $master_array[$data['master_id']]['total_admin_share_amount']+=$user_data['admin_share_amount'];
     $master_array[$data['master_id']]['total_admin_company_amount']+=$user_data['admin_final_amount'];


     $master_array[$data['master_id']]['total_superadmin_match_comm']+=$data['superadmin_match_commission'];
     $master_array[$data['master_id']]['total_superadmin_session_comm']+=$data['superadmin_session_commission'];
     $master_array[$data['master_id']]['total_superadmin_match_session_comm']+=$data['superadmin_session_commission']+$data['superadmin_match_commission'];
     $master_array[$data['master_id']]['total_superadmin_net_amount']+=$user_data['superadmin_net_amount'];
     $master_array[$data['master_id']]['total_superadmin_share_amount']+=$user_data['superadmin_share_amount'];
     $master_array[$data['master_id']]['total_superadmin_company_amount']+=$user_data['superadmin_final_amount'];
   }


   if(!array_key_exists($data['sa_id'], $sa_array))
   {
     $client_sa_data[$data['sa_id']][$data['agent_id']]=$data['agent_name'];
     $sa_array[$data['sa_id']]=[
        'sa_name'=>$data['sa_name'],
        'total_agent_match_coins'=>$data['client_match_coins'],
        'total_agent_session_coins'=>$data['client_session_coins'],
        'total_agent_match_session_coins'=>$data['client_match_coins']+$data['client_session_coins'],

        'total_agent_match_comm'=>$data['agent_match_commission'],
        'total_agent_session_comm'=>$data['agent_session_commission'],
        'total_agent_match_session_comm'=>$data['agent_match_commission']+$data['agent_session_commission'],
        'total_agent_total_amount'=>$data['agent_total_amount'],
        'total_agent_share_amount'=>$user_data['agent_share_amount'],
        'total_agent_net_amount'=>$user_data['agent_net_amount'],
        'total_agent_company_amount'=>$user_data['agent_final_amount'],

        'total_sa_match_comm'=>$data['sa_match_commission'],
        'total_sa_session_comm'=>$data['sa_session_commission'],
        'total_sa_match_session_comm'=>$data['sa_match_commission']+$data['sa_session_commission'],
        'total_sa_share_amount'=>$user_data['sa_share_amount'],
        'total_sa_net_amount'=>$user_data['sa_net_amount'],
        'total_sa_company_amount'=>$user_data['sa_final_amount'],


        'total_master_match_comm'=>$data['master_match_commission'],
        'total_master_session_comm'=>$data['master_session_commission'],
        'total_master_match_session_comm'=>$data['master_match_commission']+$data['master_session_commission'],
        'total_master_share_amount'=>$user_data['master_share_amount'],
        'total_master_net_amount'=>$user_data['master_net_amount'],
        'total_master_company_amount'=>$user_data['master_final_amount'],


        'total_admin_match_comm'=>$data['admin_match_commission'],
        'total_admin_session_comm'=>$data['admin_session_commission'],
        'total_admin_match_session_comm'=>$data['admin_match_commission']+$data['admin_session_commission'],
        'total_admin_share_amount'=>$user_data['admin_share_amount'],
        'total_admin_net_amount'=>$user_data['admin_net_amount'],
        'total_admin_company_amount'=>$user_data['admin_final_amount'],

        'total_superadmin_match_comm'=>$data['superadmin_match_commission'],
        'total_superadmin_session_comm'=>$data['superadmin_session_commission'],
        'total_superadmin_match_session_comm'=>$data['superadmin_match_commission']+$data['superadmin_session_commission'],
        'total_superadmin_share_amount'=>$user_data['superadmin_share_amount'],
        'total_superadmin_net_amount'=>$user_data['superadmin_net_amount'],
        'total_superadmin_company_amount'=>$user_data['superadmin_final_amount']

     ];
   }
   else
   { 
    //_dx($sa_array);
     if(!array_key_exists($data['agent_id'],$client_sa_data[$data['sa_id']]))
     {
        $client_sa_data[$data['sa_id']][$data['agent_id']]=$data['agent_name'];
     }
     $sa_array[$data['sa_id']]['total_agent_match_coins']+=$data['client_match_coins'];
     $sa_array[$data['sa_id']]['total_agent_session_coins']+=$data['client_session_coins'];
     $sa_array[$data['sa_id']]['total_agent_match_session_coins']+=$data['client_session_coins']+$data['client_match_coins'];
     $sa_array[$data['sa_id']]['total_agent_match_comm']+=$data['agent_match_commission'];
     $sa_array[$data['sa_id']]['total_agent_session_comm']+=$data['agent_session_commission'];
     $sa_array[$data['sa_id']]['total_agent_match_session_comm']+=$data['agent_session_commission']+$data['agent_match_commission'];
     $sa_array[$data['sa_id']]['total_agent_total_amount']+=$data['agent_total_amount'];
     $sa_array[$data['sa_id']]['total_agent_net_amount']+=$user_data['agent_net_amount'];
     $sa_array[$data['sa_id']]['total_agent_share_amount']+=$user_data['agent_share_amount'];
     $sa_array[$data['sa_id']]['total_agent_company_amount']+=$user_data['agent_final_amount'];

     $sa_array[$data['sa_id']]['total_sa_match_comm']+=$data['sa_match_commission'];
     $sa_array[$data['sa_id']]['total_sa_session_comm']+=$data['sa_session_commission'];
     $sa_array[$data['sa_id']]['total_sa_match_session_comm']+=$data['sa_session_commission']+$data['sa_match_commission'];
     $sa_array[$data['sa_id']]['total_sa_net_amount']+=$user_data['sa_net_amount'];
     $sa_array[$data['sa_id']]['total_sa_share_amount']+=$user_data['sa_share_amount'];
     $sa_array[$data['sa_id']]['total_sa_company_amount']+=$user_data['sa_final_amount'];

     $sa_array[$data['sa_id']]['total_master_match_comm']+=$data['master_match_commission'];
     $sa_array[$data['sa_id']]['total_master_session_comm']+=$data['master_session_commission'];
     $sa_array[$data['sa_id']]['total_master_match_session_comm']+=$data['master_session_commission']+$data['master_match_commission'];
     $sa_array[$data['sa_id']]['total_master_net_amount']+=$user_data['master_net_amount'];
     $sa_array[$data['sa_id']]['total_master_share_amount']+=$user_data['master_share_amount'];
     $sa_array[$data['sa_id']]['total_master_company_amount']+=$user_data['master_final_amount'];


     $sa_array[$data['sa_id']]['total_admin_match_comm']+=$data['admin_match_commission'];
     $sa_array[$data['sa_id']]['total_admin_session_comm']+=$data['admin_session_commission'];
     $sa_array[$data['sa_id']]['total_admin_match_session_comm']+=$data['admin_session_commission']+$data['admin_match_commission'];
     $sa_array[$data['sa_id']]['total_admin_net_amount']+=$user_data['admin_net_amount'];
     $sa_array[$data['sa_id']]['total_admin_share_amount']+=$user_data['admin_share_amount'];
     $sa_array[$data['sa_id']]['total_admin_company_amount']+=$user_data['admin_final_amount'];


     $sa_array[$data['sa_id']]['total_superadmin_match_comm']+=$data['superadmin_match_commission'];
     $sa_array[$data['sa_id']]['total_superadmin_session_comm']+=$data['superadmin_session_commission'];
     $sa_array[$data['sa_id']]['total_superadmin_match_session_comm']+=$data['superadmin_session_commission']+$data['superadmin_match_commission'];
     $sa_array[$data['sa_id']]['total_superadmin_net_amount']+=$user_data['superadmin_net_amount'];
     $sa_array[$data['sa_id']]['total_superadmin_share_amount']+=$user_data['superadmin_share_amount'];
     $sa_array[$data['sa_id']]['total_superadmin_company_amount']+=$user_data['superadmin_final_amount'];
     
   }
   
   if(!array_key_exists($data['agent_id'], $agent_array))
   {
    
        $agent_array[$data['agent_id']]=[
        'agent_name'=>$data['agent_name'],

        'total_agent_match_coins'=>$data['client_match_coins'],
        'total_agent_session_coins'=>$data['client_session_coins'],
        'total_agent_match_session_coins'=>$data['client_match_coins']+$data['client_session_coins'],
        'total_client_match_comm'=>$data['client_match_commission'],
        'total_client_session_comm'=>$data['client_session_commission'],
        'total_client_match_session_comm'=>$data['client_match_commission']+$data['client_session_commission'],
        'total_client_total_amount'=>$data['client_total_amount'],

        'total_agent_match_comm'=>$data['agent_match_commission'],
        'total_agent_session_comm'=>$data['agent_session_commission'],
        'total_agent_match_session_comm'=>$data['agent_match_commission']+$data['agent_session_commission'],
        'total_agent_total_amount'=>$data['agent_total_amount'],
        'total_agent_share_amount'=>$user_data['agent_share_amount'],
        'total_agent_net_amount'=>$user_data['agent_net_amount'],
        'total_agent_company_amount'=>$user_data['agent_final_amount'],

        'total_sa_match_comm'=>$data['sa_match_commission'],
        'total_sa_session_comm'=>$data['sa_session_commission'],
        'total_sa_match_session_comm'=>$data['sa_match_commission']+$data['sa_session_commission'],
        'total_sa_share_amount'=>$user_data['sa_share_amount'],
        'total_sa_net_amount'=>$user_data['sa_net_amount'],
        'total_sa_company_amount'=>$user_data['sa_final_amount'],


        'total_master_match_comm'=>$data['master_match_commission'],
        'total_master_session_comm'=>$data['master_session_commission'],
        'total_master_match_session_comm'=>$data['master_match_commission']+$data['master_session_commission'],
        'total_master_share_amount'=>$user_data['master_share_amount'],
        'total_master_net_amount'=>$user_data['master_net_amount'],
        'total_master_company_amount'=>$user_data['master_final_amount'],


        'total_admin_match_comm'=>$data['admin_match_commission'],
        'total_admin_session_comm'=>$data['admin_session_commission'],
        'total_admin_match_session_comm'=>$data['admin_match_commission']+$data['admin_session_commission'],
        'total_admin_share_amount'=>$user_data['admin_share_amount'],
        'total_admin_net_amount'=>$user_data['admin_net_amount'],
        'total_admin_company_amount'=>$user_data['admin_final_amount'],

        'total_superadmin_match_comm'=>$data['superadmin_match_commission'],
        'total_superadmin_session_comm'=>$data['superadmin_session_commission'],
        'total_superadmin_match_session_comm'=>$data['superadmin_match_commission']+$data['superadmin_session_commission'],
        'total_superadmin_share_amount'=>$user_data['superadmin_share_amount'],
        'total_superadmin_net_amount'=>$user_data['superadmin_net_amount'],
        'total_superadmin_company_amount'=>$user_data['superadmin_final_amount']
      ];

     $data['agent_net_amount']=$user_data['agent_net_amount'];
     $data['agent_share_amount']=$user_data['agent_share_amount'];
     $data['agent_company_amount']=$user_data['agent_final_amount'];

     $data['sa_net_amount']=$user_data['sa_net_amount'];
     $data['sa_share_amount']=$user_data['sa_share_amount'];
     $data['sa_company_amount']=$user_data['sa_final_amount'];

     $data['master_net_amount']=$user_data['master_net_amount'];
     $data['master_share_amount']=$user_data['master_share_amount'];
     $data['master_company_amount']=$user_data['master_final_amount'];

     $data['admin_net_amount']=$user_data['admin_net_amount'];
     $data['admin_share_amount']=$user_data['admin_share_amount'];
     $data['admin_company_amount']=$user_data['admin_final_amount'];

     $data['superadmin_net_amount']=$user_data['superadmin_net_amount'];
     $data['superadmin_share_amount']=$user_data['superadmin_share_amount'];
     $data['superadmin_company_amount']=$user_data['superadmin_final_amount'];

     $client_agent_data[$data['agent_id']][$data['client_id']]=$data;


   }
   else
   {
     $agent_array[$data['agent_id']]['total_client_match_comm']+=$data['client_match_commission'];
     $agent_array[$data['agent_id']]['total_client_session_comm']+=$data['client_session_commission'];
     $agent_array[$data['agent_id']]['total_client_match_session_comm']+=$data['client_session_commission']+$data['agent_match_commission'];



     $agent_array[$data['agent_id']]['total_agent_match_coins']+=$data['client_match_coins'];
     $agent_array[$data['agent_id']]['total_agent_session_coins']+=$data['client_session_coins'];
     $agent_array[$data['agent_id']]['total_client_total_amount']+=$data['client_total_amount'];
     $agent_array[$data['agent_id']]['total_agent_match_session_coins']+=$data['client_session_coins']+$data['client_match_coins'];
     $agent_array[$data['agent_id']]['total_agent_match_comm']+=$data['agent_match_commission'];
     $agent_array[$data['agent_id']]['total_agent_session_comm']+=$data['agent_session_commission'];
     $agent_array[$data['agent_id']]['total_agent_match_session_comm']+=$data['agent_session_commission']+$data['agent_match_commission'];
     $agent_array[$data['agent_id']]['total_agent_total_amount']+=$data['agent_total_amount'];
     $agent_array[$data['agent_id']]['total_agent_net_amount']+=$user_data['agent_net_amount'];
     $agent_array[$data['agent_id']]['total_agent_share_amount']+=$user_data['agent_share_amount'];
     $agent_array[$data['agent_id']]['total_agent_company_amount']+=$user_data['agent_final_amount'];

     $agent_array[$data['agent_id']]['total_sa_match_comm']+=$data['sa_match_commission'];
     $agent_array[$data['agent_id']]['total_sa_session_comm']+=$data['sa_session_commission'];
     $agent_array[$data['agent_id']]['total_sa_match_session_comm']+=$data['sa_session_commission']+$data['sa_match_commission'];
     $agent_array[$data['agent_id']]['total_sa_net_amount']+=$user_data['sa_net_amount'];
     $agent_array[$data['agent_id']]['total_sa_share_amount']+=$user_data['sa_share_amount'];
     $agent_array[$data['agent_id']]['total_sa_company_amount']+=$user_data['sa_final_amount'];

     $agent_array[$data['agent_id']]['total_master_match_comm']+=$data['master_match_commission'];
     $agent_array[$data['agent_id']]['total_master_session_comm']+=$data['master_session_commission'];
     $agent_array[$data['agent_id']]['total_master_match_session_comm']+=$data['master_session_commission']+$data['master_match_commission'];
     $agent_array[$data['agent_id']]['total_master_net_amount']+=$user_data['master_net_amount'];
     $agent_array[$data['agent_id']]['total_master_share_amount']+=$user_data['master_share_amount'];
     $agent_array[$data['agent_id']]['total_master_company_amount']+=$user_data['master_final_amount'];


     $agent_array[$data['agent_id']]['total_admin_match_comm']+=$data['admin_match_commission'];
     $agent_array[$data['agent_id']]['total_admin_session_comm']+=$data['admin_session_commission'];
     $agent_array[$data['agent_id']]['total_admin_match_session_comm']+=$data['admin_session_commission']+$data['admin_match_commission'];
     $agent_array[$data['agent_id']]['total_admin_net_amount']+=$user_data['admin_net_amount'];
     $agent_array[$data['agent_id']]['total_admin_share_amount']+=$user_data['admin_share_amount'];
     $agent_array[$data['agent_id']]['total_admin_company_amount']+=$user_data['admin_final_amount'];


     $agent_array[$data['agent_id']]['total_superadmin_match_comm']+=$data['superadmin_match_commission'];
     $agent_array[$data['agent_id']]['total_superadmin_session_comm']+=$data['superadmin_session_commission'];
     $agent_array[$data['agent_id']]['total_superadmin_match_session_comm']+=$data['superadmin_session_commission']+$data['superadmin_match_commission'];
     $agent_array[$data['agent_id']]['total_superadmin_net_amount']+=$user_data['superadmin_net_amount'];
     $agent_array[$data['agent_id']]['total_superadmin_share_amount']+=$user_data['superadmin_share_amount'];
     $agent_array[$data['agent_id']]['total_superadmin_company_amount']+=$user_data['superadmin_final_amount'];

     $data['agent_net_amount']=$user_data['agent_net_amount'];
     $data['agent_share_amount']=$user_data['agent_share_amount'];
     $data['agent_company_amount']=$user_data['agent_final_amount'];

     $data['sa_net_amount']=$user_data['sa_net_amount'];
     $data['sa_share_amount']=$user_data['sa_share_amount'];
     $data['sa_company_amount']=$user_data['sa_final_amount'];

     $data['master_net_amount']=$user_data['master_net_amount'];
     $data['master_share_amount']=$user_data['master_share_amount'];
     $data['master_company_amount']=$user_data['master_final_amount'];

     $data['admin_net_amount']=$user_data['admin_net_amount'];
     $data['admin_share_amount']=$user_data['admin_share_amount'];
     $data['admin_company_amount']=$user_data['admin_final_amount'];

     $data['superadmin_net_amount']=$user_data['superadmin_net_amount'];
     $data['superadmin_share_amount']=$user_data['superadmin_share_amount'];
     $data['superadmin_company_amount']=$user_data['superadmin_final_amount'];
     $client_agent_data[$data['agent_id']][$data['client_id']]=$data;
   }



}


//_dx($client_master_data);

include('header.php');
?>
<style>
    table {
        background-color: white;
    }
    table th{
        border: 10px;
        border-color: blue;
        background-color: white;
    }
</style>

  <div class="content-wrapper">
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Match & Session Plus Minus Report</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="dashboard?page_name=dashboard">Home</a></li>
              <li class="breadcrumb-item active">Match & Session Plus Minus Report</li>
            </ol>
          </div>
        </div>
      </div>
    </section>

    <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div>
                        <div class="card card-default">
                          <div class="card-header text-center text-bold">
                            <h5 class="card-title">MATCH CODE : (<?= strtoupper($match_data['event_id'])?>) <?= strtoupper($userdata['user_type'])?> &amp; CLIENT OF <?= strtoupper($match_data['match_name'])?> (<?= strtoupper($match_data['match_type'])?>)</h5>
                            </div>
                            <?php  if($user_priority>=priority('superadmin')) { ?>
                            <div class="card-body">
                             <div class="card card-dark  bg-gray-light">
                               <div class="card-header text-center">
                                  <h5 class="card-title">SUBADMIN PLUS MINUS</h5>
                                </div>
                             <?php } ?>
                            
<?php foreach ($admin_array as $admin_id => $admin) 
{  ?>
   <?php  if($user_priority>=priority('admin')) { ?>
    <div class="card-body">
        <div class="card card-danger bg-gradient-white ">
            <div class="card-header text-center">
              <h2 class="card-title text-bold text-uppercase">
                Admin Name : <?= $admin['admin_name'] ?> 
              </h2>
            </div>
   <?php } ?>

        

<!-- // MASTER CALCULATTION START -->
<?php 
$master_data=$client_admin_data[$admin_id];
foreach ($master_data as $master_id => $master) 
{  ?>
   <?php  if($user_priority>=priority('master')) { ?>
       <div class="card-body">
        <div class="card card-info bg-gradient-white ">
            <div class="card-header text-center">
              <h2 class="card-title text-bold text-uppercase">
                Master Name : <?= $master ?> 
              </h2>
            </div>
   <?php } ?>
        
  

<!-- // SUPERAGENT CALCULATION START -->

<?php 
$sa_data=$client_master_data[$master_id];
foreach ($sa_data as $sa_id => $sa) { 

$agent_data=$client_sa_data[$sa_id];

?>
<?php  if($user_priority>=priority('superagent')) { ?>
    <div class="card-body">
        <div class="card card-success bg-gradient-white ">
            <div class="card-header text-center">
              <h2 class="card-title text-bold text-uppercase">
                Superagent Name : <?= $sa ?> 
              </h2>
            </div>
<?php  } ?>
        

<?php  foreach ($agent_data as $agent_id => $agent) {  ?>
    <div class="card-body">
        <div class="card card-warning bg-gradient-white ">
            <div class="card-header text-center">
              <h2 class="card-title text-bold text-uppercase">
                Agent Name : <?= $agent ?> 
              </h2>
            </div>
       
    
  <table id="data" class="table table-striped table-bordered">
    <thead>
      <tr>

        <th colspan="<?= $user_type=='agent'?7:4 ?>" class="text-center">CLIENT</th>
      <?php if($user_priority>=priority('agent')){?>
        <th colspan="7" class="text-center">AGENT</th>
      <?php } if($user_priority>=priority('superagent')) {?>
        <th colspan="7" class="text-center">SUPERAGENT</th>
     <?php } if($user_priority>=priority('master')) { ?>
        <th colspan="7" class="text-center">MASTER</th>
     <?php } if($user_priority>=priority('admin')) { ?>
        <th colspan="7" class="text-center">SUB-ADMIN</th>
     <?php } if($user_priority>=priority('superadmin')) { ?>
        <th colspan="7" class="text-center">SUPERADMIN</th>
     <?php } ?>
      </tr>
    </thead>
    <thead>
      <tr>

       <th>CLIENT</th>
       <th>M AMT</th>
       <th>S AMT</th>
       <?php if($user_type=='agent'){?>
       <th>M COM</th>
       <th>S COM</th>
       <th>TOT COM</th>

       <?php } ?>
       <th>TOT AMT</th>
       <?php if($user_priority>=priority('agent')){?>
       <th>M COM</th>
       <th>S COM</th>
       <th>TOT COM</th>
       <th>NET AMT</th>
       <th>SHR AMT</th>
       <th>MOB APP</th>
       <th>FINAL</th>
       <?php } if($user_priority>=priority('superagent')) { ?>

       <th>M COM</th>
       <th>S COM</th>
       <th>TOL COM</th>
       <th>NET AMT</th>
       <th>SHR AMT</th>
       <th>MOB APP</th>
       <th>FINAL</th>
       <?php } if($user_priority>=priority('master')) { ?>

       <th>M COM</th>
       <th>S COM</th>
       <th>TOL COM</th>
       <th>NET AMT</th>
       <th>SHR AMT</th>
       <th>MOB APP</th>
       <th>FINAL</th>
    <?php } if($user_priority>=priority('admin')) { ?>

       <th>M COM</th>
       <th>S COM</th>
       <th>TOL COM</th>
       <th>NET AMT</th>
       <th>SHR AMT</th>
       <th>MOB APP</th>
       <th>FINAL</th>
    <?php } if($user_priority>=priority('superadmin')) { ?>


       <th>M COM</th>
       <th>S COM</th>
       <th>TOL COM</th>
       <th>NET AMT</th>
       <th>SHR AMT</th>
       <th>MOB APP</th>
       <th>FINAL</th>
    <?php  } ?>
     </tr>
    </thead>
<tbody>
<?php 
$client_data=$client_agent_data[$agent_id];
foreach ($client_data as $key => $client) { 
   //_dx($client);
    extract($client);
    $client_id=$client['client_id'];
?>
<tr>
    <td class="text-uppercase"><?= ($client_code) ?> (<?= ($client_name) ?>)</td>
    <td><?= (number_format($client_match_coins,2)) ?></td>
    <td><?= (number_format($client_session_coins,2)) ?></td>
    
    <?php if($user_type=='agent'){?>
    <td><?= (number_format($client_match_commission,2)) ?></td>
    <td><?= (number_format($client_session_commission,2)) ?></td>
    <td><?= (number_format($client_match_commission+$client_session_commission,2)) ?></td> 
    <?php } ?>

    <td><?= (number_format($client_total_amount,2)) ?></td>

    <?php if($user_priority>=priority('agent')){?>
    <td><?= (number_format(-1*$agent_match_commission,2)) ?></td>
    <td><?= (number_format(-1*$agent_session_commission,2)) ?></td>
    <td><?= (number_format(-1*($agent_session_commission+$agent_match_commission),2)) ?></td>
    <td><?= (number_format($agent_net_amount,2)) ?></td>
    <td><?= (number_format($agent_share_amount,2)) ?></td>
    <td>0.00</td>
    <td><?= (number_format($agent_company_amount,2)) ?></td>


    <!-- // Superagent Calculation -->
    <?php } if($user_priority>=priority('superagent')){?>
    <td><?= (number_format(-1*$sa_match_commission,2)) ?></td>
    <td><?= (number_format(-1*$sa_session_commission,2)) ?></td>
    <td><?= (number_format(-1*($sa_session_commission+$sa_match_commission),2)) ?></td>
    <td><?= (number_format($sa_net_amount,2)) ?></td>
    <td><?= (number_format($sa_share_amount,2)) ?></td>
                                 <td>0.00</td>
    <td><?= (number_format($sa_company_amount,2)) ?></td>
    


    <!-- // Master Calculation -->
    <?php } if($user_priority>=priority('master')){?>
    <td><?= (number_format(-1*$master_match_commission,2)) ?></td>
    <td><?= (number_format(-1*$master_session_commission,2)) ?></td>
    <td><?= (number_format(-1*($master_session_commission+$master_match_commission),2)) ?></td>
    <td><?= (number_format($master_net_amount,2)) ?></td>
    <td><?= (number_format($master_share_amount,2)) ?></td>
                                 <td>0.00</td>
    <td><?= (number_format($master_company_amount,2)) ?></td>



    <!-- // Admin Calculation -->
    <?php } if($user_priority>=priority('admin')){?>
    <td><?= (number_format(-1*$admin_match_commission,2)) ?></td>
    <td><?= (number_format(-1*$admin_session_commission,2)) ?></td>
    <td><?= (number_format(-1*($admin_session_commission+$admin_match_commission),2)) ?></td>
    <td><?= (number_format($admin_net_amount,2)) ?></td>
    <td><?= (number_format($admin_share_amount,2)) ?></td>
                                 <td>0.00</td>
    <td><?= (number_format($admin_company_amount,2)) ?></td>


    <!-- // SUperadmin Calculation -->
 <?php } if($user_priority>=priority('superadmin')){?>
    <td><?= (number_format(-1*$superadmin_match_commission,2)) ?></td>
    <td><?= (number_format(-1*$superadmin_session_commission,2)) ?></td>
    <td><?= (number_format(-1*($superadmin_session_commission+$superadmin_match_commission),2)) ?></td>
    <td><?= (number_format($superadmin_net_amount,2)) ?></td>
    <td><?= (number_format($superadmin_share_amount,2)) ?></td>
                                 <td>0.00</td>
    <td><?= (number_format($superadmin_company_amount,2)) ?></td>
 <?php  } ?>
</tr>  
<?php } 
$agent_data=$agent_array[$agent_id];
extract($agent_data);
?>
</tbody>
<tfoot>
 <tr> 
    <th>TOTAL</th>

    <th><?= (number_format($total_agent_match_coins,2)) ?></th>
    <th><?= (number_format($total_agent_session_coins,2)) ?></th>
    
    <?php if($user_type=='agent'){?>
    <th><?= (number_format($client_match_commission,2)) ?></th>
    <th><?= (number_format($client_session_commission,2)) ?></th>
    <th><?= (number_format($client_match_commission+$client_session_commission,2)) ?></th> 
    <?php } ?>

    <th><?= (number_format($total_client_total_amount,2)) ?></th>

    <?php if($user_priority>=priority('agent')){?>
    <th><?= (number_format(-1*$total_agent_match_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_agent_session_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_agent_match_session_comm,2)) ?></th>  
    <th><?= (number_format($total_agent_net_amount,2)) ?></th>  
    <th><?= (number_format($total_agent_share_amount,2)) ?></th> 
    <th>0.00</th>
    <th><?= (number_format($total_agent_company_amount,2)) ?></th>


    <?php } if($user_priority>=priority('superagent')){?>
    <th><?= (number_format(-1*$total_sa_match_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_sa_session_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_sa_match_session_comm,2)) ?></th>  
    <th><?= (number_format($total_sa_net_amount,2)) ?></th>  
    <th><?= (number_format($total_sa_share_amount,2)) ?></th> 
    <th>0.00</th>
    <th><?= (number_format($total_sa_company_amount,2)) ?></th> 



   <?php } if($user_priority>=priority('master')){?>                                    
    <th><?= (number_format(-1*$total_master_match_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_master_session_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_master_match_session_comm,2)) ?></th>  
    <th><?= (number_format($total_master_net_amount,2)) ?></th>  
    <th><?= (number_format($total_master_share_amount,2)) ?></th> 
    <th>0.00</th>
    <th><?= (number_format($total_master_company_amount,2)) ?></th> 

    <?php } if($user_priority>=priority('admin')){?>              
    <th><?= (number_format(-1*$total_admin_match_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_admin_session_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_admin_match_session_comm,2)) ?></th>  
    <th><?= (number_format($total_admin_net_amount,2)) ?></th>  
    <th><?= (number_format($total_admin_share_amount,2)) ?></th> 
    <th>0.00</th>
    <th><?= (number_format($total_admin_company_amount,2)) ?></th>

    <?php } if($user_priority>=priority('superadmin')){?>
    <th><?= (number_format(-1*$total_superadmin_match_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_superadmin_session_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_superadmin_match_session_comm,2)) ?></th>  
    <th><?= (number_format($total_superadmin_net_amount,2)) ?></th>  
    <th><?= (number_format($total_superadmin_share_amount,2)) ?></th> 
    <th>0.00</th>
    <th><?= (number_format($total_superadmin_company_amount,2)) ?></th>
    <?php  } ?>
 </tr>
</tfoot>
</table>

</div>
</div>

<!-- // CLIENT CALCULATION FINISH -->
<?php } 
$sa_total_data=$sa_array[$sa_id];
extract($sa_total_data);
?>
<?php  if($user_priority>=priority('superagent')) { ?>
<div class="card-footer">
  <table class="table table-striped table-bordered">
    <thead class="bg-gradient-white">
      <tr>
        <th>
            SA TOTAL
            <br>
            <small style="color:red"> <?= $sa_name ?></small>
        </th>
        <th><?= (number_format($total_agent_match_coins,2)) ?></th>
    <th><?= (number_format($total_agent_session_coins,2)) ?></th>
    <th><?= (number_format($total_agent_match_coins+$total_agent_session_coins,2)) ?></th>
    <?php  if($user_priority>=priority('agent')){?>
    <th><?= (number_format(-1*$total_agent_match_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_agent_session_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_agent_match_session_comm,2)) ?></th>  
    <th><?= (number_format($total_agent_net_amount,2)) ?></th>  
    <th><?= (number_format($total_agent_share_amount,2)) ?></th> 
    <th>0.00</th>
    <th><?= (number_format($total_agent_company_amount,2)) ?></th>


    <?php } if($user_priority>=priority('superagent')){?>
    <th><?= (number_format(-1*$total_sa_match_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_sa_session_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_sa_match_session_comm,2)) ?></th>  
    <th><?= (number_format($total_sa_net_amount,2)) ?></th>  
    <th><?= (number_format($total_sa_share_amount,2)) ?></th> 
    <th>0.00</th>
    <th><?= (number_format($total_sa_company_amount,2)) ?></th> 



   <?php } if($user_priority>=priority('master')){?>                                         
    <th><?= (number_format(-1*$total_master_match_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_master_session_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_master_match_session_comm,2)) ?></th>  
    <th><?= (number_format($total_master_net_amount,2)) ?></th>  
    <th><?= (number_format($total_master_share_amount,2)) ?></th> 
    <th>0.00</th>
    <th><?= (number_format($total_master_company_amount,2)) ?></th> 

   <?php } if($user_priority>=priority('admin')){?>                
    <th><?= (number_format(-1*$total_admin_match_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_admin_session_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_admin_match_session_comm,2)) ?></th>  
    <th><?= (number_format($total_admin_net_amount,2)) ?></th>  
    <th><?= (number_format($total_admin_share_amount,2)) ?></th> 
    <th>0.00</th>
    <th><?= (number_format($total_admin_company_amount,2)) ?></th>

    <?php } if($user_priority>=priority('superadmin')){?>
    <th><?= (number_format(-1*$total_superadmin_match_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_superadmin_session_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_superadmin_match_session_comm,2)) ?></th>  
    <th><?= (number_format($total_superadmin_net_amount,2)) ?></th>  
    <th><?= (number_format($total_superadmin_share_amount,2)) ?></th> 
    <th>0.00</th>
    <th><?= (number_format($total_superadmin_company_amount,2)) ?></th>
    <?php } ?>
     </tr>
    </thead>
  </table>
</div>
<?php }  ?>

</div>
</div>
<!-- // AGENT CALCULATION FINISH --> 
<?php } 
$master_total_data=$master_array[$master_id];
extract($master_total_data);
?>
<?php  if($user_priority>=priority('master')) { ?>
<div class="card-footer">
  <table class="table table-striped table-bordered">
    <thead class="bg-gradient-white">
      <tr>
        <th>MASTER TOTAL
            <br>
           <small style="color:red"> <?= $master_name ?></small>
        </th>
        <th><?= (number_format($total_agent_match_coins,2)) ?></th>
    <th><?= (number_format($total_agent_session_coins,2)) ?></th>
    <th><?= (number_format($total_agent_match_coins+$total_agent_session_coins,2)) ?></th>
    <?php  if($user_priority>=priority('agent')){?>
    <th><?= (number_format(-1*$total_agent_match_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_agent_session_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_agent_match_session_comm,2)) ?></th>  
    <th><?= (number_format($total_agent_net_amount,2)) ?></th>  
    <th><?= (number_format($total_agent_share_amount,2)) ?></th> 
    <th>0.00</th>
    <th><?= (number_format($total_agent_company_amount,2)) ?></th>


    <?php } if($user_priority>=priority('superagent')){?>
    <th><?= (number_format(-1*$total_sa_match_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_sa_session_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_sa_match_session_comm,2)) ?></th>  
    <th><?= (number_format($total_sa_net_amount,2)) ?></th>  
    <th><?= (number_format($total_sa_share_amount,2)) ?></th> 
    <th>0.00</th>
    <th><?= (number_format($total_sa_company_amount,2)) ?></th> 



   <?php } if($user_priority>=priority('master')){?>                                         
    <th><?= (number_format(-1*$total_master_match_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_master_session_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_master_match_session_comm,2)) ?></th>  
    <th><?= (number_format($total_master_net_amount,2)) ?></th>  
    <th><?= (number_format($total_master_share_amount,2)) ?></th> 
    <th>0.00</th>
    <th><?= (number_format($total_master_company_amount,2)) ?></th> 

   <?php } if($user_priority>=priority('admin')){?>                
    <th><?= (number_format(-1*$total_admin_match_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_admin_session_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_admin_match_session_comm,2)) ?></th>  
    <th><?= (number_format($total_admin_net_amount,2)) ?></th>  
    <th><?= (number_format($total_admin_share_amount,2)) ?></th> 
    <th>0.00</th>
    <th><?= (number_format($total_admin_company_amount,2)) ?></th>

     <?php } if($user_priority>=priority('superadmin')){?>
    <th><?= (number_format(-1*$total_superadmin_match_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_superadmin_session_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_superadmin_match_session_comm,2)) ?></th>  
    <th><?= (number_format($total_superadmin_net_amount,2)) ?></th>  
    <th><?= (number_format($total_superadmin_share_amount,2)) ?></th> 
    <th>0.00</th>
    <th><?= (number_format($total_superadmin_company_amount,2)) ?></th>
    <?php } ?>
     </tr>
    </thead>
  </table>
</div>
<?php  } ?>
</div>
</div>
<!-- // SA CALCULATION FINISH -->
<?php } 
$admin_total_data=$admin_array[$admin_id];
extract($admin_total_data);
?>
<?php  if($user_priority>=priority('admin')) { ?>
<div class="card-footer">
  <table class="table table-striped table-bordered">
    <thead class="bg-gradient-white">
      <tr>
        <th>ADMIN TOTAL
            <br>
            <small style="color:red"> <?= $admin_name ?></small>
        </th>
        <th><?= (number_format($total_agent_match_coins,2)) ?></th>
    <th><?= (number_format($total_agent_session_coins,2)) ?></th>
    <th><?= (number_format($total_agent_match_coins+$total_agent_session_coins,2)) ?></th>
    <?php  if($user_priority>=priority('agent')){?>
    <th><?= (number_format(-1*$total_agent_match_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_agent_session_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_agent_match_session_comm,2)) ?></th>  
    <th><?= (number_format($total_agent_net_amount,2)) ?></th>  
    <th><?= (number_format($total_agent_share_amount,2)) ?></th> 
    <th>0.00</th>
    <th><?= (number_format($total_agent_company_amount,2)) ?></th>


    <?php } if($user_priority>=priority('superagent')){?>
    <th><?= (number_format(-1*$total_sa_match_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_sa_session_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_sa_match_session_comm,2)) ?></th>  
    <th><?= (number_format($total_sa_net_amount,2)) ?></th>  
    <th><?= (number_format($total_sa_share_amount,2)) ?></th> 
    <th>0.00</th>
    <th><?= (number_format($total_sa_company_amount,2)) ?></th> 



    <?php } if($user_priority>=priority('master')){?>                           
    <th><?= (number_format(-1*$total_master_match_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_master_session_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_master_match_session_comm,2)) ?></th>  
    <th><?= (number_format($total_master_net_amount,2)) ?></th>  
    <th><?= (number_format($total_master_share_amount,2)) ?></th> 
    <th>0.00</th>
    <th><?= (number_format($total_master_company_amount,2)) ?></th> 

   <?php } if($user_priority>=priority('admin')){?>                
    <th><?= (number_format(-1*$total_admin_match_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_admin_session_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_admin_match_session_comm,2)) ?></th>  
    <th><?= (number_format($total_admin_net_amount,2)) ?></th>  
    <th><?= (number_format($total_admin_share_amount,2)) ?></th> 
    <th>0.00</th>
    <th><?= (number_format($total_admin_company_amount,2)) ?></th>

    <?php } if($user_priority>=priority('superadmin')){?>
    <th><?= (number_format(-1*$total_superadmin_match_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_superadmin_session_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_superadmin_match_session_comm,2)) ?></th>  
    <th><?= (number_format($total_superadmin_net_amount,2)) ?></th>  
    <th><?= (number_format($total_superadmin_share_amount,2)) ?></th> 
    <th>0.00</th>
    <th><?= (number_format($total_superadmin_company_amount,2)) ?></th>
    <?php } ?>
     </tr>
    </thead>
  </table>
</div>
<?php } ?>
</div>
</div>
<!-- // MASTER CALCULATION FINISH -->
<?php } 
$superadmin_total_data=$superadmin_array[$superadmin_id];
extract($superadmin_total_data);
?>
<?php  if($user_priority>=priority('superadmin')) { ?>
<div class="card-footer">
  <table class="table table-striped table-bordered">
    <thead class="bg-gradient-white">
      <tr>
        <th>SUPERADMIN TOTAL
            <br>
            <small style="color:red"> <?= $superadmin_name ?></small>
        </th>
    <th><?= (number_format($total_agent_match_coins,2)) ?></th>
    <th><?= (number_format($total_agent_session_coins,2)) ?></th>
    <th><?= (number_format($total_agent_match_coins+$total_agent_session_coins,2)) ?></th>
    <?php  if($user_priority>=priority('agent')){?>
    <th><?= (number_format(-1*$total_agent_match_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_agent_session_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_agent_match_session_comm,2)) ?></th>  
    <th><?= (number_format($total_agent_net_amount,2)) ?></th>  
    <th><?= (number_format($total_agent_share_amount,2)) ?></th> 
    <th>0.00</th>
    <th><?= (number_format($total_agent_company_amount,2)) ?></th>


    <?php } if($user_priority>=priority('superagent')){?>
    <th><?= (number_format(-1*$total_sa_match_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_sa_session_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_sa_match_session_comm,2)) ?></th>  
    <th><?= (number_format($total_sa_net_amount,2)) ?></th>  
    <th><?= (number_format($total_sa_share_amount,2)) ?></th> 
    <th>0.00</th>
    <th><?= (number_format($total_sa_company_amount,2)) ?></th> 



    <?php } if($user_priority>=priority('master')){?>                           
    <th><?= (number_format(-1*$total_master_match_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_master_session_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_master_match_session_comm,2)) ?></th>  
    <th><?= (number_format($total_master_net_amount,2)) ?></th>  
    <th><?= (number_format($total_master_share_amount,2)) ?></th> 
    <th>0.00</th>
    <th><?= (number_format($total_master_company_amount,2)) ?></th> 

   <?php } if($user_priority>=priority('admin')){?>                
    <th><?= (number_format(-1*$total_admin_match_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_admin_session_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_admin_match_session_comm,2)) ?></th>  
    <th><?= (number_format($total_admin_net_amount,2)) ?></th>  
    <th><?= (number_format($total_admin_share_amount,2)) ?></th> 
    <th>0.00</th>
    <th><?= (number_format($total_admin_company_amount,2)) ?></th>

    <?php } if($user_priority>=priority('superadmin')){?>
    <th><?= (number_format(-1*$total_superadmin_match_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_superadmin_session_comm,2)) ?></th>  
    <th><?= (number_format(-1*$total_superadmin_match_session_comm,2)) ?></th>  
    <th><?= (number_format($total_superadmin_net_amount,2)) ?></th>  
    <th><?= (number_format($total_superadmin_share_amount,2)) ?></th> 
    <th>0.00</th>
    <th><?= (number_format($total_superadmin_company_amount,2)) ?></th>
    <?php } ?>
     </tr>
    </thead>
  </table>
</div>
<?php } ?>
</div>
</div>
<?php  ?>

</div>
</div>
</div>
</div>
</div>
</section>

<?php  include('footer.php');  ?>