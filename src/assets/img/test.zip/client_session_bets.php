<?php 
include('include/config.php');
include('header.php');
$declared_run='null';
$loss_profit=0;
$market_id=isset($_GET['market_id'])?$_GET['market_id']:'';
$page_name=isset($_GET['page_name'])?$_GET['page_name']:'';
$session_data=array();
$show_client_id='';
if(isset($_POST) AND isset($_POST['market_id']))
{ 
  $usertype=$userdata['user_type']=='superagent'?'superagent':$userdata['user_type'];
  $page_name=$_POST['page_name'];
  $market_id=isset($_POST['market_id'])?$_POST['market_id']:$market_id;
  $where="market_id='".$market_id."' AND ".$usertype."_id=".$userdata['user_id']." AND deleted_status=0";
  if(isset($_POST['client_id']) AND $_POST['client_id']!='')
  {
    $show_client_id=$_POST['client_id'];
    $where=$where." AND client_id='".$_POST['client_id']."'";
  }
  if(isset($_POST['selection_id']) AND $_POST['selection_id']!='')
  {
    $where=$where." AND selection_id='".$_POST['selection_id']."'";
    $declared_run=get_data('session_crick_tbl',"market_id='".$market_id."' AND selection_id='".$_POST['selection_id']."'",'s')['decision_run'];
    
  }
  $session_data=get_data('client_session_bat_tbl',$where,'','amount,bhav,type,selection_id,decision_run,time_inserted,runner_name,pass_amount,fail_amount,client_name,comm_perm,bet_run,ip');
}
else
{
    $_POST['client_id']='';
    $_POST['selection_id']='';
}
$client_data=$client_played_match = get_data('client_played_match', user_where("market_id='".$market_id."' AND play_status=1", 's'), '', 'client_id,client_details');
$session_list=get_data('session_crick_tbl',"market_id='".$market_id."'");
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Session Bet Details</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="dashboard?page_name=dashboard">Home</a></li>
              <li class="breadcrumb-item active">Session Bet Details</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">

                        <!-- /.card -->

                        <div class="card">


                            <form action="client_session_bets" id="myForm" method="post">
                              <input type="hidden" name="market_id" value="<?= $market_id ?>">
                              <input type="hidden" name="page_name" value="<?= $page_name ?>">

                                <div class="card-header ">


                                    <div class="form-row">

                                        <div>
                                                    </div><div>
                                                    </div><table class="table table-bordered table-striped">
                                            <thead class="text-bold">

                                            <tr>
                                                <th>Client</th>
                                                <th class="col-lg-4" style="min-width: 240px">

                                                    <select class="form-control select2" id="client_id" placeholder="Select Client" name="client_id" data-select2-id="name" tabindex="-1" aria-hidden="true">
                                                <option value="">Select Client...</option>
                                                <?php foreach ($client_data as $key => $value) { 

                                                    $client_details=json_decode($value['client_details'],true);

                                                    //_dx($client_details);

                                                    ?>
                                                <option value="<?= $client_details['id'] ?>"  <?php if($_POST['client_id']==$client_details['id']) echo 'selected' ?>><?= $client_details['ClientCode'] ?> (<?= $client_details['ClientName'] ?>)</option>
                                              <?php } ?>
                                                
                                            </select>
                                                  </th>
                                                <th></th>
                                                <th>Declare @ <?= $declared_run ?></th>
                                            </tr>
                                            <tr>
                                                <th>Session</th>
                                                <th class="col-lg-4" style="min-width: 240px"><select class="form-control custom-select select2"  id="session" placeholder="Select Client" name="selection_id">
                                                    <option value="">All Session</option>
                                                    <?php foreach ($session_list as $key => $value) { ?>
                                                    <option <?php if($_POST['selection_id']==$value['selection_id']) echo 'selected' ?> value="<?= $value['selection_id'] ?>"><?= strtoupper($value['session_name']) ?></option>
                                                  <?php } ?>
                                                    
                                                </select>
                                              </th>
                                                <th>
                                                  <input type="submit" class="btn-primary " id="btn" name="submit" value="View">
                                                </th>
                                              <th class="text-red">0</th>
                                            </tr>
                                            </thead>
                                        </table>
                                    </div>
                                </div>

                                <div class="card-body">
                                  <?php if(empty($session_data)){?>
                                    
                                    <div class="alert alert-warning">
                                        <h6>No Record Found</h6>
                                    </div>
                                  <?php } else{?>

                                    
                                    <div>

                                        <div class="row">

                                            <div class="col-md-10">
                                                <table class="table table-striped table-bordered">

                                                    <thead>

                                                    <tr>
                                                        <th>#</th>
                                                        <th>Client</th>
                                                        <th>Session</th>
                                                        <th>Rate</th>
                                                        <th>Amount</th>
                                                        <th>Runs</th>
                                                        <th style="width: 40px">Mode</th>
                                                        <th>Profit</th>
                                                        <th>Loss</th>
                                                        <th>Date &amp; Time</th>
                                                        <th>Ip</th> 
                                                    </tr>
                                                    </thead>

                                                    <tbody>
                                                      <?php $no=1;  foreach ($session_data as $key => $session) { ?>
                                                     
                                                    <tr>
                                                        <td><?= $no++ ?></td>
                                                        <td><?= $session['client_name'] ?></td>
                                                        <td><?= $session['runner_name'] ?><br><?php  if($session['comm_perm']==0){ echo '<small class="text-danger"> (No Comm)</small>';} ?></td>
                                                        <td><?= $session['bhav'] ?> </td>
                                                        <td><?= $session['amount'] ?></td>
                                                        <td><?= $session['bet_run'] ?></td>
                                                        <td><?= $session['type']=='Y'?'YES':'NO' ?></td>
                                                        <td><?= $session['pass_amount'] ?></td>
                                                        <td><?= $session['fail_amount'] ?></td>
                                                        <td><?= $session['time_inserted'] ?></td>
                                                        <td><?= $session['ip'] ?></td> 
                                                    </tr>
                                                  <?php } ?>
                                                    </tbody>


                                                </table>
                                            </div>

                                            <div class="col-md-2">
                                                <table class="table table-bordered table-striped ">

                                                    <thead>
                                                    <tr>
                                                        <th>RUNS</th>
                                                        <th>Amount</th>
                                                    </tr>
                                                    </thead>

                                                    <tbody id="session_position">
                                                    
                                                    
                                                    </tbody>
                                                </table>
                                            </div>

                                        </div>

                                    </div>
                                    

                                </div>
<?php } ?>
                                </div>
                                <!-- /.card-body -->
                            </form>

                        </div>
                        <!-- /.card -->


                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </section>

   

   
  </div>
  <!-- /.content-wrapper -->

  <script type="text/javascript">
function session_position(selection_id)
   {
      var market_id="<?= $market_id ?>";
      var selection_id=selection_id;
      var client_id="<?= $show_client_id?>"
     
    sendData={                
                  'market_id':market_id,
                  'selection_id':selection_id,
                  'client_id':client_id,
                  'session_position':true
             };
      
         $("#session_position").html('');
    
              $.ajax({
                    url : "position/session_position",
                    type : "post",
                    dataType: 'json',
                    data : sendData,
                    success : function(res){  
                   // console.log(res)
                    res.map((value,key)=>{

                       var poss=`<tr class="gradeX">
                            <td>${value.run}</td>
                            <td>${color(value.pos)}</td>
                      </tr>`

                     $("#session_position").append(poss);

                    })

                   }
                 });
         
   }

   <?php if(isset($_POST['selection_id'])){?>
    var selection_id="<?= $_POST['selection_id'] ?>"
     session_position(selection_id)
   <?php } ?>

 function color(value) {
    if (value < 0) {
      return `<span style="color:red">${value}</span>`;
    } else {
      return `<span style="color:#008000">${value}</span>`;
    }
  }

  </script>

  <?php  include('footer.php');  ?>