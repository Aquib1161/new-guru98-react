<?php
include('include/config.php');
$data=array();
if(isset($_POST['submit']))
{
  $report_type=$_POST['report_type'];
  $page_name=$_POST['page_name'];
  $_POST['from_date']=date_convert($_POST['from_date']);
  $_POST['to_date']=date_convert($_POST['to_date']);
  extract($_POST);

  $date_where=$where="date BETWEEN '".$from_date."' AND '".$to_date."'";
  //$date_where=$where="1=1";
  if($user_id!='all')
  {
    $where=$where." AND user_id='".$user_id."' AND user_type='".$report_type."'";
  }
  else
  {
    $where=$where." AND creater_id='".$userdata['user_id']."'";
  }

  if($report_for!='All')
  {
    $where=$where." AND task_for='".$report_for."'";
  }

  if($report_type!='client')
  {
    $where=$where." ORDER BY log_id DESC";
    $data=get_data('user_history_log',$where);
    $_POST['to_date']=date_convert($_POST['to_date'],'c');
    $_POST['from_date']=date_convert($_POST['from_date'],'c');
  }
  else
  { 
    $where=$date_where." AND user_type='client'";

    if($_POST['user_id']!='all')
    {
        $where=$where." AND client_id='".$_POST['user_id']."'";
    }
    else
    {
        $where=$where." AND creater_id='".$userdata['user_id']."'";
    }

    if($report_for!='All')
    {
        $where=$where." AND task_for='".$report_for."'";
    }

    $where=$where." ORDER BY log_id DESC";
      // /_dx($where);
    $data=get_data('user_history_log',$where);
    $_POST['to_date']=date_convert($_POST['to_date'],'c');
    $_POST['from_date']=date_convert($_POST['from_date'],'c');

  }
}
else
{
       $_POST['from_date']=date_convert('','c');
       $_POST['to_date']=date_convert('','c');
   
      $_POST['report_for']='all';
      $_POST['user_id']='all';
      $report_type=$_GET['report_type'];
      $_GET['page_name']= !isset($_GET['page_name'])?$_GET['report_type']:$_GET['page_name'];
      $page_name=$_GET['page_name'];
      $report_for='all';
      $user_id='all';
}

$page_name=isset($_GET['page_name'])?$_GET['page_name']:$_POST['page_name'];
$user_data=downline_data($report_type);
include('header.php');
?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Report</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="dashboard?page_name=dashboard">Home</a></li>
              <li class="breadcrumb-item active">Report</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">

                        <!-- /.card -->

                        <div class="card">


                            
                              <form action="report" method="POST">
                                <input type="hidden"  name="report_type" value="<?= $report_type ?>">
                                <?php if(isset($_GET['page_name'])){?>

                                    <input type="hidden"  name="page_name" value="<?= $_GET['page_name'] ?>">

                                <?php }elseif(isset($_POST['page_name'])){?>

                                    <input type="hidden"  name="page_name" value="<?= $_POST['page_name'] ?>">

                                <?php } else{?>
                                <input type="hidden"  name="page_name" value="<?= $page_name ?>">

                                <?php } ?>

                                <div class="card-header bg-gradient-purple">

                                    <h4 class="text-capitalize"><?= $report_type ?> Reports</h4>


                                    <div class="form-row">
                                        <div class="form-group col-md-3">
                                            <label for="name" class="text-capitalize"><?= $report_type ?></label>
                                            <select class="form-control select2 " id="user_id" placeholder="Select Client"  name="user_id" >
                                                <option value="all"> All <?= $report_type ?> </option>
                                                <?php foreach ($user_data as $key => $value) {?>
                                                <option <?php if($user_id==$value['user_id']) echo 'selected'; ?> value="<?= $value['user_id'] ?>"><?= $value['username'] ?> <?= $value['name'] ?></option>
                                               <?php  } ?>
                                                
                                            </select>
                                        </div>

                                        <div class="form-group col-md-2">
                                            <label for="type">Report Type</label>
                                            <select class="form-control custom-select" required="" id="report_for" placeholder="Select Client" name="report_for">
                                                <option <?php if($report_for=='All') echo 'selected';  ?> value="All" selected="selected">All</option>
                                                <option <?php if($report_for=='name') echo 'selected';  ?> value="name">Name</option>
                                                <option <?php if($report_for=='mobile_charge') echo 'selected';  ?> value="mobile_charge">MobAppCharge</option>
                                                <option <?php if($report_for=='mobile') echo 'selected';  ?> value="mobile">ContactNo</option>
                                                <option <?php if($report_for=='coins') echo 'selected';  ?> value="coins">Limit</option>
                                                <option <?php if($report_for=='match_commission') echo 'selected';  ?> value="match_commission">MatchCommission</option>
                                                <option <?php if($report_for=='session_commission') echo 'selected';  ?> value="session_commission">SessionCommission</option>
                                                <option <?php if($report_for=='match_share') echo 'selected';  ?> value="match_share">Share</option>
                                                <option <?php if($report_for=='status') echo 'selected';  ?> value="status">Status</option>
                                            </select>
                                        </div>

                                        <div class="form-group col-md-2">
                                            <div class="form-group">
                                                <label for="from">Date From</label>
                                                <div class="input-group date" id="reservationdateFrom"  data-target-input="nearest">

                                                    <input type="date" class="form-control datetimepicker-input" id="from_date" value="<?= $_POST['from_date'] ?>" name="from_date" >

                                                    <div class="input-group-append" data-target="#reservationdateFrom" data-toggle="datetimepicker">
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group col-md-2">
                                            <div class="form-group">
                                                <label for="to">Date To</label>
                                                <div class="input-group date" id="reservationdateTo" data-target-input="nearest">
                                                     <input type="date" class="form-control datetimepicker-input" id="to_date" data-target="#reservationdateFrom1" name="to_date" value="<?= $_POST['to_date'] ?>">

                                                    <div class="input-group-append" data-target="#reservationdateFrom1" data-toggle="datetimepicker">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group col-md-3">

                                            <label class="control-label text-purple" for="btn">`</label>
                                            <input type="submit" class="form-control btn-primary" onclick="submit()" name="submit" value="Sumbit">

                                        </div>


                                    </div>



                                </div>
                                <!-- /.card-header -->


                          <div class="card-body">
              <table id="example1" class="table table-bordered table-striped">

<style type="text/css">
  th{
    color: black;
    background-color: #FFC411;
  }
</style>
                <thead>
                    <tr>
                      <th>#</th>
                      <th><?= ucfirst($report_type)?></th>
                      <th>Type</th>
                      <th>Old</th>
                      <th>New</th>
                      <th>User</th>
                      <th>Date</th>
                      <th>IP</th>
                      <th>NOTE</th>
                    </tr>
                </thead>
                <tbody>
                  <?php $no=1; foreach ($data as $key => $data_value) { 
                    $data_array=json_decode($data_value['data_array'],true);
                    ?>
                 <tr>
                  <td><?= $no++; ?></td>
                  <td><?= $data_array['client'] ?></td>
                  <td><?= $data_array['type'] ?></td>
                  <td><?= $data_array['old'] ?></td>
                  <td><?= $data_array['new'] ?></td>
                  <td><?= $data_array['user'] ?></td>
                  <td><?= $data_value['date_time'] ?></td>
                  <td><?= $data_value['ip'] ?></td>
                  <td><?= $data_array['note'] ?></td>
                </tr>
                  <?php } ?>

                </tbody>


              </table>
            </div>
          </form>
        </div>
      </div>
    </div>

  </div>

        </section>

   

   
  </div>


  <?php  include('footer.php');  ?>