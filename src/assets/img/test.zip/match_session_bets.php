    <?php 
include('include/config.php');
$_GET=sanatize($_GET);
$_POST=sanatize($_POST);
$market_id=$_GET['market_id'];
$match_data=get_data('upcoming_match','market_id='.$market_id,'single','team_data_array,count');
$team_data=json_decode($match_data['team_data_array'],true);
/*$team_data=get_data('match_team_tbl','market_id='.$market_id);*/
$count=count($team_data);
$team1_selection_id=$team_data[0]['selection_id'];
$team1_name=$team_data[0]['runner_name'];
$team2_selection_id=$team_data[1]['selection_id'];
$team2_name=$team_data[1]['runner_name'];
$team3_selection_id='';
if($count==3)
{
$team3_selection_id=$team_data[2]['selection_id'];
$team3_name=$team_data[2]['runner_name'];
}
$client_data=market_id_client_data($market_id);
include('header.php');
?>
 
  <div class="content-wrapper">
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Match & Session Bet Details MatchCode</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="dashboard?page_name=dashboard">Home</a></li>
              <li class="breadcrumb-item active">Match & Session Bet Details</li>
            </ol>
          </div>
        </div>
      </div>
    </section>

    <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">

                        <!-- /.card -->

                        <div class="card">
                                <div class="card-header ">
                                    <div class="form-row col-md-9">
                                        <div class="form-group col-md-4">
                                            <label for="name">Client</label>
                                            <select class="form-control select2 " required="" onchange="select()" id="client_id" placeholder="Select Client" name="client" data-select2-id="name" tabindex="-1" aria-hidden="true">
                                                <option value="0">Select Client...</option>
                                                <?php foreach ($client_data as $key => $value) { ?>
                                                <option value="<?= $value['id'] ?>"><?= $value['ClientCode'] ?> <?= $value['ClientName'] ?></option>
                                              <?php } ?>
                                                
                                            </select>
                                        </div>

                                        <div class="form-group col-md-4">

                                            <label class="control-label text-purple" for="btn">`</label>
                                            <input type="submit" class="form-control btn-primary" id="btn" name="submit" value="Sumbit">

                                        </div>


                                    </div>


                                </div>
                                <!-- /.card-header -->


                                <div class="card-body">
                                    <div>

                                        <div class="form-row">

                                            <div class="col-md-6">
                                                <table class="table table-responsive table-striped table-bordered">

                                                    <thead>

                                                    <tr>
                                                        <th class="text-center bg-secondary" colspan="9">MATCH BETS
                                                        </th>
                                                    </tr>

                                                    <tr>
                                                        <th>#</th>
                                                        <th>Rate</th>
                                                        <th>Mode</th>
                                                        <th>Team</th>
                                                        <th>Amount</th>
                                                        <?php foreach ($team_data as $key => $value) {
                                                        echo '<th>'.$value['runner_name'].'</th>';
                                                        }  ?>
                                                        <th>Date &amp; Time</th>

                                                    </tr>
                                                    </thead>

                                                    <tbody id="match_bets">
                                                    
                                                   
                                                    </tbody>

                                                    <tbody id='match_total'>
                                                    

                                                </tbody></table>
                                            </div>

                                            <div class="col-md-6">
                                                <table class="table table-responsive table-striped table-bordered">
                                                    <thead>

                                                    <tr>
                                                        <th class="text-center bg-secondary" colspan="8">SESSION BETS
                                                        </th>
                                                    </tr>

                                                    <tr>
                                                        <th>#</th>
                                                        <th>Session</th>
                                                        <th>Rate</th>
                                                        <th>Run</th>
                                                        <th>Mode</th>
                                                        <th>Amount</th>
                                                        <th>Dec</th>
                                                        <th>Date &amp; Time</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody id="session_bet">
                                                    
                                                    
                                                  
                                                    </tbody>

                                                    <tfoot id="session_total">
                                                    
                                                </tfoot>

                                                </table>
                                            </div>
                                        </div>

                                    </div>
                                    

                                </div>
                                <!-- /.card-body -->
                            </form>

                        </div>
                        <!-- /.card -->


                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </section>

    
  </div>
  <!-- /.content-wrapper -->

<script type="text/javascript">


    var market_id ='<?php echo $market_id ?>';
    var team1_selection_id ='<?= $team1_selection_id ?>';
    var team2_selection_id ='<?= $team2_selection_id ?>';
    var team3_selection_id ='<?= $team3_selection_id ?>';
    var count="<?= $count ?>"

    function select()
    {
        var client_id=$('#client_id').val()

        if(client_id==0)
        {   
            $("#match_bets").html('');
            $('#match_total').html('')
            $('#session_bet').html('')
            $('#session_total').html('')
            return false;
        }

        match_bet(client_id)
        session_bet(client_id)
       
       
    }
       function match_bet(client_id)
     {
          
                $("#match_bets tr").remove();
                $('#match_total').html('')
                var check=true;
                var match_type ='match_odds'
                var bet_type = 0;
                var client_id = client_id
                var market_id ='<?php echo $_GET['market_id'] ?>';
                $.ajax({
                    url : "ajax/match_bet",
                    type : "post",
                    dataType: 'json',
                    data : {bet_type:bet_type,match_type:match_type,client_id :client_id,market_id:market_id},
                    success : function(res){
                        var data=res.data;
                        var no=1;
                        var total_favour_amount=0
                        var total_amount=0
                        var total_unfavour_amount=0
                        var total_third_amount=0

                            jQuery.each(data, function(i,bet_data) 
                            {   
                               
                                var position_array=bet_data.position_array
                                total_amount+=parseInt(bet_data.amount)
                                total_favour_amount+=parseInt(position_array.team1_amount)
                                total_unfavour_amount+=parseInt(position_array.team2_amount)
                                


                          var share_amount_favour=(bet_data.my_share*bet_data.favor_amount/100);
                          var share_amount_unfavour=(bet_data.my_share*bet_data.unfavour_amount/100);
                          if(count==3)
                          { 
                            total_third_amount+=parseInt(position_array.team3_amount)
                            var str='<tr class=""><td>'+ no++ +'</td><td>'+bet_data.bhav+'</td><td>'+bet_data.type+'</td><td>'+bet_data.team_name+'</td><td>'+bet_data.amount+'</td><td>'+position_array.team1_amount+'</td><td>'+position_array.team2_amount+'</td><td>'+position_array.team3_amount+'</td><td>'+bet_data.time_inserted+'</td></tr>';
                          }
                          else
                          {
                            var str='<tr class=""><td>'+ no++ +'</td><td>'+bet_data.bhav+'</td><td>'+bet_data.type+'</td><td>'+bet_data.team_name+'</td><td>'+bet_data.amount+'</td><td>'+position_array.team1_amount+'</td><td>'+position_array.team2_amount+'</td><td>'+bet_data.time_inserted+'</td></tr>';

                          }
                          
                          $("#match_bets").append(str);
                    });

                          if(count==3)
                          {
                            var total=`<tr>
                                                        <th class="text-center" colspan="2"> </th>
                                                        <th class="text-center">Total </th>
                                                        <th class="text-red"></th>
                                                        <th class="text-red">${color(total_amount)}</th>
                                                        <th class="text-red">${color(total_favour_amount)}</th>
                                                        <th class="text-red">${color(total_unfavour_amount)}</th>
                                                        <th class="text-red">${color(total_third_amount)}</th>
                                                        <th></th>
                                                    </tr>`
                          }
                          else
                          {
                            var total=`<tr>
                                                        <th class="text-center" colspan="2"> </th>
                                                        <th class="text-center">Total </th>
                                                        <th class="text-red"></th>
                                                        <th class="text-red">${color(total_amount)}</th>
                                                        <th class="text-red">${color(total_favour_amount)}</th>
                                                        <th class="text-red">${color(total_unfavour_amount)}</th>
                                                       
                                                        <th></th>
                                                    </tr>`
                          }
                            


                                $('#match_total').append(total)
                            
                    }
                });
            
     }



      function session_bet(client_id)
    {
         
                var check=true;
                $('#session_bet').html('')
        
                $.ajax({
                    url : "ajax/session_bet",
                    type : "post",
                    dataType: 'json',
                    data : {selection_id:'',client_id :client_id,market_id:market_id,deleted_status:0},
                    success : function(res){
                        var data=res.data;
                        var no=1;
                        var total_amount=0;
                            jQuery.each(data, function(i,bet_data) 
                            {  
                           total_amount+=parseInt(bet_data.amount) 
                          var share_amount_favour=(bet_data.my_share*bet_data.pass_amount/100);
                          var share_amount_unfavour=(bet_data.my_share*bet_data.fail_amount/100);

                          var comm_perm='';
                          if(bet_data.comm_perm==0)
                          {
                            comm_perm='<small class="text-danger"> (No Comm)</small>'
                          }

                          var background_color='danger';
                          var font_color='white';

                          if(!bet_data.win)
                          {
                            background_color='success';
                          }

                          if(!bet_data.decision_run)
                          {
                            background_color='blue';
                            bet_data.decision_run='Decision Pending'
                          }

                          var str='<tr class="bg-'+background_color+' "><td>'+ no++ +'</td><td>'+bet_data.runner_name+''+comm_perm+'</td><td>'+bet_data.bhav+'</td><td>'+bet_data.bet_run+'</td><td>'+bet_data.type+'</td><td>'+bet_data.amount+'</td><<td>'+bet_data.decision_run+'</td><td>'+bet_data.time_inserted+'</td></tr>';

                          $("#session_bet").append(str);
                    });

                             data= get_queyr_data('position','client_id='+client_id+' AND market_id='+market_id+'','s','client_session_coins')
  

                            var session_total=`<tr>
                                                 <th colspan="5" class="text-center">Session Plus</th>
                                                 <th colspan="3" class="text-blue">${color(data.data.client_session_coins)}</th>
                                               </tr>`

                                               $('#session_total').html(session_total)
                        
                        
                    }
                });
            
    }



     
</script>

  <?php  include('footer.php');  ?>