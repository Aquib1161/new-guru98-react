<?php 

function get_series_by_id($series_id)
{
   global $con;
   $query="SELECT id from series_tbl WHERE series_id=".$series_id."";
   $res=mysqli_query($con,$query);
   return $count=mysqli_fetch_assoc($res); 
}

function get_ledger($market_id='',$type='',$id='')
{ 
  global $con;
  if(empty($type) OR empty($id))
  {
   $type=$_SESSION['user_type'];
   $id=$_SESSION['user_id'];
  }

  $where="".$type."_id='".$id."'";

  if(!empty($market_id))
  {
   $where=$where." AND market_id='".$market_id."'";
  }
  
  $query="SELECT * FROM ".$type."_ledger WHERE ".$where." order by id desc";

  $user_res = mysqli_query($con,$query);
  $send_array=array();
  if(empty($market_id))
   {
     while($data=mysqli_fetch_assoc($user_res))
     { 
      $send_array['amount']=$data[$type.'_amount'];
      array_push($send_array, $data);
     }    
   }
   else
   { 
     $send_array=mysqli_fetch_assoc($user_res);
     $send_array['amount']=$send_array[$type.'_amount'];
   }
   //_dx($send_array);
    return $send_array;
  
}


function team_name($market_id)
{

  $team_tbl=get_data('match_team_tbl',"market_id='".$market_id."'");
  $count=count($team_tbl);
  $team1_name=$team_tbl[0]['runner_name'];
  $team1_selection_id=$team_tbl[0]['selection_id'];
  $team2_name=$team_tbl[1]['runner_name'];
  $team2_selection_id=$team_tbl[1]['selection_id'];
  $send_array=array('team1_name'=>$team1_name,'team2_name'=>$team2_name,'team1_selection_id'=>$team1_selection_id,'team2_selection_id'=>$team2_selection_id);
  if($count==3)
  {
    $draw_name=$team_tbl[2]['runner_name'];
    $draw_selection_id=$team_tbl[2]['selection_id'];
    $send_array['draw_name']=$draw_name;
    $send_array['draw_selection_id']=$draw_selection_id;
  }
 
  return $send_array;
}

/*function insert_bookmaker_word777($event_id,$market_id)
{  
  $market_id='1.195049884';
  $url="https://worldindia.bet/GameData/".$event_id."/".$market_id."/BookmakerMarketPriceIP"
   $data = api_data_curl_no_header($url);
   $odds_data=json_decode($data,true);
   if(empty($odds_data))
   {
    return false;
    die();
    exit();
   }
}
*/


function insert_bookmaker($event_id)
{
   $url = bookmaker.$event_id;
   $data = api_data_curl_no_header($url);
   $odds_data=json_decode($data,true);
   if(empty($odds_data))
   {
    return false;
    die();
    exit();
   }
   foreach ($odds_data['t2'][0]['bm1'] as $key => $odds_value) 
   {   
       extract($odds_value);
       $insert_array=array(
        'selection_id'=>$sid,
        'runner_name'=>$nat,
        'market_id'=>$mid,
       /* 'event_id'=>$event_id*/
       );

       $count=count_data('match_team_tbl',"event_id='".$event_id."' AND selection_id='".$sid."'");
       if($count==0)
       {
       $insert=insert_array('diamond_match_team_tbl',$insert_array);
       _d($insert);
       }
   }

}


function insert_bookmaker_bookmaker_table($event_id)
{
   $url = bookmaker.$event_id;
   $data = api_data_curl_no_header($url);
   $odds_data=json_decode($data,true);

   foreach ($odds_data['t2'][0]['bm1'] as $key => $odds_value) 
   {   
       extract($odds_value);
       $insert_array=array(
        'selection_id'=>$sid,
        'team_name'=>$nat,
        'market_id'=>$mid,
        'event_id'=>$event_id
       );

       $count=count_data('diamond_match_team_tbl',"event_id='".$event_id."' AND selection_id='".$sid."'");
       if($count==0)
       {
       $insert=insert_array('diamond_match_team_tbl',$insert_array);
       }
   }

}


function worldapi_bookmaker_api($match_data)
{
   $url = worldindia_bookmaker.$match_data['event_id'].'/'.$match_data['market_id'].'/BookmakerMarketPriceIP';
   $data = api_data_curl_no_header($url);
   $odds_data=json_decode($data,true);
   $status=false;
   if(!empty($odds_data))
   {
   $odds_data=$odds_data[0];
   $send_status=1;
   $team_data=array();
     if($odds_data['ggstatus']=='ACTIVE')
     {
      $status=true;
      $runners=$odds_data['runners'];
       foreach ($runners as $key => $bookmaker_value) 
         {  
            $insert_array=array(
              'runner_name'=>$bookmaker_value['nation'],
              'selection_id'=>$bookmaker_value['selectionId'],
              'market_id'=>$match_data['market_id'],
              'time_inserted'=>_date_time()
            );
            $insert=insert_array('match_team_tbl',$insert_array);
         }
     }
   }

   return $status;
}


function match_details($market_id,$specific='')
{
   if(!empty($specific))
   { 
     return get_data('upcoming_match',"market_id='".$market_id."'",'s');
   }
   else
   {
    return get_data('upcoming_match',"market_id='".$market_id."'",'s',$specific);
   }
}


?>