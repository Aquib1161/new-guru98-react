<?php 

function agent_count($where,$status)
{
   global $con;
   $query="SELECT id from agent WHERE ".$where." AND status =".$status."";
   $res=mysqli_query($con,$query);
   return $count=mysqli_num_rows($res); 
}

function client_count($where,$status)
{
   global $con;
   $query="SELECT id from client WHERE ".$where." AND status =".$status."";
   $res=mysqli_query($con,$query);
   return $count=mysqli_num_rows($res); 
}

function sa_count($where,$status)
{
   global $con;
   $query="SELECT id from superagent WHERE ".$where." AND status =".$status."";
   $res=mysqli_query($con,$query);
   return $count=mysqli_num_rows($res); 
}

function master_count($where,$status)
{
   global $con;
   $query="SELECT id from master WHERE ".$where." AND status =".$status."";
   $res=mysqli_query($con,$query);
   return $count=mysqli_num_rows($res); 
}



?>