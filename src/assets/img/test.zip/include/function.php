<?php

date_default_timezone_set('Asia/Kolkata');
$date_time = date("d-m-Y H:i:s");
$time = date("H:i:s");
$date = date('d-m-Y');
$insert_date = date('Y-m-d');


function _d($data = '')
{

  echo "<pre>", print_r($data);
}

function _dx($data = '')
{
  if ($data != '') {
    echo "<pre>", print_r($data);
  } else {
    echo "<pre>", print_r('check');
  }
  die();
}

function user_type($type)
{
  if ($type == 1) {
    return 'superadmin';
  } else if ($type == 2) {
    return 'admin';
  } else if ($type == 3) {
    return 'master';
  } else if ($type == 4) {
    return 'superagent';
  } else if ($type == 5) {
    return 'agent';
  } else {
    return false;
  }
}



function page_backdoor($user_type)
{
  global $con;
  $query = "SELECT page_name FROM page_backdoor WHERE user_type='$user_type'";
  $result = mysqli_query($con, $query);
  $send_array = array();
  while ($fetch_data = mysqli_fetch_assoc($result)) {
    array_push($send_array, $fetch_data);
  }
  return $send_array;
}
function get_backdoor($url)
{
  global $con;
  $query = "SELECT * FROM backdoor WHERE user_type='employee' AND url='$url'";
  $res = mysqli_query($con, $query);
  return $data = mysqli_num_rows($res);
}

function api_data_curl_1($url, $post_fields = null, $headers = null)
{
  $ch = curl_init();
  $timeout = 5;
  $headers = [
    'Authorization:Restrictedapi',

  ];
  curl_setopt($ch, CURLOPT_URL, $url);
  if ($headers && !empty($headers)) {
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
  }
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
  curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
  $data = curl_exec($ch);
  if (curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
  }
  curl_close($ch);
  return $data;
}
function api_data_curl_no_header($url, $post_fields = null, $headers = null)
{
  $ch = curl_init();
  $timeout = 5;
  $headers = [
    'Authorization:Restrictedapi',

  ];
  curl_setopt($ch, CURLOPT_URL, $url);
  if ($headers && !empty($headers)) {
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
  }
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
  curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
  $data = curl_exec($ch);
  if (curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
  }
  curl_close($ch);
  return $data;
}


function ip()
{
  if (!empty($_SERVER['HTTP_CLIENT_IP']))   //check ip from share internet
  {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
  } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   //to check ip is pass from proxy
  {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
  } else {
    $ip = $_SERVER['REMOTE_ADDR'];
  }

  return $ip;
}

function _date($change='')
{
  date_default_timezone_set('Asia/Kolkata');
  if(!empty($change))
  {
    $date=date('Y-m-d');
  }
  else
  {
    $date=date('d-m-Y');
  }
  return  $date;
}
function _time()
{
  date_default_timezone_set('Asia/Kolkata');
  return  date("H:i:s");
}
function _date_time()
{
  date_default_timezone_set('Asia/Kolkata');
  return  date("d-m-Y H:i:s");
}


function user_log()
{
  global $con;
  $ip = ip();
  $date_time = _date_time();
  $get_data = '';
  $post_data = '';
  $load_url = '';
  $request_uri = $_SERVER['REQUEST_URI'];
  if (isset($_SESSION['user_type'])) {
    $user_type = $_SESSION['user_type'];
  }
  if (isset($_SERVER['HTTP_REFERER'])) {
    $load_url = $_SERVER['HTTP_REFERER'];
  }
  if (isset($_GET)) {
    $get_data = json_encode($_GET);
  }
  if (isset($_POST)) {
    $post_data = json_encode($_POST);
  }
  if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
  } else {
    $user_id = 0;
  }
  $query = "INSERT INTO user_log_tbl(user_id,user_type,ip_address,time_inserted,hit_url,previous_url,get_data,post_data)  VALUES('$user_id','$user_type','$ip','$date_time','$request_uri','$load_url','$get_data','$post_data')";
  mysqli_query($con, $query);
  return true;
}

function is_client($client_id)
{
  global $con;
  global $master_id;
  global $load_url;
  $query = "SELECT id FROM client WHERE id=$client_id";

  $res = mysqli_query($con, $query);
  $num = mysqli_num_rows($res);
  if ($num == 1) {
    $status = 1;
    return true;
  } else {
    $_SESSION['error_msg'] = 'Unauthorised use';
    header('location:dashboard.php');
    exit();
    die;
    return false;
  }
}



function color($value)
{
  if ($value < 0) {
    return  "<span style='color:#FF0000;'>" . $value . "</span>";
  } else {
    return  "<span style='color:#4289FF;'>" . $value . "</span>";
  }
}


function msg()
{
  if (isset($_SESSION['notify']) && $_SESSION['notify']['type'] == 'error') {

    $msg = $_SESSION['notify']['msg'];
    $type = $_SESSION['notify']['type'];
    unset($_SESSION['notify']);
    $return = "  
            <div>
                <div class='alert alert-danger'>
                    <label>" . $msg . "</label>
                </div>
            </div>
            ";
    return $return;
  }
}


function client_casino_bet_status($client_id, $status, $client_data = '', $agent_data = '')
{

  if (empty($client_data)) {
    $client_data = get_data('client', "id='" . $client_id . "'", 's', 'casino_bet_status,creater_id,A_id');
  }
  if (empty($agent_data)) {
    $agent_data = get_data('users_tbl', "user_id='" . $client_data['creater_id'] . "'", 's', 'user_casino_perm');
  }
  $update_array = ['casino_bet_status' => 0];

  if ($status == 1 and $agent_data['user_casino_perm'] == 1) {
    $update_array = ['casino_bet_status' => 1];
  }
  $update_array = update_array('client', $update_array, "id='" . $client_id . "'");
  return true;
}


function user_casino_bet_status($user_id, $status, $user_data = '', $parent_data = '')
{

  if (empty($user_data)) {
    $user_data = get_data('users_tbl', "id='" . $user_id['user_id'] . "'", 's', 'user_casino_perm,user_type,user_id');
    extract($user_data);
  }

  if (empty($parent_data)) {
    $parent_data = get_data('users_tbl', "id='" . $user_data['creater_id'] . "'", 's', 'user_casino_perm,user_type,user_id');
  }

  $update_array = array(
    'user_casino_perm' => 0
  );

  if ($status == 1 and $parent_data['user_casino_perm'] == 1) {
    $update_array = array(
      'user_casino_perm' => 1
    );
  } else {
    $status = 0;
  }


  $update = update_array('users_tbl', $update_array, "user_id='" . $user_id . "'");
  $update_downline = update_array('users_tbl', $update_array, $user_data['user_type'] . "_id='" . $user_data['user_id'] . "'");

  $client_data = get_data('client', user_where($user_data['user_type'] . "_id='" . $user_data['user_id'] . "'", 's'), '', 'id,agent_id,creater_id,A_id,casino_bet_status');
  foreach ($client_data as $key => $client_id) {
    $client = client_casino_bet_status($client_id['id'], $status, $client_id);
  }

  return true;
}

/**
 * Send Push Notification
 * 
 * @param Number $user_id
 * @param String $tbl
 * @param Array $noti
 */
function send_push_notification($user_id, $tbl, $noti)
{

  $data = get_data($tbl, "id=$user_id", 's','device_token');

  $notification = array(
    'notification' => ['title' => 'New Notification'],
    'data' => ($noti),
    'to' => $data['device_token'],
  );

  $curl = curl_init();

  curl_setopt_array($curl, array(
    CURLOPT_URL => 'https://fcm.googleapis.com/fcm/send',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_POSTFIELDS => json_encode($notification),
    CURLOPT_HTTPHEADER => array(
      'Authorization: key=AAAAVTYmh0s:APA91bG8mnzZMZqXQvPv3nWh3kbetERJRjkRDHnSzQPXMfocas4rtJUfuKT0UVwosBvXlAm5g67xICfG5lMCdrl4nh5lcYV7Q1tDpcKdTtnKwG8_6Kjx0XkHMK2LiDY-jI9lKgD8C75I',
      'Content-Type: application/json'
    ),
  ));

  $response = curl_exec($curl);

  curl_close($curl);
}



