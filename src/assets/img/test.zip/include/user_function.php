<?php
function date_convert($originalDate,$repeat='')
{
  if(empty($originalDate)) 
  {
    $originalDate = _date();
  }

  if(!empty($repeat))
  {
     $newDate = date("Y-m-d", strtotime($originalDate));
  }
  else
  {
    $newDate = date("d-m-Y", strtotime($originalDate));
  }
  
   
  return $newDate;
}



function client_share_array_update($client_id)
{
  $client_data = get_data('client', "id='" . $client_id . "'", 'S');
  $user_details = get_data('users_tbl', "user_id='" . $client_data['creater_id'] . "'", 's');
  $agent_details = get_data('users_tbl', "user_id='" . $client_data['agent_id'] . "'", 's');
  $sa_details = get_data('users_tbl', "user_id='" . $client_data['sa_id'] . "'", 's');
  $master_details = get_data('users_tbl', "user_id='" . $client_data['master_id'] . "'", 's');
  $admin_details = get_data('users_tbl', "user_id='" . $client_data['admin_id'] . "'", 's');
  extract($user_details);
  $share_array = array();
  if ($client_data['A_id'] != 0) {
    $agent_self_share = $user_details['agent_share'];
    $agent_self_casino_share = $user_details['user_casino_share'];
    $agent_dena_casino_share = 100 - $user_details['user_casino_share'];
    $agent_dena_share = 100 - $user_details['agent_share'];
  } else {
    $agent_self_share = 0;
    $agent_self_casino_share = 0;
    $agent_dena_share = 0;
    $agent_dena_casino_share = 0;
  }


  if ($client_data['sa_id'] != 0) {
    $sa_details = get_data('users_tbl', "user_id='" . $client_data['sa_id'] . "'", 's');
    if ($client_data['A_id'] != 0) {
      $agent_details = get_data('users_tbl', "user_id='" . $client_data['A_id'] . "'", 's');
      $sa_self_share = $sa_details['sa_share'] - $agent_details['agent_share'];
      $sa_self_casino_share = $sa_details['sa_casino_share'] - $agent_details['agent_casino_share'];
    } else {
      $sa_self_share = $sa_details['sa_share'];
      $sa_self_casino_share = $sa_details['sa_casino_share'];
    }
    $sa_dena_share = 100 - $sa_details['sa_share'];
    $sa_dena_casino_share = 100 - $sa_details['sa_casino_share'];
  } else {
    $sa_self_share = 0;
    $sa_self_casino_share = 0;
    $sa_dena_share = 0;
    $sa_dena_casino_share = 0;
  }


  if ($client_data['master_id'] != 0) {
    $master_details = get_data('users_tbl', "user_id='" . $client_data['master_id'] . "'", 's');
    if ($client_data['sa_id'] != 0) {
      $master_self_share = $master_details['master_share'] - $sa_details['sa_share'];
      $master_self_casino_share = $master_details['master_casino_share'] - $sa_details['sa_casino_share'];
    } else {

      if ($client_data['A_id'] != 0) {
        $master_self_share = $master_details['master_share'] - $agent_details['agent_share'];
        $master_self_casino_share = $master_details['master_casino_share'] - $agent_details['agent_casino_share'];
      } else {
        $master_self_share = $master_details['master_share'];
        $master_self_casino_share = $master_details['master_casino_share'];
      }
    }

    $master_dena_share = 100 - $master_details['master_share'];
    $master_dena_casino_share = 100 - $master_details['master_casino_share'];
  } else {
    $master_self_share = 0;
    $master_self_casino_share = 0;
    $master_dena_share = 0;
    $master_dena_casino_share = 0;
  }


  if ($client_data['admin_id'] != 0) {
    $admin_details = get_data('users_tbl', "user_id='" . $client_data['admin_id'] . "'", 's');
    if ($client_data['master_id'] != 0) {
      $admin_self_share = $admin_details['admin_share'] - $master_details['master_share'];
      $admin_self_casino_share = $admin_details['admin_casino_share'] - $master_details['master_casino_share'];
    } else {

      if ($client_data['sa_id'] != 0) {
        $admin_self_share = $admin_details['admin_share'] - $sa_details['sa_share'];
        $admin_self_casino_share = $admin_details['admin_casino_share'] - $sa_details['sa_casino_share'];
      } else {
        if ($client_data['A_id'] != 0) {
          $admin_self_share = $admin_details['admin_share'] - $agent_details['agent_share'];
          $admin_self_casino_share = $admin_details['admin_casino_share'] - $agent_details['agent_casino_share'];
        } else {
          $admin_self_share = $admin_details['admin_share'];
          $admin_self_casino_share = $admin_details['admin_casino_share'];
        }
      }

      if ($client_data['A_id'] != 0) {
        $master_self_share = $master_details['master_share'] - $agent_details['agent_share'];
        $master_self_casino_share = $master_details['master_casino_share'] - $agent_details['agent_casino_share'];
      } else {

        $master_self_share = $master_details['master_share'];
        $master_self_casino_share = $master_details['master_casino_share'];
      }
    }

    $admin_dena_share = 100 - $admin_details['admin_share'];
    $admin_dena_casino_share = 100 - $admin_details['admin_casino_share'];
  } else {
    $admin_self_share = 0;
    $admin_self_casino_share = 0;
    $admin_dena_share = 0;
    $admin_dena_casino_share = 0;
  }

  $superadmin_details = get_data('users_tbl', "user_id='" . $client_data['superadmin_id'] . "'", 's');

  $superadmin_self_share = $superadmin_details['user_share'] - $admin_details['admin_share'];
  $superadmin_self_casino_share = $superadmin_details['user_casino_share'] - $admin_details['admin_casino_share'];
  $superadmin_dena_share = 0;
  $superadmin_dena_casino_share = 0;

  $client_share_array = array(
    'client_id' => $client_data['id'],
    'client_mobile_charge' => $client_data['ClientMobileCharge'],
    'client_match_comm' => $client_data['MatchCommissionClient'],
    'client_session_comm' => $client_data['SessionCommissionClient'],
    'client_casino_comm' => $client_data['client_casino_comm'],
  );
  $agent_share_array = array(
    'agent_id' => $agent_id,
    'agent_name' => $agent_details['name'],
    'agent_code' => $agent_details['username'],
    'agent_match_total_share' => $agent_share,
    'agent_match_cut_share' => $agent_self_share,
    'agent_comm_type' => $agent_comm_type,
    'agent_match_comm' => $agent_match_comm,
    'agent_session_comm' => $agent_session_comm,
    'agent_casino_share' => $agent_casino_share,
    'agent_casino_comm' => $agent_casino_comm,
    'agent_self_share' => $agent_self_share,
    'agent_self_casino_share' => $agent_self_casino_share,
    'agent_dena_share' => $agent_dena_share,
    'agent_dena_casino_share' => $agent_dena_casino_share
  );
  $superagent_share_array = array(
    'superagent_id' => $superagent_id,
    'superagent_name' => $sa_details['name'],
    'superagent_code' => $sa_details['username'],
    'superagent_match_total_share' => $sa_share,
    'superagent_match_cut_share' => $sa_cut_share,
    'superagent_comm_type' => $sa_comm_type,
    'superagent_match_comm' => $sa_match_comm,
    'superagent_session_comm' => $sa_session_comm,
    'superagent_casino_share' => $sa_casino_share,
    'superagent_casino_comm' => $sa_casino_comm,
    'superagent_self_share' => $sa_self_share,
    'superagent_self_casino_share' => $sa_self_casino_share,
    'superagent_dena_share' => $sa_dena_share,
    'superagent_dena_casino_share' => $sa_dena_casino_share
  );
  $master_share_array = array(
    'master_id' => $master_id,
    'master_name' => $master_details['name'],
    'master_code' => $master_details['username'],
    'master_match_total_share' => $master_share,
    'master_match_cut_share' => $master_cut_share,
    'master_comm_type' => $master_comm_type,
    'master_match_comm' => $master_match_comm,
    'master_session_comm' => $master_session_comm,
    'master_casino_share' => $master_casino_share,
    'master_casino_comm' => $master_casino_comm,
    'master_self_share' => $master_self_share,
    'master_self_casino_share' => $master_self_casino_share,
    'master_dena_share' => $master_dena_share,
    'master_dena_casino_share' => $master_dena_casino_share
  );
  $admin_share_array = array(
    'admin_id' => $admin_id,
    'admin_name' => $admin_details['name'],
    'admin_code' => $admin_details['username'],
    'admin_match_total_share' => $admin_share,
    'admin_match_cut_share' => $admin_cut_share,
    'admin_comm_type' => $admin_comm_type,
    'admin_match_comm' => $admin_match_comm,
    'admin_session_comm' => $admin_session_comm,
    'admin_casino_share' => $admin_casino_share,
    'admin_casino_comm' => $admin_casino_comm,
    'admin_self_share' => $admin_self_share,
    'admin_self_casino_share' => $admin_self_casino_share,
    'admin_dena_share' => $admin_dena_share,
    'admin_dena_casino_share' => $admin_dena_casino_share
  );
  $superadmin_share_array = array(
    'superadmin_id' => $superadmin_id,
    'superadmin_name' => $superadmin_details['name'],
    'superadmin_code' => $superadmin_details['username'],
    'superadmin_match_total_share' => $superadmin_share,
    'superadmin_match_cut_share' => $superadmin_cut_share,
    'superadmin_comm_type' => $superadmin_comm_type,
    'superadmin_match_comm' => $superadmin_match_comm,
    'superadmin_session_comm' => $superadmin_session_comm,
    'superadmin_casino_share' => $superadmin_casino_share,
    'superadmin_casino_comm' => $superadmin_casino_comm,
    'superadmin_self_share' => $superadmin_self_share,
    'superadmin_self_casino_share' => $superadmin_self_casino_share,
    'superadmin_dena_share' => $superadmin_dena_share,
    'superadmin_dena_casino_share' => $superadmin_dena_casino_share
  );
  $share_array['client_share_array'] = $client_share_array;
  $share_array['agent_share_array'] = $agent_share_array;
  $share_array['superagent_share_array'] = $superagent_share_array;
  $share_array['master_share_array'] = $master_share_array;
  $share_array['admin_share_array'] = $admin_share_array;
  $share_array['superadmin_share_array'] = $superadmin_share_array;

  /* _dx($share_array);*/
  $share_array = json_encode($share_array);
  $update_array = array(
    'share_array' => $share_array
  );

  $update = update_array('client', $update_array, "id='" . $client_data['id'] . "'");
  return $update;
}


function flate_share_client_share_update($client_id,$client_data='')
{
  if(empty($client_data))
  {
    $client_data = get_data('client', "id='" . $client_id . "'", 'S');
  }
  $user_details = get_data('users_tbl', "user_id='" . $client_data['creater_id'] . "'", 's');
  $agent_details = get_data('users_tbl', "user_id='" . $client_data['agent_id'] . "'", 's');
  $sa_details = get_data('users_tbl', "user_id='" . $client_data['sa_id'] . "'", 's');
  $master_details = get_data('users_tbl', "user_id='" . $client_data['master_id'] . "'", 's');
  $admin_details = get_data('users_tbl', "user_id='" . $client_data['admin_id'] . "'", 's');
  extract($user_details);
  $share_array = array();

    $agent_self_share = $client_data['MatchShare2'];
    $agent_self_casino_share = $user_details['user_casino_share'];
    $agent_dena_casino_share = 100 - $user_details['user_casino_share'];
    $agent_dena_share = 100 - $client_data['MatchShare2'];

    $sa_self_share = $client_data['sa_share_total_value'] - $client_data['MatchShare2'];
    $sa_self_casino_share = $sa_details['sa_casino_share'] - $agent_details['agent_casino_share'];
    $sa_dena_share = 100 - $client_data['sa_share_total_value'];
    $sa_dena_casino_share = 100 - $sa_details['sa_casino_share'];

    $master_self_share = $client_data['master_share_total_value'] - $client_data['sa_share_total_value'];
    $master_self_casino_share = $master_details['master_casino_share'] - $sa_details['sa_casino_share'];
    $master_dena_share = 100 - $client_data['master_share_total_value'];
    $master_dena_casino_share = 100 - $master_details['master_casino_share'];


    $admin_self_share = $client_data['admin_share_total_value'] - $client_data['master_share_total_value'];
    $admin_self_casino_share = $admin_details['admin_casino_share'] - $master_details['master_casino_share'];

    $admin_dena_share = 100 - $client_data['admin_share_total_value'];
    $admin_dena_casino_share = 100 - $admin_details['admin_casino_share'];

  $superadmin_details = get_data('users_tbl', "user_id='" . $client_data['superadmin_id'] . "'", 's');

  $superadmin_self_share = $superadmin_details['user_share'] - $admin_details['admin_share'];
  $superadmin_self_casino_share = $superadmin_details['user_casino_share'] - $admin_details['admin_casino_share'];
  $superadmin_dena_share = 0;
  $superadmin_dena_casino_share = 0;

  $client_share_array = array(
    'client_id' => $client_data['id'],
    'client_mobile_charge' => $client_data['ClientMobileCharge'],
    'client_match_comm' => $client_data['MatchCommissionClient'],
    'client_session_comm' => $client_data['SessionCommissionClient'],
    'client_casino_comm' => $client_data['client_casino_comm'],
  );
  $agent_share_array = array(
    'agent_id' => $agent_id,
    'agent_name' => $agent_details['name'],
    'agent_code' => $agent_details['username'],
    'agent_match_total_share' => $agent_share,
    'agent_match_cut_share' => $agent_self_share,
    'agent_comm_type' => $agent_comm_type,
    'agent_match_comm' => $agent_match_comm,
    'agent_session_comm' => $agent_session_comm,
    'agent_casino_share' => $agent_casino_share,
    'agent_casino_comm' => $agent_casino_comm,
    'agent_self_share' => $agent_self_share,
    'agent_self_casino_share' => $agent_self_casino_share,
    'agent_dena_share' => $agent_dena_share,
    'agent_dena_casino_share' => $agent_dena_casino_share
  );
  $superagent_share_array = array(
    'superagent_id' => $superagent_id,
    'superagent_name' => $sa_details['name'],
    'superagent_code' => $sa_details['username'],
    'superagent_match_total_share' => $client_data['sa_share_total_value'],
    'superagent_match_cut_share' => $sa_cut_share,
    'superagent_comm_type' => $sa_comm_type,
    'superagent_match_comm' => $sa_match_comm,
    'superagent_session_comm' => $sa_session_comm,
    'superagent_casino_share' => $sa_casino_share,
    'superagent_casino_comm' => $sa_casino_comm,
    'superagent_self_share' => $sa_self_share,
    'superagent_self_casino_share' => $sa_self_casino_share,
    'superagent_dena_share' => $sa_dena_share,
    'superagent_dena_casino_share' => $sa_dena_casino_share
  );
  $master_share_array = array(
    'master_id' => $master_id,
    'master_name' => $master_details['name'],
    'master_code' => $master_details['username'],
    'master_match_total_share' => $client_data['master_share_total_value'],
    'master_match_cut_share' => $master_cut_share,
    'master_comm_type' => $master_comm_type,
    'master_match_comm' => $master_match_comm,
    'master_session_comm' => $master_session_comm,
    'master_casino_share' => $master_casino_share,
    'master_casino_comm' => $master_casino_comm,
    'master_self_share' => $master_self_share,
    'master_self_casino_share' => $master_self_casino_share,
    'master_dena_share' => $master_dena_share,
    'master_dena_casino_share' => $master_dena_casino_share
  );
  $admin_share_array = array(
    'admin_id' => $admin_id,
    'admin_name' => $admin_details['name'],
    'admin_code' => $admin_details['username'],
    'admin_match_total_share' => $admin_share,
    'admin_match_cut_share' => $admin_cut_share,
    'admin_comm_type' => $admin_comm_type,
    'admin_match_comm' => $admin_match_comm,
    'admin_session_comm' => $admin_session_comm,
    'admin_casino_share' => $admin_casino_share,
    'admin_casino_comm' => $admin_casino_comm,
    'admin_self_share' => $admin_self_share,
    'admin_self_casino_share' => $admin_self_casino_share,
    'admin_dena_share' => $admin_dena_share,
    'admin_dena_casino_share' => $admin_dena_casino_share
  );
  $superadmin_share_array = array(
    'superadmin_id' => $superadmin_id,
    'superadmin_name' => $superadmin_details['name'],
    'superadmin_code' => $superadmin_details['username'],
    'superadmin_match_total_share' => $superadmin_share,
    'superadmin_match_cut_share' => $superadmin_cut_share,
    'superadmin_comm_type' => $superadmin_comm_type,
    'superadmin_match_comm' => $superadmin_match_comm,
    'superadmin_session_comm' => $superadmin_session_comm,
    'superadmin_casino_share' => $superadmin_casino_share,
    'superadmin_casino_comm' => $superadmin_casino_comm,
    'superadmin_self_share' => $superadmin_self_share,
    'superadmin_self_casino_share' => $superadmin_self_casino_share,
    'superadmin_dena_share' => $superadmin_dena_share,
    'superadmin_dena_casino_share' => $superadmin_dena_casino_share
  );
  $share_array['client_share_array'] = $client_share_array;
  $share_array['agent_share_array'] = $agent_share_array;
  $share_array['superagent_share_array'] = $superagent_share_array;
  $share_array['master_share_array'] = $master_share_array;
  $share_array['admin_share_array'] = $admin_share_array;
  $share_array['superadmin_share_array'] = $superadmin_share_array;
  $share_array = json_encode($share_array);
  $update_array = array(
    'share_array' => $share_array
  );

  $update = update_array('client', $update_array, "id='" . $client_data['id'] . "'");
  return $update;
}


function user_where($where = '', $is_superagent = '')
{
 
  $user_type = $_SESSION['user_type'];
  if ($is_superagent != '') {
    if ($_SESSION['user_type'] == 'superagent') {
      $user_type = 'sa';
    }
  } else {
    $user_type = $_SESSION['user_type'];
  }

  if (empty($where)) {
    $where = "1=1";
  }
  $where = "" . $user_type . "_id='" . $_SESSION['user_id'] . "' AND " . $where . "  ";

  return $where;
}

function priority_name($priority)
{
  if ($priority == '6') {
    $return = 'superadmin';
  }

  if ($priority == '5') {
    $return = 'admin';
  }

  if ($priority == '4') {
    $return = 'master';
  }

  if ($priority == '3') {
    $return = 'superagent';
  }

  if ($priority == '2') {
    $return = 'agent';
  }
  if ($priority == '1') {
    $return = 'client';
  }

  return $return;
}


function update_details($id, $post, $parent_result)
{
  $user_type = $post['user_type'];
  if ($user_type == 'admin') {
    $post['admin_id'] = $id;
    $post['user_id'] = $id;
    $post['superadmin_id'] = $parent_result['superadmin_id'];
    $post['superadmin_share'] = $parent_result['superadmin_share'];
    $post['superadmin_match_comm'] = $parent_result['superadmin_match_comm'];
    $post['superadmin_session_comm'] = $parent_result['superadmin_session_comm'];
    $post['superadmin_casino_comm'] = $parent_result['superadmin_casino_comm'];
    $post['superadmin_casino_share'] = $parent_result['superadmin_casino_share'];
    $post['superadmin_comm_type'] = $parent_result['superadmin_comm_type'];
    $post['admin_share'] = $post['user_share'];
    $post['admin_match_comm'] = $post['user_match_comm'];
    $post['admin_session_comm'] = $post['user_session_comm'];
    $post['admin_casino_comm'] = $post['user_casino_comm'];
    $post['admin_casino_share'] = $post['user_casino_share'];
    $post['admin_comm_type'] = $post['user_comm_type'];
  } elseif ($user_type == 'master') {
    $post['master_id'] = $id;
    $post['user_id'] = $id;
    $post['superadmin_id'] = $parent_result['superadmin_id'];
    $post['superadmin_share'] = $parent_result['superadmin_share'];
    $post['superadmin_match_comm'] = $parent_result['superadmin_match_comm'];
    $post['superadmin_session_comm'] = $parent_result['superadmin_session_comm'];
    $post['superadmin_casino_comm'] = $parent_result['superadmin_casino_comm'];
    $post['superadmin_casino_share'] = $parent_result['superadmin_casino_share'];
    $post['superadmin_comm_type'] = $parent_result['superadmin_comm_type'];
    $post['admin_id'] = $parent_result['admin_id'];
    $post['admin_share'] = $parent_result['admin_share'];
    $post['admin_match_comm'] = $parent_result['admin_match_comm'];
    $post['admin_comm_type'] = $parent_result['admin_comm_type'];
    $post['admin_session_comm'] = $parent_result['admin_session_comm'];
    $post['admin_casino_comm'] = $parent_result['admin_casino_comm'];
    $post['admin_casino_share'] = $parent_result['admin_casino_share'];
    $post['master_share'] = $post['user_share'];
    $post['master_match_comm'] = $post['user_match_comm'];
    $post['master_session_comm'] = $post['user_session_comm'];
    $post['master_casino_comm'] = $post['user_casino_comm'];
    $post['master_casino_share'] = $post['user_casino_share'];
    $post['master_comm_type'] = $post['user_comm_type'];
  } elseif ($user_type == 'superagent') {
    $post['sa_id'] = $id;
    $post['user_id'] = $id;
    $post['superadmin_id'] = $parent_result['superadmin_id'];
    $post['superadmin_share'] = $parent_result['superadmin_share'];
    $post['superadmin_match_comm'] = $parent_result['superadmin_match_comm'];
    $post['superadmin_session_comm'] = $parent_result['superadmin_session_comm'];
    $post['superadmin_casino_comm'] = $parent_result['superadmin_casino_comm'];
    $post['superadmin_casino_share'] = $parent_result['superadmin_casino_share'];
    $post['superadmin_comm_type'] = $parent_result['superadmin_comm_type'];
    $post['admin_id'] = $parent_result['admin_id'];
    $post['admin_share'] = $parent_result['admin_share'];
    $post['admin_match_comm'] = $parent_result['admin_match_comm'];
    $post['admin_session_comm'] = $parent_result['admin_session_comm'];
    $post['admin_casino_comm'] = $parent_result['admin_casino_comm'];
    $post['admin_casino_share'] = $parent_result['admin_casino_share'];
    $post['admin_comm_type'] = $parent_result['admin_comm_type'];
    $post['master_id'] = $parent_result['master_id'];
    $post['master_share'] = $parent_result['master_share'];
    $post['master_match_comm'] = $parent_result['master_match_comm'];
    $post['master_session_comm'] = $parent_result['master_session_comm'];
    $post['master_comm_type'] = $parent_result['master_comm_type'];
    $post['master_casino_comm'] = $parent_result['master_casino_comm'];
    $post['master_casino_share'] = $parent_result['master_casino_share'];
    $post['sa_share'] = $post['user_share'];
    $post['superagent_id'] = $id;
    $post['sa_match_comm'] = $post['user_match_comm'];
    $post['sa_session_comm'] = $post['user_session_comm'];
    $post['sa_casino_comm'] = $post['user_casino_comm'];
    $post['sa_casino_share'] = $post['user_casino_share'];
    $post['sa_comm_type'] = $post['user_comm_type'];
  } elseif ($user_type == 'agent') {
    $post['agent_id'] = $id;
    $post['user_id'] = $id;
    $post['superadmin_id'] = $parent_result['superadmin_id'];
    $post['superadmin_share'] = $parent_result['superadmin_share'];
    $post['superadmin_match_comm'] = $parent_result['superadmin_match_comm'];
    $post['superadmin_session_comm'] = $parent_result['superadmin_session_comm'];
    $post['superadmin_casino_comm'] = $parent_result['superadmin_casino_comm'];
    $post['superadmin_casino_share'] = $parent_result['superadmin_casino_share'];
    $post['superadmin_comm_type'] = $parent_result['superadmin_comm_type'];
    $post['admin_id'] = $parent_result['admin_id'];
    $post['admin_share'] = $parent_result['admin_share'];
    $post['admin_match_comm'] = $parent_result['admin_match_comm'];
    $post['admin_session_comm'] = $parent_result['admin_session_comm'];
    $post['admin_casino_comm'] = $parent_result['admin_casino_comm'];
    $post['admin_casino_share'] = $parent_result['admin_casino_share'];
    $post['admin_comm_type'] = $parent_result['admin_comm_type'];
    $post['master_id'] = $parent_result['master_id'];
    $post['master_share'] = $parent_result['master_share'];
    $post['master_match_comm'] = $parent_result['master_match_comm'];
    $post['master_session_comm'] = $parent_result['master_session_comm'];
    $post['master_casino_comm'] = $parent_result['master_casino_comm'];
    $post['master_casino_share'] = $parent_result['master_casino_share'];
    $post['master_comm_type'] = $parent_result['master_comm_type'];
    $post['superagent_id'] = $parent_result['sa_id'];
    $post['sa_id'] = $parent_result['sa_id'];
    $post['sa_share'] = $parent_result['sa_share'];
    $post['sa_match_comm'] = $parent_result['sa_match_comm'];
    $post['sa_session_comm'] = $parent_result['sa_session_comm'];
    $post['sa_casino_comm'] = $parent_result['sa_casino_comm'];
    $post['sa_casino_share'] = $parent_result['sa_casino_share'];
    $post['sa_comm_type'] = $parent_result['sa_comm_type'];
    $post['agent_share'] = $post['user_share'];
    $post['agent_match_comm'] = $post['user_match_comm'];
    $post['agent_session_comm'] = $post['user_session_comm'];
    $post['agent_casino_comm'] = $post['user_casino_comm'];
    $post['agent_casino_share'] = $post['user_casino_share'];
    $post['agent_comm_type'] = $post['user_comm_type'];
  } else if ($user_type == 'client') {

    /*        _d($parent_result);
        _dx($_POST);*/

    $post['superadmin_id'] = $parent_result['superadmin_id'];
    $post['superadmin_share'] = ($parent_result['superadmin_share'] - $parent_result['admin_share']);
    $post['superadmin_total_share'] = $parent_result['superadmin_share'];
    $post['superadmin_match_comm'] = $parent_result['superadmin_match_comm'];
    $post['superadmin_session_comm'] = $parent_result['superadmin_session_comm'];
    $post['superadmin_casino_comm'] = $parent_result['superadmin_casino_comm'];
    $post['superadmin_casino_share'] = $parent_result['superadmin_casino_share'];
    $post['superadmin_comm_type'] = $parent_result['superadmin_comm_type'];

    $post['admin_id'] = $parent_result['admin_id'];
    $post['admin_share'] = ($parent_result['admin_share'] - $parent_result['master_share']);
    if ($post['admin_share'] < 0) {
      $post['admin_share'] = 0;
    }
    $post['admin_share_total_value'] = $parent_result['admin_share'];
    $post['admin_match_comm'] = $parent_result['admin_match_comm'];
    $post['admin_session_comm'] = $parent_result['admin_session_comm'];
    $post['admin_comm_type'] = $parent_result['admin_comm_type'];
    /*$post['admin_casino_comm']=$parent_result['admin_casino_comm'];
      $post['admin_casino_share']=$parent_result['admin_casino_share'];*/
    $post['admin_comm_type'] = $parent_result['admin_comm_type'];

    $post['master_id'] = $parent_result['master_id'];
    $post['master_share'] = ($parent_result['master_share'] - $parent_result['sa_share']);
    if ($post['master_share'] < 0) {
      $post['master_share'] = 0;
    }
    $post['master_share_total_value'] = $parent_result['master_share'];
    $post['master_match_commission'] = $parent_result['master_match_comm'];
    $post['master_session_commission'] = $parent_result['master_session_comm'];
    /*$post['master_casino_comm']=$parent_result['master_casino_comm'];
      $post['master_casino_share']=$parent_result['master_casino_share'];*/
    $post['master_commission_type'] = $parent_result['master_comm_type'];
    $post['superagent_id'] = $parent_result['sa_id'];
    $post['sa_id'] = $parent_result['sa_id'];
    $post['sa_share'] = ($parent_result['sa_share'] - $post['MatchShare']);
    if ($post['sa_share'] < 0) {
      $post['sa_share'] = 0;
    }
    $post['sa_share_total_value'] = $parent_result['sa_share'];
    $post['sa_match_commission'] = $parent_result['sa_match_comm'];
    $post['sa_session_commission'] = $parent_result['sa_session_comm'];
    $post['sa_commission_type'] = $parent_result['sa_comm_type'];
    $post['A_id'] = $parent_result['agent_id'];
    $post['agent_id'] = $parent_result['agent_id'];
    $post['agent_share'] = $post['MatchShare'];
    if ($post['agent_share'] < 0) {
      $post['agent_share'] = 0;
    }
    $post['MatchShare2'] = $post['MatchShare'];
    $post['agent_share_total_value'] = $post['MatchShare'];
    $post['agent_match_commission'] = $parent_result['agent_match_comm'];
    $post['agent_commission_type'] = $parent_result['agent_comm_type'];
    $post['MatchCommission2'] = $parent_result['agent_match_comm'];
    $post['agent_session_commission'] = $parent_result['agent_session_comm'];
    $post['SessionCommission2'] = $parent_result['agent_session_comm'];
  } else {
    return false;
  }

  return $post;
}


function get_user_list($user_type, $user_id = '', $table_name = '', $status = '')
{
  global $con;
  $status = $status == '' ? $status : 1;
  $parent_user_type = $_SESSION['user_type'];
  $parent_user_id = $_SESSION['user_id'];

  if (!empty($user_type) and empty($user_id)) {
    $where = "user_type='" . $user_type . "'";
    if ($parent_user_type != 'superadmin') {
      $where = $where . " AND " . $parent_user_type . "_id = '" . $parent_user_id . "'";
    }
  } else if (!empty($user_id)) {
    $where = "user_id='" . $user_id . "'";
    if (!empty($table_name)) {

      $where = "id='" . $user_id . "'";
    }
  }
  if (empty($table_name)) {
    $query = "SELECT * FROM users_tbl WHERE " . $where . " order by user_id desc";
  } else {
    $query = "SELECT * FROM " . $table_name . " WHERE " . $where . " AND status=" . $status . "";
  }
  // _dx($query);
  $user_res = mysqli_query($con, $query);
  $send_array = array();
  if (empty($user_id)) {
    while ($data = mysqli_fetch_assoc($user_res)) {
      array_push($send_array, $data);
    }
  } else {
    $send_array = mysqli_fetch_assoc($user_res);
  }
  return $send_array;
}


function get_data($table_name, $where = '', $single = '', $specific = '')
{
  global $con;
  if (empty($where)) {
    $where = '1=1';
  }
  if ($specific != '') {
    $query = "SELECT " . $specific . " FROM " . $table_name . " WHERE " . $where . "";
  } else {

    $query = "SELECT * FROM " . $table_name . " WHERE " . $where . "";
  }
  /* _d($query);*/
  $user_res = mysqli_query($con, $query);
  $send_array = array();
  if (empty($single)) {
    // while ($data = mysqli_fetch_assoc($user_res)) {
    //   array_push($send_array, $data);
    // }
    $send_array = mysqli_fetch_all($user_res, MYSQLI_ASSOC);
  } else {  
    $send_array = mysqli_fetch_assoc($user_res);
  }
  return $send_array;
}

function inner_get_data($table_name1, $table_name2, $condition, $where = '', $single = '', $specific = '', $time = '')
{
  global $read_con;
  global $con;

  _d($table_name1);
  _d($table_name2);
  if (empty($where)) {
    $where = '1=1';
  }
  if ($specific != '') {
    $query = "SELECT " . $specific . " FROM " . $table_name1 . " INNER JOIN " . $table_name2 . " ON " . $condition . " WHERE " . $where . "";
  } else {
    $query = "SELECT * FROM " . $table_name1 . " INNER JOIN " . $table_name2 . " ON " . $condition . " WHERE " . $where . "";
  }
  $user_res = mysqli_query($read_con, $query);

  if (!isset($user_res->num_rows)) {
    _d($query);
    _d($user_res);
  }
  $send_array = array();
  if (empty($single)) {
    while ($data = mysqli_fetch_assoc($user_res)) {
      array_push($send_array, $data);
    }
  } else {
    $send_array = mysqli_fetch_assoc($user_res);
  }

  return $send_array;
}



function priority($role)
{
  if ($role == 'superadmin') {
    $return = 6;
  }

  if ($role == 'admin') {
    $return = 5;
  }

  if ($role == 'master') {
    $return = 4;
  }

  if ($role == 'superagent') {
    $return = 3;
  }

  if ($role == 'agent') {
    $return = 2;
  }
  if ($role == 'client') {
    $return = 1;
  }

  return $return;
}
function check_role($role)
{
  // _dx($_SESSION);
  $superadmin = 6;
  $admin = 5;
  $master = 4;
  $superagent = 3;
  $agent = 2;
  $client = 1;
  $session_priority = $_SESSION['user_priority'];
  $return = 0;

  if ($role == 'superadmin') {
    if ($session_priority >= $superadmin) {
      $return = 1;
    }
  }

  if ($role == 'admin') {
    if ($session_priority >= $admin) {
      $return = 1;
    }
  }

  if ($role == 'master') {

    if ($session_priority >= $master) {
      $return = 1;
    }
  }

  if ($role == 'superagent') {
    if ($session_priority >= $superagent) {
      $return = 1;
    }
  }

  if ($role == 'agent') {
    if ($session_priority >= $agent) {
      $return = 1;
    }
  }

  return $return;
}

function check_authority($user_id, $client = '')
{
  if (empty($client)) {
    $count_data = count_data('users_tbl', user_where("user_id='" . $user_id . "'"));
  } else {
    $count_data = count_data('client', user_where("id='" . $user_id . "'", 's'));
  }

  if ($count_data != 1) {
    invalid();
  }
}



function label_name($role)
{

  if ($role == 'owner') {
    $return = 'owner';
  }

  if ($role == 'superadmin') {
    $return = 'superadmin';
  }

  if ($role == 'admin') {
    $return = 'admin';
  }

  if ($role == 'master') {
    $return = 'master';
  }

  if ($role == 'superagent') {
    $return = 'superagent';
  }

  if ($role == 'sa') {
    $return = 'superagent';
  }

  if ($role == 'agent') {
    $return = 'agent';
  }

  return $return;
}

function get_code($role)
{
  global $con;
  if($role!='client')
  {
    $query = "SELECT MAX(user_id) FROM users_tbl";
    $ress = mysqli_query($con, $query);
    $id_data = mysqli_fetch_assoc($ress)['MAX(user_id)'];
  }
  else
  {
    $query = "SELECT MAX(id) FROM client";
    $ress = mysqli_query($con, $query);
    $id_data = mysqli_fetch_assoc($ress)['MAX(id)'];
  }
  $last_id = ($id_data + 1);
  $return = 0;
  $add=user_list_strat[$role];
  if ($role == 'superadmin') {
    $return = 'SU' . ($last_id + $add);
  }
  if ($role == 'admin') {
    $return = 'SUB' . ($last_id + $add);
  }

  if ($role == 'master') {
    $return = 'MA' . ($last_id + $add);
  }

  if ($role == 'superagent') {
    $return = 'SA' . ($last_id + $add);
  }

  if ($role == 'agent') {
    $return = 'A' . ($last_id + $add);
  }

  if ($role == 'client') {
 
    $last_id = ($id_data + 1 + $add);
    $return = 'C' . $last_id;
  }

  return $return;
}


function collection_code()
{
  global $con;
  $query = "SELECT MAX(collection_id) FROM collection";
  $ress = mysqli_query($con, $query);
  $id_data = mysqli_fetch_assoc($ress)['MAX(collection_id)'];
  $last_id = ($id_data + 1);
  return 'CA' . $last_id;
}


function invalid()
{
  header('location:404');
}

function column_names($table)
{
  global $con;
  $sql = 'DESCRIBE ' . $table;
  $result = mysqli_query($con, $sql);
  $rows = array();
  while ($row = mysqli_fetch_assoc($result)) {
    $name = $row['Field'];
    $rows['table']['' . $name . ''] = '';
  }
  return $rows;
}

function sanatize($array)
{
  global $con;
  $post_array = array();
  foreach ($array as $key => $value) {
    $post_array[$key] = trim(mysqli_real_escape_string($con, $value));
  }
  return $post_array;
}

function insert_array($table, $data, $exclude = array())
{
  global $con;
  $fields = $values = array();
  if (!is_array($exclude)) $exclude = array($exclude);
  foreach (array_keys($data) as $key) {
    if (!in_array($key, $exclude)) {
      $fields[] = "`$key`";
      $values[] = "'" . $data[$key] . "'";
    }
  }
  $fields = implode(",", $fields);
  $values = implode(",", $values);
  if (mysqli_query($con, "INSERT INTO `$table` ($fields) VALUES ($values)")) {
    return array(
      "error" => 0,
      "insert_id" => mysqli_insert_id($con),
      "affected_rows" => mysqli_affected_rows($con),
      "info" => mysqli_info($con)
    );
  } else {
    return array("error" => mysqli_error($con));
  }
}




function update_array($table, $data, $where)
{
  global $con;
  $final = $fields = $values = array();
  if (!empty($table) and !empty($data) and !empty($where)) {
    foreach ($data as $key => $value) {
      $fields[] = "`$key`= '" . $value . "'";
    }
    $final = implode(",", $fields);
    $query = "UPDATE `$table` SET " . $final . " WHERE " . $where . "";
    //_d($query);
    if (mysqli_query($con, $query)) {
      return array(
        "error" => 0,
        "insert_id" => mysqli_insert_id($con),
        "affected_rows" => mysqli_affected_rows($con),
        "info" => mysqli_info($con)
      );
    } else {
      return array("error" => mysqli_error($con));
    }
  }
}

function check_id($id)
{
  global $con;

  $self_id = $_SESSION['user_id'];
  $query = "SELECT user_id FROM users_tbl WHERE " . $_SESSION['user_type'] . "_id='" . $_SESSION['user_id'] . "' AND user_id='" . $id . "'";
  $res = mysqli_query($con, $query);
  $data = mysqli_num_rows($res);
  if ($data == '1') {
    return true;
  } else {
    invalid();
  }
}

function check_client_id($id)
{
  global $con;
  $self_id = $_SESSION['user_id'];
  $query = "SELECT id FROM client WHERE " . $_SESSION['user_type'] . "_id='" . $_SESSION['user_id'] . "' AND id='" . $id . "'";
  $res = mysqli_query($con, $query);
  $data = mysqli_num_rows($res);
  if ($data == '1') {
    return true;
  } else {
    invalid();
  }
}

function pagination($table_name, $where = '', $page_no = '')
{
  if (empty($page_no)) {
    $page_no = 1;
  }
  $where = $where != '' ? $where : "1=1";
  $no_of_records_per_page = 10;
  $offset = ($page_no - 1) * $no_of_records_per_page;
  $where = "" . $where . " AND 1=1 LIMIT $offset, $no_of_records_per_page";
  $data = get_data($table_name, $where);
  $total_count = count($data);
  $total_pages = ceil($total_count / $no_of_records_per_page);

  return $send_array = array(
    'data' => $data,
    'total_pages' => $total_pages
  );
}


function count_data($table_name, $where = '')
{
  global $con;
  if (empty($where)) {
    $where = '1=1';
  }
  $query = "SELECT * FROM " . $table_name . " WHERE " . $where . "";
  $user_res = mysqli_query($con, $query);
  return mysqli_num_rows($user_res);
}



function cricket_pagination($table_name, $where = '', $page_no = '',$specific='')
{
  if (empty($page_no)) {
    $page_no = 1;
  }
  $where = $where != '' ? $where : "1=1";
  $no_of_records_per_page = 15;
  $count = count_data($table_name, $where);
  $offset = ($page_no - 1) * $no_of_records_per_page;
  $where = "" . $where . " AND 1=1 order by id desc LIMIT $offset, $no_of_records_per_page";
  $data = get_data($table_name, $where,'',$specific);
  $total_count = $count;
  $total_pages = ceil($total_count / $no_of_records_per_page);
  return $send_array = array(
    'data' => $data,
    'total_pages' => $total_pages
  );
}

function get_data_pagination($table_name, $where = '', $page_no = '', $order_by = '',$specific='')
{
  if (empty($page_no)) {
    $page_no = 1;
  }
  $where = $where != '' ? $where : "1=1";
  $no_of_records_per_page = 20;
  $count = count_data($table_name, $where);
  $offset = ($page_no - 1) * $no_of_records_per_page;
  $where = "" . $where . " AND 1=1 " . $order_by . " LIMIT $offset, $no_of_records_per_page";
  $data = get_data($table_name, $where,'',$specific);
  $total_count = $count;
  $total_pages = ceil($total_count / $no_of_records_per_page);
  return $send_array = array(
    'data' => $data,
    'total_pages' => $total_pages
  );
}

function get_location()
{
  global $con;
  $url = "http://ip-api.com/json";
  $data = api_data_curl_no_header($url, true);
  return json_decode($data);
}

function send_sms($sms,$mobile)
{

  $authKey="13e050bf582cbdd05af4ec7247bd1bf9";
  $senderId="DEMOOS";
  $serverUrl="sms.mysmpp.com";
  $routeId=14;
  $getData = 'mobileNos='.$mobile.'&message='.urlencode($sms).'&senderId='.$senderId.'&routeId='.$routeId;
  $url="http://msg.msgclub.net/rest/services/sendSMS/sendGroupSms?AUTH_KEY=".$authKey."&".$getData;
  _dx($url);
  $ch = curl_init();
    curl_setopt_array($ch, array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_SSL_VERIFYPEER => 0
    ));

    $output = curl_exec($ch);
    if(curl_errno($ch))
    {
        echo 'error:' .curl_error($ch);
    }
    curl_close($ch);
     //
    return $output;
}

function update_login_details($user_id, $msg = '', $is_client = '')
{
  if (!empty($client)) {
    $data = get_data('client', "id='" . $user_id . "'", 's');
    $send_url = client_url;
    $username = $data['CLientCode'];
    $usertype = 'Client';
    $password = $data['password'];
    $mobile = $data['mobile'];
  } else {
    $data = get_data('users_tbl', "user_id='" . $user_id . "'", 's', 'username,user_type,password,mobile');
    $username = $data['username'];
    $usertype = $data['user_type'];
    $password = $data['password'];
    $mobile = $data['mobile'];
    $send_url = admin_url;
  }
  if (empty($msg)) {

    $sms = $msg = "Dear " . $usertype . " Your username is " . $username . " and password is " . $password . " AND login domain is " . $send_url;
  }
  $return=send_sms($sms,$mobile);
  return $return;
}



function get_share_array($client_data)
{
  $client_share_array = json_decode($client_data, true);
  return $share_array = json_decode($client_share_array['share_array'], true);
}

function down_user_type($usertype)
{
  return priority_name((priority($usertype) - 1));
}


function user_share_edit($new_user_share, $user_details, $parent_details, $new_casino_share = '')
{
  global $con;
  $parent_result = $parent_details;
  $show_user_type = $user_details['user_type'] == 'superagent' ? 'sa' : $user_details['user_type'];
  $show_parent_type = $parent_details['user_type'] == 'superagent' ? 'sa' : $parent_details['user_type'];
  // in case of dream999 get downline max distribute share 
  $down_user_type = down_user_type($user_details['user_type']);
  $down_user_type = $down_user_type == 'superagent' ? 'sa' : $down_user_type;
  $query = "SELECT MAX(" . $down_user_type . "_share) max_share FROM users_tbl WHERE " . $show_user_type . "_id='" . $user_details['user_id'] . "' AND user_type!='" . $user_details['user_type'] . "'";
  $max_distributrd_share = mysqli_query($con, $query);
  $max_distributrd_share = mysqli_fetch_assoc($max_distributrd_share)['max_share'];
  if ($max_distributrd_share > $new_user_share) {
    $send_array = array(
      'status' => false,
      'msg' => $user_details['user_type'] . ' downline share can not be greather than your new share'

    );

    return $send_array;
    die();
    exit();
  }

  $downline_client_data = $client_data = get_data('client', "" . $show_user_type . "_id='" . $user_details['user_id'] . "'");
  $downline_user_data = get_data('users_tbl', "" . $show_user_type . "_id='" . $user_details['user_id'] . "'");
  foreach ($downline_user_data as $key => $user_value) {
    $update_array = array(
      $show_user_type . '_share' => $new_user_share
    );
    if ($new_user_share <= $parent_result['user_share']) {
      $update = update_array('users_tbl', $update_array, "user_id='" . $user_value['user_id'] . "'");
    }
  }


  foreach ($downline_client_data as $key => $client_value) {
    $update_share = $parent_result['user_share'] - $new_user_share;

    if ($user_details['user_type'] == 'agent') {
      $sa_share = $parent_result['sa_share'] - $new_user_share;
      $sa_share = $sa_share < 0 ? 0 : $sa_share;
      $update_array = array(
        'agent_share_total_value' => $new_user_share,
        'sa_share_total_value' => $parent_result['sa_share'],
        'agent_share' => $new_user_share,
        'MatchShare' => $new_user_share,
        'MatchShare2' => $new_user_share,
        'sa_share' => $sa_share

      );
    }

    if ($user_details['user_type'] == 'superagent') {
      $master_share = $parent_result['master_share'] - $new_user_share;
      $master_share = $master_share < 0 ? 0 : $master_share;

      $update_array = array(
        'sa_share_total_value' => $new_user_share,
        'master_share_total_value' => $parent_result['master_share'],
        'sa_share' => $new_user_share - $client_value['agent_share_total_value'],
        'master_share' => $master_share
      );
    }

    if ($user_details['user_type'] == 'master') {
      $admin_share = $parent_result['admin_share'] - $new_user_share;
      $admin_share = $admin_share < 0 ? 0 : $admin_share;
      $update_array = array(
        'master_share_total_value' => $new_user_share,
        'admin_share_total_value' => $parent_result['admin_share'],
        'master_share' => $new_user_share - $client_value['sa_share_total_value'],
        'admin_share' => $admin_share
      );
    }

    if ($user_details['user_type'] == 'admin') {
      $superadmin_share = $parent_result['superadmin_share'] - $new_user_share;
      $superadmin_share = $superadmin_share < 0 ? 0 : $superadmin_share;
      $update_array = array(
        'admin_share_total_value' => $new_user_share,
        'superadmin_share_total_value' => $parent_result['superadmin_share'],
        'admin_share' => $new_user_share - $client_value['master_share_total_value'],
        'superadmin_share' => $superadmin_share
      );
    }
    if ($new_user_share <= $parent_result['user_share']) {
      $update = update_array('client', $update_array, "id='" . $client_value['id'] . "'");
      $share_update = client_share_array_update($client_value['id']);
    }
  }

  $user_update_array = array(
    'user_share' => $new_user_share,
    $show_user_type . '_share' => $new_user_share
  );
  $data = update_array('users_tbl', $user_update_array, 'user_id=' . $user_details['user_id']);

  $task_array = array(
    'user_id' => $user_details['user_id'],
    'user_type' => $user_details['user_type'],
    'user_share' => $new_user_share,
    'task_name' => $user_details['user_type'] . '(' . $user_details['username'] . ') updated match share by ' . $parent_result['user_type'] . ' to new share ' . $new_user_share,
    'note' => $user_details['user_type'] . '(' . $user_details['username'] . ') updated match share by ' . $parent_result['user_type'] . ' to new share ' . $new_user_share,
    'creater_id' => $_SESSION['user_id'],
    'creater_type' => $_SESSION['user_type'],
    'creater_name' => $_SESSION['name'],
    'ip' => ip(),
    'date' => _date(),
    'date_time' => _date_time(),
    'user_name' => $user_details['name'] . ' (' . $user_details['username'] . ')'

  );
  $result = insert_array('user_history_log', $task_array, '');
  $send_array = array(
    'status' => true,
    'msg' => $result
  );

  return $send_array;
  die();
  exit();
}

function get_page_name()
{
  $page_name = $_SERVER['SCRIPT_NAME'];
  $var = explode('.', $page_name);
  $var = $var[0];
  $var2 = explode('/', $var);
  $page_name = $var2[2];
  $send_array = array(
    'page_name' => $page_name,
  );
  $explode = explode('&', $_SERVER['QUERY_STRING']);
  foreach ($explode as $key => $explode_value) {
    $value_explode = explode('=', $explode_value);
    if (isset($value_explode[1])) {
      $send_array[$value_explode[0]] = $value_explode[1];
    }
  }
  return $send_array;
}


function active_inctive($page_data_array = '', $key, $value, $is_menu_open = '')
{
  $return = '';
  if (empty($page_data_array)) {
    $page_data_array = get_page_name();
  }
  if (array_key_exists($key, $page_data_array)) {

    if ($page_data_array[$key] == $value) {
      $return = 'active';
      if (!empty($is_menu_open)) {
        $return = 'menu-open';
      }
    }
  }
  return $return;
}



function status_button($status)
{
  $show_status = $status == 1 ? 'active' : 'inactive';



  return   $return = '<div>
             <span class="float-center badge  bg-' . $show_status . '">
             ' . $show_status . '
            </span>
            </div>';
}



function client_status($client_id, $status)
{
  $update_array = array(
    'status' => $status,
  );

  if ($status == 0) {/*
       $client_coins=used_limit($client_id);
       $client_total_coins=$client_coins['total_coins'];
       $update_status=update_client_coins($client_id,$client_total_coins,'withdraw');
        if($client_total_coins>0)
        {
          $update_array['last_limit']=$client_total_coins;
        }
      */
  }

  if ($status == 1) {/*
       $client_total_coins=get_data('client',"id='".$client_id."'",'s',"last_limit")['last_limit'];
       $update_status=update_client_coins($client_id,$client_total_coins,'deposit');
      */
  }

  return $update = update_array('client', $update_array, "id='" . $client_id . "'");
}


function user_status($user_id, $status)
{
  $user_data = get_data('users_tbl', "user_id='" . $user_id . "'", 's');
  $user_type = $user_data['user_type'];
  $last_amount = $user_data['total_coins'];
  $last_limit = $user_data['last_limit'];

  if ($status == 1) {/*
      $update_coins=update_user_coins($user_data['creater_id'],$user_id,$last_limit,'deposit');
    */
  }

  $client_data = get_data('client', user_where($user_type . "_id='" . $user_id . "'", 's'), '', 'id');
  foreach ($client_data as $key => $client_id) {
    client_status($client_id['id'], $status);
  }

  $update_array = array(
    'status' => $status
  );


  if ($status == 0) {/*
      $amount=call_total_coins($user_data['user_type'],$user_data['user_id']);
      $update_coins=update_user_coins($user_data['creater_id'],$user_id,$amount,'withdraw');
      if($amount>0)
      {
        $update_array['last_limit']=$amount;
      }*/
  }


  $update_downline = update_array('users_tbl', $update_array, $user_type . "_id='" . $user_id . "'");

  if ($status == 1) {/*  
      $amount=call_total_coins($user_data['user_type'],$user_data['user_id']);
      $update_array['total_coins']=$amount;
    */
  }

  return $update = update_array('users_tbl', $update_array, "user_id='" . $user_id . "'");
}




function downline_data($report_type = '')
{
  if ($report_type != 'client') {
    if (empty($report_type)) {
      $user_data = get_data('users_tbl', user_where(), '', 'user_id,username,name,mobile');
    } else {
      $user_data = get_data('users_tbl', user_where("user_type='" . $report_type . "'"), '', 'user_id,username,name,mobile');
    }
  } else {
    $user_data = get_data('client', user_where('', 's'), '', 'ClientCode as username , ClientName as name , ContactNo as mobile , id as user_id');
  }

  return $user_data;
}


function subdomain()
{
      $url =$_SERVER['HTTP_HOST'];
      $parsedUrl = parse_url($url);
      $path=$parsedUrl['path'];
      $host='';
      if($path!='127.0.0.1')
      {
         $host = explode('.', $path);
      }

      if(!empty($host))
      {
       $subdomain = $host[0];
      }
      else
      {
        $subdomain='';
      }
    return  $subdomain;
}

function domain()
{
      $url =$_SERVER['HTTP_HOST'];
      $parsedUrl = parse_url($url);
      $path=$parsedUrl['path'];
      $host='';
      if($path!='127.0.0.1')
      {
         $host = explode('.', $path);
      }

      if(!empty($host))
      {
       $domain = $host[1];
      }
      else
      {
        $domain='';
      }
    return  $domain;
}


function login_detail()
{
  global $con;
  $insert_array = array(
    'user_id' => $_SESSION['user_id'],
    'date' => _date(),
    'date_time' => _date_time(),
    'name' => $_SESSION['name'],
    'user_code' => $_SESSION['username'],
    'ip_address' => ip()
  );
  return $insert = insert_array('user_login_details', $insert_array);
}


function user_position($data)
{
  global $con;
  extract($data);
  $all_selection_id = $data['all_selection_id'];
  $fav_selection_id = $all_selection_id['team1_selection_id'];
  $non_fav_selection_id = $all_selection_id['team2_selection_id'];
  $draw_selection_id=3;
  if(isset($all_selection_id['team3_selection_id']))
  {
    $draw_selection_id = $all_selection_id['team3_selection_id'];
  }
  $user_type=$_SESSION['user_type'] == 'superagent'?'sa':$_SESSION['user_type'];
/*
  _d($data);
   $query = "SELECT selection_id, SUM(" . $user_type . "_amount) total_profit FROM match_bet_calculation WHERE  market_id = '" . $market_id . "' AND " . $user_type . "_id='" . $user_id . "'  group by selection_id";
   _d($query);
*/
  $query = "SELECT a.random_id, b.random_id, b.selection_id, SUM(b." . $user_type . "_amount) total_profit FROM match_bet_calculation b, client_match_bet_tbl a WHERE a.market_id = '" . $market_id . "' AND a." . $user_type . "_id='" . $user_id . "' AND a.random_id = b.random_id and a.deleted_status = 0 group by selection_id";
  $data = mysqli_query($con, $query);


  // /_dx($data);


  $fav_pos = 0;
  $non_fav_pos = 0;
  $draw_pos = 0;
  
  while ($res = mysqli_fetch_assoc($data)) 
  {
    if ($res['selection_id'] == $fav_selection_id) 
    {
      $fav_pos = round($res['total_profit'], 2);
    }
    else if($res['selection_id'] == '60443' OR $res['selection_id'] ==$draw_selection_id) 
    {
      $draw_pos = round($res['total_profit'], 2);
      $draw_selection_id = $res['selection_id'];
    } 
    else 
    {
      $non_fav_pos = round($res['total_profit'], 2);
    }
  }



  if ($count == 2) {
    $team_data = array(
      'team1_selection_id' => $fav_selection_id,
      'team1_position' => (-1 * $fav_pos),
      'team2_selection_id' => $non_fav_selection_id,
      'team2_position' => (-1 * $non_fav_pos)

    );
  }

  if ($count == 3) {

    $team_data = array(
      'team1_selection_id' => $fav_selection_id,
      'team1_position' => (-1 * $fav_pos),
      'team2_selection_id' => $non_fav_selection_id,
      'team2_position' => (-1 * $non_fav_pos),
      'team3_selection_id' => $draw_selection_id,
      'team3_position' => (-1 * $draw_pos)
    );
  }

  //_dx($team_data);

  return $team_data;
}

function convert_key_array($array_data,$array_key)
    {   
        $send_array=[];
        $key_array=[];

        foreach ($array_data as $key => $value) 
        {
            if(!array_key_exists($value[$array_key], $send_array))
            {
                $send_array[$value[$array_key]]=$value; 
                array_push($key_array,$value[$array_key]);
            }
        }
        $key_data=implode(',',$key_array);
        $return['array_data']=$send_array;
        $return['key_array']=$key_data;
        return $return;
    }





function market_id_client_data($market_id)
{ 
  global $con;
  $client_played_match = get_data('client_played_match', user_where('market_id=' . $market_id.'', 's'), '', 'client_id');
  $client_data = [];
  $client_data_array = get_data('client', user_where('', 's'), '', 'id,ClientCode,ClientName');

  foreach ($client_played_match as $key => $value) {
    foreach ($client_data_array as $key => $client_value) {
      if ($value['client_id'] == $client_value['id']) {
        array_push($client_data, $client_value);
      }
    }
  }
  return $client_data;
}


function user_exist($user_id,$is_client='')
{  
   $count=0;
   if($is_client=='')
   {
    
      $count=count_data('users_tbl',user_where("user_id='".$user_id."'",'s'));
   }
   else
   {

      $count=count_data('client',user_where("id='".$user_id."'",'s'));
   }

   return $count;
}


function match_position_data($team_data,$bet_data)
{   
    if($bet_data['type']=='L')
    {
      $profit=$bet_data['amount']*$bet_data['bhav'];
      $loss=-$bet_data['amount'];
    }
    elseif($bet_data['type']=='K')
    {
      $profit=$bet_data['amount'];
      $profit=-1*$bet_data['amount']*$bet_data['bhav'];
    }
    else
    {
      $profit=0;
      $loss=0;
    }
    $team_data[$bet_data['selection_id']]['amount']=$profit;
    if(!isset($team_data[$bet_data['selection_id']]))
    {
       $team_data[$bet_data['selection_id']]['amount']=$loss;
    }
   
   _d($team_data);
   $send_array=[];


   _dx($bet_data);


}

