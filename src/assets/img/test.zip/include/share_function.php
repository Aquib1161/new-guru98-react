<?php  
function agent_share_change($user_id,$new_share)
{  
	global  $userdata;
    $user_data=get_data('users_tbl',"user_id='".$user_id."'",'s');
    $user_update_array=array(

    	'agent_share'=>$new_share,
    	'user_share'=>$new_share,
    	'user_casino_share'=>$new_share,
    	'agent_casino_share'=>$new_share,
    );
    update_array('users_tbl',$user_update_array,"user_id='".$user_id."'");
    $client_data=get_data('client',"A_id='".$user_id."'");
    foreach ($client_data as $key => $client) 
    {

    	$client_update_array=array(
    		'MatchShare'=>$new_share,
    		'MatchShare2'=>$new_share,
    		'sa_share'=>$user_data['sa_share']-$new_share,
    		'agent_share'=>$new_share,
    		'agent_share_total_value'=>$new_share,
    		'sa_share_total_value'=>$user_data['sa_share'],
    	);
    	$update=update_array('client',$client_update_array,"id='".$client['id']."'");
    	client_share_array_update($client['id']);
    }
    $data_array=array(
                    'client'=>'('.$user_data['name'].') '.$user_data['username'].'',
                    'old'=>$user_data['user_share'],
                    'new'=>$new_share,
                    'user'=>$userdata['username'],
                    'note'=>'Agent ('.$user_data['username'].') '.$user_data['name'].' share change from '.$user_data['user_share'].' To '.$new_share,
                    'type'=>'shares'
                );

                $task_array=array(
                	'user_id'=>$user_id,
                	'user_type'=>$user_data['user_type'],
                    'task_name'=>'Agent ('.$user_data['username'].') '.$user_data['name'].' share change from '.$user_data['user_share'].' To '.$new_share,
                    'user_type'=>'Agent',
                    'creater_id'=>$_SESSION['user_id'],
                    'creater_type'=>$_SESSION['user_type'],
                    'creater_name'=>$_SESSION['name'],
                    'ip'=>ip(),
                    'date'=>_date(),
                    'date_time'=>_date_time(),
                    'user_name'=>$user_data['name'],
                    'history_type'=>'match_share',
                    'data_array'=>json_encode($data_array),
                    'agent_id'=>$user_data['agent_id'],
                    'sa_id'=>$user_data['sa_id'],
                    'master_id'=>$user_data['master_id'],
                    'admin_id'=>$user_data['admin_id'],
                    'superadmin_id'=>$user_data['superadmin_id'],
                );
                $result=insert_array('user_history_log',$task_array);

                return true;
}



function sa_share_change($user_id,$new_share)
{  
	global  $userdata;
	$return=1;
	$min_distribute_share=get_data('users_tbl',"sa_id='".$user_id."'AND user_type='agent'","s","max(agent_share) max_share")['max_share'];
	if($min_distribute_share>$new_share)
	{
		$return=0;
	}
     
	if($return==1)
	{
    $user_data=get_data('users_tbl',"user_id='".$user_id."'",'s');
    $user_update_array=array(
    	'sa_share'=>$new_share,
    	'user_share'=>$new_share,
    	'user_casino_share'=>$new_share,
    	'sa_casino_share'=>$new_share,
    );
   $update= update_array('users_tbl',$user_update_array,"user_id='".$user_id."'");
    $agent_list=get_data('users_tbl',"sa_id='".$user_id."'");

    foreach ($agent_list as $key => $agent) 
    {
    	$agent_update_array=array(
    		'sa_share'=>$new_share,
    		'sa_casino_share'=>$new_share,
    	);
    	$update=update_array('users_tbl',$agent_update_array,"user_id='".$agent['user_id']."'");
    }

    $client_data=get_data('client',"sa_id='".$user_id."'");

    foreach ($client_data as $key => $client) 
    {

    	$client_update_array=array(
    		'sa_share'=>$new_share-$client['agent_share_total_value'],
    		'master_share'=>$user_data['master_share']-$new_share,
    		'master_share_total_value'=>$user_data['master_share'],
    		'sa_share_total_value'=>$new_share,
    	);
    	$update=update_array('client',$client_update_array,"id='".$client['id']."'");
    	client_share_array_update($client['id']);
    }
    $data_array=array(
                    'client'=>'('.$user_data['name'].') '.$user_data['username'].'',
                    'old'=>$user_data['user_share'],
                    'new'=>$new_share,
                    'user'=>$userdata['username'],
                    'note'=>'SuperAgent ('.$user_data['username'].') '.$user_data['name'].' share change from '.$user_data['user_share'].' To '.$new_share,
                    'type'=>'shares'
                );

                $task_array=array(
                	'user_id'=>$user_id,
                	'user_type'=>$user_data['user_type'],
                    'task_name'=>'SuperAgent ('.$user_data['username'].') '.$user_data['name'].' share change from '.$user_data['user_share'].' To '.$new_share,
                    'user_type'=>'superagent',
                    'creater_id'=>$_SESSION['user_id'],
                    'creater_type'=>$_SESSION['user_type'],
                    'creater_name'=>$_SESSION['name'],
                    'ip'=>ip(),
                    'date'=>_date(),
                    'date_time'=>_date_time(),
                    'user_name'=>$user_data['name'],
                    'history_type'=>'match_share',
                    'data_array'=>json_encode($data_array),
                    'agent_id'=>$user_data['agent_id'],
                    'sa_id'=>$user_data['sa_id'],
                    'master_id'=>$user_data['master_id'],
                    'admin_id'=>$user_data['admin_id'],
                    'superadmin_id'=>$user_data['superadmin_id'],
                );
                $result=insert_array('user_history_log',$task_array);
            }
            else
            {    
            	$_SESSION['notify']=['type'=>'error','msg'=>'Share can not be less than '.$min_distribute_share.' Because your Maximum agent share is '.$min_distribute_share];
            	return false;
            }
}


function master_share_change($user_id,$new_share)
{  
	global  $userdata;
	$return=1;
	$min_distribute_share=get_data('users_tbl',"master_id='".$user_id."'AND user_type='superagent'","s","max(sa_share) max_share")['max_share'];
	if($min_distribute_share>$new_share)
	{
		$return=0;
	}

	if($return==1)
	{
    $user_data=get_data('users_tbl',"user_id='".$user_id."'",'s');
    $user_update_array=array(
    	'master_share'=>$new_share,
    	'user_share'=>$new_share,
    	'user_casino_share'=>$new_share,
    	'master_casino_share'=>$new_share,
    );
    $update= update_array('users_tbl',$user_update_array,"user_id='".$user_id."'");
    $user_list=get_data('users_tbl',"master_id='".$user_id."'");
    foreach ($user_list as $key => $user) 
    {
    	$user_update_array=array(
    		'master_share'=>$new_share,
    		'master_casino_share'=>$new_share,
    	);
    	$update=update_array('users_tbl',$user_update_array,"user_id='".$user['user_id']."'");
    }

    $client_data=get_data('client',"master_id='".$user_id."'");
    foreach ($client_data as $key => $client) 
    {

    	$client_update_array=array(
    		'master_share'=>$new_share-$client['sa_share_total_value'],
    		'master_share_total_value'=>$new_share,
    		'admin_share'=>$user_data['admin_share']-$new_share,
    		'admin_share_total_value'=>$user_data['admin_share'],
    	);
 
    	$update=update_array('client',$client_update_array,"id='".$client['id']."'");
    	client_share_array_update($client['id']);
    }
    $data_array=array(
                    'client'=>'('.$user_data['name'].') '.$user_data['username'].'',
                    'old'=>$user_data['user_share'],
                    'new'=>$new_share,
                    'user'=>$userdata['username'],
                    'note'=>'Master ('.$user_data['username'].') '.$user_data['name'].' share change from '.$user_data['user_share'].' To '.$new_share,
                    'type'=>'shares'
                );

                $task_array=array(
                	'user_id'=>$user_id,
                	'user_type'=>$user_data['user_type'],
                    'task_name'=>'master ('.$user_data['username'].') '.$user_data['name'].' share change from '.$user_data['user_share'].' To '.$new_share,
                    'user_type'=>'master',
                    'creater_id'=>$_SESSION['user_id'],
                    'creater_type'=>$_SESSION['user_type'],
                    'creater_name'=>$_SESSION['name'],
                    'ip'=>ip(),
                    'date'=>_date(),
                    'date_time'=>_date_time(),
                    'user_name'=>$user_data['name'],
                    'history_type'=>'match_share',
                    'data_array'=>json_encode($data_array),
                    'agent_id'=>$user_data['agent_id'],
                    'sa_id'=>$user_data['sa_id'],
                    'master_id'=>$user_data['master_id'],
                    'admin_id'=>$user_data['admin_id'],
                    'superadmin_id'=>$user_data['superadmin_id'],
                );
                $result=insert_array('user_history_log',$task_array);
            }
            else
            {    
            	$_SESSION['notify']=['type'=>'error','msg'=>'Share can not be less than '.$min_distribute_share.' Because your minimum agent share is '.$min_distribute_share];
            	return false;
            }
}

function admin_share_change($user_id,$new_share)
{

	global  $userdata;
	$return=1;
	$min_distribute_share=get_data('users_tbl',"admin_id='".$user_id."'AND user_type='master'","s","max(master_share) max_share")['max_share'];
	if($min_distribute_share>$new_share)
	{
		$return=0;
	}

	if($return==1)
	{
    $user_data=get_data('users_tbl',"user_id='".$user_id."'",'s');
    $user_update_array=array(
    	'admin_share'=>$new_share,
    	'user_share'=>$new_share,
    	'user_casino_share'=>$new_share,
    	'admin_casino_share'=>$new_share,
    );
    $update= update_array('users_tbl',$user_update_array,"user_id='".$user_id."'");
    $user_list=get_data('users_tbl',"admin_id='".$user_id."'");
    foreach ($user_list as $key => $user) 
    {
    	$user_update_array=array(
    		'admin_share'=>$new_share,
    		'admin_casino_share'=>$new_share,
    	);
    	$update=update_array('users_tbl',$user_update_array,"user_id='".$user['user_id']."'");
    }

    $client_data=get_data('client',"admin_id='".$user_id."'");
    foreach ($client_data as $key => $client) 
    {

    	$client_update_array=array(
    		'admin_share'=>$new_share-$client['master_share_total_value'],
    		'admin_share_total_value'=>$new_share,
    		'superadmin_share'=>$user_data['superadmin_share']-$new_share,
    		'superadmin_share_total_value'=>$user_data['superadmin_share'],
    	);
 
    	$update=update_array('client',$client_update_array,"id='".$client['id']."'");

    	client_share_array_update($client['id']);
    }
    $data_array=array(
                    'client'=>'('.$user_data['name'].') '.$user_data['username'].'',
                    'old'=>$user_data['user_share'],
                    'new'=>$new_share,
                    'user'=>$userdata['username'],
                    'note'=>'Admin ('.$user_data['username'].') '.$user_data['name'].' share change from '.$user_data['user_share'].' To '.$new_share,
                    'type'=>'shares'
                );

                $task_array=array(
                	'user_id'=>$user_id,
                	'user_type'=>$user_data['user_type'],
                    'task_name'=>'Admin ('.$user_data['username'].') '.$user_data['name'].' share change from '.$user_data['user_share'].' To '.$new_share,
                    'user_type'=>'admin',
                    'creater_id'=>$_SESSION['user_id'],
                    'creater_type'=>$_SESSION['user_type'],
                    'creater_name'=>$_SESSION['name'],
                    'ip'=>ip(),
                    'date'=>_date(),
                    'date_time'=>_date_time(),
                    'user_name'=>$user_data['name'],
                    'history_type'=>'match_share',
                    'data_array'=>json_encode($data_array),
                    'agent_id'=>$user_data['agent_id'],
                    'sa_id'=>$user_data['sa_id'],
                    'master_id'=>$user_data['master_id'],
                    'admin_id'=>$user_data['admin_id'],
                    'superadmin_id'=>$user_data['superadmin_id'],
                );
                $result=insert_array('user_history_log',$task_array);
            }
            else
            {    
            	$_SESSION['notify']=['type'=>'error','msg'=>'Share can not be less than '.$min_distribute_share.' Because your minimum agent share is '.$min_distribute_share];
            	return false;
            }

}





function change_share($user_type,$user_id,$new_share)
{  
	if($user_type=='agent')
	{
		$return=agent_share_change($user_id,$new_share);
	}
	elseif($user_type=='superagent')
	{
		$return=sa_share_change($user_id,$new_share);
	}
	elseif($user_type=='master')
	{
		$return=master_share_change($user_id,$new_share);
	}
	elseif($user_type=='admin')
	{
		$return=admin_share_change($user_id,$new_share);
	}
	else
	{
		$return=false;
	}

	return $return;
}


function change_agent_commission($user_type,$user_id,$new_commission,$commision_for)
{
    global  $userdata;
    $new_share=$new_commission;


    $user_data=get_data('users_tbl',"user_id='".$user_id."'",'s');
    if($commision_for=='match_commission')
    {
            $user_update_array=array(
            'agent_match_comm'=>$new_commission,
            'user_match_comm'=>$new_commission
          );

            $client_update_array=array(
            'agent_match_commission'=>$new_commission,
          );

            $data_array=array(
                    'client'=>'('.$user_data['name'].') '.$user_data['username'].'',
                    'old'=>$user_data['user_match_comm'],
                    'new'=>$new_share,
                    'user'=>$userdata['username'],
                    'note'=>'Agent ('.$user_data['username'].') '.$user_data['name'].' Match Commission change from '.$user_data['user_match_comm'].' To '.$new_share,
                    'type'=>'match_commission'
                );

                $task_array=array(
                    'user_id'=>$user_id,
                    'user_type'=>$user_data['user_type'],
                    'task_name'=>'Agent ('.$user_data['username'].') '.$user_data['name'].' Match Commission change from '.$user_data['user_match_comm'].' To '.$new_share,
                    'user_type'=>'agent',
                    'creater_id'=>$_SESSION['user_id'],
                    'creater_type'=>$_SESSION['user_type'],
                    'creater_name'=>$_SESSION['name'],
                    'ip'=>ip(),
                    'date'=>_date(),
                    'date_time'=>_date_time(),
                    'user_name'=>$user_data['name'],
                    'history_type'=>'match_commission',
                    'data_array'=>json_encode($data_array),
                    'agent_id'=>$user_data['agent_id'],
                    'sa_id'=>$user_data['sa_id'],
                    'master_id'=>$user_data['master_id'],
                    'admin_id'=>$user_data['admin_id'],
                    'superadmin_id'=>$user_data['superadmin_id'],
                );
                



    }
    elseif($commision_for=='session_commission')
    {
            $user_update_array=array(
            'agent_session_comm'=>$new_commission,
            'user_session_comm'=>$new_commission
          );

            $client_update_array=array(
            'agent_session_commission'=>$new_commission,
          );

            $data_array=array(
                    'client'=>'('.$user_data['name'].') '.$user_data['username'].'',
                    'old'=>$user_data['user_session_comm'],
                    'new'=>$new_share,
                    'user'=>$userdata['username'],
                    'note'=>'Agent ('.$user_data['username'].') '.$user_data['name'].' Session Commission change from '.$user_data['user_session_comm'].' To '.$new_share,
                    'type'=>'session_commission'
                );

                $task_array=array(
                    'user_id'=>$user_id,
                    'user_type'=>$user_data['user_type'],
                    'task_name'=>'Agent ('.$user_data['username'].') '.$user_data['name'].' Session Commission change from '.$user_data['user_session_comm'].' To '.$new_share,
                    'user_type'=>'agent',
                    'creater_id'=>$_SESSION['user_id'],
                    'creater_type'=>$_SESSION['user_type'],
                    'creater_name'=>$_SESSION['name'],
                    'ip'=>ip(),
                    'date'=>_date(),
                    'date_time'=>_date_time(),
                    'user_name'=>$user_data['name'],
                    'history_type'=>'session_commission',
                    'data_array'=>json_encode($data_array),
                    'agent_id'=>$user_data['agent_id'],
                    'sa_id'=>$user_data['sa_id'],
                    'master_id'=>$user_data['master_id'],
                    'admin_id'=>$user_data['admin_id'],
                    'superadmin_id'=>$user_data['superadmin_id'],
                );

    }
    elseif($commision_for=='commission_type')
    {
            $user_update_array=array(
            'agent_comm_type'=>$new_commission,
            'user_comm_type'=>$new_commission
          );
            $client_update_array=array(
            'agent_commission_type'=>$new_commission,
          );


            $data_array=array(
                    'client'=>'('.$user_data['name'].') '.$user_data['username'].'',
                    'old'=>$user_data['user_comm_type'],
                    'new'=>$new_share,
                    'user'=>$userdata['username'],
                    'note'=>'Agent ('.$user_data['username'].') '.$user_data['name'].' Commission Type change from '.$user_data['user_comm_type'].' To '.$new_share,
                    'type'=>'commission_type'
                );

                $task_array=array(
                    'user_id'=>$user_id,
                    'user_type'=>$user_data['user_type'],
                    'task_name'=>'Agent ('.$user_data['username'].') '.$user_data['name'].' Commission Type change from '.$user_data['user_comm_type'].' To '.$new_share,
                    'user_type'=>'agent',
                    'creater_id'=>$_SESSION['user_id'],
                    'creater_type'=>$_SESSION['user_type'],
                    'creater_name'=>$_SESSION['name'],
                    'ip'=>ip(),
                    'date'=>_date(),
                    'date_time'=>_date_time(),
                    'user_name'=>$user_data['name'],
                    'history_type'=>'commission_type',
                    'data_array'=>json_encode($data_array),
                    'agent_id'=>$user_data['agent_id'],
                    'sa_id'=>$user_data['sa_id'],
                    'master_id'=>$user_data['master_id'],
                    'admin_id'=>$user_data['admin_id'],
                    'superadmin_id'=>$user_data['superadmin_id'],
                );

    }
    $update=update_array('users_tbl',$user_update_array,"user_id='".$user_id."'");
    $result=insert_array('user_history_log',$task_array);

    $client_data=get_data('client',"A_id='".$user_id."'");
    foreach ($client_data as $key => $client) 
    {
        $update=update_array('client',$client_update_array,"id='".$client['id']."'");

    }

     return true;

}

function change_sa_commission($user_type,$user_id,$new_commission,$commision_for)
{
    global  $userdata;
 
    $new_share=$new_commission;
    $user_data=get_data('users_tbl',"user_id='".$user_id."'",'s');
    if($commision_for=='match_commission')
    {
            $user_update_array=array(
            'sa_match_comm'=>$new_commission,
            'user_match_comm'=>$new_commission
          );

            $client_update_array=array(
            'sa_match_commission'=>$new_commission,
          );

            $down_user_update_array=array(
            'sa_match_comm'=>$new_share,
          );

            $data_array=array(
                    'client'=>'('.$user_data['name'].') '.$user_data['username'].'',
                    'old'=>$user_data['user_match_comm'],
                    'new'=>$new_share,
                    'user'=>$userdata['username'],
                    'note'=>'SuperAgent ('.$user_data['username'].') '.$user_data['name'].' Match Commission change from '.$user_data['user_match_comm'].' To '.$new_share,
                    'type'=>'match_commission'
                );

                $task_array=array(
                    'user_id'=>$user_id,
                    'user_type'=>$user_data['user_type'],
                    'task_name'=>'SuperAgent ('.$user_data['username'].') '.$user_data['name'].' Match Commission change from '.$user_data['user_match_comm'].' To '.$new_share,
                    'user_type'=>'SuperAgent',
                    'creater_id'=>$_SESSION['user_id'],
                    'creater_type'=>$_SESSION['user_type'],
                    'creater_name'=>$_SESSION['name'],
                    'ip'=>ip(),
                    'date'=>_date(),
                    'date_time'=>_date_time(),
                    'user_name'=>$user_data['name'],
                    'history_type'=>'match_commission',
                    'data_array'=>json_encode($data_array),
                    'agent_id'=>$user_data['agent_id'],
                    'sa_id'=>$user_data['sa_id'],
                    'master_id'=>$user_data['master_id'],
                    'admin_id'=>$user_data['admin_id'],
                    'superadmin_id'=>$user_data['superadmin_id'],
                );
                



    }
    elseif($commision_for=='session_commission')
    {
            $user_update_array=array(
            'sa_session_comm'=>$new_commission,
            'user_session_comm'=>$new_commission
          );

            $client_update_array=array(
            'sa_session_commission'=>$new_commission,
          );

            $down_user_update_array=array(
            'sa_session_comm'=>$new_commission,
          );

            $data_array=array(
                    'client'=>'('.$user_data['name'].') '.$user_data['username'].'',
                    'old'=>$user_data['user_session_comm'],
                    'new'=>$new_share,
                    'user'=>$userdata['username'],
                    'note'=>'SuperAgent ('.$user_data['username'].') '.$user_data['name'].' Session Commission change from '.$user_data['user_session_comm'].' To '.$new_share,
                    'type'=>'session_commission'
                );

                $task_array=array(
                    'user_id'=>$user_id,
                    'user_type'=>$user_data['user_type'],
                    'task_name'=>'SuperAgent ('.$user_data['username'].') '.$user_data['name'].' Session Commission change from '.$user_data['user_session_comm'].' To '.$new_share,
                    'user_type'=>'superagent',
                    'creater_id'=>$_SESSION['user_id'],
                    'creater_type'=>$_SESSION['user_type'],
                    'creater_name'=>$_SESSION['name'],
                    'ip'=>ip(),
                    'date'=>_date(),
                    'date_time'=>_date_time(),
                    'user_name'=>$user_data['name'],
                    'history_type'=>'session_commission',
                    'data_array'=>json_encode($data_array),
                    'agent_id'=>$user_data['agent_id'],
                    'sa_id'=>$user_data['sa_id'],
                    'master_id'=>$user_data['master_id'],
                    'admin_id'=>$user_data['admin_id'],
                    'superadmin_id'=>$user_data['superadmin_id'],
                );

    }
    elseif($commision_for=='commission_type')
    {
            $user_update_array=array(
            'sa_comm_type'=>$new_commission,
            'user_comm_type'=>$new_commission
          );

            $client_update_array=array(
            'sa_commission_type'=>$new_commission,
          );

            $down_user_update_array=array(
            'sa_comm_type'=>$new_commission,
          );


            $data_array=array(
                    'client'=>'('.$user_data['name'].') '.$user_data['username'].'',
                    'old'=>$user_data['user_comm_type'],
                    'new'=>$new_share,
                    'user'=>$userdata['username'],
                    'note'=>'SuperAgent ('.$user_data['username'].') '.$user_data['name'].' Commission Type change from '.$user_data['user_comm_type'].' To '.$new_share,
                    'type'=>'commission_type'
                );

                $task_array=array(
                    'user_id'=>$user_id,
                    'user_type'=>$user_data['user_type'],
                    'task_name'=>'SuperAgent ('.$user_data['username'].') '.$user_data['name'].' Commission Type change from '.$user_data['user_comm_type'].' To '.$new_share,
                    'user_type'=>'superagent',
                    'creater_id'=>$_SESSION['user_id'],
                    'creater_type'=>$_SESSION['user_type'],
                    'creater_name'=>$_SESSION['name'],
                    'ip'=>ip(),
                    'date'=>_date(),
                    'date_time'=>_date_time(),
                    'user_name'=>$user_data['name'],
                    'history_type'=>'commission_type',
                    'data_array'=>json_encode($data_array),
                    'agent_id'=>$user_data['agent_id'],
                    'sa_id'=>$user_data['sa_id'],
                    'master_id'=>$user_data['master_id'],
                    'admin_id'=>$user_data['admin_id'],
                    'superadmin_id'=>$user_data['superadmin_id'],
                );

    }

    $update=update_array('users_tbl',$user_update_array,"user_id='".$user_id."'");
    $result=insert_array('user_history_log',$task_array);


    $agent_data=get_data('users_tbl',"sa_id='".$user_id."'");


    foreach ($agent_data as $key => $agent) 
    {
        $update=update_array('users_tbl',$down_user_update_array,"user_id='".$agent['user_id']."'");
    }



    $client_data=get_data('client',"sa_id='".$user_id."'");
    foreach ($client_data as $key => $client) 
    {
        $update=update_array('client',$client_update_array,"id='".$client['id']."'");
    }

     return true;

}

function change_master_commission($user_type,$user_id,$new_commission,$commision_for)
{
    global  $userdata;
    $new_share=$new_commission;
    $user_data=get_data('users_tbl',"user_id='".$user_id."'",'s');
    if($commision_for=='match_commission')
    {
            $user_update_array=array(
            'master_match_comm'=>$new_commission,
            'user_match_comm'=>$new_commission
          );

            $client_update_array=array(
            'master_match_commission'=>$new_commission,
          );

            $down_user_update_array=array(
            'master_match_comm'=>$new_share,
          );

            $data_array=array(
                    'client'=>'('.$user_data['name'].') '.$user_data['username'].'',
                    'old'=>$user_data['user_match_comm'],
                    'new'=>$new_share,
                    'user'=>$userdata['username'],
                    'note'=>'Master ('.$user_data['username'].') '.$user_data['name'].' Match Commission change from '.$user_data['user_match_comm'].' To '.$new_share,
                    'type'=>'match_commission'
                );

                $task_array=array(
                    'user_id'=>$user_id,
                    'user_type'=>$user_data['user_type'],
                    'task_name'=>'Master ('.$user_data['username'].') '.$user_data['name'].' Match Commission change from '.$user_data['user_match_comm'].' To '.$new_share,
                    'user_type'=>'master',
                    'creater_id'=>$_SESSION['user_id'],
                    'creater_type'=>$_SESSION['user_type'],
                    'creater_name'=>$_SESSION['name'],
                    'ip'=>ip(),
                    'date'=>_date(),
                    'date_time'=>_date_time(),
                    'user_name'=>$user_data['name'],
                    'history_type'=>'match_commission',
                    'data_array'=>json_encode($data_array),
                    'agent_id'=>$user_data['agent_id'],
                    'sa_id'=>$user_data['sa_id'],
                    'master_id'=>$user_data['master_id'],
                    'admin_id'=>$user_data['admin_id'],
                    'superadmin_id'=>$user_data['superadmin_id'],
                );
                



    }
    elseif($commision_for=='session_commission')
    {
            $user_update_array=array(
            'master_session_comm'=>$new_commission,
            'user_session_comm'=>$new_commission
          );

            $client_update_array=array(
            'master_session_commission'=>$new_commission,
          );

            $down_user_update_array=array(
            'master_session_comm'=>$new_commission,
          );

            $data_array=array(
                    'client'=>'('.$user_data['name'].') '.$user_data['username'].'',
                    'old'=>$user_data['user_session_comm'],
                    'new'=>$new_share,
                    'user'=>$userdata['username'],
                    'note'=>'Master ('.$user_data['username'].') '.$user_data['name'].' Session Commission change from '.$user_data['user_session_comm'].' To '.$new_share,
                    'type'=>'session_commission'
                );

                $task_array=array(
                    'user_id'=>$user_id,
                    'user_type'=>$user_data['user_type'],
                    'task_name'=>'Master ('.$user_data['username'].') '.$user_data['name'].' Session Commission change from '.$user_data['user_session_comm'].' To '.$new_share,
                    'user_type'=>'master',
                    'creater_id'=>$_SESSION['user_id'],
                    'creater_type'=>$_SESSION['user_type'],
                    'creater_name'=>$_SESSION['name'],
                    'ip'=>ip(),
                    'date'=>_date(),
                    'date_time'=>_date_time(),
                    'user_name'=>$user_data['name'],
                    'history_type'=>'session_commission',
                    'data_array'=>json_encode($data_array),
                    'agent_id'=>$user_data['agent_id'],
                    'sa_id'=>$user_data['sa_id'],
                    'master_id'=>$user_data['master_id'],
                    'admin_id'=>$user_data['admin_id'],
                    'superadmin_id'=>$user_data['superadmin_id'],
                );

    }
    elseif($commision_for=='commission_type')
    {
            $user_update_array=array(
            'master_comm_type'=>$new_commission,
            'user_comm_type'=>$new_commission
          );

            $client_update_array=array(
            'master_commission_type'=>$new_commission,
          );

            $down_user_update_array=array(
            'master_comm_type'=>$new_commission,
          );


            $data_array=array(
                    'client'=>'('.$user_data['name'].') '.$user_data['username'].'',
                    'old'=>$user_data['user_comm_type'],
                    'new'=>$new_share,
                    'user'=>$userdata['username'],
                    'note'=>'Master ('.$user_data['username'].') '.$user_data['name'].' Commission Type change from '.$user_data['user_comm_type'].' To '.$new_share,
                    'type'=>'commission_type'
                );

                $task_array=array(
                    'user_id'=>$user_id,
                    'user_type'=>$user_data['user_type'],
                    'task_name'=>'Master ('.$user_data['username'].') '.$user_data['name'].' Commission Type change from '.$user_data['user_comm_type'].' To '.$new_share,
                    'user_type'=>'master',
                    'creater_id'=>$_SESSION['user_id'],
                    'creater_type'=>$_SESSION['user_type'],
                    'creater_name'=>$_SESSION['name'],
                    'ip'=>ip(),
                    'date'=>_date(),
                    'date_time'=>_date_time(),
                    'user_name'=>$user_data['name'],
                    'history_type'=>'commission_type',
                    'data_array'=>json_encode($data_array),
                    'agent_id'=>$user_data['agent_id'],
                    'sa_id'=>$user_data['sa_id'],
                    'master_id'=>$user_data['master_id'],
                    'admin_id'=>$user_data['admin_id'],
                    'superadmin_id'=>$user_data['superadmin_id'],
                );

    }
    $update=update_array('users_tbl',$user_update_array,"user_id='".$user_id."'");
    
    $result=insert_array('user_history_log',$task_array);

    $agent_data=get_data('users_tbl',"master_id='".$user_id."'");

    foreach ($agent_data as $key => $agent) 
    {
        $update=update_array('users_tbl',$down_user_update_array,"user_id='".$agent['user_id']."'");
    }

    $client_data=get_data('client',"master_id='".$user_id."'");
    foreach ($client_data as $key => $client) 
    {
        $update=update_array('client',$client_update_array,"id='".$client['id']."'");
    }

     return true;

}

function change_admin_commission($user_type,$user_id,$new_commission,$commision_for)
{
    global  $userdata;
    $new_share=$new_commission;
    $user_data=get_data('users_tbl',"user_id='".$user_id."'",'s');
    if($commision_for=='match_commission')
    {
            $user_update_array=array(
            'admin_match_comm'=>$new_commission,
            'user_match_comm'=>$new_commission
          );

            $client_update_array=array(
            'admin_match_comm'=>$new_commission,
          );

            $down_user_update_array=array(
            'admin_match_comm'=>$new_share,
          );

            $data_array=array(
                    'client'=>'('.$user_data['name'].') '.$user_data['username'].'',
                    'old'=>$user_data['user_match_comm'],
                    'new'=>$new_share,
                    'user'=>$userdata['username'],
                    'note'=>'Admin ('.$user_data['username'].') '.$user_data['name'].' Match Commission change from '.$user_data['user_match_comm'].' To '.$new_share,
                    'type'=>'match_commission'
                );

                $task_array=array(
                    'user_id'=>$user_id,
                    'user_type'=>$user_data['user_type'],
                    'task_name'=>'Admin ('.$user_data['username'].') '.$user_data['name'].' Match Commission change from '.$user_data['user_match_comm'].' To '.$new_share,
                    'user_type'=>'admin',
                    'creater_id'=>$_SESSION['user_id'],
                    'creater_type'=>$_SESSION['user_type'],
                    'creater_name'=>$_SESSION['name'],
                    'ip'=>ip(),
                    'date'=>_date(),
                    'date_time'=>_date_time(),
                    'user_name'=>$user_data['name'],
                    'history_type'=>'match_commission',
                    'data_array'=>json_encode($data_array),
                    'agent_id'=>$user_data['agent_id'],
                    'sa_id'=>$user_data['sa_id'],
                    'master_id'=>$user_data['master_id'],
                    'admin_id'=>$user_data['admin_id'],
                    'superadmin_id'=>$user_data['superadmin_id'],
                );
                



    }
    elseif($commision_for=='session_commission')
    {
            $user_update_array=array(
            'admin_session_comm'=>$new_commission,
            'user_session_comm'=>$new_commission
          );

            $client_update_array=array(
            'admin_session_comm'=>$new_commission,
          );

            $down_user_update_array=array(
            'admin_session_comm'=>$new_commission,
          );

            $data_array=array(
                    'client'=>'('.$user_data['name'].') '.$user_data['username'].'',
                    'old'=>$user_data['user_session_comm'],
                    'new'=>$new_share,
                    'user'=>$userdata['username'],
                    'note'=>'Admin ('.$user_data['username'].') '.$user_data['name'].' Session Commission change from '.$user_data['user_session_comm'].' To '.$new_share,
                    'type'=>'session_commission'
                );

                $task_array=array(
                    'user_id'=>$user_id,
                    'user_type'=>$user_data['user_type'],
                    'task_name'=>'Admin ('.$user_data['username'].') '.$user_data['name'].' Session Commission change from '.$user_data['user_session_comm'].' To '.$new_share,
                    'user_type'=>'admin',
                    'creater_id'=>$_SESSION['user_id'],
                    'creater_type'=>$_SESSION['user_type'],
                    'creater_name'=>$_SESSION['name'],
                    'ip'=>ip(),
                    'date'=>_date(),
                    'date_time'=>_date_time(),
                    'user_name'=>$user_data['name'],
                    'history_type'=>'session_commission',
                    'data_array'=>json_encode($data_array),
                    'agent_id'=>$user_data['agent_id'],
                    'sa_id'=>$user_data['sa_id'],
                    'master_id'=>$user_data['master_id'],
                    'admin_id'=>$user_data['admin_id'],
                    'superadmin_id'=>$user_data['superadmin_id'],
                );

    }
    elseif($commision_for=='commission_type')
    {
            $user_update_array=array(
            'admin_comm_type'=>$new_commission,
            'user_comm_type'=>$new_commission
          );

            $client_update_array=array(
            'admin_comm_type'=>$new_commission,
          );

            $down_user_update_array=array(
            'admin_comm_type'=>$new_commission,
          );


            $data_array=array(
                    'client'=>'('.$user_data['name'].') '.$user_data['username'].'',
                    'old'=>$user_data['user_comm_type'],
                    'new'=>$new_share,
                    'user'=>$userdata['username'],
                    'note'=>'Admin ('.$user_data['username'].') '.$user_data['name'].' Commission Type change from '.$user_data['user_comm_type'].' To '.$new_share,
                    'type'=>'commission_type'
                );

                $task_array=array(
                    'user_id'=>$user_id,
                    'user_type'=>$user_data['user_type'],
                    'task_name'=>'Admin ('.$user_data['username'].') '.$user_data['name'].' Commission Type change from '.$user_data['user_comm_type'].' To '.$new_share,
                    'user_type'=>'admin',
                    'creater_id'=>$_SESSION['user_id'],
                    'creater_type'=>$_SESSION['user_type'],
                    'creater_name'=>$_SESSION['name'],
                    'ip'=>ip(),
                    'date'=>_date(),
                    'date_time'=>_date_time(),
                    'user_name'=>$user_data['name'],
                    'history_type'=>'commission_type',
                    'data_array'=>json_encode($data_array),
                    'agent_id'=>$user_data['agent_id'],
                    'sa_id'=>$user_data['sa_id'],
                    'master_id'=>$user_data['master_id'],
                    'admin_id'=>$user_data['admin_id'],
                    'superadmin_id'=>$user_data['superadmin_id'],
                );

    }
    $update=update_array('users_tbl',$user_update_array,"user_id='".$user_id."'");
    $result=insert_array('user_history_log',$task_array);

    $agent_data=get_data('users_tbl',"admin_id='".$user_id."'");

    foreach ($agent_data as $key => $agent) 
    {
        $update=update_array('users_tbl',$down_user_update_array,"user_id='".$agent['user_id']."'");
    }

    $client_data=get_data('client',"admin_id='".$user_id."'");
    foreach ($client_data as $key => $client) 
    {
        $update=update_array('client',$client_update_array,"id='".$client['id']."'");
    }

     return true;

}





function commission_share($user_type,$user_id,$new_share,$commision_for)
{  
    if($user_type=='agent')
    {
        $return=change_agent_commission($user_type,$user_id,$new_share,$commision_for);
    }
    elseif($user_type=='superagent')
    {
        $return=change_sa_commission($user_type,$user_id,$new_share,$commision_for);
    }
    elseif($user_type=='master')
    {
        $return=change_master_commission($user_type,$user_id,$new_share,$commision_for);
    }
    elseif($user_type=='admin')
    {
        $return=change_admin_commission($user_type,$user_id,$new_share,$commision_for);
    }
    else
    {
        $return=false;
    }

    return $return;
}


?>