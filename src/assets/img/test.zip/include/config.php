<?php 
require_once('constant.php');
if(redis)   // constat me redis constant hai isliye chaye redis
{
  require './vendor/autoload.php';
  $redis = new Predis\Client();
}
require_once('database.php');
session_start();

if(isset($_SESSION['user_type']))
{
  if($_SESSION['user_type']=='sa')
  {
  $_SESSION['user_type']='superagent'; 
  }
}
require_once('function.php');
require_once('count.php');
require_once('total_coins_function.php');
require_once('user_function.php');
require_once('match_function.php');
require_once('ledger_function.php');
require_once('share_function.php');

$browser = get_browser();
$request_uri=$_SERVER['REQUEST_URI'];
if(environment=='development')
{
  error_reporting(-1);
}
else
{
  error_reporting(0);
}


if(isset($page_id) AND $page_id=='login')
{
  return true;
}
else
{
  if(!isset($_SESSION['is_verify_logged_in']))
  {
    header("location:logout.php");
    die;
    exit();
  }
}
user_log();

if(isset($_SERVER['HTTP_REFERER']))
{
	$previous_url=$load_url=$_SERVER['HTTP_REFERER'];
}
else
{
	$previous_url=$load_url='dashboard.php';
}

$user_type=$_SESSION['user_type'];
$userdata=$_SESSION['user_data'];



?>
