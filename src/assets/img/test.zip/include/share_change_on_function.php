<?php
function change_superagent_share_on_agent($user_id,$change_share)
{
	$userdata=get_data('users_tbl',"user_id='".$user_id."'",'s');
	$update_array=[
		'sa_share'=>$change_share
	];
	$update=update_array('users_tbl',$update_array,"user_id='".$user_id."'");
	$sa_share_total_value=$change_share;
	$sa_share=$change_share-$userdata['user_share'];
	$master_share=$userdata['master_share']-$change_share;
	$client_update_array=[
		'sa_share'=>$sa_share,
		'master_share'=>$master_share,
		'sa_share_total_value'=>$sa_share_total_value,
     ];
     $update=update_array('client',$client_update_array,"A_id='".$userdata['user_id']."'");

       $data_array=array(
                    'client'=>'('.$userdata['name'].') '.$userdata['username'].'',
                    'old'=>$userdata['user_share'],
                    'new'=>$change_share,
                    'user'=>$userdata['username'],
                    'note'=>'SUPERAGENT ('.$userdata['username'].') '.$userdata['name'].' SHARE  change from '.$userdata['user_share'].' To '.$change_share,
                    'type'=>'share_change_on'
                );

                $task_array=array(
                    'user_id'=>$user_id,
                    'user_type'=>$userdata['user_type'],
                    'task_name'=>'SUPERAGENT ('.$userdata['username'].') '.$userdata['name'].' SHARE  change from '.$userdata['user_share'].' To '.$change_share,
                    'user_type'=>'agent',
                    'creater_id'=>$_SESSION['user_id'],
                    'creater_type'=>$_SESSION['user_type'],
                    'creater_name'=>$_SESSION['name'],
                    'ip'=>ip(),
                    'date'=>_date(),
                    'date_time'=>_date_time(),
                    'user_name'=>$userdata['name'],
                    'history_type'=>'share_change_on',
                    'data_array'=>json_encode($data_array),
                    'agent_id'=>$userdata['agent_id'],
                    'sa_id'=>$userdata['sa_id'],
                    'master_id'=>$userdata['master_id'],
                    'admin_id'=>$userdata['admin_id'],
                    'superadmin_id'=>$userdata['superadmin_id'],
                );
                $result=insert_array('user_history_log',$task_array);
	 return $update;
}

function change_master_share_on_superagent($user_id,$change_share)
{
	$userdata=get_data('users_tbl',"user_id='".$user_id."'",'s');
	$update_array=[
		'master_share'=>$change_share
	];
	$update=update_array('users_tbl',$update_array,"user_id='".$user_id."'");
	$master_share_total_value=$change_share;
	$master_share=$change_share-$userdata['user_share'];
	$admin_share=$userdata['admin_share']-$change_share;
	$client_update_array=[
		'master_share'=>$master_share,
		'admin_share'=>$admin_share,
		'master_share_total_value'=>$master_share_total_value,
     ];

     $update=update_array('client',$client_update_array,"sa_id='".$userdata['user_id']."'");
      $data_array=array(
                    'client'=>'('.$userdata['name'].') '.$userdata['username'].'',
                    'old'=>$userdata['user_share'],
                    'new'=>$change_share,
                    'user'=>$userdata['username'],
                    'note'=>'MASTER ('.$userdata['username'].') '.$userdata['name'].' SHARE  change from '.$userdata['user_share'].' To '.$change_share,
                    'type'=>'share_change_on'
                );

                $task_array=array(
                    'user_id'=>$user_id,
                    'user_type'=>$userdata['user_type'],
                    'task_name'=>'MASTER ('.$userdata['username'].') '.$userdata['name'].' SHARE  change from '.$userdata['user_share'].' To '.$change_share,
                    'user_type'=>'agent',
                    'creater_id'=>$_SESSION['user_id'],
                    'creater_type'=>$_SESSION['user_type'],
                    'creater_name'=>$_SESSION['name'],
                    'ip'=>ip(),
                    'date'=>_date(),
                    'date_time'=>_date_time(),
                    'user_name'=>$userdata['name'],
                    'history_type'=>'share_change_on',
                    'data_array'=>json_encode($data_array),
                    'agent_id'=>$userdata['agent_id'],
                    'sa_id'=>$userdata['sa_id'],
                    'master_id'=>$userdata['master_id'],
                    'admin_id'=>$userdata['admin_id'],
                    'superadmin_id'=>$userdata['superadmin_id'],
                );
                $result=insert_array('user_history_log',$task_array);

	 return $update;
}

function change_admin_share_on_master($user_id,$change_share)
{
	$userdata=get_data('users_tbl',"user_id='".$user_id."'",'s');
	$update_array=[
		'admin_share'=>$change_share
	];
	$update=update_array('users_tbl',$update_array,"user_id='".$user_id."'");
	$admin_share_total_value=$change_share;
	$admin_share=$change_share-$userdata['user_share'];
	$superadmin_share=$userdata['superadmin_share']-$change_share;
	$client_update_array=[
		'admin_share'=>$admin_share,
		'superadmin_share'=>$superadmin_share,
		'admin_share_total_value'=>$admin_share_total_value,
     ];
     $update=update_array('client',$client_update_array,"master_id='".$userdata['user_id']."'");

      $data_array=array(
                    'client'=>'('.$userdata['name'].') '.$userdata['username'].'',
                    'old'=>$userdata['user_share'],
                    'new'=>$change_share,
                    'user'=>$userdata['username'],
                    'note'=>'ADMIN ('.$userdata['username'].') '.$userdata['name'].' SHARE  change from '.$userdata['user_share'].' To '.$change_share,
                    'type'=>'share_change_on'
                );

                $task_array=array(
                    'user_id'=>$user_id,
                    'user_type'=>$userdata['user_type'],
                    'task_name'=>'ADMIN ('.$userdata['username'].') '.$userdata['name'].' SHARE  change from '.$userdata['user_share'].' To '.$change_share,
                    'user_type'=>'agent',
                    'creater_id'=>$_SESSION['user_id'],
                    'creater_type'=>$_SESSION['user_type'],
                    'creater_name'=>$_SESSION['name'],
                    'ip'=>ip(),
                    'date'=>_date(),
                    'date_time'=>_date_time(),
                    'user_name'=>$userdata['name'],
                    'history_type'=>'share_change_on',
                    'data_array'=>json_encode($data_array),
                    'agent_id'=>$userdata['agent_id'],
                    'sa_id'=>$userdata['sa_id'],
                    'master_id'=>$userdata['master_id'],
                    'admin_id'=>$userdata['admin_id'],
                    'superadmin_id'=>$userdata['superadmin_id'],
                );
                $result=insert_array('user_history_log',$task_array);
	 return $update;
}



function overall_change_share($user_id,$user_type,$change_share)
{
	if($user_type=='agent')
	{
	  $return=change_superagent_share_on_agent($user_id,$change_share);
	}
	else if($user_type=='superagent')
	{
		$return=change_master_share_on_superagent($user_id,$change_share);
	}
	else if($user_type=='master')
	{
		$return=change_admin_share_on_master($user_id,$change_share);
	}
	else
	{
		$return =true;
	}
    return $return;
}




?>