<?php

function get_user_ledger($user_id,$user_type,$statement_type='')
{
	global $con;
    $where="user_id='".$user_id."'";
    if(!empty($statement_type) AND $statement_type==1)
    {
    	$where=$where." AND ledger_type='CASH'";
    }
    if(!empty($statement_type) AND $statement_type==2)
    {
    	$where=$where." AND ledger_type!='CASH' AND ledger_type!=''";
    }
    if(!empty($statement_type) AND $statement_type==3)
    {
    	$where=$where." AND ledger_type!='CASH' AND ledger_type=''";
    }

	$total = "SELECT sum(amount) total_credit FROM user_ledger WHERE  transaction_type='C' AND ".$where;

	$total_bal = mysqli_query($con,$total);
	$total_credit_balance=mysqli_fetch_assoc($total_bal)['total_credit'];

	$total = "SELECT sum(amount) total_debit FROM user_ledger WHERE transaction_type='D' AND ".$where;
	$total_bal = mysqli_query($con,$total);


	$total_debit_balance=mysqli_fetch_assoc($total_bal)['total_debit'];
    $total_balance=$total_credit_balance-$total_debit_balance;

	$send_array=array('credit_balance'=>$total_credit_balance,'debit_balance'=>$total_debit_balance,'total_balance'=>$total_balance);
    return $send_array;
}


function get_client_ledger($client_id,$market_id='',$statement_type='')
{
	global $con;
    if($market_id!='')
    {
    	$where="market_id='".$market_id."'";
    }
    else
    {
    	$where="1=1 ";
    }

    if(!empty($statement_type) AND $statement_type==1)
    {
    	$where=$where." AND  ledger_type='CASH'";
    }

     if(!empty($statement_type) AND $statement_type==2)
    {
         $where=$where." AND ledger_type!='CASH' AND ledger_type!=''";
    }

     if(!empty($statement_type) AND $statement_type==3)
    {
         $where=$where." AND ledger_type!='CASH' AND ledger_type=''";
    }

	$total = "SELECT sum(amount) total_credit FROM ledger WHERE client_id = '".$client_id."' AND payment_type='C' AND ".$where;
	$total_bal = mysqli_query($con,$total);
	$total_credit_balance=mysqli_fetch_assoc($total_bal)['total_credit'];

	$total = "SELECT sum(amount) total_debit FROM ledger WHERE client_id = '".$client_id."' AND payment_type='D' AND ".$where;
	$total_bal = mysqli_query($con,$total);
	$total_debit_balance=mysqli_fetch_assoc($total_bal)['total_debit'];
    $total_balance=$total_credit_balance-$total_debit_balance;
   
	$send_array=array('credit_balance'=>$total_credit_balance,'debit_balance'=>$total_debit_balance,'total_balance'=>$total_balance);

    return $send_array;
}





?>