<?php  

function user_generate_report($report_type,$old_value,$new_value,$user_data='',$parent_data='',$user_id='',$note='')
{
	if(empty($report_type))
	{
		return false;
	}
	if(empty($parent_data))
	{
		$parent_data=$userdata;
	}
	if(empty($user_id))
	{
		$user_id=$user_data['user_id'];
	}


	if(empty($note))
	{
		$note=$_SESSION['username']." (".$_SESSION['name'].") ".$report_type." change from ".$old_value." To  ".$new_value." ";
	}
	 $data_array=array(
                    'client'=>'('.$user_data['name'].') '.$user_data['username'].'',
                    'old'=>$old_value,
                    'new'=>$new_value,
                    'user'=>$user_data['username'],
                    'user_type'=>$user_data['user_type'],
                    'user_name'=>'('.$user_data['name'].') '.$user_data['username'].'',
                    'note'=>$note,
                    'type'=>$report_type
                );

                $task_array=array(
                    'user_id'=>$user_id,
                    'user_type'=>$user_data['user_type'],
                    'task_name'=>$report_type,
                    'note'=>$note,
                    'user_type'=>$user_data['user_type'],
                    'creater_id'=>$_SESSION['user_id'],
                    'creater_type'=>$_SESSION['user_type'],
                    'creater_name'=>$_SESSION['name'],
                    'ip'=>ip(),
                    'date'=>_date(),
                    'date_time'=>_date_time(),
                    'user_name'=>$user_data['name'],
                    'history_type'=>$report_type,
                    'data_array'=>json_encode($data_array),
                    'agent_id'=>$user_data['agent_id'],
                    'sa_id'=>$user_data['sa_id'],
                    'master_id'=>$user_data['master_id'],
                    'admin_id'=>$user_data['admin_id'],
                    'superadmin_id'=>$user_data['superadmin_id'],
                );

            $result=insert_array('user_history_log',$task_array);
	}


function no_comm_session_perm_update($user_data,$new_perm)
{
	$user_type=$user_data['user_type']=='superagent'?'sa':$user_data['user_type'];
	$user_id=$user_data['user_id'];
	$update_array=['no_comm_perm'=>$new_perm];
	$client_update=update_array('client',$update_array,$user_type."_id='".$user_id."'");
}

?>