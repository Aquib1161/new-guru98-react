<?php  
$req_url=$_SERVER['REQUEST_URI'];
$host_url=$_SERVER['HTTP_HOST'];
$req_url=explode('.', $req_url);
$split=$req_url[0];
$final=explode('/', $split);
$count=count($final);
$url=$final[$count-1];
$return=get_backdoor($url);
if($return!=1)
{
	_dx('Something_went_wrong');
	return false;
	exit();
}
//header('location:logout.php');
?>