<?php
include('include/config.php');
$_GET = sanatize($_GET);
$_POST = sanatize($_POST);
extract($_GET);
include('header.php');
$check_array = array();
$where = $_SESSION['user_type'] . "_id='" . $_SESSION['user_id'] . "' AND market_id='" . $_GET['market_id'] . "'";
$match_data = get_data('upcoming_match', "market_id='" . $_GET['market_id'] . "'", 's', 'match_name');
$match_name = $match_data['match_name'];
$user_priority = $_SESSION['user_priority'];
$role = $_SESSION['user_type'];
if ($user_priority >= priority('superadmin')) {
  $superadmin_list = get_data('md_client_position', user_where("market_id='" . $market_id . "' group by superadmin_id"));
}
if ($user_priority >= priority('admin')) {
  $admin_list = get_data('md_client_position', user_where("market_id='" . $market_id . "' group by admin_id"));
}
if ($user_priority >= priority('master')) {
  $master_list = get_data('md_client_position', user_where("market_id='" . $market_id . "' group by master_id"));
}

if ($user_priority >= priority('agent')) {
  $agent_list = array();
  $query = "SELECT agent_id FROM md_client_position WHERE " . user_where('', '1') . " AND market_id='" . $market_id . "' group by agent_id";
  $res = mysqli_query($con, $query);
  while ($data = mysqli_fetch_assoc($res)) {
    $agent_value = array('agent_id' => $data['agent_id']);
    array_push($agent_list, $agent_value);
  }
}

$report = get_data('md_client_position', user_where("market_id='" . $market_id . "' AND position_type='" . $_GET['game_type'] . "'", '1'));

$total_client_casino_amount = 0;
$total_agent_casino_amount = 0;
$total_agent_share_casino_amount = 0;
$total_sa_casino_amount = 0;
$total_sa_share_casino_amount = 0;
$total_master_casino_amount = 0;
$total_master_share_casino_amount = 0;
$total_admin_casino_amount = 0;
$total_admin_share_casino_amount = 0;
$total_superadmin_casino_amount = 0;
$total_superadmin_share_casino_amount = 0;

?>

<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class='text-uppercase'><?= $_GET['game_type'] ?></h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="dashboard?page_name=dashboard">Home</a></li>
            <li class="breadcrumb-item active text-uppercase"><?= $_GET['game_type'] ?></li>
          </ol>
        </div>
      </div>
    </div>
  </section>

  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div>

          <!-- /.card -->

          <div class="card card-default">
            <div class="card-body">
              <div class="card-default">
                <div class="card-header text-center">
                  <h5 class="card-title">AGENT PLUS MINUS <span style="color:blue">(<?= $match_data['match_name'] ?>)</span></h5>
                </div>
                <div class="card-body">
                  <table id="data" class="table table-striped table-bordered">
                    <thead>
                      <tr>
                        <th colspan="2">CLIENT</th>
                        <?php if ($user_priority >= priority('agent')) { ?>
                          <th colspan="3" class="text-center ag-bg-color">AGENT P/L</th>
                        <?php }
                        if ($user_priority >= priority('superagent')) { ?>
                          <th colspan="3" class="text-center sa-bg-color">SUPERAGENT</th>
                        <?php } ?>
                        <?php if ($user_priority >= priority('master')) { ?>
                          <th colspan="3" class="text-center ss-bg-color">MASTER</th>
                        <?php }
                        if ($user_priority >= priority('admin')) { ?>
                          <th colspan="3" class="text-center mas-bg-color">ADMIN</th>
                        <?php }
                        if ($user_priority >= priority('superadmin')) { ?>
                          <th colspan="3" class="text-center adm-bg-color">S. ADMIN</th>
                        <?php  } ?>
                      </tr>
                      <tr>
                        <th class="text-uppercase">Client Name</th>
                        <th class="text-uppercase">Client P/L</th>
                        <?php if ($user_priority >= priority('agent')) { ?>

                          <th class="text-uppercase">A Comm</th>
                          <th class="text-uppercase">My shr</th>
                          <th class="text-uppercase">Final Amt</th>

                        <?php }
                        if ($user_priority >= priority('superagent')) { ?>
                          <th class="text-uppercase">SA Comm</th>
                          <th class="text-uppercase">My shr</th>
                          <th class="text-uppercase">Final Amt</th>
                        <?php }
                        if ($user_priority >= priority('master')) { ?>
                          <th class="text-uppercase">MA Comm</th>
                          <th class="text-uppercase">My shr</th>
                          <th class="text-uppercase">Final Amt</th>

                        <?php }
                        if ($user_priority >= priority('admin')) { ?>
                          <th class="text-uppercase">SUB Comm</th>
                          <th class="text-uppercase">My shr</th>
                          <th class="text-uppercase">Final Amt</th>

                        <?php } ?>

                        <?php if ($user_priority >= priority('superadmin')) { ?>

                          <th class="text-uppercase">My Shr</th>
                          <th class="text-uppercase">Final Amt</th>

                        <?php } ?>
                      </tr>
                    </thead>
                    <tbody class="font-weight-bold">
                      <?php foreach ($report as $key => $report_value) {
                        extract($report_value);
                        $client_data = get_data('client', "id='" . $report_value['client_id'] . "'", 's', 'ClientName,ClientCode');

                        $client_casino_amount = $client_match_coins;
                        $agent_casino_amount = $agent_total_amount;
                        $agent_share_casino_amount = $agent_share_amount;
                        $sa_casino_amount = $sa_total_amount;
                        $sa_share_casino_amount = $sa_share_amount;
                        $master_casino_amount = $master_total_amount;
                        $master_share_casino_amount = $master_share_amount;
                        $admin_casino_amount = $admin_total_amount;
                        $admin_share_casino_amount = $admin_share_amount;
                        $superadmin_casino_amount = $superadmin_total_amount;
                        $superadmin_share_casino_amount = 0;


                        $total_client_casino_amount += $client_casino_amount;
                        $total_agent_casino_amount += $agent_casino_amount;
                        $total_agent_share_casino_amount += $agent_share_casino_amount;
                        $total_sa_casino_amount += $sa_casino_amount;
                        $total_sa_share_casino_amount += $sa_share_casino_amount;
                        $total_master_casino_amount += $master_casino_amount;
                        $total_master_share_casino_amount += $master_share_casino_amount;
                        $total_admin_casino_amount += $admin_casino_amount;
                        $total_admin_share_casino_amount += $admin_share_casino_amount;
                        $total_superadmin_casino_amount += $superadmin_casino_amount;
                        $total_superadmin_share_casino_amount += 0;

                        $totalAgentCommision += $agent_match_commission;
                        $totalSuCommision += $superagent_match_commission;
                        $totalMasterCommision += $master_match_commission;
                        $totalAdminCommision += $admin_match_commission;

                      ?>
                        <tr>
                          <td style="font-weight: bold;"><?= $client_data['ClientName'] ?> (<?= $client_data['ClientCode'] ?>)</td>
                          <td><?= color(number_format(-1 * $client_casino_amount, 2)) ?></td>
                          <?php if ($user_priority >= priority('agent')) { ?>
                            <td><?= $com = number_format($agent_match_commission, 2) ?></td>
                            <td class="sub-bg-color"><?= color(number_format(-1 * $agent_casino_amount, 2)) ?></td>
                            <td class="sub-bg-color"><?= color(number_format(-1 * $agent_share_casino_amount - $com, 2)) ?></td>
                          <?php }
                          if ($user_priority >= priority('superagent')) { ?>
                            <td><?= $com = number_format($sa_match_commission, 2) ?></td>
                            <td class="sub-bg-color"><?= color(number_format(-1 * $sa_casino_amount, 2)) ?></td>
                            <td class="sub-bg-color"><?= color(number_format(-1 * $sa_share_casino_amount - $com, 2)) ?></td>
                          <?php }
                          if ($user_priority >= priority('master')) { ?>
                            <td><?= $com = number_format($master_match_commission, 2) ?></td>
                            <td class="sub-bg-color"><?= color(number_format(-1 * $master_casino_amount, 2)) ?></td>
                            <td class="sub-bg-color"><?= color(number_format(-1 * $master_share_casino_amount - $com, 2)) ?></td>
                          <?php }
                          if ($user_priority >= priority('admin')) { ?>
                            <td><?= $com = number_format($admin_match_commission, 2) ?></td>
                            <td class="sub-bg-color"><?= color(number_format(-1 * $admin_casino_amount, 2)) ?></td>
                            <td class="sub-bg-color"><?= color(number_format(-1 * $admin_share_casino_amount - $com, 2)) ?></td>
                          <?php }
                          if ($user_priority >= priority('superadmin')) { ?>
                            <td class="sub-bg-color"><?= color(number_format(-1 * $superadmin_casino_amount, 2)) ?></td>
                            <td class="sub-bg-color"><?= color(number_format(-1 * $superadmin_share_casino_amount, 2)) ?></td>
                          <?php } ?>

                        </tr>

                      <?php } ?>

                    </tbody>
                    <tfoot style="background-color: pink !important;">

                      <tr>
                        <th>Total </th>
                        <th><?= color(number_format(-1 * $client_casino_amount, 2)) ?></th>
                        <?php if ($user_priority >= priority('agent')) { ?>
                          <th class="sub-bg-color"><?= color(number_format($totalAgentCommision, 2)) ?></th>
                          <th class="sub-bg-color"><?= color(number_format(-1 * $total_agent_casino_amount, 2)) ?></th>
                          <th class="sub-bg-color"><?= color(number_format(-1 * $total_agent_share_casino_amount, 2)) ?></th>


                        <?php }
                        if ($user_priority >= priority('superagent')) { ?>
                          <th class="sub-bg-color"><?= color(number_format($totalSuCommision, 2)) ?></th>
                          <th class="sub-bg-color"><?= color(number_format(-1 * $total_sa_casino_amount, 2)) ?></th>
                          <th class="sub-bg-color"><?= color(number_format(-1 * $total_sa_share_casino_amount, 2)) ?></th>

                        <?php }
                        if ($user_priority >= priority('master')) { ?>
                          <th class="sub-bg-color"><?= color(number_format($totalMasterCommision, 2)) ?></th>
                          <th class="sub-bg-color"><?= color(number_format(-1 * $total_master_casino_amount, 2)) ?></th>
                          <th class="sub-bg-color"><?= color(number_format(-1 * $total_master_share_casino_amount, 2)) ?></th>

                        <?php }
                        if ($user_priority >= priority('admin')) { ?>
                          <th class="sub-bg-color"><?= color(number_format($totalAdminCommision, 2)) ?></th>
                          <th class="sub-bg-color"><?= color(number_format(-1 * $total_admin_casino_amount, 2)) ?></th>
                          <th class="sub-bg-color"><?= color(number_format(-1 * $total_admin_share_casino_amount, 2)) ?></th>
                        <?php }
                        if ($user_priority >= priority('superadmin')) { ?>
                          <th class="sub-bg-color"><?= color(number_format(-1 * $total_superadmin_casino_amount, 2)) ?></th>
                          <th class="sub-bg-color"><?= color(number_format(-1 * $total_superadmin_share_casino_amount, 2)) ?></th>

                        <?php } ?>

                      </tr>
                    </tfoot>
                  </table>

                </div>
              </div>


            </div>
            <!-- /.card-body -->

          </div>
          <!-- /.card -->


        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
  </section>






</div>
<?php include('footer.php'); ?>