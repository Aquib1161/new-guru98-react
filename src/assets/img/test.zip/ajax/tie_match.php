<?php include('../include/config.php');
$_POST=($_POST);
extract($_POST);

$market_id = $_POST['market_id'];
if ($market_id == "Select Match" OR !isset($_SESSION['password_verify'])) {
	$send_array=array(
     'msg'=>"Something went wrong"
    );

    $status='error';
    $data_to_send=array(
	'data'=>$send_array,
	'status'=>$status
);
	$data=json_encode($data_to_send);
	echo $data;
	exit();
}

unset($_SESSION['password_verify']);


if(isset($_POST['id_array']) AND isset($_POST['individual']) AND $_POST['individual']=='individual')
{
   
   foreach ($id_array as $key => $bet_data) 
   {  
   	  $data=get_data('client_match_bet_tbl',"client_match_bet_id='".$bet_data."'",'s');
   	  $deleted_status=$data['deleted_status']==1?0:1;
      $query="UPDATE  client_match_bet_tbl SET deleted_status='".$deleted_status."' WHERE  market_id='$market_id' AND client_match_bet_id='".$bet_data."' ";
      $res=mysqli_query($con,$query);
   }
          $send_array=array(
     'msg'=>"Successufully Done"
    );

$status='success';
    $data_to_send=array(
	'data'=>$send_array,
	'status'=>$status
);
	$data=json_encode($data_to_send);
	echo $data;
	exit();

}



/*$query="SELECT * FROM match_bet_calculation WHERE  market_id='$market_id'";
$calculation_res=mysqli_query($con,$query);
$count=mysqli_num_rows($calculation_res);
if($count>0)
{
while ($data=mysqli_fetch_assoc($calculation_res)) 
{ 
	
	extract($data);
	$query="INSERT INTO deleted_match_bet_calculation (`match_bet_id`, `selection_id`, `bat_id`, `market_id`, `profit`, `client_id`, `sa_id`, `master_id`, `agent_id`, `match_name`, `bet_value`, `lose`, `type`, `admin_share`, `master_share`, `sa_share`, `agent_share`, `auto_limit`, `admin_amount`, `master_amount`, `sa_amount`, `agent_amount`) VALUES ('$match_bet_id','$selection_id','$bat_id','$market_id','$profit','$client_id','$sa_id','$master_id','$agent_id','$match_name','$bet_value','$lose','$type','$admin_share','$master_share','$sa_share','$agent_share','$auto_limit','$admin_amount','$master_amount','$sa_amount','$agent_amount')";  
	$res=mysqli_query($con,$query);
}
}*/


/*$query="SELECT * FROM transaction_log WHERE  match_id='$market_id' AND overall_type='MD'";
$trans_res=mysqli_query($con,$query);
$count=mysqli_num_rows($trans_res);
if($count>0)
{
while ($trans_data=mysqli_fetch_assoc($trans_res)) 
{
	extract($trans_data);
	$query="INSERT INTO `deleted_transaction_log` (`transition_id`, `amount`, `user_type`, `transaction_type`, `client_id`, `admin_id`, `sa_id`, `master_id`, `agent_id`, `remark`, `date`, `for_bet`, `selection_id`, `match_id`, `overall_type`, `is_declare`, `match_declare`, `admin_share`, `agent_share`, `master_share`, `sa_share`, `auto_limit`, `admin_amount`, `master_amount`, `sa_amount`, `agent_amount`) VALUES ('$transition_id','$amount','$user_type','$transaction_type','$client_id','$admin_id','$sa_id','$master_id','$agent_id','$remark','$date','$for_bet','$selection_id','$match_id','$overall_type','$is_declare','$match_declare','$admin_share','$agent_share','$master_share','$sa_share','$auto_limit','$admin_amount','$master_amount','$sa_amount','$agent_amount')";  
	$res=mysqli_query($con,$query);
}
}*/


$query = "DELETE FROM transaction_log WHERE overall_type='MC' AND match_id='$market_id'";
mysqli_query($con, $query);
$query = "DELETE FROM transaction_log WHERE overall_type='MCC' AND match_id='$market_id'";
mysqli_query($con, $query);
$query = "DELETE FROM transaction_log WHERE autolimit_debit='YES' AND auto_market_id='$market_id'";
mysqli_query($con, $query);
$query = "DELETE FROM ledger WHERE market_id='$market_id'";
mysqli_query($con, $query);
$query = "DELETE FROM agent_ledger WHERE market_id='$market_id'";
mysqli_query($con, $query);
$query = "DELETE FROM sa_ledger WHERE market_id='$market_id'";
mysqli_query($con, $query);
$query = "DELETE FROM master_ledger WHERE market_id='$market_id'";
mysqli_query($con, $query);
$query = "DELETE FROM admin_ledger WHERE market_id='$market_id'";
mysqli_query($con, $query);

$query="UPDATE  client_match_bet_tbl SET deleted_status=1  WHERE  market_id='$market_id' ";
$res=mysqli_query($con,$query);
$query1="DELETE FROM match_bet_calculation WHERE  market_id='$market_id' ";
$res=mysqli_query($con,$query1);
$query = "DELETE FROM transaction_log WHERE overall_type='MD' AND match_id='$market_id'";
mysqli_query($con, $query);
$query = "UPDATE upcoming_match SET status = 'COMPLETED' , won_team_selection_id='111111', won_team_name='Match Tie' WHERE market_id = '$market_id'";
mysqli_query($con, $query);
$query = "UPDATE market_price SET is_declare = '1' WHERE market_id = '$market_id' ";
mysqli_query($con, $query);

$send_array=array(
     'msg'=>"Tie match status has been update successfully"
    );

$status='success';
    $data_to_send=array(
	'data'=>$send_array,
	'status'=>$status
);
	$data=json_encode($data_to_send);
	echo $data;
	exit();


?>