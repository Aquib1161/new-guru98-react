<?php
$page_id='login';
include('../include/config.php');
/*$_POST=sanatize($_POST);
$market_id=$_POST['market_id'];*/
$market_id='10a45e2831341489eb840982df27a92f6d0bdea1';
if ($market_id == "") 
{
    $send_array=array(
     'msg'=>"Something went wrong"
    );

    $status='error';
    $data_to_send=array(
    'data'=>$send_array,
    'status'=>$status
);
    $data=json_encode($data_to_send);
    echo $data;
    exit();
}
$array=array();
$match_data=get_data('upcoming_match',"market_id='".$market_id."'",'s');
$match_name = $match_data['match_name'];

$query="DELETE FROM md_client_position WHERE market_id='$market_id' AND ";
mysqli_query($con,$query);


$client_ledger=get_data('ledger',"market_id='".$market_id."'");

foreach ($client_ledger as $key => $client_data) 
{
        $share_data=json_decode($client_data['share_array'],true);
        extract($share_data);  // extraction all share array
        _dx($share_data);
       


        $agent_lena='';


}

_dx($client_ledger);




$send_array=array(
     'msg'=>"Position has been updated successfully"
    );
    $status='success';
   $data_to_send=array(
    'data'=>$send_array,
    'status'=>$status
);
$data=json_encode($data_to_send);
echo $data;
exit();
die;




?>