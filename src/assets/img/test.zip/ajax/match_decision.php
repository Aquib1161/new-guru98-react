<?php include('../include/config.php');
$_POST=sanatize($_POST);

if(!isset($_SESSION['password_verify']))
{

    $send_array=array(
     'msg'=>"Password Not Verified"
    );

    $status='error';
    $data_to_send=array(
    'data'=>$send_array,
    'status'=>$status
);
    $data=json_encode($data_to_send);
    echo $data;
    exit();
}




if(count($_POST)==0)
{
    $send_array=array(
     'msg'=>"Something went wrong"
    );

    $status='error';
    $data_to_send=array(
    'data'=>$send_array,
    'status'=>$status
);
    $data=json_encode($data_to_send);
    echo $data;
    exit();
}



$market_id = $_POST['market_id'];
if ($market_id == "Select Match" OR !isset($_SESSION['password_verify']) OR $_POST['won_team_selection_id']=='') {
	$send_array=array(
     'msg'=>"Something went wrong"
    );

    $status='error';
    $data_to_send=array(
	'data'=>$send_array,
	'status'=>$status
);
	$data=json_encode($data_to_send);
	echo $data;
	exit();
}

unset($_SESSION['password_verify']);

$query="SELECT session_crick_id FROM session_crick_tbl WHERE market_id='".$market_id."' AND decision_run ='' AND deleted_status=0";
$session_res=mysqli_query($con,$query);
$session_count=mysqli_num_rows($session_res);
if($session_count>0)
{
    $send_array=array(
     'msg'=>"Session pending ! Please give session decision"
    );

    $status='error';
    $data_to_send=array(
	'data'=>$send_array,
	'status'=>$status
);
	$data=json_encode($data_to_send);
	echo $data;
	exit();
	die();
}

$market_id = $_POST['market_id'];
$winner_team_id = $_POST['won_team_selection_id'];
$match_data=get_data('upcoming_match',"market_id='".$market_id."'",'s');
$match_name = $match_data['match_name'];
//_dx($match_data);
$team_data=get_data('match_team_tbl',"market_id='".$market_id."'");
$count=count($team_data);
$team1=$team1_selection_id=$team_data[0]['selection_id'];
$team1_name=$team_data[0]['runner_name'];

$team2= $team2_selection_id=$team_data[1]['selection_id'];
$team2_name=$team_data[1]['runner_name'];

$won_team_name='';
if($count==3)
{
	$team3_selection_id=$team_data[2]['selection_id'];
    $team3_name=$team_data[2]['runner_name'];
    if ($winner_team_id == $team3_selection_id)
{

    $won_team_name = $team3_name;
}
}
if ($winner_team_id == $team1_selection_id)
{

    $won_team_name = $team1_name;
}

if ($winner_team_id == $team2_selection_id)
{

    $won_team_name = $team2_name;
}

$query = "UPDATE client_match_bet_tbl SET decision_selection_id = '$winner_team_id'  WHERE market_id = '$market_id' ";
mysqli_query($con, $query);
$query = "UPDATE upcoming_match SET status = 'COMPLETED' , won_team_selection_id='$winner_team_id', won_team_name='$won_team_name' WHERE market_id = '$market_id'";
mysqli_query($con, $query);
$query = "UPDATE market_price SET is_declare = '1' WHERE market_id = '$market_id' ";
mysqli_query($con, $query);

$query = "DELETE FROM transaction_log WHERE overall_type='MC' AND match_id='$market_id'";
mysqli_query($con, $query);
$query = "DELETE FROM transaction_log WHERE overall_type='MCC' AND match_id='$market_id'";
mysqli_query($con, $query);
$query = "DELETE FROM transaction_log WHERE autolimit_debit='YES' AND auto_market_id='$market_id'";
mysqli_query($con, $query);
$query = "DELETE FROM ledger WHERE market_id='$market_id'";
mysqli_query($con, $query);
$query = "DELETE FROM agent_ledger WHERE market_id='$market_id'";
mysqli_query($con, $query);
$query = "DELETE FROM sa_ledger WHERE market_id='$market_id'";
mysqli_query($con, $query);
$query = "DELETE FROM master_ledger WHERE market_id='$market_id'";
mysqli_query($con, $query);
$query = "DELETE FROM admin_ledger WHERE market_id='$market_id'";
mysqli_query($con, $query);


$query = "SELECT * FROM client_match_bet_tbl WHERE market_id = '$market_id' AND deleted_status='0'";
$res = mysqli_query($con, $query);

$decision = array();
$client_wise = array();

while ($data = mysqli_fetch_assoc($res))
{

    if (!array_key_exists($data['client_id'], $client_wise))
    {
        $client_wise[$data['client_id']] = array(
            "debit" => 0,
            "credit" => 0,
            "bet_commission" => 0,
            "com_per"=>$data['commission'],
            "commission_type" => $data['commission_type'],
            "agent_id" => $data['agent_id'],
            "runner_name" => $data['team_name'],
            "sa_id" => $data['super_agent_id'],
            "master_id" => $data['master_id'],
            "master_share" => $data['master_share'],
            "admin_share" => $data['admin_share'],
            "admin_id" => $data['admin_id'],
            "sa_share" => $data['sa_share'],
            "agent_share" => $data['agent_share'],
            "superadmin_id" => $data['superadmin_id'],
            "superadmin_share" => $data['superadmin_share'],
            "auto_limit" => $data['auto_limit']
        );
    }

    if ($data['type'] == 'L' && $data['decision_selection_id'] == $data['selection_id'])
    {
        $client_wise[$data['client_id']]['credit'] += floatval($data['amount'] * $data['bhav']);
        $client_wise[$data['client_id']]['bet_commission'] += floatval($data['commission'] / 100) * (int)$data['amount'];

    }

    if ($data['type'] == 'K' && $data['decision_selection_id'] == $data['selection_id'])
    {
        $client_wise[$data['client_id']]['debit'] += floatval($data['amount'] * $data['bhav']);
        $client_wise[$data['client_id']]['bet_commission'] += floatval($data['commission'] / 100) * (int)$data['amount'] * (int)$data['bhav'];

    }

    if ($data['type'] == 'L' && $data['decision_selection_id'] != $data['selection_id'])
    {
        $client_wise[$data['client_id']]['debit'] += floatval($data['amount']);
        $client_wise[$data['client_id']]['bet_commission'] += floatval($data['commission'] / 100) * $data['amount'];

    }

    if ($data['type'] == 'K' && $data['decision_selection_id'] != $data['selection_id'])
    {
        $client_wise[$data['client_id']]['credit'] += floatval($data['amount']);
        $client_wise[$data['client_id']]['bet_commission'] += floatval($data['commission'] / 100) * (int)$data['amount'];

    }

}


foreach ($client_wise as $clid => $crdb)
{

    $debit = $crdb['debit'];
    $credit = $crdb['credit'];
    $agent_id = $crdb['agent_id'];
    $runner_name = $crdb['runner_name'];
    $master_id = $crdb['master_id'];
    $sa_id = $crdb['sa_id'];
    $admin_id = $crdb['admin_id'];
    $superadmin_id = $crdb['superadmin_id'];
    $sa_share = $crdb['sa_share'];
    $master_share = $crdb['master_share'];
    $admin_share = $crdb['admin_share'];
    $agent_share = $crdb['agent_share'];
    $superadmin_share = $crdb['superadmin_share'];
    $auto_limit = $crdb['auto_limit'];

    $query = "SELECT * FROM shares WHERE market_id='$market_id' AND client_id='$clid'";
    $res = mysqli_query($con, $query);
    $share = mysqli_fetch_assoc($res);

    $superadmin_share = $share['superadmin_share'];
    $admin_share = $share['admin_share'];
    $master_share = $share['master_share'];
    $sa_share = $share['sa_share'];
    $agent_share = $share['agent_Share'];

    $agent_commission_type=$share['agent_commission_type'];
    $sa_commission_type=$share['sa_commission_type'];
    $master_commission_type=$share['master_commission_type'];
    $admin_commission_type=$share['admin_commission_type'];
    $superadmin_commission_type=$share['superadmin_commission_type'];

    $agent_match_commission=$share['agent_match_commission'];
    $sa_match_commission=$share['sa_match_commission'];
    $master_match_commission=$share['master_match_commission'];
    $admin_match_commission=$share['admin_match_commission'];
    $superadmin_match_commission=$share['superadmin_match_commission'];


    $agent_session_commission=$share['agent_session_commission'];
    $sa_session_commission=$share['sa_session_commission'];
    $master_session_commission=$share['master_session_commission'];
    $admin_session_commission=$share['admin_session_commission'];
    $superadmin_session_commission=$share['superadmin_session_commission'];

    $admin_amount = ($admin_share / 100) * $debit;
    $admin_amount=round($admin_amount,2);
    $superadmin_amount = ($superadmin_share / 100) * $debit;
    $superadmin_amount=round($superadmin_amount,2);
    $master_amount = ($master_share / 100) * $debit;
    $master_amount=round($master_amount,2);
    $sa_amount = ($sa_share / 100) * $debit;
    $sa_amount=round($sa_amount,2);
    $agent_amount = ($agent_share / 100) * $debit;
    $agent_amount=round($agent_amount,2);

     $insert_array=array(  
       'amount'=>$debit,
       'user_type'=>'CLIENT',
       'transaction_type'=>'D',
       'client_id'=>$clid,
       'admin_id'=>$admin_id,
       'master_id'=>$master_id,
       'superadmin_id'=>$superadmin_id,
       'agent_id'=>$agent_id,
       'sa_id'=>$sa_id,
       'remark'=>$runner_name,
       'for_bet'=>'1',
       'match_id'=>$market_id,
       'overall_type'=>'MD',
       'is_declare'=>'1',
       'match_declare'=>'1',
       'admin_share'=>$admin_share,
       'master_share'=>$master_share,
       'sa_share'=>$sa_share,
       'superadmin_share'=>$superadmin_share,
       'agent_share'=>$agent_share,
       'auto_limit'=>$auto_limit,
       'admin_amount'=>$admin_amount,
       'master_amount'=>$master_amount,
       'agent_amount'=>$agent_amount,
       'superadmin_amount'=>$superadmin_amount,
       'sa_amount'=>$sa_amount
     );
     
     $update=update_array('transaction_log',$insert_array,"client_id = '" . $clid . "'   AND overall_type = 'MD' AND match_id = '" . $market_id . "' ");
   

    $admin_amount = ($admin_share / 100) * $credit;
    $admin_amount=round($admin_amount,2);
    $superadmin_amount = ($superadmin_share / 100) * $credit;
    $superadmin_amount=round($superadmin_amount,2);
    $master_amount = ($master_share / 100) * $credit;
    $master_amount=round($master_amount,2);
    $sa_amount = ($sa_share / 100) * $credit;
    $sa_amount=round($sa_amount,2);
    $agent_amount = ($agent_share / 100) * $credit;
    $agent_amount=round($agent_amount,2);

    $insert_array=array(
       'amount'=>$credit,
       'user_type'=>'CLIENT',
       'transaction_type'=>'C',
       'client_id'=>$clid,
       'admin_id'=>$admin_id,
       'master_id'=>$master_id,
       'superadmin_id'=>$superadmin_id,
       'agent_id'=>$agent_id,
       'sa_id'=>$sa_id,
       'remark'=>$runner_name,
       'for_bet'=>'1',
       'match_id'=>$market_id,
       'overall_type'=>'MC',
       'is_declare'=>'1',
       'match_declare'=>'1',
       'admin_share'=>$admin_share,
       'master_share'=>$master_share,
       'sa_share'=>$sa_share,
       'superadmin_share'=>$superadmin_share,
       'agent_share'=>$agent_share,
       'auto_limit'=>$auto_limit,
       'admin_amount'=>$admin_amount,
       'master_amount'=>$master_amount,
       'agent_amount'=>$agent_amount,
       'superadmin_amount'=>$superadmin_amount,
       'sa_amount'=>$sa_amount
     );

     
     $insert=insert_array('transaction_log',$insert_array);

      //_dx($insert_array);
     $commission = 0;
     $com_per=$crdb['com_per'];

      //_dx($com_per);
     if ($crdb['commission_type'] == 'OM' && $crdb['debit'] > $crdb['credit'])
    {
        $com_per=($com_per/100);
        $commission = (($crdb['debit']-$crdb['credit'])*$com_per);

    }

    if ($crdb['commission_type'] == 'BB' && $crdb['debit'] > $crdb['credit'])
    {
        $com_per=($com_per/100);
        $commission = (($crdb['debit']-$crdb['credit'])*$com_per);

    }

$agent_amount=0;
$sa_amount=0;
$master_amount=0;
$admin_amount=0;
$superadmin_amount=0;

      if($agent_commission_type=='BB' && $crdb['debit'] > $crdb['credit'] ){
        $agent_match_commission=($agent_match_commission/100);
          $agent_amount=(($crdb['debit']-$crdb['credit'])*$agent_match_commission);
          $agent_amount=round($agent_amount,2);
          }
          if($agent_commission_type=='OM' && $crdb['debit'] > $crdb['credit']){
         $agent_match_commission=($agent_match_commission/100);
          $agent_amount=(($crdb['debit']-$crdb['credit'])*$agent_match_commission);
          $agent_amount=round($agent_amount,2);
         }


        if($master_commission_type=='BB' && $crdb['debit'] > $crdb['credit'] ){
        $master_match_commission=($master_match_commission/100);
          $master_amount=(($crdb['debit']-$crdb['credit'])*$master_match_commission);
          $master_amount=round($master_amount,2);
          }
        if($master_commission_type=='OM' && $crdb['debit'] > $crdb['credit']){
         $master_match_commission=($master_match_commission/100);
          $master_amount=(($crdb['debit']-$crdb['credit'])*$master_match_commission);
          $master_amount=round($master_amount,2);
          }



        if($sa_commission_type=='BB' && $crdb['debit'] > $crdb['credit'] ){
        $sa_match_commission=($sa_match_commission/100);
          $sa_amount=(($crdb['debit']-$crdb['credit'])*$sa_match_commission);
          $sa_amount=round($sa_amount,2);
          }
        if($sa_commission_type=='OM' && $crdb['debit'] > $crdb['credit']){
         $sa_match_commission=($sa_match_commission/100);
          $sa_amount=(($crdb['debit']-$crdb['credit'])*$sa_match_commission);
          $sa_amount=round($sa_amount,2);

        }

        if($admin_commission_type=='BB' && $crdb['debit'] > $crdb['credit'] ){
        $admin_match_commission=($admin_match_commission/100);
          $admin_amount=(($crdb['debit']-$crdb['credit'])*$admin_match_commission);
          $admin_amount=round($admin_amount,2);
          }
        if($admin_commission_type=='OM' && $crdb['debit'] > $crdb['credit']){
         $admin_match_commission=($admin_match_commission/100);
          $admin_amount=(($crdb['debit']-$crdb['credit'])*$admin_match_commission);
          $admin_amount=round($admin_amount,2);

        }

        if($superadmin_commission_type=='BB' && $crdb['debit'] > $crdb['credit'] ){
        $superadmin_match_commission=($superadmin_match_commission/100);
          $superadmin_amount=(($crdb['debit']-$crdb['credit'])*$superadmin_match_commission);
          $superadmin_amount=round($superadmin_amount,2);
          }
        if($superadmin_commission_type=='OM' && $crdb['debit'] > $crdb['credit']){
         $superadmin_match_commission=($superadmin_match_commission/100);
          $superadmin_amount=(($crdb['debit']-$crdb['credit'])*$superadmin_match_commission);
          $superadmin_amount=round($superadmin_amount,2);

        }

        $insert_array=array(
       
       'amount'=>$commission,
       'user_type'=>'CLIENT',
       'transaction_type'=>'C',
       'client_id'=>$clid,
       'admin_id'=>$admin_id,
       'master_id'=>$master_id,
       'superadmin_id'=>$superadmin_id,
       'agent_id'=>$agent_id,
       'sa_id'=>$sa_id,
       'remark'=>$runner_name,
       'for_bet'=>'1',
       'match_id'=>$market_id,
       'overall_type'=>'MCC',
       'is_declare'=>'1',
       'match_declare'=>'1',
       'admin_share'=>$admin_share,
       'master_share'=>$master_share,
       'sa_share'=>$sa_share,
       'superadmin_share'=>$superadmin_share,
       'agent_share'=>$agent_share,
       'auto_limit'=>$auto_limit,
       'admin_amount'=>$admin_amount,
       'master_amount'=>$master_amount,
       'agent_amount'=>$agent_amount,
       'superadmin_amount'=>$superadmin_amount,
       'sa_amount'=>$sa_amount
     );

     $insert=insert_array('transaction_log',$insert_array);

     client_tbl_update_coins($clid);

}

$send_array=array(
     'msg'=>"Decision has been update Please Update ledger"
    );
    $status='success';
   $data_to_send=array(
	'data'=>$send_array,
	'status'=>$status
);
$data=json_encode($data_to_send);
echo $data;
exit();
die;







?>