<?php
include('../include/config.php');
if (!isset($_POST)) {
	invalid();
}
$_POST = $post_array = sanatize($_POST);

$negativeValue = ['data' => ['msg' => 'Negative Value is not allowed'], 'status' => 'error'];

if (isset($post_array['update_limit']) && $post_array['update_limit'] < 0) {
	echo json_encode($negativeValue);
	exit;
}

if (isset($_POST['real_update_coins']) && $_POST['real_update_coins'] < 0) {
	echo json_encode($negativeValue);
	exit;
}
extract($_POST);
if(isset($user_id))
{
	$exist=user_exist($user_id);
}
else
{
	$exist=user_exist($client_id,true);
}


//$exist=$is_client==false?user_exist($user_id):user_exist($client_id,true);

if ($exist<1) 
{
	echo json_encode(['data' => ['msg' => 'User Does Not Exists'], 'status' => 'error']);
	exit;
}
if (isset($user_id)) {
	$amount = $update_limit = $_POST['update_limit'];
	$user_result = get_user_list('', $post_array['user_id']);
	$parent_id = $creater_id = $user_result['creater_id'];
	$return = $exist;
	if ($return == 1) {
		$update_status = update_user_coins($parent_id, $user_id, $update_limit, $operation_type);
		$status = $update_status['status'];
		$msg = $update_status['data']['msg'];
		$_SESSION['notify'] = ['type' => 'success', 'msg' => $msg];
	} else {
		$status = 'error';
		$msg = "Something went wrong";
	}
} else 
{
	if (isset($client_id)) {
		$update_status = update_client_coins($client_id, $real_update_coins, $deposit_type);
		$status = $update_status['status'];
		$msg = $update_status['data']['msg'];

		/*send_push_notification(
			$client_id,
			'client',
			[
				'title' => 'Balance Update',
				'body' => json_encode([
					'user' => $client_id,
					'total_coins' => $update_status['data']['data']['new'],
				]),
			]
		);*/
		//$_SESSION['notify']=['type'=>'success','msg'=>$msg];
	}
}

$send_array = array('msg' => $msg);
$data_to_send = array(
	'data' => $send_array,
	'status' => $status
);
$data = json_encode($data_to_send);
echo $data;
exit();
