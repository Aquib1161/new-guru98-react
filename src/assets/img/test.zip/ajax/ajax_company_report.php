<?php include('../include/config.php'); 
 $_POST=sanatize($_POST);
 $_GET=sanatize($_GET);
 extract($_POST);
 $where="AND market_id='".$market_id."'";
 $final_array=array();

 if($report_for=='self')
 {
    $where=user_where('','s').$where;

    if($_SESSION['user_type']=='admin' OR $_SESSION['user_type']=='superadmin')
    {
        $share_amount_text=$_SESSION['user_type'].'_share_value';
        $user_total_text=$_SESSION['user_type'].'_total_amount';
        $user_match_commission=$_SESSION['user_type'].'_match_commission';
        $user_session_commission=$_SESSION['user_type'].'_session_commission';
    }
    else if($_SESSION['user_type']=='superagent')
    {
        $share_amount_text='sa_share_amount';
        $user_total_text='sa_total_amount';
        $user_match_commission='sa_match_commission';
        $user_session_commission='sa_session_commission';
    }
    else
    {
        $share_amount_text=$_SESSION['user_type'].'_share_amount';
        $user_total_text=$_SESSION['user_type'].'_total_amount';
        $user_match_commission=$_SESSION['user_type'].'_match_commission';
        $user_session_commission=$_SESSION['user_type'].'_session_commission';
    }

    $get_data=get_data('md_client_position',$where,'s',"sum(client_match_coins) total_client_match_coins, sum(client_session_coins) total_client_session_coins, sum(client_match_commission) total_client_match_commission,sum(client_session_commission) total_client_session_commission,sum(".$share_amount_text.") total_company_share_value ,sum(client_mobile_charge) client_mobile_charge,sum(".$user_total_text.") user_total_amount");
    
     $send_array=array(
        'client_total_match_amount'=>$get_data['total_client_match_coins'],
        'client_total_session_amount'=>$get_data['total_client_session_coins'],
        'client_total_match_commission'=>(-1*$get_data['total_client_match_commission']),
        'client_total_session_commission'=>(-1*$get_data['total_client_session_commission']),
        'client_total_match_session_amount'=>$get_data['total_client_match_coins']+$get_data['total_client_session_coins'],
        'client_total_match_session_commission'=>-1*($get_data['total_client_match_commission']+$get_data['total_client_session_commission']),
        'client_mobile_charge'=>$get_data['client_mobile_charge'],
        'user_share_amount'=>$get_data['total_company_share_value'],
        'user_total_amount'=>$get_data['user_total_amount'],
        'user_code'=>$userdata['username'],
        'name'=>$userdata['name'],
        'user_id'=>$userdata['user_id'],
        'user_type'=>$userdata['user_type'],
        );
     array_push($final_array,$send_array);
 }
 else if($report_for=='downline')
 {
   $downline_type=priority_name(priority($user_type)-1);
   if($downline_type=='superagent')
   {
    $downline_type='sa';
   }
    if($user_type=='superagent')
   {
    $user_type='sa';
   }
   
   $get_downline_list=get_data('client_played_match',$user_type."_id='".$user_id."' AND market_id='".$market_id."' group by ".$downline_type."_id",'',$downline_type."_id");
   if($downline_type!='client'){
   foreach ($get_downline_list as $key => $downline_value) 
   {
    extract($downline_value);
    $downline_data=get_data('users_tbl',"user_id='".$downline_value[$downline_type.'_id']."'",'s',"username,name,user_id,user_type");
      if($_SESSION['user_type']=='admin' OR $_SESSION['user_type']=='superadmin')
    {
        $share_amount_text=$_SESSION['user_type'].'_share_value';
        $user_total_text=$_SESSION['user_type'].'_total_amount';
        $user_match_commission=$_SESSION['user_type'].'_match_commission';
        $user_session_commission=$_SESSION['user_type'].'_session_commission';
    }
    else if($_SESSION['user_type']=='superagent')
    {
        $share_amount_text='sa_share_amount';
        $user_total_text='sa_total_amount';
        $user_match_commission='sa_match_commission';
        $user_session_commission='sa_session_commission';
    }
    else
    {
        $share_amount_text=$_SESSION['user_type'].'_share_amount';
        $user_total_text=$_SESSION['user_type'].'_total_amount';
        $user_match_commission=$_SESSION['user_type'].'_match_commission';
        $user_session_commission=$_SESSION['user_type'].'_session_commission';
    }

    $where=$downline_type."_id='".$downline_data['user_id']."' AND market_id='".$market_id."'";
    $get_data=get_data('md_client_position',$where,'s',"sum(client_match_coins) total_client_match_coins, sum(client_session_coins) total_client_session_coins, sum(client_match_commission) total_client_match_commission,sum(client_session_commission) total_client_session_commission,sum(".$share_amount_text.") total_company_share_value ,sum(client_mobile_charge) client_mobile_charge,sum(".$user_total_text.") user_total_amount");

    $send_array=array(
        'client_total_match_amount'=>$get_data['total_client_match_coins'],
        'client_total_session_amount'=>$get_data['total_client_session_coins'],
        'client_total_match_commission'=>(-1*$get_data['total_client_match_commission']),
        'client_total_session_commission'=>(-1*$get_data['total_client_session_commission']),
        'client_total_match_session_amount'=>$get_data['total_client_match_coins']+$get_data['total_client_session_coins'],
        'client_total_match_session_commission'=>-1*($get_data['total_client_match_commission']+$get_data['total_client_session_commission']),
        'client_mobile_charge'=>$get_data['client_mobile_charge'],
        'user_share_amount'=>$get_data['total_company_share_value'],
        'user_total_amount'=>$get_data['user_total_amount'],
        'user_code'=>$downline_data['username'],
        'name'=>$downline_data['name'],
        'user_id'=>$downline_data['user_id'],
        'user_type'=>$downline_data['user_type'],
        );
     array_push($final_array,$send_array);
       
   }
  }
  else
  {
     
     foreach ($get_downline_list as $key => $downline_value) 
   {
    extract($downline_value);
    $downline_data=get_data('client',"id='".$downline_value['client_id']."'",'s',"username,ClientName,id");
    $where="client_id='".$downline_value['client_id']."' AND market_id='".$market_id."'";
    $get_data=get_data('md_client_position',$where,'s',"sum(client_match_coins) total_client_match_coins, sum(client_session_coins) total_client_session_coins, sum(client_match_commission) total_client_match_commission,sum(client_session_commission) total_client_session_commission,sum(client_mobile_charge) client_mobile_charge");

    $send_array=array(
        'client_total_match_amount'=>$get_data['total_client_match_coins'],
        'client_total_session_amount'=>$get_data['total_client_session_coins'],
        'client_total_match_commission'=>(-1*$get_data['total_client_match_commission']),
        'client_total_session_commission'=>(-1*$get_data['total_client_session_commission']),
        'client_total_match_session_amount'=>$get_data['total_client_match_coins']+$get_data['total_client_session_coins'],
        'client_total_match_session_commission'=>-1*($get_data['total_client_match_commission']+$get_data['total_client_session_commission']),
        'client_mobile_charge'=>$get_data['client_mobile_charge'],
        'user_share_amount'=>0,
        'user_total_amount'=>0,
        'user_code'=>$downline_data['username'],
        'name'=>$downline_data['ClientName'],
        'user_id'=>$downline_data['id'],
        'user_type'=>'client',
        );
     array_push($final_array,$send_array);
       
   } 
  }
 }



        $overall_client_total_match_amount=0; 
        $overall_client_total_session_amount=0; 
        $overall_client_total_match_session_amount=0;
        $overall_client_total_match_commission=0;
        $overall_client_total_session_commission=0;
        $overall_client_total_match_session_commission=0;
        $overall_total_amount=0;
        $overall_user_total_amount=0;
        $overall_user_share_amount=0;


?>
<style type="text/css">
   
table,thead,th,tr {
   background-color: white !important;
}


th {
   background-color: #322E73 !important;
   color: white !important;
}


</style>

 <div class="px-0 px-md-2 mx-0 row">
    <div class="col-container company_report_table col">
        <div class="infinite-scroll-component__outerdiv">
            <div class="infinite-scroll-component" style="height: auto; overflow: auto;">
                <div class="table-responsive">
                    <table class="mt-3 betslip table table-bordered table-striped ">
                        
                        <thead>
                        
                            <tr style="background-color: white;">
                                <th>Code</th>
                                <th>Match Amt</th>
                                <th>Session Amt</th>
                                <th>Total</th>
                                <th>Match Comm+</th>
                                <th>Session Comm+</th>
                                <th>Total Comm</th>
                                <th>Total Amount</th>
                                <th>My Share</th>
                                <th>M.App</th>
                                <th>Net Amount</th>
                                </tr>
                        </thead>


<tbody>
                            <?php foreach ($final_array as $key => $report_value) { 
                                extract($report_value);

                                $total_amount=$client_total_match_session_amount+$client_total_match_session_commission;
            
                            ?>
                      
                            <tr>
                                <?php if($user_type!='client') {?>
                                <td style="cursor: pointer;" onclick="change('<?= $user_id ?>','<?= $user_type ?>')"><strong><?= $name ?> (<?= $user_code ?>)</strong></td>
                            <?php } else{?>

                                <td><strong><?= $name ?> (<?= $user_code ?>)</strong></td>

                            <?php } ?>


                                <td><?= color(number_format($client_total_match_amount,2)) ?></td>
                                <td><?= color(number_format($client_total_session_amount,2)) ?></td>
                                <td><?= color(number_format($client_total_match_session_amount,2)) ?></td>
                                <td><?= color(number_format($client_total_match_commission,2)) ?></td>
                                <td><?= color(number_format($client_total_session_commission,2)) ?></td>
                                <td><?= color(number_format($client_total_match_session_commission,2)) ?></td>
                                <td><?= color(number_format($total_amount,2)) ?></td>
                                <td><?= color(number_format($user_total_amount,2)) ?></td>
                                <td><?= color(number_format(0,2)) ?></td>
                                <td><?= color(number_format($user_share_amount,2)) ?></td>
                            </tr>


                
                              <?php 
        $overall_client_total_match_amount+=$client_total_match_amount; 
        $overall_client_total_session_amount+=$client_total_session_amount; 
        $overall_client_total_match_session_amount+=$client_total_match_session_amount;
        $overall_client_total_match_commission+=$client_total_match_commission;
        $overall_client_total_session_commission+=$client_total_session_commission;
        $overall_client_total_match_session_commission+=$client_total_match_session_commission;
        $overall_total_amount+=$total_amount;
        $overall_user_total_amount+=$user_total_amount;
        $overall_user_share_amount+=$user_share_amount;





                          } ?>
                                
                        </tbody>

                   

                        <tfoot>

                            <tr>
                                <td style="background-color:#D5DC66;"><strong>Total</strong></td>
                                <td style="background-color:#D5DC66;"><?= color(number_format($overall_client_total_match_amount,2)) ?></td>
                                <td style="background-color:#D5DC66;"><?= color(number_format($overall_client_total_session_amount,2)) ?></td>
                                <td style="background-color:#D5DC66;"><?= color(number_format($overall_client_total_match_session_amount,2)) ?></td>
                                <td style="background-color:#D5DC66;"><?= color(number_format($overall_client_total_match_commission,2)) ?></td>
                                <td style="background-color:#D5DC66;"><?= color(number_format($overall_client_total_session_commission,2)) ?></td>
                                <td style="background-color:#D5DC66;"><?= color(number_format($overall_client_total_match_session_commission,2)) ?></td>
                                <td style="background-color:#D5DC66;"><?= color(number_format($overall_total_amount,2)) ?></td>
                                <td style="background-color:#D5DC66;"><?= color(number_format($overall_user_total_amount,2)) ?></td>
                                <td style="background-color:#D5DC66;"><?= color(number_format(0,2)) ?></td>
                                <td style="background-color:#D5DC66;"><?= color(number_format($overall_user_share_amount,2)) ?></td>
                            </tr>
                        </tfoot>
                        
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>