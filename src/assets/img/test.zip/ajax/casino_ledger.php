<?php
include('../include/config.php');
 $_POST=sanatize($_POST);
 $_GET=sanatize($_GET);
$date=_date();
if(isset($_POST['date']))
{
	$date=date("d-m-Y", strtotime($_POST['date']));
}

_dx($_POST);
/*
if(!isset($_SESSION['password_verify']))
{

    $send_array=array(
     'msg'=>"Password Not Verified"
    );

    $status='error';
    $data_to_send=array(
    'data'=>$send_array,
    'status'=>$status
);
    $data=json_encode($data_to_send);
    echo $data;
    exit();
}
unset($_SESSION['password_verify']);*/

$game_market_id=sha1($date.rand(1111,999999));





if($_POST['casino_type']=='Teen Pati t20')
{        
	    $query="DELETE FROM ledger WHERE ledger_type='TEENPATTI T20' AND date='".$date."'";
	    mysqli_query($con,$query);
	    $query="DELETE FROM user_ledger WHERE ledger_type='TEENPATTI T20' AND create_date='".$date."'";
	    mysqli_query($con,$query);
	    $query="DELETE FROM transaction_log WHERE casino_type='TEENPATTI T20' AND overall_type='CCC' AND bet_date='".$date."'";
	    mysqli_query($con,$query);
	    $query="DELETE FROM md_client_position WHERE position_type='TEENPATTI T20' AND ledger_date='".$date."'";
	    mysqli_query($con,$query);
	    $update_array=array(
	    	'decision_status'=>0
	    );
	    update_array('casino_bet_tbl',$update_array,"casino_type='TEENPATTI T20' date='".$date."'");
		$client_array=get_data('casino_bet_tbl',"casino_type='TEENPATTI T20' AND deleted_status=0 AND date='".$date."'",'','client_id,client_detail_array');
		$client_data=array();
		foreach ($client_array as $key => $client_value)
		{
		    if (!array_key_exists($client_value['client_id'], $client_value))
		    {
		            $client_data[$client_value['client_id']] = array(
		                           "client_detail_array" => $client_value['client_detail_array']
		               );
		    }
		}

		


		foreach ($client_data as $key => $value) 
		{    
			
			$client_id=$key;

			$share_array=get_data('client',"id='".$key."'",'s','share_array');
			$share_array=json_decode($share_array['share_array'],true);

			/*$share_array=get_share_array($value['client_detail_array']);*/
		

			$credit=get_data('transaction_log',"client_id='".$client_id."' AND casino_type='TEENPATTI T20' AND event_id='2222' AND bet_date='".$date."' AND transaction_type='C'",'s','SUM(amount)total_amount');

			$debit=get_data('transaction_log',"client_id='".$client_id."' AND casino_type='TEENPATTI T20' AND event_id='2222' AND bet_date='".$date."' AND transaction_type='D'",'s','SUM(amount) total_amount');
			

			$total_amount=$credit['total_amount']-$debit['total_amount'];
			$client_share=$share_array['client_share_array'];
			$agent_id=$share_array['agent_share_array']['agent_id'];
			$superagent_id=$share_array['superagent_share_array']['superagent_id'];
			$master_id=$share_array['master_share_array']['master_id'];
			$admin_id=$share_array['admin_share_array']['admin_id'];
			$superadmin_id=$share_array['superadmin_share_array']['superadmin_id'];
			$client_commission=0;
			if($total_amount<0)
			{   
				$client_commission=abs($total_amount*$client_share['client_casino_comm']/100);
				$transaction_array=array(
	 		  	'amount'=>round($client_commission,2),
			  	'transaction_type'=>'C',  
			  	'overall_type'=>'CCC',  // casino commission credited
			  	'transaction_for'=>'CASINO',
			  	'share_array'=>json_encode($share_array),
			  	'date'=>_date_time(),
			  	'bet_date'=>$date,
			  	'for_bet'=>1,
			  	'user_type'=>'CLIENT',
			  	'client_id'=>$client_id,
			  	'agent_id'=>$agent_id,
			  	'superagent_id'=>$superagent_id,
			  	'sa_id'=>$superagent_id,
			  	'master_id'=>$master_id,
			  	'admin_id'=>$admin_id,
			  	'superadmin_id'=>$superadmin_id,
			  	'casino_type'=>'TEENPATTI T20',
			  	'is_declare'=>1,
 		    );
			 $insert=insert_array('transaction_log',$transaction_array);
			}

			$ledger_amount=round(($total_amount+$client_commission),2);
			if($ledger_amount<0)
			{
				$transaction_type='D';
			}
			else
			{
				$transaction_type='C';
			}
						
			$client_ledger=array(
				'client_id'=>$client_id,
				'market_id'=>$game_market_id,
			  	'agent_id'=>$agent_id,
			  	'sa_id'=>$superagent_id,
			  	'master_id'=>$master_id,
			  	'admin_id'=>$admin_id,
			  	'superadmin_id'=>$superadmin_id,
			  	'amount'=>abs($ledger_amount),
			  	'actual_minus_plus'=>$total_amount,
			  	'date'=>$date,
			  	's_date'=>$date,
			  	'payment_type'=>$transaction_type,
			  	'ledger_type'=>'TEENPATTI T20',
			  	'share_array'=>json_encode($share_array),
			  	'match_name'=>'TEENPATTI T20 '.'('.$date.')'
			);
			$insert_ledger=insert_array('ledger',$client_ledger);

            // insert position code
			$amount=$total_amount;
			$client_match_coins=$amount;

			$agent_match_commission=0;
			$sa_match_commission=0;
			$master_match_commission=0;
			$admin_match_commission=0;
			$superadmin_match_commission=0;
			$client_match_commission=0;
			if($amount<0)
			{
				$client_match_commission=($amount*$share_array['client_share_array']['client_casino_comm']/100);

				$agent_match_commission=($amount*$share_array['agent_share_array']['agent_casino_comm']/100*$share_array['agent_share_array']['agent_dena_casino_share']/100); //itna comm milega agent ko upper se

				$sa_match_commission=($amount*$share_array['superagent_share_array']['superagent_casino_comm']/100*$share_array['superagent_share_array']['superagent_dena_casino_share']/100); //itna comm milega agent ko upper se

				$master_match_commission=($amount*$share_array['master_share_array']['master_casino_comm']/100*$share_array['master_share_array']['master_dena_casino_share']/100); //itna comm milega agent ko upper se


				$admin_match_commission=($amount*$share_array['admin_share_array']['admin_casino_comm']/100*$share_array['admin_share_array']['admin_dena_casino_share']/100); //itna comm milega agent ko upper se

				$superadmin_match_commission=($amount*$share_array['superadmin_share_array']['superadmin_casino_comm']/100*$share_array['superadmin_share_array']['superadmin_dena_casino_share']/100); //itna comm milega agent ko upper se
				
			}


			$total_agent_profit=($share_array['agent_share_array']['agent_self_casino_share']*$amount/100);
			$agent_total_amount=($share_array['agent_share_array']['agent_casino_share']*$amount/100);

			$agent_share_amount=($share_array['agent_share_array']['agent_dena_share']*$amount/100);

			$total_sa_profit=($share_array['superagent_share_array']['superagent_self_casino_share']*$amount/100);
			$sa_total_amount=($share_array['superagent_share_array']['superagent_casino_share']*$amount/100);
			$sa_share_amount=($share_array['superagent_share_array']['superagent_dena_share']*$amount/100);

			$total_master_profit=($share_array['master_share_array']['master_self_casino_share']*$amount/100);
			$master_total_amount=($share_array['master_share_array']['master_casino_share']*$amount/100);
			$master_share_amount=($share_array['master_share_array']['master_dena_share']*$amount/100);

			$total_admin_profit=($share_array['admin_share_array']['admin_self_casino_share']*$amount/100);
			$admin_total_amount=($share_array['admin_share_array']['admin_casino_share']*$amount/100);
			$admin_share_amount=($share_array['admin_share_array']['admin_dena_share']*$amount/100);


			$total_superadmin_profit=($share_array['superadmin_share_array']['superadmin_self_casino_share']*$amount/100);
			$superadmin_total_amount=($share_array['superadmin_share_array']['superadmin_casino_share']*$amount/100);
			$superadmin_share_amount=($share_array['superadmin_share_array']['superadmin_dena_share']*$amount/100);

			$insert_array=array(
				'market_id'=>$game_market_id,
				'position_type'=>'TEENPATTI T20',
				'ledger_date'=>$date,
				'agent_id'=>$client_ledger['agent_id'],
				'sa_id'=>$client_ledger['sa_id'],
				'master_id'=>$client_ledger['master_id'],
				'admin_id'=>$client_ledger['admin_id'],
				'client_id'=>$client_ledger['client_id'],
				'superadmin_id'=>$client_ledger['superadmin_id'],
				'client_match_coins'=>$client_match_coins,
				'total_agent_profit'=>$total_agent_profit,
				'agent_total_amount'=>$agent_total_amount,
				'agent_share_amount'=>$agent_share_amount,
				'total_sa_profit'=>$total_sa_profit,
				'sa_total_amount'=>$sa_total_amount,
				'sa_share_amount'=>$sa_share_amount,
				'total_master_profit'=>$total_master_profit,
				'master_total_amount'=>$master_total_amount,
				'master_share_amount'=>$master_share_amount,
				'total_admin_profit'=>$total_admin_profit,
				'admin_total_amount'=>$admin_total_amount,
				'admin_share_amount'=>$admin_share_amount,
				'total_superadmin_profit'=>$total_superadmin_profit,
				'superadmin_total_amount'=>$superadmin_total_amount,
				'client_match_commission'=>abs($client_match_commission),
				'agent_match_commission'=>abs($agent_match_commission),
				'sa_match_commission'=>abs($sa_match_commission),
				'master_match_commission'=>abs($master_match_commission),
				'admin_match_commission'=>abs($admin_match_commission),
				'superadmin_match_commission'=>abs($superadmin_match_commission)
			);

			
		
			$insert_array['array_data']=json_encode($insert_array);
			$insert=insert_array('md_client_position',$insert_array);
			

		}



		$agent_data=get_data('md_client_position',"position_type='TEENPATTI T20' AND agent_id!=0 AND ledger_date='".$date."' group by agent_id",'',"agent_id");
		$sa_data=get_data('md_client_position',"position_type='TEENPATTI T20' AND sa_id!=0 AND ledger_date='".$date."' group by sa_id",'',"sa_id");
		$master_data=get_data('md_client_position',"position_type='TEENPATTI T20' AND master_id!=0 AND ledger_date='".$date."' group by master_id",'',"master_id");
		$admin_data=get_data('md_client_position',"position_type='TEENPATTI T20' AND admin_id!=0 AND ledger_date='".$date."' group by admin_id",'',"admin_id");
		$superadmin_data=get_data('md_client_position',"position_type='TEENPATTI T20' AND superadmin_id!=0 AND ledger_date='".$date."' group by superadmin_id",'',"superadmin_id");


		foreach ($agent_data as $key => $agent_value) 
		{   
			$agent_share_amount=0;
			$agent_id=$agent_value['agent_id'];
			$agent_amount=get_data('md_client_position',"position_type='TEENPATTI T20' AND agent_id!=0 AND ledger_date='".$date."' AND market_id='".$game_market_id."'",'s',"sum(agent_share_amount) agent_share_amount,sum(agent_match_commission) agent_casino_commission");
			$agent_share_amount=$agent_amount['agent_share_amount'];
			$agent_casino_commission=$agent_amount['agent_casino_commission'];

			$agent_share_amount=round(($agent_share_amount+$agent_casino_commission),2);

			$transaction_type=$agent_share_amount<0?'D':'C';
			$remark=$agent_share_amount<0?'agent minus':'agent plus';

			$agent_insert_array=array(
				'user_id'=>$agent_id,
				'market_id'=>$game_market_id,
				'user_type'=>'agent',
				'create_date'=>$date,
				'amount'=>abs($agent_share_amount),
				'actual_minus_plus'=>($agent_share_amount),
				'transaction_type'=>$transaction_type,
				'match_name'=>'TEENPATTI T20 '.'('.$date.')',
				'remark'=>$remark,
				'ledger_type'=>'TEENPATTI T20',
				'ledger_date'=>$date,
				'share_array'=>json_encode($share_array),
				'ledger_status'=>1,
			);
			
			$agent_insert=insert_array('user_ledger',$agent_insert_array);
		}

		foreach ($sa_data as $key => $sa_value) 
		{    
			$sa_share_amount=0;
			$sa_id=$sa_value['sa_id'];
			$sa_amount=get_data('md_client_position',"position_type='TEENPATTI T20' AND sa_id!=0 AND ledger_date='".$date."' AND market_id='".$game_market_id."'",'s',"sum(sa_share_amount) sa_share_amount,sum(sa_match_commission) sa_casino_commission");
			$sa_share_amount=$sa_amount['sa_share_amount'];
			$sa_casino_commission=$sa_amount['sa_casino_commission'];

			$sa_share_amount=round(($sa_share_amount+$sa_casino_commission),2);

			$transaction_type=$sa_share_amount<0?'D':'C';
			$remark=$sa_share_amount<0?'Superagent minus':'Superagent plus';

			$sa_insert_array=array(
				'user_id'=>$sa_id,
				'market_id'=>$game_market_id,
				'user_type'=>'superagent',
				'create_date'=>$date,
				'amount'=>abs($sa_share_amount),
				'actual_minus_plus'=>($sa_share_amount),
				'transaction_type'=>$transaction_type,
				'match_name'=>'TEENPATTI T20 '.'('.$date.')',
				'remark'=>$remark,
				'ledger_type'=>'TEENPATTI T20',
				'ledger_date'=>$date,
				'share_array'=>json_encode($share_array),
				'ledger_status'=>1,
			);
			
			$sa_insert=insert_array('user_ledger',$sa_insert_array);
		}

		foreach ($master_data as $key => $master_value) 
		{    $master_share_amount=0;
			$master_id=$master_value['master_id'];
			$master_amount=get_data('md_client_position',"position_type='TEENPATTI T20' AND master_id!=0 AND ledger_date='".$date."' AND market_id='".$game_market_id."'",'s',"sum(master_share_amount) master_share_amount,sum(master_match_commission) master_casino_commission");
			$master_share_amount=$master_amount['master_share_amount'];
			$master_casino_commission=$master_amount['master_casino_commission'];

			$master_share_amount=round(($master_share_amount+$master_casino_commission),2);

			$transaction_type=$master_share_amount<0?'D':'C';
			$remark=$master_share_amount<0?'master minus':'master plus';

			$master_insert_array=array(
				'user_id'=>$master_id,
				'market_id'=>$game_market_id,
				'user_type'=>'master',
				'create_date'=>$date,
				'amount'=>abs($master_share_amount),
				'actual_minus_plus'=>($master_share_amount),
				'transaction_type'=>$transaction_type,
				'match_name'=>'TEENPATTI T20 '.'('.$date.')',
				'remark'=>$remark,
				'ledger_type'=>'TEENPATTI T20',
				'ledger_date'=>$date,
				'share_array'=>json_encode($share_array),
				'ledger_status'=>1,
			);
			
			$master_insert=insert_array('user_ledger',$master_insert_array);
		}


		foreach ($admin_data as $key => $admin_value) 
		{
			$admin_id=$admin_value['admin_id'];
			$admin_amount=get_data('md_client_position',"position_type='TEENPATTI T20' AND admin_id!=0 AND ledger_date='".$date."' AND market_id='".$game_market_id."'",'s',"sum(admin_share_amount) admin_share_amount,sum(admin_match_commission) admin_casino_commission");
			$admin_share_amount=$admin_amount['admin_share_amount'];
			$admin_casino_commission=$admin_amount['admin_casino_commission'];

			$admin_share_amount=round(($admin_share_amount+$admin_casino_commission),2);

			$transaction_type=$master_share_amount<0?'D':'C';
			$remark=$master_share_amount<0?'master minus':'master plus';

			$transaction_type=$admin_share_amount<0?'D':'C';
			$remark=$admin_share_amount<0?'admin minus':'admin plus';

			$admin_insert_array=array(
				'user_id'=>$admin_id,
				'market_id'=>$game_market_id,
				'user_type'=>'admin',
				'create_date'=>$date,
				'amount'=>abs($admin_share_amount),
				'actual_minus_plus'=>($admin_share_amount),
				'transaction_type'=>$transaction_type,
				'match_name'=>'TEENPATTI T20 '.'('.$date.')',
				'remark'=>$remark,
				'ledger_type'=>'TEENPATTI T20',
				'ledger_date'=>$date,
				'share_array'=>json_encode($share_array),
				'ledger_status'=>1,
			);
			
			$admin_insert=insert_array('user_ledger',$admin_insert_array);
		}

		foreach ($superadmin_data as $key => $superadmin_value) 
		{
			$superadmin_id=$superadmin_value['superadmin_id'];
			$superadmin_amount=get_data('md_client_position',"position_type='TEENPATTI T20' AND superadmin_id!=0 AND ledger_date='".$date."' AND market_id='".$game_market_id."'",'s',"sum(superadmin_match_commission) superadmin_casino_commission");
			$superadmin_share_amount=0;
			$superadmin_casino_commission=$superadmin_amount['superadmin_casino_commission'];

			$superadmin_share_amount=round(($superadmin_share_amount+$superadmin_casino_commission),2);

			$transaction_type=$superadmin_share_amount<0?'D':'C';
			$remark=$superadmin_share_amount<0?'superadmin minus':'superadmin plus';

			$superadmin_insert_array=array(
				'user_id'=>$superadmin_id,
				'market_id'=>$game_market_id,
				'user_type'=>'superadmin',
				'create_date'=>$date,
				'amount'=>abs($superadmin_share_amount),
				'actual_minus_plus'=>($superadmin_share_amount),
				'transaction_type'=>$transaction_type,
				'match_name'=>'TEENPATTI T20 '.'('.$date.')',
				'remark'=>$remark,
				'ledger_type'=>'TEENPATTI T20',
				'ledger_date'=>$date,
				'share_array'=>json_encode($share_array),
				'ledger_status'=>1,
			);
			$superadmin_insert=insert_array('user_ledger',$superadmin_insert_array);
		}
		$game_count=count_data('upcoming_match',"game_type='TEENPATTI T20' AND 	uploading_date='".$date."'");
		if($game_count==0)
		{
			$insert_array=array(
				'game_type'=>'TEENPATTI T20',
				'uploading_date'=>$date,
				'status'=>'COMPLETED',
				'match_type'=>'T20',
				'match_date'=>_date_time(),
				'market_id'=>$game_market_id,
				'match_name'=>'TEENPATTI T20 ('.$date.')',
			);
			$insert=insert_array('upcoming_match',$insert_array);
			$insert_id=$insert['insert_id'];
			$update_array=array(
				'game_id'=>$game_market_id,
				'decision_status'=>1,
				'ledger_id'=>$insert_id
			);
			$update=update_array('casino_bet_tbl',$update_array,"casino_type='TEENPATTI T20' AND date='".$date."'");

		}
		else
		{
          
           $game_data=get_data('upcoming_match',"game_type='TEENPATTI T20' AND 	uploading_date='".$date."'",'s',"id");
           $upcoming_id=$game_data['id'];

           $update_array=array(
				'game_id'=>$game_market_id,
				'decision_status'=>1,
				'ledger_id'=>$upcoming_id
			);
			$update=update_array('casino_bet_tbl',$update_array,"casino_type='TEENPATTI T20' AND date='".$date."'");

			$update_array=array(
				'market_id'=>$game_market_id,
			);
			$update=update_array('upcoming_match',$update_array,"id='".$upcoming_id."'");

		}


		$send_array=array(
		     'msg'=>"TEENPATTI T20 Ledger has been generated successfully"
		    );
		    $status='success';
		    $data_to_send=array(
		    'data'=>$send_array,
		    'status'=>$status
		);
		$data=json_encode($data_to_send);
		echo $data;
		exit();
		die;



}
		
		



?>

