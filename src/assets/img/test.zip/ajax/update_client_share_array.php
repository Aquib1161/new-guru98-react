<?php
include('config.php');
$post_data=sanatize($_POST);
$get_data=sanatize($_GET);
extract($post_data);
extract($get_data);
  if (!isset($_SESSION['password_verify'])) {
   $send_array=array(
     'msg'=>"Something went wrong"
    );

    $status='error';
    $data_to_send=array(
   'data'=>$send_array,
   'status'=>$status
);
   $data=json_encode($data_to_send);
   echo $data;
   exit();
}
unset($_SESSION['password_verify']);

$client_data=get_data('client');

foreach ($client_data as $key => $client_value) 
{
   $share_update=client_share_array_update($client_value['id']); 
}
$data_to_send=array(
    'status'=>'success',
    'msg'=>'ok'
);
$data=json_encode($data_to_send);
echo $data;
exit();
die;
?>
