<?php
include('config.php');
$post_data=sanatize($_POST);
$get_data=sanatize($_GET);
extract($post_data);
extract($get_data);


if(isset($type) AND $type=='fix_limit')
{   $user_result=get_user_list('',$user_id);
	$update_array=array('fix_limit'=>$post_data['fix_limit']);
	$where="user_id='".$post_data['user_id']."'";
	$update_data=update_array('users_tbl',$update_array,$where);
	if($update_data['error']==0)
	{
		$send_array=array('msg'=>'Fix Limit Updated Successfully');
		$status='success';
	}
	else
	{
		$send_array=array('msg'=>'Something went wrong');
		$status='error';
	}

	$task_array=array(
	'user_id'=>$user_id,
	'note'=>'Fix Limit',
	'fix_limit'=>$post_data['fix_limit'],
    'user_type'=>$user_result['user_type'],
    'user_match_comm'=>$user_result['user_match_comm'],
    'user_session_comm'=>$user_result['user_session_comm'],
    'user_share'=>$user_result['user_share'],
    'task_name'=>'Fix Limit'.' '.$user_result['user_type'],
    'creater_id'=>$_SESSION['user_id'],
    'creater_type'=>$_SESSION['user_type'],
    'creater_name'=>$_SESSION['name'],
    'ip'=>ip(),
    'date'=>_date(),
    'date_time'=>_date_time(),
    'user_name'=>$user_result['name']
);
$result=insert_array('user_history_log',$task_array,'');
}


if(isset($type) AND $type=='match_update')
{   

	$parent_result=get_user_list('',$user_id);
	if($parent_result['user_type']=='admin')
	{   
        $data=array('user_id'=>$user_id,'user_type'=>$parent_result['user_type'],'user_status'=>1,'market_id'=>$market_id,'user_status'=>$status);
        $where="user_id='".$user_id."' AND market_id='".$market_id."'";
		$value=update_array('master_permission', $data, $where);
		if($value['error']==0)
		{
		$send_array=array('msg'=>'Status Updated Successfully');
		$status='success';
		}
		else
		{
		$send_array=array('msg'=>'Something went wrong');
		$status='error';
		}
		
	}
	else
	{
     $send_array=array('msg'=>'User not correct');
	 $status='error';
	}
}

if(isset($type) AND $type=='client_limit_update')
{   
	$client_details=get_data('client',"id='".$client_id."'",'single');
	$parent_id=$creater_id=$client_details['creater_id'];
	$parent_details=get_data('users_tbl',"user_id='".$creater_id."'",'s');
	$user_id=$userdata['user_id'];
	$user_fix_limit=$parent_details['fix_limit'];
	$parent_coin=$user_coin=call_total_coins($parent_details['user_type'],$parent_details['user_id']);

	$rest_user_coin=$user_coin;
   
	$client_coins=used_limit($client_details['id']);
	$client_total_coins=$client_coins['total_coins'];

	

	$client_used_limit=$client_coins['total_used_coins'];
	$client_update_limit=$update_limit;
	$status='success';

	if($update_limit<$client_used_limit)
	{
		$status='error';
		$send_array=array('msg'=>'Client coins can not be less than bloked limit','coins'=>$client_total_coins);
	}

	if($update_limit>$fix_limit)
	{
		$status='error';
		$send_array=array('msg'=>'Update coins can not be greather than fix limit','coins'=>$client_total_coins);
	}
	if($update_limit>$user_fix_limit)
	{
		$status='error';
		$send_array=array('msg'=>'Client coins can not be grether than '.$_SESSION['user_type'].' fix limit','coins'=>$client_total_coins);
	}

	if($_SESSION['user_type']!='superadmin')
	{

	if(($update_limit-$client_total_coins)>$rest_user_coin)
	{
		$status='error';
		$send_array=array('msg'=>'You have '.$rest_user_coin.' Coins Please update coins for update client limit ! Thank you','coins'=>$client_total_coins);
	}
   }
    
    $real_update_limit=$update_limit-$client_total_coins-$client_coins['total_used_coins'];
	$transaction_type = $real_update_limit<0 ? 'D' : 'C';
	if($transaction_type=='D')
	{
		  $real_update_limit=-1*$real_update_limit;
	}

	if($status!='error')
	{
     
     $transaction_array=array(
	'transaction_type'=>$transaction_type,
	'amount'=>$real_update_limit,
	'user_type'=>'client',
	'admin_id'=>$client_details['admin_id'],
	'superadmin_id'=>$client_details['superadmin_id'],
	'master_id'=>$client_details['master_id'],
	'agent_id'=>$client_details['agent_id'],
	'sa_id'=>$client_details['superagent_id'],
	'client_id'=>$client_id,
	'given_by'=>$parent_details['user_type'],
	'given_id'=>$parent_details['user_id'],
	'for_bet'=>'0',
	'remark'=>'Update '.$update_limit.' coins',
	'note'=>'Update Coins',
	'overall_type'=>'agent'
);
     //_dx($transaction_array);
$result=insert_array('transaction_log',$transaction_array,'');
$update_array=array('FixLimit'=>$_POST['fix_limit']);
$update=update_array('client',$update_array,"id='".$_POST['client_id']."'");

if (!empty($client_detail)) {
    $AutoLimit = $client_detail['AutoLimit'];
	}else
	{
		  $AutoLimit = '';
	}
  
  $auto_limit=get_data('autolimit_tbl','client_id='.$client_id,'single');
  $autolimit_data=array(
  	'max_autolimit'=>$update_limit,
  	'autolimit_status'=>$AutoLimit,
  	'client_id'=>$client_id,
  	'agent_id'=>$client_details['agent_id'],
  	'master_id'=>$client_details['master_id'],
  	'sa_id'=>$client_details['sa_id'],
  	'superadmin_id'=>$client_details['superadmin_id'],
  	'admin_id'=>$client_details['admin_id'],

  );
  if(!empty($auto_limit))
  {  
     $update=update_array('autolimit_tbl',$autolimit_data,'client_id'.$client_id);

  }
  else
  {
  	$insert=insert_array('autolimit_tbl',$autolimit_data);
  }
  $task_array=array(
	'user_id'=>$user_id,
	'note'=>'Update Limit From'.$client_total_coins.' to'.$update_limit,
	'amount'=>$update_limit,
    'user_type'=>'client',
    'user_match_comm'=>$client_details['MatchCommissionClient'],
    'user_session_comm'=>$client_details['SessionCommissionClient'],
    'user_share'=>$client_details['MatchShare'],
    'task_name'=>$client_details['ClientName'].'('.$client_details['ClientCode'].')',
    'creater_id'=>$_SESSION['user_id'],
    'creater_type'=>$_SESSION['user_type'],
    'creater_name'=>$_SESSION['name'],
    'ip'=>ip(),
    'date'=>_date(),
    'date_time'=>_date_time(),
    'user_name'=>$client_details['ClientName'].'('.$client_details['ClientCode'].')'
);
$result=insert_array('user_history_log',$task_array,'');

        $status='success';
		$send_array=array('msg'=>'Coins has been updated successfully','coins'=>$update_limit);
}

}

$data_to_send=array(
	'data'=>$send_array,
	'status'=>$status
);
$data=json_encode($data_to_send);
echo $data;

?>