<?php include('../include/config.php'); 
 $_POST=sanatize($_POST);
 $_GET=sanatize($_GET);
$market_id=$_POST['market_id'];

//_dx($_POST);

 if(isset($_POST['manual_type']) AND $_POST['manual_type']=='kirti')
{   
	$selection_id=$_POST['selection_id'];
	unset($_POST['manual_type']);
	unset($_POST['selection_id']);
	$update=update_array('match_team_tbl',$_POST,"selection_id='".$selection_id."' AND market_id='".$_POST['market_id']."'");
}

   if(isset($_POST['odds_hard_lock']))
{
	$odds_hard_lock=$_POST['odds_hard_lock'];
	$query = "UPDATE market_price SET odds_hard_lock = '$odds_hard_lock' WHERE market_id = '".$_POST['market_id']."'";									
	$res = mysqli_query($con, $query);
}

  if(isset($_POST['match_range']))
{
	$match_range=$_POST['match_range'];
	$query = "UPDATE market_price SET match_range = '$match_range' WHERE market_id = '".$_POST['market_id']."'";									
	$res = mysqli_query($con, $query);
}

if(isset($_POST['khaai']))
{
	$khaai=$_POST['khaai'];
	$lggai=$_POST['lggai'];
	$query = "UPDATE market_price SET fav_khai = '$khaai',fav_lgai = '$lggai' WHERE market_id = '".$_POST['market_id']."'";	
	//_dx($query);								
	$res = mysqli_query($con, $query);
}

if(isset($_POST['both_status']) AND $_POST['both_status']=='both'){
	$match_status=$_POST['status'];
    $status = $_POST['status'];
	$market_id = $_POST['market_id'];
	$query = "UPDATE market_price SET api_active='$status' WHERE market_id = $market_id";	
	mysqli_query($con, $query) ;	
	$query = "UPDATE session_crick_tbl SET play_status ='$status' WHERE market_id = $market_id";
	mysqli_query($con, $query);
	$query = "UPDATE upcoming_match SET session_status ='$status' WHERE market_id = $market_id";	
    mysqli_query($con, $query);
}

if(isset($_POST['both_status']) AND $_POST['both_status']=='session'){
    $status = $_POST['status'];
	$market_id = $_POST['market_id'];
	$query = "UPDATE session_crick_tbl SET play_status =$status WHERE market_id = $market_id";
	mysqli_query($con, $query);
	$query = "UPDATE upcoming_match SET session_status =$status WHERE market_id = $market_id";	
	mysqli_query($con, $query) ;
}

if(isset($_POST['both_status']) AND $_POST['both_status']=='match'){
	$status = $_POST['status'];
	$market_id = $_POST['market_id'];
	$query = "UPDATE market_price SET api_active = $status WHERE market_id = $market_id";	
	mysqli_query($con, $query) ;
}


$send_array=array('msg'=>'Status Updated');
$status='success';
$data_to_send=array(
	'data'=>$send_array,
	'status'=>$status
);
$data=json_encode($data_to_send);
echo $data;
?>