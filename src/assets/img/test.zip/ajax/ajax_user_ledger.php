<?php include('../include/config.php'); 
 $_POST=sanatize($_POST);
 $_GET=sanatize($_GET);
$user_result=get_user_list('',$_POST['id']);
extract($user_result);
$where="user_id='".$_POST['id']."' ";

if(isset($_POST['statement_type']) && $_POST['statement_type']==1)
{
    $where=$where." AND ledger_type='cash'";
}

if(isset($_POST['statement_type']) && $_POST['statement_type']==2)
{
        $where=$where." AND ledger_type!='CASH' AND ledger_type!=''";
}

if(isset($_POST['statement_type']) && $_POST['statement_type']==3)
{
        $where=$where." AND ledger_type!='CASH' AND ledger_type=''";
}

   // _d($where);
/*if(isset($ledger_type) AND $ledger_type=='cash')
{
    $where=$where." AND ledger_type='cash'";
}
if(isset($ledger_type) AND $ledger_type=='match')
{
    $where=$where." AND ledger_type=''";
}*/
$ledger_data=get_data('user_ledger',$where." order by ledger_id desc");
$amount=get_user_ledger($user_id,$user_type,$_POST['statement_type']);
$total_balance=$amount['total_balance'];
$debit_balance=$amount['credit_balance'];
$credit_balance=$amount['debit_balance'];
$balance=$credit_balance-$debit_balance;
if($_POST['self']=='false')
{
  $lena='DENA';
  $dena='LENA';
  $credit_balance=-1*$credit_balance;
  $debit_balance=-1*$debit_balance;
  $balance=-1*($balance);
  $credit_show_label='CREDIT';
  $debit_show_label='DEBIT';
}
else
{
    $lena='LENA';
    $dena='DENA';
    $credit_show_label='CREDIT';
    $debit_show_label='DEBIT';

}

?>

<?php if(!empty($ledger_data)) {?>

<div class="card-body">
                                    <div>

                                        <table  class="table table-bordered table-striped">
                                            <thead>

                                            <tr>
                                                <th>#</th>
                                                <th> Date</th>
                                                <th>Collection Name</th>
                                                <th>Debit</th>
                                                <th>Credit</th>
                                                <th>Balance</th>
                                                <th>Payment Type</th>
                                                <th>Remark</th>
                                            </tr>

                                            <tr>
                                                <th></th>
                                                <th></th>
                                                <th class="<?= $balance<0?'text-red':'text-blue' ?>">Total Amount</th>
                                                <th><?= abs(round($credit_balance,2)) ?></th>
                                                <th><?= abs(round($debit_balance,2)) ?></th>
                                                <th class="<?= $balance<0?'text-red':'text-blue' ?>"><?= (round($balance,2)) ?></th>
                                                <th></th>
                                                <th></th>
                                            </tr>

                                            </thead>
                                            <tbody>
                                                   <?php $no=1; $total_calculate_amount=0; $credit=0; $debit=0; $total_credit=0; $total_debit=0; $balnace=0; foreach ($ledger_data as $key => $value) {  ?>
                                                    

                                   

                                    <?php  if($value['transaction_type']=='D'){$amount=(-1*$value['amount']); $debit_show=$value['amount']; $debit+=$value['amount']; $credit+=0; $credit_show='-';} else{$amount=($value['amount']); $credit_show=$value['amount']; $credit+=$value['amount']; $debit_show='-'; $debit+=0;} 
                                         $balance=$total_balance-$total_calculate_amount;
                                         $total_calculate_amount+=$amount;
                                         $balance=round($balance,2);
                                    ?>
                                             <tr <?php if($value['ledger_type']=='cash') { echo  'style="background-color: pink;"';} ?>>
                                                <td><?= $no++ ?></td>
                                                <td><?= $value['create_date'] ?></td>
                                                <td class="text-uppercase"><?= $value['match_name'] ?></td>
                                                <th class="text-danger"><?= $debit_show; ?></th>
                                                <th class="text-primary"><?= $credit_show; ?></th>
                                                <td><?= color($balance);  ?></td>
                                                <td> <?php if($value['ledger_type']=='cash') 
                                                { 
                                                    if($value['transaction_type']=='C')
                                                    {
                                                       echo 'DIYA';
                                                    }
                                                    else
                                                    {
                                                       echo 'LIYA';
                                                    }

                                                 } 
                                                 ?>   
                                               </td>
                                                <td class="text-uppercase">
                                                    <?= $value['remark']!=''?$value['remark']:$value['note']; ?>
                                                        
                                                    </td>
                                            </tr>


                                           <?php  } ?>

                                            </tbody>
                                            <tfoot>

                                            </tfoot>
                                        </table>

                                    </div>
                                    

                                </div>
                            <?php } else{?>
                                  <div class="card-body">
                                    
                                    <div class="alert alert-warning">
                                        <h6>No Record Found</h6>
                                    </div>

                                </div>

                            <?php } ?>

