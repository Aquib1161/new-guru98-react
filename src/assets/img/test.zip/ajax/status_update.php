<?php
include('../include/config.php');
extract($_POST);
$status=$status=='active'?1:0;

if(isset($is_client) AND $is_client==true)
{
	if(isset($id_array))
	{
		foreach ($id_array as $key => $client_id) 
		{
		 $return=client_status($client_id,$status);	
		}
	}

}
else
{
	if(isset($id_array))
	{
		foreach ($id_array as $key => $user_id) 
		{
		 $return=user_status($user_id,$status);
		}
	}

}

$send_array=array(
     'msg'=>"Status has been updated suucessfully"
    );
    $status='success';
   $data_to_send=array(
    'data'=>$send_array,
    'status'=>$status
);
$data=json_encode($data_to_send);
echo $data;
exit();
die;
?>