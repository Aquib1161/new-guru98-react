<?php include('../include/config.php'); 
 $_POST=sanatize($_POST);
 $_GET=sanatize($_GET);
 extract($_POST);
 extract($_GET);

		 if(isset($_POST['table_name']) AND !isset($_POST['where']))
		{
			$table_name=$_POST['table_name'];
			unset($_POST['table_name']);
			$query=insert_array($table_name,$_POST);
		}
		else
		{   
			$table_name=$_POST['table_name'];
			unset($_POST['table_name']);
			$where=$_POST['where'];
			unset($_POST['where']);
			$query=update_array($table_name,$_POST,$where);
		}

		if(isset($type) AND $type=='get')
		{

			if($table_name=='position')
			{
				$table_name='md_client_position';
			}
        if(!isset($where))
        {
        	$where="1=1";
        }

        if(!isset($single))
        {
        	 $single='';
        }
        if(!isset($specific))
        {
        	 $specific='';
        }
          $get_data=get_data($table_name,$where,$single,$specific);
        
       $send_array=array('msg'=>'Client status updated successfuly');
		$status='success';
		$data_to_send=array(
			'data'=>$get_data,
			'status'=>'success'
		);
		$data=json_encode($data_to_send);
		echo $data;
		exit();
		die;

		}



     $send_array=array('msg'=>'Client status updated successfuly');
		$status='success';
		$data_to_send=array(
			'data'=>$send_array,
			'status'=>$status
		);
		$data=json_encode($data_to_send);
		echo $data;
		exit();
		die;


 


 



?>