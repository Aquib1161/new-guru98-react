<?php include('../include/config.php'); 
 $_POST=sanatize($_POST);
 $_GET=sanatize($_GET);
 $status='error';
 if($_POST['market_id']=='' OR !isset($_POST['market_id']))
 {
	 $send_array=array('msg'=>'Something went wrong');
	$status='error';
	$data_to_send=array(
		'data'=>$send_array,
		'status'=>$status
	);
	$data=json_encode($data_to_send);
	echo $data;
 }
 $market_id=$_POST['market_id'];


  if(isset($_POST['type']) AND $_POST['type']=='insert_session')
{   

   $count=count_data('session_crick_tbl',"session_name='".trim($_POST['session_name'])."' AND market_id='".$market_id."'");
   if($count>=1)
   {
   	  $send_array=array('msg'=>'Session Already Exist');
			$status='error';
			$data_to_send=array(
				'data'=>$send_array,
				'status'=>$status
			);
			$data=json_encode($data_to_send);
			echo $data;
			exit();
			die();
   }
  
		unset($_POST['type']);
		$insert_array=array(
			'session_name'=>trim($_POST['session_name']),
			'market_id'=>$_POST['market_id'],
			'session_type_name'=>'manual',
			'old_session_type'=>'manual',
			'date1'=>_date(),
			'insert_date'=>_date_time(),
			'api_active'=>0,
			'play_status'=>0,
			'api_active'=>0,
			'yes_size'=>0,
			'no_size'=>0,
			'yes_price'=>0,
			'no_price'=>0,
			'yes_price_diffrence'=>0,
		);							
	$insert=insert_array('session_crick_tbl',$insert_array);
	$insert_id=$insert['insert_id'];
	$update_array=array(
		'selection_id'=>sha1(trim($insert_id).trim($_POST['market_id'])),
		'manual_selection_id'=>$insert_id
	);
	$update=update_array('session_crick_tbl',$update_array,"market_id='".$market_id."' AND session_crick_id='".$insert_id."'");
	if($update['error']==0)
	{
		$status='success';
		$_SESSION['notify']=['type'=>'success','msg'=>'Session inserted Successfully'];
	}
}

if(isset($_POST['type']) AND $_POST['type']=='update_session_bhav')
{
	unset($_POST['type']);
	$update_array=array(
		'yes_size'=>$_POST['yes_run'],
		'no_size'=>$_POST['no_run'],
		'yes_price_diffrence'=>$_POST['yes_range'],
		'bhav_type'=>$_POST['bhav_type'],
	);

	$update=update_array('session_crick_tbl',$update_array,"market_id='".$market_id."' AND session_crick_id='".$_POST['session_id']."'");
	if($update['error']==0)
	{
		$status='success';
	}

}

if(isset($_POST['type']) AND $_POST['type']=='session_status')
{
	unset($_POST['type']);
	$update_array=array(
		'play_status'=>$_POST['status'],
	);

	$update=update_array('session_crick_tbl',$update_array,"market_id='".$market_id."' AND session_crick_id='".$_POST['session_id']."'");
	if($update['error']==0)
	{
		$status='success';
	}
}


$send_array=array('msg'=>'Status Updated');
$data_to_send=array(
	'data'=>$send_array,
	'status'=>$status
);
$data=json_encode($data_to_send);
echo $data;
?>