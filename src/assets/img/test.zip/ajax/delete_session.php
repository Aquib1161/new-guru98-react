<?php
include('../include/config.php');
$_POST=$_POST;
extract($_POST);
if ($market_id == "Select Match" OR !isset($_SESSION['password_verify'])) {
	$send_array=array(
     'msg'=>"Something went wrong"
    );

    $status='error';
    $data_to_send=array(
	'data'=>$send_array,
	'status'=>$status
);
	$data=json_encode($data_to_send);
	echo $data;
	exit();
}
unset($_SESSION['password_verify']);

if(isset($_POST['status']) AND $_POST['status']=='rollback')
{
$query="UPDATE  client_session_bat_tbl SET deleted_status=0 WHERE  market_id='$market_id' AND selection_id='$selection_id'";
mysqli_query($con,$query);
$query="UPDATE  session_crick_tbl SET deleted_status=0 WHERE  market_id='$market_id' AND selection_id='$selection_id'";
mysqli_query($con,$query);

$send_array=array(
     'msg'=>"Session bets has been rolled back successfully"
    );
    $status='success';
   $data_to_send=array(
	'data'=>$send_array,
	'status'=>$status
);
$data=json_encode($data_to_send);
echo $data;
exit();
die;
}


if(isset($_POST['id_array']) AND $_POST['individual']=='individual')
{
	$id_array=$_POST['id_array'];
	$id_count=count($id_array);
	

	
foreach ($id_array as $key => $deleted_id) 
{
$client_session_data=get_data('client_session_bat_tbl',"client_session_bat_id='".$deleted_id."'",'s');
$deleted_status=$client_session_data['deleted_status']==0?1:0;
$selection_id=$client_session_data['selection_id'];
$client_id=$client_session_data['client_id'];
$query="UPDATE client_session_bat_tbl SET deleted_status=".$deleted_status." WHERE  market_id='$market_id' AND client_session_bat_id='".$deleted_id."'";
mysqli_query($con,$query);

if($deleted_status==1)
{
$query= "DELETE FROM transaction_log WHERE overall_type='SC' AND match_id='$market_id' AND selection_id='$selection_id' AND client_id='".$client_id."'";
mysqli_query($con,$query);
$query= "DELETE FROM transaction_log WHERE overall_type='SCC' AND match_id='$market_id' AND selection_id='$selection_id' AND client_id='".$client_id."'";
mysqli_query($con,$query);
$query= "DELETE FROM transaction_log WHERE overall_type='SD' AND match_id='$market_id' AND selection_id='$selection_id' AND client_id='".$client_id."'";
mysqli_query($con,$query);
}

}
$send_array=array(
     'msg'=>"Session bets has been deleted successfully"
    );
    $status='success';
   $data_to_send=array(
	'data'=>$send_array,
	'status'=>$status
);   
$data=json_encode($data_to_send);
echo $data;
exit();
die;		
}




$query="UPDATE  client_session_bat_tbl SET deleted_status=1 WHERE  market_id='$market_id' AND selection_id='$selection_id'";
$res=mysqli_query($con,$query);
$query="UPDATE  session_crick_tbl SET deleted_status=1  WHERE  market_id='$market_id' AND selection_id='$selection_id'";
$res=mysqli_query($con,$query);
$query= "DELETE FROM transaction_log WHERE overall_type='SC' AND match_id='$market_id' AND selection_id='$selection_id'";
mysqli_query($con,$query);
$query= "DELETE FROM transaction_log WHERE overall_type='SCC' AND match_id='$market_id' AND selection_id='$selection_id'";
mysqli_query($con,$query);
$query= "DELETE FROM transaction_log WHERE overall_type='SD' AND match_id='$market_id' AND selection_id='$selection_id'";
mysqli_query($con,$query);


$send_array=array(
     'msg'=>"All session Bets has been deleted succesfully"
    );
    $status='success';
   $data_to_send=array(
	'data'=>$send_array,
	'status'=>$status
);
$data=json_encode($data_to_send);
echo $data;
exit();
die;

?>