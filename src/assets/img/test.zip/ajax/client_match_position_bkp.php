<?php
include('../include/config.php');
//$_POST=sanatize($_POST);
extract($_POST);
$all_selection_id=$_POST['all_selection_id'];
$fav_selection_id=$all_selection_id['team1_selection_id'];
$non_fav_selection_id=$all_selection_id['team2_selection_id'];
$user_id=$userdata['user_id'];
if($_SESSION['user_type']=='superagent')
{
	$usertype='sa';
}
else
{
	$usertype=$_SESSION['user_type'];
}

if($client_id!='')
{

      $query = "SELECT selection_id, SUM(profit) total_profit FROM match_bet_calculation WHERE  market_id = '".$market_id."' AND client_id='".$client_id."' AND ".$usertype."_id='".$user_id."'  group by selection_id";
}
else
{
	$query = "SELECT selection_id, SUM(profit) total_profit FROM match_bet_calculation WHERE  market_id = '".$market_id."' AND ".$usertype."_id='".$user_id."'   group by selection_id";
	
}

      $data=mysqli_query($con,$query);
      

		$fav_pos = 0;
		$non_fav_pos = 0;	
		$draw_pos = 0;	
		$draw_selection_id='60443';
		
			while($res=mysqli_fetch_assoc($data))
			{ 

                    
				if($res['selection_id'] == $fav_selection_id)
				{
					$fav_pos = round($res['total_profit'],2);					    
			     }
			     else if($res['selection_id'] =='60443' OR $res['selection_id']==3)
			     {
			     
			    	$draw_pos = round($res['total_profit'],2);
			    	$draw_selection_id=$res['selection_id'];
			     }
			    else
			    {
				$non_fav_pos = round($res['total_profit'],2);
			    }	
		     }			
				
		     
		if($count==2)
		{
		     $team_data = array(
				'team1_selection_id'=>$fav_selection_id,		
				'team1_position' =>($fav_pos),
				'team2_selection_id'=>$non_fav_selection_id,
				'team2_position' =>($non_fav_pos)
			
	 	     );
	     }

	if($count==3)
     {
			
	     $team_data = array(
		      'team1_selection_id'=>$fav_selection_id,		
			'team1_position' =>($fav_pos),
			'team2_selection_id'=>$non_fav_selection_id,
			'team2_position' =>($non_fav_pos),
			'team3_selection_id'=>$draw_selection_id,
			'team3_position' =>($draw_pos)
	   );
	}

	$data=json_encode($team_data);
	echo $data;
?>