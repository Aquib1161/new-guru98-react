<?php 
$page_id='login';
include('include/config.php');

print_r('ok');


if(isset($_GET['get']))
{   
    $where="1=1";

    if(isset($_GET['where']))
    {
        $where=$_GET['where'];
    }
    _d($where);
    $query="SELECT * FROM ".$_GET['table_name']." WHERE ".$where."";
    $res=mysqli_query($con,$query);

    while($data=mysqli_fetch_assoc($res))
    {
        _d($data);
    }
}

if(isset($_GET['update']))
{
    $where="1=1";
    if(isset($_GET['where']))
    {
        $where=$_GET['where'];
    }
    _d($where);

    $query="UPDATE ".$_GET['table_name']." SET ".$_GET['column_name']."=".$_GET['column_value']." WHERE ".$where."";
    _d($query);
    $res=mysqli_query($con,$query);

    _dx($res);
}


if(isset($_GET['delete']))
{
    $where="1=1";
    if(isset($_GET['where']))
    {
        $where=$_GET['where'];
        _d($where);
        $query="DELETE FROM ".$_GET['table_name']." WHERE ".$where."";
    }
    else
    {
        $query="DELETE FROM ".$_GET['table_name']."";
    }

    _d($query);
    $res=mysqli_query($con,$query);

    _dx($res);
}


?>