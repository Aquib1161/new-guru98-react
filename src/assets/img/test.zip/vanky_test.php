

                

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="en">
      
    
                

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
        <title>Casino List</title>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="stylesheet" href="/css/bootstrap.css" />
        <link rel="stylesheet" href="/css/style.css?v=0.8" />
        <link rel="stylesheet" href="/css/responsive.css?v=0.8" />
		<link rel="stylesheet" href="/css/fonts.css" />
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" />
		        	<script src="/include/js/handlebars3.0.0.js?v=0.12" type="text/javascript"></script>  
    <script src="/include/js/handlebars-helper-x.js?v=0.12" type="text/javascript"></script> 
	</head>
	<style>
	.modal
	{
	padding-right:0 !important;
	}
	.mark-lay
	{
	background:#FCA4B7!important;
	color:#000;
	font-weight:bold;
	}
	.mark-back
	{
	background:#CDF9FF!important;
	color:#000;
	font-weight:bold;
	}
            .fade:not(.show) {
                opacity: 1;
            }
            .casino-banner-item {
                float: left;
            }
            .casino-tabs .nav-tabs .nav-item .nav-link.active {
                border-bottom: none;
            }
            .casino-tabs .nav-tabs .nav-item.active {
                border-bottom: 3px solid #fdcf13;
            }
            .casino-box-tabs {
                padding: 10px 0;
              //  position: sticky;
                top: 0px;
              //  margin-top: -6px;
                z-index: 1;
                width: 100%;
                background: var(--bg-body);
                display: flex;
                justify-content: space-between;
            }
            .casino-box-tabs ul {
                margin: 0 30px;
                white-space: nowrap;
                flex-wrap: nowrap;
                overflow-x: hidden;
            }
            .casino-box-tabs .nav-pills .nav-item {
                margin-right: 10px;
            }
            .casino-box-tabs .nav-pills .nav-link.active {
                border: 2px solid var(--text-fancy);
            }
            .casino-box-tabs .nav-pills .nav-link {
                border: 2px solid var(--bg-table-header);
                color: var(--text-body);
                border-radius: 20px;
                background-color: transparent;
                min-height:41px;
                display: flex;
                align-items: center;
                padding:5px;
            }
            .casino-box-tabs .nav-pills .nav-item img {
                height:25px;
                margin-right: 5px;
            }
            .arrow-tabs.arrow-left {
                transform: none;
            }
            .arrow-tabs.arrow-right {
                transform: none;
            }
            .casino-tabs-menu {
                width: 100%;
            }
            .b-toast {
                display: block;
                position: relative;
                max-width: 350px;
                -webkit-backface-visibility: hidden;
                backface-visibility: hidden;
                background-clip: padding-box;
                z-index: 1;
                border-radius: 0.25rem;
            }
            .b-toast .toast {
                background-color: rgba(255, 255, 255, 0.85);
            }
            .b-toast:not(:last-child) {
                margin-bottom: 0.75rem;
            }
            .b-toast.b-toast-solid .toast {
                background-color: white;
            }
            .b-toast .toast {
                opacity: 1;
            }
            .b-toast .toast.fade:not(.show) {
                opacity: 0;
            }
            .b-toast .toast .toast-body {
                display: block;
            }

            .b-toast-primary .toast {
                background-color: rgba(230, 242, 255, 0.85);
                border-color: rgba(184, 218, 255, 0.85);
                color: #004085;
            }
            .b-toast-primary .toast .toast-header {
                color: #004085;
                background-color: rgba(204, 229, 255, 0.85);
                border-bottom-color: rgba(184, 218, 255, 0.85);
            }
            .b-toast-primary.b-toast-solid .toast {
                background-color: #e6f2ff;
            }

            .b-toast-secondary .toast {
                background-color: rgba(239, 240, 241, 0.85);
                border-color: rgba(214, 216, 219, 0.85);
                color: #383d41;
            }
            .b-toast-secondary .toast .toast-header {
                color: #383d41;
                background-color: rgba(226, 227, 229, 0.85);
                border-bottom-color: rgba(214, 216, 219, 0.85);
            }
            .b-toast-secondary.b-toast-solid .toast {
                background-color: #eff0f1;
            }

            .b-toast-success .toast {
                background-color: rgba(230, 245, 233, 0.85);
                border-color: rgba(195, 230, 203, 0.85);
                color: #155724;
            }
            .b-toast-success .toast .toast-header {
                color: #155724;
                background-color: rgba(212, 237, 218, 0.85);
                border-bottom-color: rgba(195, 230, 203, 0.85);
            }
            .b-toast-success.b-toast-solid .toast {
                background-color: #e6f5e9;
            }

            .b-toast-info .toast {
                background-color: rgba(229, 244, 247, 0.85);
                border-color: rgba(190, 229, 235, 0.85);
                color: #0c5460;
            }
            .b-toast-info .toast .toast-header {
                color: #0c5460;
                background-color: rgba(209, 236, 241, 0.85);
                border-bottom-color: rgba(190, 229, 235, 0.85);
            }
            .b-toast-info.b-toast-solid .toast {
                background-color: #e5f4f7;
            }

            .b-toast-warning .toast {
                background-color: rgba(255, 249, 231, 0.85);
                border-color: rgba(255, 238, 186, 0.85);
                color: #856404;
            }
            .b-toast-warning .toast .toast-header {
                color: #856404;
                background-color: rgba(255, 243, 205, 0.85);
                border-bottom-color: rgba(255, 238, 186, 0.85);
            }
            .b-toast-warning.b-toast-solid .toast {
                background-color: #fff9e7;
            }

            .b-toast-danger .toast {
                background-color: rgba(252, 237, 238, 0.85);
                border-color: rgba(245, 198, 203, 0.85);
                color: #721c24;
            }
            .b-toast-danger .toast .toast-header {
                color: #721c24;
                background-color: rgba(248, 215, 218, 0.85);
                border-bottom-color: rgba(245, 198, 203, 0.85);
            }
            .b-toast-danger.b-toast-solid .toast {
                background-color: #fcedee;
            }

            .b-toast-light .toast {
                background-color: rgba(255, 255, 255, 0.85);
                border-color: rgba(253, 253, 254, 0.85);
                color: #818182;
            }
            .b-toast-light .toast .toast-header {
                color: #818182;
                background-color: rgba(254, 254, 254, 0.85);
                border-bottom-color: rgba(253, 253, 254, 0.85);
            }
            .b-toast-light.b-toast-solid .toast {
                background-color: white;
            }

            .b-toast-dark .toast {
                background-color: rgba(227, 229, 229, 0.85);
                border-color: rgba(198, 200, 202, 0.85);
                color: #1b1e21;
            }
            .b-toast-dark .toast .toast-header {
                color: #1b1e21;
                background-color: rgba(214, 216, 217, 0.85);
                border-bottom-color: rgba(198, 200, 202, 0.85);
            }
            .b-toast-dark.b-toast-solid .toast {
                background-color: #e3e5e5;
            }

            .b-toaster {
                z-index: 1100;
            }
            .b-toaster .b-toaster-slot {
                position: relative;
                display: block;
            }
            .b-toaster .b-toaster-slot:empty {
                display: none !important;
            }

            .b-toaster.b-toaster-top-right,
            .b-toaster.b-toaster-top-left,
            .b-toaster.b-toaster-top-center,
            .b-toaster.b-toaster-top-full,
            .b-toaster.b-toaster-bottom-right,
            .b-toaster.b-toaster-bottom-left,
            .b-toaster.b-toaster-bottom-center,
            .b-toaster.b-toaster-bottom-full {
                position: fixed;
                left: 0.5rem;
                right: 0.5rem;
                margin: 0;
                padding: 0;
                height: 0;
                overflow: visible;
            }
            .b-toaster.b-toaster-top-right .b-toaster-slot,
            .b-toaster.b-toaster-top-left .b-toaster-slot,
            .b-toaster.b-toaster-top-center .b-toaster-slot,
            .b-toaster.b-toaster-top-full .b-toaster-slot,
            .b-toaster.b-toaster-bottom-right .b-toaster-slot,
            .b-toaster.b-toaster-bottom-left .b-toaster-slot,
            .b-toaster.b-toaster-bottom-center .b-toaster-slot,
            .b-toaster.b-toaster-bottom-full .b-toaster-slot {
                position: absolute;
                max-width: 350px;
                width: 100%;
                /* IE 11 fix */
                left: 0;
                right: 0;
                padding: 0;
                margin: 0;
            }
            .b-toaster.b-toaster-top-full .b-toaster-slot,
            .b-toaster.b-toaster-bottom-full .b-toaster-slot {
                width: 100%;
                max-width: 100%;
            }
            .b-toaster.b-toaster-top-full .b-toaster-slot .b-toast,
            .b-toaster.b-toaster-top-full .b-toaster-slot .toast,
            .b-toaster.b-toaster-bottom-full .b-toaster-slot .b-toast,
            .b-toaster.b-toaster-bottom-full .b-toaster-slot .toast {
                width: 100%;
                max-width: 100%;
            }
            .b-toaster.b-toaster-top-right,
            .b-toaster.b-toaster-top-left,
            .b-toaster.b-toaster-top-center,
            .b-toaster.b-toaster-top-full {
                top: 0;
            }
            .b-toaster.b-toaster-top-right .b-toaster-slot,
            .b-toaster.b-toaster-top-left .b-toaster-slot,
            .b-toaster.b-toaster-top-center .b-toaster-slot,
            .b-toaster.b-toaster-top-full .b-toaster-slot {
                top: 0.5rem;
            }
            .b-toaster.b-toaster-bottom-right,
            .b-toaster.b-toaster-bottom-left,
            .b-toaster.b-toaster-bottom-center,
            .b-toaster.b-toaster-bottom-full {
                bottom: 0;
            }
            .b-toaster.b-toaster-bottom-right .b-toaster-slot,
            .b-toaster.b-toaster-bottom-left .b-toaster-slot,
            .b-toaster.b-toaster-bottom-center .b-toaster-slot,
            .b-toaster.b-toaster-bottom-full .b-toaster-slot {
                bottom: 0.5rem;
            }
            .b-toaster.b-toaster-top-right .b-toaster-slot,
            .b-toaster.b-toaster-bottom-right .b-toaster-slot,
            .b-toaster.b-toaster-top-center .b-toaster-slot,
            .b-toaster.b-toaster-bottom-center .b-toaster-slot {
                margin-left: auto;
            }
            .b-toaster.b-toaster-top-left .b-toaster-slot,
            .b-toaster.b-toaster-bottom-left .b-toaster-slot,
            .b-toaster.b-toaster-top-center .b-toaster-slot,
            .b-toaster.b-toaster-bottom-center .b-toaster-slot {
                margin-right: auto;
            }

            .b-toaster.b-toaster-top-right .b-toast.b-toaster-enter-active,
            .b-toaster.b-toaster-top-right .b-toast.b-toaster-leave-active,
            .b-toaster.b-toaster-top-right .b-toast.b-toaster-move,
            .b-toaster.b-toaster-top-left .b-toast.b-toaster-enter-active,
            .b-toaster.b-toaster-top-left .b-toast.b-toaster-leave-active,
            .b-toaster.b-toaster-top-left .b-toast.b-toaster-move,
            .b-toaster.b-toaster-bottom-right .b-toast.b-toaster-enter-active,
            .b-toaster.b-toaster-bottom-right .b-toast.b-toaster-leave-active,
            .b-toaster.b-toaster-bottom-right .b-toast.b-toaster-move,
            .b-toaster.b-toaster-bottom-left .b-toast.b-toaster-enter-active,
            .b-toaster.b-toaster-bottom-left .b-toast.b-toaster-leave-active,
            .b-toaster.b-toaster-bottom-left .b-toast.b-toaster-move {
                transition: -webkit-transform 0.175s;
                transition: transform 0.175s;
                transition: transform 0.175s, -webkit-transform 0.175s;
            }
            .b-toaster.b-toaster-top-right .b-toast.b-toaster-enter-to .toast.fade,
            .b-toaster.b-toaster-top-right .b-toast.b-toaster-enter-active .toast.fade,
            .b-toaster.b-toaster-top-left .b-toast.b-toaster-enter-to .toast.fade,
            .b-toaster.b-toaster-top-left .b-toast.b-toaster-enter-active .toast.fade,
            .b-toaster.b-toaster-bottom-right .b-toast.b-toaster-enter-to .toast.fade,
            .b-toaster.b-toaster-bottom-right .b-toast.b-toaster-enter-active .toast.fade,
            .b-toaster.b-toaster-bottom-left .b-toast.b-toaster-enter-to .toast.fade,
            .b-toaster.b-toaster-bottom-left .b-toast.b-toaster-enter-active .toast.fade {
                transition-delay: 0.175s;
            }
            .b-toaster.b-toaster-top-right .b-toast.b-toaster-leave-active,
            .b-toaster.b-toaster-top-left .b-toast.b-toaster-leave-active,
            .b-toaster.b-toaster-bottom-right .b-toast.b-toaster-leave-active,
            .b-toaster.b-toaster-bottom-left .b-toast.b-toaster-leave-active {
                position: absolute;
                transition-delay: 0.175s;
            }
            .b-toaster.b-toaster-top-right .b-toast.b-toaster-leave-active .toast.fade,
            .b-toaster.b-toaster-top-left .b-toast.b-toaster-leave-active .toast.fade,
            .b-toaster.b-toaster-bottom-right .b-toast.b-toaster-leave-active .toast.fade,
            .b-toaster.b-toaster-bottom-left .b-toast.b-toaster-leave-active .toast.fade {
                transition-delay: 0s;
            }
            .b-toast .toast {
	max-width: unset;
	display: flex;
	justify-content: center;
	position: fixed;
	z-index: 1070;
	-ms-flex-align: start;
	align-items: flex-start;
	transition: background-color .15s
}
.b-toast.b-toast-success .toast {
	background-color: var(--btn-primary)
}
.b-toast.b-toast-danger .toast {
	background-color: var(--bg-danger)
}
.b-toast.b-toast-info .toast {
	background-color: var(--bg-info)
}
.b-toast.b-toast-warning .toast {
	background-color: var(--bg-warning)
}
.toast-header {
	display: none
}
.toast-body {
	position: relative;
	color: var(--text-white);
	padding-left: 40px
}
.b-toast.b-toast-warning .toast-body {
	color: var(--text-black)
}
.toast .toast-body {
	position: relative
}
.b-toast.b-toast-success .toast .toast-body:before {
	position: absolute;
	content: "\f058";
	font-family: "Font Awesome 5 Free";
	font-weight: 900;
	left: 10px
}
.b-toast.b-toast-danger .toast .toast-body:before {
	position: absolute;
	content: "\f057";
	font-family: "Font Awesome 5 Free";
	font-weight: 900;
	left: 10px
}
.b-toast.b-toast-info .toast .toast-body:before {
	position: absolute;
	content: "\f05a";
	font-family: "Font Awesome 5 Free";
	font-weight: 900;
	left: 10px
}
.b-toast.b-toast-warning .toast .toast-body:before {
	position: absolute;
	content: "\f06a";
	font-family: "Font Awesome 5 Free";
	font-weight: 900;
	left: 10px
}
.b-toast.b-toast-success .toast {
	border-color: var(--btn-primary)
}
.b-toast.b-toast-danger .toast {
	border-color: var(--bg-danger)
}
.b-toast.b-toast-info .toast {
	border-color: var(--bg-info)
}
.b-toast.b-toast-warning .toast {
	border-color: var(--bg-warning)
}
.b-toaster-top-full {
	position: fixed!important;
	left: 50%!important;
	width: 300px!important;
	transform: translateX(-50%)!important;
	top: 10px!important
}
.toast 
{
font-size:15px;
}
#loader-1 {
    width: 100%;
    height: 100vh;
    display: flex;
    justify-content: center;
    position: fixed!important;
    align-items: center;
    z-index: 9999;
    position: relative;
    background:#000000b8;
}	
.modal-backdrop
{
opacity:0.5;
}
	</style>
<script>
function addRemoveClass(parentclass, childclass){
	if($(parentclass).hasClass(childclass) == false){
		  $(parentclass).addClass(childclass); 
	  }else{
		  $(parentclass).removeClass(childclass);
	  }
}	
$(function() {
$('.casino-cards-shuffle').on('click', function(){
    addRemoveClass('.casino-video-cards','hide-cards');
});

$('.casino-video-lr-icon').on('click', function(){
	addRemoveClass('.casino-video-last-results','hide-lr');
});
	

});

</script>
<div id="errormodal" class="b-toaster b-toaster-top-full" style="display: none;">
    <div class="b-toaster-slot vue-portal-target">
        <div id="__BVID__5124__toast_outer" role="alert" aria-live="assertive" aria-atomic="true" class="b-toast b-toast-prepend b-toast-danger">
            <div id="__BVID__5124" tabindex="0" class="toast">
                <div class="toast-body" id="errorMessage" >Bet Not Confirm Check Balance.</div>
            </div>
        </div>
    </div>
</div>

<div id="successmodal" class="b-toaster b-toaster-top-full" style="display: none;">
    <div class="b-toaster-slot vue-portal-target">
        <div id="__BVID__5124__toast_outer" role="alert" aria-live="assertive" aria-atomic="true" class="b-toast b-toast-prepend b-toast-success">
            <div id="__BVID__5124" tabindex="0" class="toast">
                <div class="toast-body" id="successMessage" >Bet Confirm Check Balance.</div>
            </div>
        </div>
    </div>
</div>
<div id="loader-1" style="display: none;">
<div id="load-inner" class="logo-login">
<div class="lds-circle">
<img src="/images/soc.gif" style="max-width:300px !important;max-height:300px !important;width: 300px;"/></div> 
</div> 
</div>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/socket.io/4.1.3/socket.io.js?v=0.12" integrity="sha512-PU5S6BA03fRv1Q5fpwXjg5nlRrgdoguZ74urFInkbABMCENyx5oP3hrDzYMMPh3qdLdknIvrGj3yqZ4JuU7Nag==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<Script>
$(document).ready(function(){
	if(!window.location.pathname.indexOf("/Lobby")==0){
		$("#userid").html(tokenPayload.sub)		
	}
	
	if(window.location.pathname!="/searchResults"){
	getUserBalance(tokenPayload)
	}
	CommonSocket()
       });

function showMessage(message,type){
	 if(type == true){
		 $("#successMessage").html(message);
	   		$("#successmodal").modal('show');
	         setTimeout(function(){
	    		 $("#successMessage").html("");
	      	   $("#successmodal").modal('hide');
			    	},1000);
			 
	 }else{
		 $("#errorMessage").html(message);
	   		$("#errormodal").modal('show');
	         setTimeout(function(){
	    		 $("#errorMessage").html("");
	      	   $("#errormodal").modal('hide');
			    	},1000);
	 }
	
}


function getLobbyUrl(payload){
	$("#loader-1").show()
		 var data = {
				userid:tokenPayload.sub
				,partnerId:tokenPayload.partnerId
				,balance:$("#userBalance").text()
					}
	 $.ajax({
			type:'POST',
			url:'/casinoAdda/getOwnLobbyUrl',
			data: JSON.stringify(data),
			dataType: "json",
			contentType:"application/json; charset=utf-8",
			success: function(jsondata, textStatus, xhr) {
			},
			complete: function(jsondata,textStatus,xhr) {
				if(jsondata.responseJSON.success==true){
					 location.replace(jsondata.responseJSON.data.url)						
				}else{
			   		$("#errorMessage").html(jsondata.responseJSON.message);
			   		$("#errormodal").modal('show');
				}
		    } 
	});
	 }
	 
function getUserBalance(payload){
		 var data = {
				userid:tokenPayload.sub
				,partnerId:tokenPayload.partnerId
				,balance:$("#userBalance").text()
					}
	 $.ajax({
			type:'POST',
			url:'/api/getUserBalance',
			data: JSON.stringify(data),
			dataType: "json",
			contentType:"application/json; charset=utf-8",
			success: function(jsondata, textStatus, xhr) {
			},
			complete: function(jsondata,textStatus,xhr) {
				if(jsondata.responseJSON.success==true){
					$("#userBalance").html(parseFloat(jsondata.responseJSON.data.balance).toFixed(2))
					$("#userBalanceMob").html(parseFloat(jsondata.responseJSON.data.balance).toFixed(2))
				}else{
					showMessage(jsondata.responseJSON.message,jsondata.responseJSON.success);
				}
		    } 
	});
	 }
var resultSocket = "";
function CommonSocket(){
	var data = {
	        userid: tokenPayload.sub,
	    }
	resultSocket = io('wss://result.casinoapi.in', {
		transports: ['websocket']});
	resultSocket.on('connect', () => {
		 console.log('Connection Established');
		});
	resultSocket.emit("result",tokenPayload.sub);
		 resultSocket.on("result", (message) => {
			 setTimeout( function(){
				 getUserBalance(tokenPayload)
				  }  , 2000 );
	});
	
		 
		 resultSocket.on('disconnect', () => {
	  console.log('Odds Connection Closed');
	  CommonSocket();
	});
	}    
</Script>
</html>
    <link rel="stylesheet" href="/css/control.css" />
    <script id="betSlipDesignHandler" type="text/x-handlebars-template">
                                        <!---->
                                        <div class="casino-place-bet-info">
                                            <div class="bet-player"><span id="playerName">Player A Main</span></div>
                                            <div class="odds-box">
                                                <span type="text" disabled="disabled" id="macthoddsbetslipodds" class="form-control"></span> 
												<img src="/images/arrow-down.svg" class="arrow-up" />
                                                <img src="/images/arrow-down.svg" class="arrow-down" />
                                            </div>
                                            <div class="bet-input lay-border"><input type="text" id="stakeinputmarchodds" onkeypress="return event.charCode >= 48 &amp;&amp; event.charCode <= 57" class="form-control input-stake" /></div>
                                            <div id="profitDiv">0</div>
                                        </div>
                                        <div class="casino-place-bet-button-container">
                                            <button class="btn btn-bet stakeButton">1</button>
<button class="btn btn-bet stakeButton">5</button>
<button class="btn btn-bet stakeButton">10</button>
                                            <button class="btn btn-bet stakeButton">50</button> 
<button class="btn btn-bet stakeButton">100</button>
<button class="btn btn-bet stakeButton">500</button>
                                            <button class="btn btn-bet stakeButton">1000</button>
<button class="btn btn-bet stakeButton">5000</button>
                                        </div>
                                        <div class="casino-place-bet-action-buttons"><button class="btn btn-reset cancel-betslip">Reset</button> <button class="btn btn-primary btn-round-done" id="placebet">Submit</button></div>

</script>
<script id="mobilebetSlipDesignHandler" type="text/x-handlebars-template">
<!---->
                <div class="casino-place-bet-box">
                    <div class="bet-slip pl-0 pr-0">
                        <div class="bet-team mt-0"><span class="bet-team-name" id="playerName">Player A Main</span> <span class="float-right" id="macthoddsbetslipodds">1.37</span></div>
                    </div>
                    <div class="casino-place-bet-info">
                        <div class="bet-input ml-0 back-border">
                            <input type="number" id="stakeinputmarchodds" maxlength="9" onkeypress="return event.charCode >= 48 &amp;&amp; event.charCode <= 57" placeholder="Amount" class="form-control input-stake" />
                        </div>
                    </div>
                    <div class="casino-place-bet-button-container">
                                            <button class="btn btn-bet stakeButton">1</button><button class="btn btn-bet stakeButton">5</button><button class="btn btn-bet stakeButton">10</button>
                                            <button class="btn btn-bet stakeButton">50</button> <button class="btn btn-bet stakeButton">100</button><button class="btn btn-bet stakeButton">500</button>
                                            <button class="btn btn-bet stakeButton">1000</button><button class="btn btn-bet stakeButton">5000</button>
                    </div>
                    <div class="casino-place-bet-action-buttons"><button class="btn btn-primary btn-round-done" disabled="disabled" id="placebet">Submit</button></div>
                </div>
</script>
    <style>
    .casino-bl-box-item
    {
    height:40px;
    }
        .teenpatti1day .casino-bl-box {
            width: 100%;
        }
        .teenpatti1day .casino-bl-box-item {
            width: calc(49%);
        }
        .casino-bl-box {
            margin-bottom: 4px;
        }
        .teen1daycasino-container {
            display: block;
        }
		.fade:not(.show)
		{
		opacity:0.5;	
		}
		.casino-odds-name img {
    height: 25px;
    max-height: 25px;
    margin-left: 3px;
    width: 25px;
}

.casino-result-cards-item .winner-icon {
    height: auto;
    width: 43px;
    transition: .1.2s ease-in;
    animation-iteration-count: infinite;
}
.card {
    border: 0;
    border-radius: 0;
    margin-left: 9px;
    height: 53px;
}
    </style>
    <body data-modal-open-count="0">
 <header class="header">
    <div class="logo-box ">
       <div class="logo" style="font-size:20px;color:#fff;cursor:pointer" onclick="goLobby()">HOME</div>
    </div>
    <div class="float-right header-right" style="
    display: flex;
">
        <div class="text-center bal-point">
            Pts:
            <span id="userBalance">0</span>
        </div>
        <div class="username-info">
            <div data-toggle="collapse" data-target="#user-dropdown" class="d-inline-block" aria-expanded="true">
                <span class="user-icon"><img src="/images/user.svg"></span> <span class="username" id="userid"></span> 
            </div>
            
        </div>
    </div>
</header>
    
        <div id="app">
            <div class="wrapper">
                <div class="main-container">
                    <div class="center-main-content">
                        <div class="report-container">
                            <div class="casino-center">
                            <div id="element" class="casino-container">
    <div class="casino-table teenpatti1day">
        <div class="casino-video">
            <!---->
            <div class="casino-video-title"><span class="casino-name">Teenpatti T-20</span> <span class="casino-video-rid" id="round_details">Round ID: -</span></div>
            <div class="video-box-container">
                <div class="video-box"><iframe src="https://alpha-m.qnsports.live/route/?id=3030"></iframe></div>
            </div>
            <div class="casino-video-cards">
                <div class="casixno-cards-shuffle"><i class="fas fa-grip-lines-vertical"></i></div>
                <div class="casino-video-cards-container">
                    <div>
                        <span><img class="p1a1"src="/images/1.png" /></span> 
                        <span><img class="p1a2"src="/images/1.png" /></span>
                        <span><img class="p1a3"src="/images/1.png" /></span>
                    </div>
                    <div>
                        <span><img class="p2a1"src="/images/1.png" /></span> 
                        <span><img class="p2a2"src="/images/1.png" /></span>
                        <span><img class="p2a3"src="/images/1.png" /></span>
                    </div>
                </div>
            </div>
            <div class="casino-timer">
                <div class="base-timer">
                    <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" class="base-timer__svg">
                        <g class="base-timer__circle">
                            <circle cx="50" cy="50" r="45" class="base-timer__path-elapsed"></circle>
                            <path
                                id="timer_clock"
                                stroke-dasharray="0 283"
                                d="
        M 50, 50
        m -45, 0
        a 45,45 0 1,0 90,0
        a 45,45 0 1,0 -90,0
      "
                                class="base-timer__path-remaining green"
                            ></path>
                        </g>
                    </svg>
                    <span class="base-timer__label green" id="timer_text_color"><span data-v-07e7cfbb="" id="timer">0</span></span>
                </div>
            </div>
            <div class="casino-video-right-icons">
                <div title="Home" class="casino-video-home-icon">
                    <a onclick="goLobby()" class="router-link-active" style="color: var(--text-highlight);"><i class="fas fa-home"></i></a>
                </div>
                <div title="Rules" data-toggle="modal" data-target="#rules-modal" class="casino-video-rules-icon"><i class="fas fa-info-circle"></i></div>
                <!---->
            </div>
            <!---->
        </div>
        <div class="casino-detail">
<div class="teen1daycasino-container d-none-big">
                  <div class="casino-box-row">
    <div class="casino-bl-box casino-bl-box-title">
        <div class="casino-bl-box-item"><b>Main</b></div>
        <div class="casino-bl-box-item"><b>Back</b></div>
       
    </div>
    <div class="casino-bl-box">
        <div class="casino-bl-box-item casino-odds-name casino-nation-name">
        <span>Player A</span> 
        <span class="float-right" id="player1">0</span>
        </div>
        <div class="back casino-bl-box-item suspended game_status"><span class="casino-box-odd" onclick='betSlipPageLoad("A","1","Back")' id="playerABack">1.96</span></div>
       
    </div>
    <div class="casino-bl-box">
        <div class="casino-bl-box-item casino-odds-name casino-nation-name"><span>Player B</span> <span class="float-right" id="player3">0</span></div>
        <div class="back casino-bl-box-item suspended game_status"><span class="casino-box-odd" onclick='betSlipPageLoad("B","3","Back")' id="playerBBack">1.96</span></div>
    </div>
</div>

                    <div class="teen1daycenter"></div>
                   
                  
                </div>

            <!---->
            <!---->
            <!---->
            <div class="casino-video-last-results d-none-desktop casinoResult">
                <span class="resulta">
                    A
                </span>
                <span class="resultb">
                    B
                </span>
                <span class="resultb">
                    B
                </span>
                <span class="resultb">
                    B
                </span>
                <span class="resulta">
                    A
                </span>
                <span class="resulta">
                    A
                </span>
                <span class="resultb">
                     B
                </span>
                <span class="resulta">
                    A
                </span>
                <span class="resultb">
                     B
                </span>
                <span class="resulta">
                    A
                </span>
                <a href="" class="result-more" style="display: none;">
                    ...
                </a>
            </div>
             <div id="casino-bets" class="card m-b-10 my-bet d-none-desktop">
                           <div class="casino-place-bet-title" style="padding:5px;background:#000;margin-top:1px;">
                                        <span>My Bets</span>
                                    </div>
                            <div class="card-body1">
                                <div class="tab-content">
                                    <div id="matched-bet" class="tab-pane active">
                                        <div class="table-responsive1">
                                            <table class="table coupon-table table-striped mb-0">
                                                <thead>
                                                    <tr>
                                                        <th style="min-width: 90px;">Name</th>
                                                        <th class="text-right" style="min-width: 50px;">Odds</th>
                                                        <th class="text-right" style="min-width: 70px;">Stake</th>
                                                        <th class="text-right" style="min-width: 70px;">P/L</th>
                                                    </tr>
                                                </thead>
                                                <tbody class="betListBody">
                                                    <tr>
                                                        <td colspan="4" class="text-center">--</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
        </div>
    </div>
</div>
<div id="__BVID__2447" role="dialog" aria-labelledby="__BVID__2447___BV_modal_title_" aria-describedby="__BVID__2447___BV_modal_body_" class="modal fade show casino-result" aria-modal="true" style="display: none; padding-right: 19px;">
    <div class="modal-dialog modal-xl">
        <span tabindex="0"></span>
        <div id="__BVID__2447___BV_modal_content_" tabindex="-1" class="modal-content">
            <header id="__BVID__2447___BV_modal_header_" class="modal-header">
                <h5 id="__BVID__2447___BV_modal_title_" class="modal-title">
                    20-20 Teenpatti Result
                </h5>
                <button type="button" aria-label="Close" class="close"  id="closeButton">×</button>
            </header>
            <div id="__BVID__2447___BV_modal_body_" class="modal-body">
                <div>
                    <div class="casino-result-round">
                        <div id="exampleModalLabelT20">Round-Id: 8394424093978</div>
                        
                    </div>
                    <!---->
                    <!---->
                    <div class="row row5">
                        <div class="col-12 col-lg-8">
                            <div class="casino-result-content">
                                <div class="casino-result-content-item text-center">
                                            <h4>Player A</h4>
                                    <div class="casino-result-cards">
                                        <div class="casino-result-cards-item" style="display: none;" id="winnerT1"><img src="https://sitethemedata.com/v62/static/front/img/winner.png" class="winner-icon" /></div>
                                        <div class="d-flex" id="player1CardT20">
                                            <div class="casino-result-cards-item"><img src="https://sitethemedata.com/v62/static/front/img/cards/ADD.png" /></div>
                                            <div class="casino-result-cards-item"><img src="https://sitethemedata.com/v62/static/front/img/cards/7HH.png" /></div>
                                            <div class="casino-result-cards-item"><img src="https://sitethemedata.com/v62/static/front/img/cards/3HH.png" /></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="casino-result-content-diveder"></div>
                                <div class="casino-result-content-item text-center">
                                            <h4>Player B</h4>
                                    <div class="casino-result-cards">
                                        <div class="casino-result-cards-item" style="display: none;" id="winnerT2"><img src="https://sitethemedata.com/v62/static/front/img/winner.png" class="winner-icon" /></div>
                                        <div class="d-flex"  id="player2CardT20">
                                            <div class="casino-result-cards-item"><img src="https://sitethemedata.com/v62/static/front/img/cards/2SS.png" /></div>
                                            <div class="casino-result-cards-item"><img src="https://sitethemedata.com/v62/static/front/img/cards/JDD.png" /></div>
                                            <div class="casino-result-cards-item"><img src="https://sitethemedata.com/v62/static/front/img/cards/4DD.png" /></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-lg-4">
                            <div class="casino-result-desc">
                                <div class="casino-result-desc-item">
                                    <div>Winner</div>
                                    <div id="playerWin"> Player A</div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
                <!---->
            </div>
            <!---->
        </div>
        <span tabindex="0"></span>
    </div>
</div>
                            </div>
                           <div id="right-sidebar-id" class="right-sidebar casino-right-sidebar teen2sidebar sticky">
   
    <span></span>
   
    <div class="casino-place-bet">
        <div class="casino-place-bet-title"><span>Last Results</span></div>
        <div class="casino-video-last-results casinoResult" id="lastresultssssss" style="padding: 5px;"></div>
    </div>

    <br />
    <br />
    <div class="casino-place-bet">
        <div class="casino-place-bet-title">
                                        <span>Place Bet</span> <span class="float-right casino-min-max"> Range:<span id="minStake">100</span>-<span id="maxStake">500K</span></span>
        </div>
        <div class="casino-place-bet-header">
            <div>(Bet for)</div>
            <div>Odds</div>
            <div>Stake</div>
            <div>Profit</div>
        </div>
        <div class="casino-place-bet-box" id="placeBetDiv" style="display:none">
        </div>
    </div>

     <div id="casino-bets" class="card m-b-10 my-bet">
                             <div class="casino-place-bet-title" style="background: #000;">
                                        <span>My Bets</span>
                                    </div>
                            <div class="card-body1">
                                <div class="tab-content">
                                    <div id="matched-bet" class="tab-pane active">
                                        <div class="table-responsive1">
                                            <table class="table coupon-table table-striped mb-0">
                                                <thead>
                                                    <tr>
                                                        <th style="min-width: 90px;">Name</th>
                                                        <th class="text-right" style="min-width: 50px;">Odds</th>
                                                        <th class="text-right" style="min-width: 70px;">Stake</th>
                                                        <th class="text-right" style="min-width: 70px;">P/L</th>
                                                    </tr>
                                                </thead>
                                                <tbody class="betListBody">
                                                    <tr>
                                                        <td colspan="4" class="text-center">--</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
    <span></span>
    <!---->
    <!---->
    <!---->
    <!---->
</div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
       <div id="rules-modal" role="dialog" aria-labelledby="modal_title_" aria-describedby="modal_body_" class="modal fade show casino-rules" aria-modal="true">
    <div class="modal-dialog modal-md">
        <span tabindex="0"></span>
        <div id="rules-modal___BV_modal_content_" tabindex="-1" class="modal-content">
            <header id="rules-modal___BV_modal_header_" class="modal-header">
                <h5 id="rules-modal___BV_modal_title_" class="modal-title">Rules</h5>
                <button type="button" aria-label="Close" class="close" data-dismiss="modal">X</button>
            </header>
            <div id="rules-modal___BV_modal_body_" class="modal-body">
            <img src="/images/teen20rules.jpg" class="img-fluid"></div>
             <div class="col-lg-12 col-xs-12" style="padding:0;margin:10px 10px;text-align:left">
<p style="color:#FFB80C;margin:5px 0px;">1. Kabhi Bhi Result Atakne Ki Condition Me Stake Vapas Kiya Jaa Skta Hai.</p>
<p style="color:#FFB80C;margin:5px 0px;">2. Kisi Bhi Vaad Vivaad Ki Condition Me Antim Faisla Company Ka Hoga.</p>
<p style="color:#FFB80C;margin:5px 0px;">2. T20 TeenPatti Me Bade Or Chote Patto Ka Example Diya Gya Hai.</p>

</div>
            <!---->
        </div>
        <span tabindex="0"></span>
    </div>
</div>

  <div id="betmodalmobile" role="dialog" aria-labelledby="__BVID__1924___BV_modal_title_" aria-describedby="__BVID__1924___BV_modal_body_" class="modal fade show" aria-modal="true">
    <div class="modal-dialog modal-md">
        <span tabindex="0"></span>
        <div id="__BVID__1924___BV_modal_content_" tabindex="-1" class="modal-content">
            <header id="__BVID__1924___BV_modal_header_" class="modal-header">
                <h5 id="__BVID__1924___BV_modal_title_" class="modal-title">
                    <h5 class="modal-title">
                        Place Bet <span class="casino-min-max ml-2"> Range:<span id="minpopStake">100</span>-<span id="maxpopStake">500K</span></span>
                    </h5>
                </h5>
                <button type="button" aria-label="Close" class="close" data-dismiss="modal">×</button>
            </header>
            <div id="bet_model_content" class="modal-body">
                
            </div>
            <!---->
        </div>
        <span tabindex="0"></span>
    </div>
</div>




    <script>
  
    var oneClickActive = false;
    var tokenPayload = parseJwt('eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJjNzQzNDIiLCJtaW4iOjEwMC4wLCJiYWxhbmNlIjoiMzAuMDAiLCJtYXgiOjIwMDAwLjAsImNsaWVudElwIjoiMTI3LjAuMC4xIiwibWF4UHJvZml0IjoxMDAwMDAuMCwicGFydG5lcklkIjoicm9sZXgxMiIsInBhZ2VQYXRoIjoiZGlhbW9uZDJ0ZWVucGF0dGl0MjAiLCJleHAiOjE2ODU0NzI3NzcsImlhdCI6MTY4NTQ3Mjc0NywiZ2FtZV9jb2RlIjoib2R0MjAifQ.zHW9TPXXDZHMzySOFGN9kwMRCTsnWmTaPNUwjRY0qax85J3YdhuLnJwjqlfAKK6rV49dt5v9VetmC1QENxY02A')
    $(document).ready(function(){
          	$("#loader-1").show()
          	        	$("#userBalance").html(tokenPayload.balance)
          	setTimeout(function(){ $("#loader-1").hide() }, 2000);
          	$("#minStake").html(tokenPayload.min)
          	$("#maxStake").html(tokenPayload.max)
          	$("#minpopStake").html(tokenPayload.min)
          	$("#maxpopStake").html(tokenPayload.max)
        }); 

  const socket = io('wss://fastapi1.newbsf.com', {
      transports: ['websocket'],
		allowUpgrades: false
  });

  socket.on('connect', () => {
      console.log('Connection Established');
  });

  socket.emit('score', '32388625'); 
  socket.on('score/32388625', (message) => {  
  console.log(message)  
      var data = message.data;
		var cards = data.t1[0]
		var status = data.t2[0].gstatus
		if(message!=""&&message.success==true){
			var placyerACards = [];
			var placyerBCards = [];

			if(cards.mid!=$("#roomid").val()){
				
				$("#oldroomid").val($("#roomid").val())
				$("#roomid").val(cards.mid)
				getBook() 
				getBet() 
				$("#round_details").html("Round ID: "+cards.mid.split(".")[1])		
			}
			
			var timer = cards.autotime
			if(timer.length==1){
				$("#timer").html("0"+timer)
			}else{
				$("#timer").html(timer)
			}
			$("#timer_clock").attr('stroke-dasharray',timer*12+' 283')
			if(timer>15){
				$("#timer_text_color").removeClass("red")
								$("#timer_text_color").addClass("green")
												$("#timer_clock").removeClass("red")
								$("#timer_clock").addClass("green")
			}else if(timer>10){
				$("#timer_text_color").removeClass("green")
								$("#timer_text_color").addClass("orange")
												$("#timer_clock").removeClass("green")
								$("#timer_clock").addClass("orange")
			}else if(timer<10){
				$("#timer_text_color").removeClass("orange")
				$("#timer_text_color").addClass("red")

				$("#timer_clock").removeClass("orange")
								$("#timer_clock").addClass("red")
			}
			if(status==0){
				$(".game_status").addClass("suspended")
			}else{
				$(".game_status").removeClass("suspended")
			}			
			$("#playerABack").html("1.96")
			$("#playerBBack").html("1.96")
			$("#playerAPair").html("0.00")
			$("#playerBPair").html("0.00")
			
			$(".p1a1").attr("src", "/diamondCard/"+cards.C1+".png")
			$(".p1a2").attr("src", "/diamondCard/"+cards.C2+".png")
			$(".p1a3").attr("src", "/diamondCard/"+cards.C3+".png")
			$(".p2a1").attr("src", "/diamondCard/"+cards.C4+".png")
			$(".p2a2").attr("src", "/diamondCard/"+cards.C5+".png")
			$(".p2a3").attr("src", "/diamondCard/"+cards.C6+".png")			

		}else{
			$("#backButton").trigger( "click" );
		}
  }); 
    		  var newData="";
  socket.emit('casinoresult', 'teen20');
  socket.on('casinoresult/teen20', (message) => {
       if(message.success==true){
    		  var data = message.data;
    		  if(($("#oldroomid").val()!='0'&&!$("#lastresultssssss").html().includes($("#oldroomid").val()))||($("#oldroomid").val()=='0'&&$("#lastresultssssss").html()=="")){
    		  $(".casinoResult").html('')
    		  if(data.mid != $("#oldroomid").val()){
    	   for(var i=0;i<data.length;i++){
    		   if(data[i].result==1){
        		   $(".casinoResult").append('<span class="resulta" onclick="showResult('+data[i].mid+')">A</span>')
    		   }else{
        		   $(".casinoResult").append('<span class="resultb" onclick="showResult('+data[i].mid+')">B</span>')    			   
    		   }
    	   }
    		  }
    		  }
       }
  });
 socket.on('disconnect', () => {
   console.log('Connection Closed');
 });

	 function betSlipPageLoad(selectionname,selectionId,type)
	    {		 
		 	var isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
			 if (isMobile == true) {
				 $("#bet_model_content").html('')
				 $("#betmodalmobile").modal('show')
				    var source   = $("#mobilebetSlipDesignHandler").html();
				    var template = Handlebars.compile(source);
				   	$("#bet_model_content").append( template());
		    	 $("#stakeinputmarchodds").val("");
				 $("#profitDiv").html('');				 
			 }else{
				 $('#placeBetDiv').show()
				 $('#placeBetDiv').html('')
				 var source   = $("#betSlipDesignHandler").html();
				    var template = Handlebars.compile(source);
				   	$("#placeBetDiv").append( template());
		    	 $("#stakeinputmarchodds").val("");
				 $("#profitDiv").html('');
			 }
	 						$("#stakeinputmarchodds").val("");
		    							$("#macthoddsbetslipodds").html($("#player"+selectionname+type).html()-1.00);
		    							 $("#playerName").html("Player "+selectionname)
	    				     $( ".stakeButton" ).click(function() {
	    				    	 $(".btn-round-done").prop('disabled', false);
	    				    	 var stake = $(this).text()
	    				    	 stake = stake.replace("k","000")
		    				    	 $("#stakeinputmarchodds").val(stake);	    				    			 
	    				    	 $("#profitDiv").html(stake*($("#macthoddsbetslipodds").html()))
	    					 });
		    							 $("#stakeinputmarchodds").on("keyup", function() {
		    	    				    	 $(".btn-round-done").prop('disabled', false);
		    						      });
	    				     $("#placebet").unbind().click(function(){
	    				    		 placeTeenPattiBet(selectionId,"Player "+selectionname,type) 
	    				     })
	    				     $(".cancel-betslip").click(function(){
	    						 $("#placeBetDiv").hide()
	    				     })
	    }
	 
	 function placeTeenPattiBet(selectionid,selectionname,type) 
	 {	
		 $("#loader-1").show();
		 var isback = false;
		 if(type=="Back"){
			 isback = true;
		 }else{
			 isback = false;
		 }
		 if($("#stakeinputmarchodds").val()<tokenPayload.min){
			 showMessage("Minimum stake you can place bet on is "+tokenPayload.min,false)
			 $("#loader-1").hide();
		 }else if($("#stakeinputmarchodds").val()>tokenPayload.max){
			 showMessage("Maximum stake you can place bet on is "+tokenPayload.max,false)
			 $("#loader-1").hide();
		 }else{
			 var data = {
					 	isBack:isback
						,userid:tokenPayload.sub
						,selectionids:"1,3"
						,odds:parseFloat($("#macthoddsbetslipodds").html()).toFixed(2)
						,selectionid:selectionid
						,selectionname:selectionname
						,amount:$("#stakeinputmarchodds").val()
						,round:$("#roomid").val()
						,partnerId:tokenPayload.partnerId
						,gameCode:tokenPayload.game_code};
					   	 $.ajax({
								type:'POST',
								url:'/api/placeCasinobet',
								data: JSON.stringify(data),
								dataType: "json",
								contentType:"application/json; charset=utf-8",
								success: function(jsondata, textStatus, xhr) {
				 			},
								complete: function(jsondata,textStatus,xhr) {
									$("#placeBetDiv").hide()
									$("#betmodalmobile").modal('hide')
									getBook() 
									getBet() 
									showMessage(jsondata.responseJSON.message,jsondata.responseJSON.success);
									if(jsondata.responseJSON.success==true){
										$("#userBalance").html(jsondata.responseJSON.data.balance)
									}
									$("#loader-1").hide();
							    } 
							}); 
		 }
	}
	 
     function parseJwt (token) {
         var base64Url = token.split('.')[1];
         var base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
         var jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c) {
             return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
         }).join(''));
         return JSON.parse(jsonPayload);
     };
     
	 function getBook() 
	 {	
			var data = {round:$("#roomid").val()
			,userid:tokenPayload.sub
			,partnerId:tokenPayload.partnerId};
		   	 $.ajax({
					type:'POST',
					url:'/api/casinoBook',
					data: JSON.stringify(data),
					dataType: "json",
					contentType:"application/json; charset=utf-8",
					success: function(jsondata, textStatus, xhr) {
	    				if(xhr.status == 200)
	    				{     
	    					jsondata = jsondata.data
	    					if(jsondata.pnl1<0.00){
	    						$("#player"+jsondata.selectionId1).css("color","#FF0000");
	    					}else{
	    						$("#player"+jsondata.selectionId1).css("color","#2cd62c");
	    					}
	    					if(jsondata.pnl2 < 0.00){
	    						$("#player"+jsondata.selectionId2).css("color","#FF0000");
	    					}else{
	    						$("#player"+jsondata.selectionId2).css("color","#2cd62c");
	    					}
	    						$("#player"+jsondata.selectionId1).html(jsondata.pnl1).show();
		    					$("#player"+jsondata.selectionId2).html(jsondata.pnl2).show();
	   					}else{
    						$("#player1").html("0.00").show();
    						$("#player3").html("0.00").show();
	   					}
	 			},
					complete: function(jsondata,textStatus,xhr) {
				    } 
				}); 
	}
	 
	 
	 function getBet() 
	 {	
			var data = {round:$("#roomid").val()
			,userid:tokenPayload.sub
			,partnerId:tokenPayload.partnerId};
		   	 $.ajax({
					type:'POST',
					url:'/api/casinoBet',
					data: JSON.stringify(data),
					dataType: "json",
					contentType:"application/json; charset=utf-8",
					success: function(jsondata, textStatus, xhr) {
	    				if(xhr.status == 200)
	    				{     
	    					jsondata = jsondata.data
	    					$(".betListBody").html('')
	    					for(var i=0;i<jsondata.length;i++){
	    						if(jsondata[i].isBack==true){
			    					$(".betListBody").html($(".betListBody").html()+'<tr class="mark-back"><td>'+jsondata[i].selectionname+'</td><td>'+jsondata[i].odds+'</td><td>'+jsondata[i].amount+'</td><td>'+((jsondata[i].odds)*jsondata[i].amount).toFixed(2)+'</td></tr>')	    						
	    						}else{
			    					$(".betListBody").html($(".betListBody").html()+'<tr class="mark-lay"><td>'+jsondata[i].selectionname+'</td><td>'+jsondata[i].odds+'</td><td>'+jsondata[i].amount+'</td><td>'+((jsondata[i].odds)*jsondata[i].amount).toFixed(2)+'</td></tr>')	    							    							
	    						}
	    					}
	   					}else{
	   						$(".betListBody").html('--')
	   					}
	 			},
					complete: function(jsondata,textStatus,xhr) {
				    } 
				}); 
	}
	 function goLobby(){
		 getLobbyUrl(tokenPayload)
	 }
	 
	 function showResult(mid){
				   	 $.ajax({
							type:'POST',
							url:'/api/getGameData?round='+mid,
							contentType:"application/json; charset=utf-8",
							success: function(jsondata, textStatus, xhr) {
			    				if(xhr.status == 200)
			    				{
			    					var data = jsondata;
					                data = JSON.parse(data.resultData);
					                var gType = data.gtype;					                  
					                setTeenPattiT20Data(data);
			   					}else{
			   						$(".betListBody").html('--')
			   					}
			 			},
							complete: function(jsondata,textStatus,xhr) {
						    } 
						}); 
		 
	 }
	 
	 
	 function setTeenPattiT20Data(data) {
         $("#__BVID__2447").show();
         var gtype =data.gtype;
         $("#exampleModalLabelT20").html("Round-Id:" + data.mid);
         const cards = data.cards.split(",");
         var cardDesignPlayer1 = "";
         $("#player1CardT20").html('');
         cardDesignPlayer1 = cardDesignPlayer1 + '<img src="/images/' + cards[0] +'.png" alt="card" class="card">';
         cardDesignPlayer1 = cardDesignPlayer1 + '<img src="/images/' + cards[2] +'.png" alt="card" class="card">';
         cardDesignPlayer1 = cardDesignPlayer1 + '<img src="/images/' + cards[4] +'.png" alt="card" class="card">';
   		
   	  	$("#player1CardT20").append(cardDesignPlayer1);
    	 var cardDesignPlayer2 = "";
     	$("#player2CardT20").html('');
         cardDesignPlayer2 = cardDesignPlayer2 + '<img  src="/images/' + cards[1] +'.png" alt="card" class="card">';
         cardDesignPlayer2 = cardDesignPlayer2 + '<img  src="/images/' + cards[3] +'.png" alt="card" class="card">';
         cardDesignPlayer2 = cardDesignPlayer2 + '<img  src="/images/' + cards[5] +'.png" alt="card" class="card">';
    		
     	$("#player2CardT20").append(cardDesignPlayer2);
         if (data.win == '1') {
         $("#playerWin").html("Player A")
             $("#winnerT1").show();
             $("#winnerT2").hide();
         } 
         else if (data.win == '3') {
        	 $("#playerWin").html("Player B")
             $("#winnerT1").hide();
             $("#winnerT2").show();
         }
     }
	 
	 $('#closeButton').click(function(e) { 
		 $("#__BVID__2447").hide();
		});

  </script>
  <input type="hidden" id="ipdetail">
<input type="hidden" id="roomid" value="0">
<input type="hidden" id="oldroomid" value="0">

<input type="hidden" id="listCount">

    </body>
</html>
