<?php 
include('include/config.php');
include('header.php');
sanatize($_GET);
$match_data=match_details($_GET['market_id'],'event_id,market_id,match_name');
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Match & Session Plus Minus Report</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="dashboard?page_name=dashboard">Home</a></li>
              <li class="breadcrumb-item active">Match & Session Plus Minus Report</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">

                        <!-- /.card -->

                        <div class="card">


                            <form action="session_list_plus_minus" method="POST" id="demoForm">
                              <input type="hidden" name="market_id" value="<?= $_GET['market_id'] ?>">
                              <input type="hidden" name="page_name" value="match">


                                <div class="card-header text-md-center text-bold">
                                    <h5><?= strtoupper($match_data['match_name']) ?> (<?= strtoupper($match_data['match_type']) ?>)</h5>
                                </div>
                                <!-- /.card-header -->
                                <div class="card-body">

                                    <div class="form-inline">
                                        <label class="my-2 mr-3" for="type">Preference</label>
                                        <select id="type" name="type" class="custom-select my-3 mr-sm-4">
                                            <option value="b">Both</option>
                                            <option value="s">Session</option>
                                        </select>

                                        <button type="submit" class="btn btn-primary my-3">Show</button>
                                    </div>

                                </div>
                                <!-- /.card-body -->

                            </form>
                        </div>
                        <!-- /.card -->


                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </section>

   

   
  </div>
  <!-- /.content-wrapper -->

  <?php  include('footer.php');  ?>