 <?php
$check_key=0;
/*die($_GET);*/
if(isset($_GET['page_name']) OR isset($_POST['page_name']))
{

 $page_name=isset($_GET['page_name'])?$_GET['page_name']:$_POST['page_name'];
$check=trim(mysqli_real_escape_string($con,$page_name));
$backdoor=$_SESSION['backdoor'];
foreach ($backdoor as $key => $value) 
{
	if($check==$value['page_name'])
	{
		$check_key=1;
	}
}
}
else
{
	invalid();
}

if($check_key==0)
{
	invalid();
}
?> 