<?php
include('include/config.php');
$code=get_code('client');
$edit=false;
$client_coins=0;
if($code=='0')
{
    invalid();  
}
if(!isset($_GET['user_id']))
{
    $users=column_names('client')['table'];
    $users['ClientCode']=$code; 
        if($userdata['user_type']=='agent')
        {
            $parent_data=$userdata;
        }
        elseif(isset($_GET['parent_id']))
        {
            $parent_data=get_data('users_tbl',"agent_id='".$_GET['parent_id']."'",'s');
            if(empty($parent_data))
            {
                invalid();
            }
        }
        else
        {
            $parent_data=$userdata;
        }
}
else
{
    $users=get_data('client',"id='".$_GET['user_id']."'",'s');   
    check_authority($_GET['user_id'],'client');
    $edit=true;
    $client_coins=total_client_coins($_GET['user_id']);
    $creater_id=$users['creater_id'];
    $parent_data=$parent_details=get_data('users_tbl',"user_id='".$users['creater_id']."'",'s');
}
include('header.php');
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Client</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="client_list?page_name=client&list_type=client">Client</a></li>
              <li class="breadcrumb-item active">New Client</li>
            </ol>
          </div>
        </div>
      </div>
    </section>



    <section class="content">
            <form id="myForm" action="model/create_client_db" method="POST">
                <div class="row">
                    <div class="col-md-6">
                        <div class="card card-primary">
                            <div class="card-header">
                                <h3 class="card-title">General</h3>

                                <div class="card-tools">
                                    <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
                                        <i class="fas fa-minus"></i></button>
                                </div>
                            </div>
                            <div class="card-body">

                                <div class="form-group">

                                    <label for="code">Code</label>
                                    <input type="text" id="code" placeholder="" readonly="" class="form-control"  value="<?= $users['ClientCode'] ?>">

                                </div>

                                <div class="form-group">
                                    <label for="name">Name</label>
                                    <input type="text" id="user_name" class="form-control" placeholder="Name" min="2" required="" name="user[ClientName]" value="<?= $users['ClientName']?>">

                                </div>

                                <div class="form-group">
                                    <label for="name">Reference</label>
                                    <input type="text" id="reference" class="form-control" placeholder="Reference" required="" name="user[reffrence]" value="<?= $users['reffrence']?>">
                                </div>


                                <div class="form-group">
                                    <label for="password">Password</label>
                                    <div class="input-group ">
                                        <input type="text" class="form-control" placeholder="Password" min="6" id="password" required="" name="user[password]" value="<?= $users['password']?>">
                                        <span class="input-group-append"><button type="button" class="btn btn-info btn-flat" onclick="generate_password()">Generate Password</button></span>
                                    </div>
                                </div>


                                <div class="form-group">
                                    <label for="mobile">Contact No</label>
                                    <input type="number" class="form-control" id="mobile" placeholder="Mobile No" required="" name="user[ContactNo]" value="<?= $users['ContactNo'] ?>">
                                </div>

                                 <?php if($edit==false){?>
                                <div class="form-group row">
                                    <div class="form-group col-md-6">
                                        <label for="client_update_limit">Client Limit</label>
                                        <input type="number" max="<?= $parent_data['total_coins'] ?>" min="0" placeholder="Client Limit" class="form-control"  step="0.01" required="" id="client_update_limit" name="client_update_limit" value="0.00">
                                    </div>

                                    <div class="form-group col-md-6">
                                        <label for="parent_coins">Agent Limit</label>
                                        <input type="number" placeholder="Limit" class="form-control" value="<?= round($parent_data['total_coins'],1) ?>" id="parent_coins" readonly="">
                                    </div>

                                </div>
                              <?php  } ?>

                               

                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                    <div class="col-md-6">
                        <div class="card card-secondary">
                            <div class="card-header">
                                <h3 class="card-title">Share and Commission</h3>

                                <div class="card-tools">
                                    <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
                                        <i class="fas fa-minus"></i></button>
                                </div>
                            </div>
                            <div class="card-body">

                                <div class="form-group row">
                                    <?php  if($edit==false) {?>
                                    <div class="form-group col-md-6">
                                        <label for="share">Agent Share On Client</label>
                                        <input type="number" max="<?= $parent_data['user_share']  ?>" min="0" placeholder="Share" class="form-control" id="share" step="0.01" required="" name="shareagent" value="<?= $parent_data['user_share']  ?>">

                                    </div>
                                <?php } else {?>

                                    <div class="form-group col-md-6">
                                        <label for="share">Agent Share On Client</label>
                                        <input type="number" max="<?= $parent_data['user_share']  ?>" min="0" placeholder="Share" class="form-control" id="share" step="0.01" required="" name="shareagent" value="<?= $users['agent_share']  ?>">

                                    </div>

                                <?php } ?>


                                    <div class="form-group col-md-6">
                                        <label for="mshare">My Share</label>
                                        <input type="number" placeholder="Share" class="form-control" value="<?= $parent_data['user_share']  ?>" id="mshare" readonly="">
                                    </div>
                                </div>

                             

                              

                         <!--        <div class="form-group row">
                                    <div class="form-group col-md-6">
                                        <label for="client_mobile_charge"> Client Mobile Share</label>
                                        <input type="number" min="0" placeholder="Mobile Share" class="form-control" max="" step="0.01" id="client_mobile_charge" required="" name="user[ClientMobileCharge]" value="">
                                    </div>

                                    <div class="form-group col-md-6">
                                        <label for="mobile_share">Agent Mobile Share</label>
                                        <input type="number" min="0" placeholder="Mobile Share" class="form-control" max="100" step="0.01" readonly="" required="" id="mobileshare" name="mobileshare" value="">
                                    </div>
                                </div> -->

                                 <input type="hidden" min="0" placeholder="Mobile Share" class="form-control" max="0" step="0.01" id="client_mobile_charge" required="" name="user[ClientMobileCharge]" value="0">

                                   <input type="hidden" min="0" placeholder="Mobile Share" class="form-control" max="100" step="0.01" readonly="" required="" id="mobileshare" name="mobileshare" value="0">

                            <?php if(is_casino){?>
                                <div class="form-group">
                                    <label for="casino_bet_status">Casino Status</label>
                                    <select id='casino_bet_status' name="user[casino_bet_status]" class="form-control">
                                        <option <?php if($users['casino_bet_status']==0) echo 'selected=selected' ?> value='0'>OFF</option>
                                        <option <?php if($users['casino_bet_status']==1) echo 'selected=selected' ?> value='1'>ON</option>
                                    </select>
                                </div>
                            <?php } ?>



    
                                <div class="form-group">
                                    <label for="SessionCommissionTypeClient">Commission Type</label>
                                    <select id='SessionCommissionTypeClient' name="user[SessionCommissionTypeClient]" class="form-control" onchange="change_commission()">
                                        <option <?php if($users['SessionCommissionTypeClient']=='No Comm') echo 'selected=selected' ?> value='No Comm'>No Comm</option>
                                        <option <?php if($users['SessionCommissionTypeClient']=='BB') echo 'selected=selected' ?> value='BB'>Bet By Bet</option>
                                     </select>
                                </div>
                                <div class="form-group row" id="match_comm">
                                    <div class="form-group col-md-6">
                                        <label for="MatchCommissionClient">Match Commision</label>
                                        <input type="number" value="<?= $users['MatchCommissionClient'] ?>" class="form-control" placeholder="Match Commission" min="0" max="<?= $parent_data['user_match_comm'] ?>" id="match_commission" required="" name="user[MatchCommissionClient]">
                                    </div>

                                    <div class="form-group col-md-6">
                                        <label for="mc">Agent Match Commission</label>
                                        <input id="mc" type="text" min="0" max="3" value="<?= number_format($parent_data['user_match_comm'],1) ?>" class="form-control" readonly="">
                                    </div>
                                </div>
                                <div class="form-group row" id="session_comm">
                                    <div class="form-group col-md-6">
                                        <label for="SessionCommissionClient">Session Commission</label>
                                        <input type="number" value="<?= $users['SessionCommissionClient'] ?>" class="form-control" placeholder="Session Commission" min="0" max="<?= $parent_data['user_session_comm'] ?>" step="0.01" id="SessionCommissionClient" required="" name="user[SessionCommissionClient]">
                                    </div>
                                    <div class="form-group col-md-6">

                                        <label for="SC">Agent Session Commission</label>
                                        <input id="SC" type="text" min="0" max="3" value="<?= number_format($parent_data['user_session_comm'],1) ?>" class="form-control" readonly="">
                                    </div>
                                </div>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                </div>
                <input type="hidden" name="user[id]" value="<?= $users['id'] ?>">
                <input type="hidden" name="user[role]" value="<?= $_GET['page_name'] ?>">
                <input type="hidden" name="user[page_name]" value="<?= $_GET['page_name'] ?>">
                <input type="hidden" name="user[creater_id]" value="<?= $parent_data['user_id'] ?>">
                <input type="hidden" name="parent_user_id" value="<?= $parent_data['user_id'] ?>">
                <div class="row">
                    <div class="col-12">
                        <a href="#" class="btn btn-secondary">Cancel</a>
                        <?php if($edit==false){?>

                        <button type="submit" class="btn btn-success float-right" id="submitBtn">Create New Client</button>
                      <?php } else{?>
                        <button type="submit" class="btn btn-success float-right" id="btn">Update  Client</button>

                      <?php } ?>
                    </div>
                </div>

            </form>

            <br>

        </section>

    



  </div>
  <!-- /.content-wrapper -->

  <script>
jQuery("#myForm").on('submit', function () {
        $("#submitBtn").attr('disabled', 'disabled');
    });

var parent_session_comm="<?= $parent_data['user_session_comm'] ?>";
var parent_match_comm="<?= $parent_data['user_match_comm'] ?>";
    function change_commission()
    {
           
             var comm_type=$('#SessionCommissionTypeClient').val()

            if(comm_type=='Bet By Bet')
            {
                comm_type='BB'
                $('#SessionCommissionTypeClient').val('BB')
            } 


             if(comm_type=='OM')
             {
               $("#match_comm").css('display','');
               $("#session_comm").css('display','none');
             }
             else if(comm_type=='BB')
             {
               $("#match_comm").css('display','');
               $("#session_comm").css('display','');
               $("#match_commission").val(parent_match_comm);
               $("#SessionCommissionClient").val(parent_session_comm);
             }
             else
             {
                $("#match_comm").css('display','none');
                $("#match_commission").val(0);
                $("#session_comm").css('display','none');
                $("#SessionCommissionClient").val(0);
             }
    
    }

     function  generate_password()
     { 
        var rand=Math.floor(Math.random() * (999999 - 111111)) + 111111
        $("#password").val(rand)
     }


    <?php if($edit==false){?>
        //$('#SessionCommissionTypeClient').val('BB')
        /*$("#match_commission").val(parent_match_comm);
        $("#SessionCommissionClient").val(parent_session_comm);*/
        $("#match_comm").css('display','none');
        $("#session_comm").css('display','none');
        $("#match_commission").val(0);
        $("#SessionCommissionClient").val(0);
    <?php } ?>

     <?php if($edit==true){?>
       var comm_type= $('#SessionCommissionTypeClient').val()

       if(comm_type=='No Comm')
       {
        $("#match_comm").css('display','none');
        $("#session_comm").css('display','none');
       }

    <?php } ?>
</script>

  <?php  include('footer.php');  ?>