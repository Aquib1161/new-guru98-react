<?php
include('include/config.php');
$_GET=sanatize($_GET);
extract($_GET);
extract($_POST);
$_POST['downline_array']=sanatize($_POST['downline_array']);
$_POST['session_array']=sanatize($_POST['session_array']);
$match_data=get_data('upcoming_match',"market_id='".$_POST['market_id']."'",'s','match_name,event_id,match_type');
$client_array=$_POST['downline_array'];

include('header.php');

                              $total_client_match_coins=0;
                              $total_client_session_coins=0;
                              $total_client_match_commission=0;
                              $total_client_session_commission=0;
                              $total_match_session_total=0;
                              $total_match_session_total=0;
                              $total_match_session_commm_total=0;
                              $total_client_total=0;
                              $total_other=0;
                              $total_final=0;
                              $total_agent_amount=0;
                              $total_agent_match_comm=0;
                              $total_agent_session_comm=0;
                              $total_superagent_amount=0;
                              $total_superagent_match_comm=0;
                              $total_superagent_session_comm=0;
                              $total_master_amount=0;
                              $total_master_match_comm=0;
                              $total_master_session_comm=0;
                              $total_admin_amount=0;
                              $total_admin_match_comm=0;
                              $total_admin_session_comm=0;
                              $total_superadmin_amount=0;
                              $total_superadmin_match_comm=0;
                              $total_superadmin_session_comm=0;
                              $total_company_amount=0;

                              $total_agent_session_match_comm=0;
                              $total_agent_net_amt=0;

                              $total_sa_session_match_comm=0;
                              $total_sa_net_amt=0;


?>

<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Match & Session Plus Minus Report</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="dashboard?page_name=dashboard">Home</a></li>
              <li class="breadcrumb-item active">Match & Session Plus Minus Report</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div>

                        <!-- /.card -->

                        <div class="card card-default">


                            <div class="card-header text-center text-bold">
                                <h5 class="card-title">MATCH CODE : (<?= strtoupper($match_data['event_id'])?>) <?= strtoupper($userdata['user_type'])?> &amp; CLIENT OF <?= strtoupper($match_data['match_name'])?> (<?= strtoupper($match_data['match_type'])?>)</h5>
                            </div>
                            <!-- /.card-header -->
                            <div class="card-body">


                                <div class="card-default">
                                    <div class="card-header text-center">
                                        <h5 class="card-title">AGENT PLUS MINUS</h5>
                                    </div>
                                    <div class="card-body">

                                        <table id="data" class="table table-striped table-bordered">

                                            <thead>
                                            <tr>
                                                <th colspan="7" class="text-center">Client PLusMinus</th>
                                                <th colspan="7" class="text-center">Agent PLusMinus</th>
                                            </tr>

                                            </thead>

                                            <thead>
                                            <tr>
                                                <th>CLIENT</th>
                                                <th>M AMT</th>
                                                <th>S AMT</th>
                                                <th>C COM</th>
                                                <th>NET AMT</th>
                                                <th>C MOB</th>
                                                <th>FINAL</th>
                                                <th>M COM</th>
                                                <th>S COM</th>
                                                <th>T COM</th>
                                                <th>NET AMT</th>
                                                <th>SHR AMT</th>
                                                <th>MOB APP</th>
                                                <th>FINAL</th>

                                            </tr>
                                            </thead>

                                            <tbody>
                                        <?php foreach ($client_array as $key => $client_id) { 


                            $report_value=get_data('md_client_position',"market_id='".$market_id."' AND client_id='".$client_id."'",'s');

                            if(!empty($report_value))
                            {
                            extract($report_value);

                            //_dx($report_value);
                            $array_data=json_decode($report_value['array_data'],true);
                            $user_data=$array_data['user_amount_old_type'];
                            extract($user_data);
                            $client_data=get_data('client',"id='".$report_value['client_id']."'",'s','ClientName,ClientCode');

                            $share_data=get_data('shares',"market_id='".$_POST['market_id']."' AND client_id='".$report_value['client_id']."'",'s');

                            $match_session_total=$report_value['client_match_coins']+$report_value['client_session_coins'];

                            $match_session_commm_total=$report_value['client_match_commission']+$report_value['client_session_commission'];

                            $client_total=$match_session_total-$match_session_commm_total;

                            $other=$report_value['client_mobile_charge'];

                            $final=$client_total-$other;


                            $agent_net_amount=$agent_net_amount;
                            $agent_amount=$agent_share_amount;


                            $agent_total_comm=$agent_match_commission+$agent_session_commission;
                            $sa_total_comm=$sa_match_commission+$sa_session_commission;
                           

                            $sa_net_amount=($agent_net_amount-$agent_amount);

                            

                            $agent_match_comm=$agent_match_commission;
                            $agent_session_comm=$agent_session_commission;

                            $superagent_amount=($sa_total_amount);
                            $superagent_match_comm=$sa_match_commission;
                            $superagent_session_comm=$sa_session_commission;


                            $master_amount=($master_total_amount-$sa_total_amount);
                            $master_match_comm=$master_match_commission;
                            $master_session_comm=$master_session_commission;
                            

                            $admin_amount=($admin_total_amount-$master_total_amount);
                            $admin_match_comm=$admin_match_commission;
                            $admin_session_comm=$admin_session_commission;

                            $superadmin_amount=($superadmin_total_amount-$admin_total_amount);
                            $superadmin_match_comm=$superadmin_match_commission;
                            $superadmin_session_comm=$superadmin_session_commission;
                             
                             $overall_superadmin_share=100;
                             $overall_admin_share=$overall_superadmin_share-$admin_share;
                             $overall_master_share=$overall_admin_share-$master_share;
                             $overall_superagent_share=$overall_master_share-$superagent_share;
                             $overall_agent_share=$overall_superagent_share-$agent_share;

                             $company_share=0;
                             $company_amount=0;
                            /* _d($report_value);*/

                             if($user_priority>=priority('agent'))
                             {
                                $company_share=100-$agent_share;
                                $company_amount=$agent_final_amount;
                             }
                             if($user_priority>=priority('superagent'))
                             {
                                $company_share=100-($agent_share+$superagent_share);
                                $company_amount=$sa_share_amount;
                             }
                             if($user_priority>=priority('master'))
                             {
                                $company_share=100-($agent_share+$superagent_share+$master_share);
                                $company_amount=$master_share_amount;
                             }
                             if($user_priority>=priority('admin'))
                             {
                                $company_share=100-$agent_share+$superagent_share+$master_share+$admin_share;
                                $company_amount=$admin_share_value;
                             }

                             if($user_priority>=priority('superadmin'))
                             {
                                $company_share=0;
                                $company_amount=0;
                             }
                             

                              $total_client_match_coins+=$report_value['client_match_coins'];
                              $total_client_session_coins+=$report_value['client_session_coins'];
                              $total_client_match_commission+=$report_value['client_match_commission'];
                              $total_client_session_commission+=$report_value['client_session_commission'];

                              $total_match_session_total+=$match_session_total;
                              //$total_match_session_total+=$match_session_total;
                              $total_match_session_commm_total+=$match_session_commm_total;
                              $total_client_total+=$client_total;
                              $total_other+=$other;
                              $total_final+=$final;


                              $total_agent_amount+=$agent_amount;
                              $total_agent_match_comm+=$agent_match_comm;
                              $total_agent_session_comm+=$agent_session_comm;
                              $total_agent_session_match_comm+=$agent_total_comm;
                              $total_agent_net_amt+=$agent_net_amount;
                             




                              $total_superagent_amount+=$superagent_amount;
                              $total_master_amount+=$master_amount;
                              $total_admin_amount+=$admin_amount;
                              $total_superadmin_amount+=$superadmin_amount;
                              $total_company_amount+=$company_amount;

                              $total_superagent_match_comm+=$superagent_match_comm;
                              $total_superagent_session_comm+=$superagent_session_comm;
                              $total_sa_session_match_comm+=$sa_total_comm;
                              $total_sa_net_amt+=$sa_net_amount;

                              $total_master_match_comm+=$master_match_comm;
                              $total_master_session_comm+=$master_session_comm;

                              $total_admin_match_comm+=$admin_match_comm;
                              $total_admin_session_comm+=$admin_session_comm;

                              $total_superadmin_match_comm+=$superadmin_match_comm;
                              $total_superadmin_session_comm+=$superadmin_session_comm;

                                            
                            ?>


                                          
                                                  
                                            <tr>

                                                <td><?= $client_data['ClientName'] ?> (<?= $client_data['ClientCode'] ?>)</td>
                                                <td><?= (number_format($report_value['client_match_coins'],2)) ?></td>
                                                <td><?= (number_format($report_value['client_session_coins'],2)) ?></td>
                                                <td><?= number_format($match_session_commm_total,2) ?></td>
                                                <td><?= (number_format($client_total,2)) ?></td>
                                               
                                                <td> <?= (number_format($other,2)) ?></td>
                                                <td><?= (number_format($final,2)) ?></td>
                                                <td><?= (number_format(-1*$agent_match_comm,2)) ?></td>
                                                <td><?= (number_format(-1*$agent_session_comm,2)) ?></td>
                                                <td><?= (number_format(-1*($agent_session_comm+$agent_match_comm),2)) ?></td>
                                                <td><?= (number_format($agent_net_amount,2)) ?></td>
                                                <td><?= (number_format($agent_amount,2)) ?></td>
                                                  <td> <?= (number_format($other,2)) ?></td>
                                                <td><?= (number_format($company_amount,2)) ?></td>
                                            </tr>

                                        <?php }  }?>
                                            
                                            
                                            </tbody>

                                            <tfoot>
                                            <tr>
                                                <th>TOTAL</th>
                                                <th ><?= (number_format($total_client_match_coins,2)) ?></th>
                                                <th ><?= (number_format($total_client_session_coins,2)) ?></th>
                                                 <th ><?= (number_format($total_match_session_commm_total,2)) ?></th>
                                                <th ><?= (number_format($total_client_total,2)) ?></th>
                                                <th ><?= (number_format($total_other,2)) ?></th>
                                                <th ><?= (number_format($total_final,2)) ?></th>
                                                <th ><?= (number_format(-1*$total_agent_match_comm,2)) ?></th>  
                                                <th ><?= (number_format(-1*$total_agent_session_comm,2)) ?></th>  
                                                <th ><?= (number_format(-1*$total_agent_session_match_comm,2)) ?></th>  
                                                <th ><?= (number_format($total_agent_net_amt,2)) ?></th>  
                                                <th ><?= (number_format($total_agent_amount,2)) ?></th> 
                                                <th ><?= (number_format($total_other,2)) ?></th>
                                                <th ><?= (number_format($total_company_amount,2)) ?></th>
                                            </tr>
                                            </tfoot>
                                        </table>

                                    </div>
                                </div>


                            </div>
                            <!-- /.card-body -->

                        </div>
                        <!-- /.card -->


                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </section>

   

   
  </div>
  <!-- /.content-wrapper -->

  <?php  include('footer.php');  ?>