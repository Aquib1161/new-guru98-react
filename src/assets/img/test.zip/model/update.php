<?php
include('../include/config.php');
if(isset($_POST['password_update']))
{

if(!isset($_POST))
{
	invalid();
}
$post_array=sanatize($_POST);
unset($post_array['password_update']);

$user_result=get_data('users_tbl',"user_id=".$userdata['user_id']."",'s');

if($user_result['password']!=$post_array['old_password'])
{
                $_SESSION['notify']=['type'=>'error','msg'=>'Old Password is not correct'];
                header("location:../password?all");
                die();  
                exit();
}

unset($post_array['old_password']);
$post_array['password']=$post_array['new_password'];
unset($post_array['new_password']);
$data= update_array('users_tbl', $post_array,'user_id='.$userdata['user_id']);
/*$user_result=get_user_list('',$post_array['user_id']);*/
$task_array=array(
	'user_id'=>$user_result['user_id'],
    'user_type'=>$user_result['user_type'],
    'user_match_comm'=>$user_result['user_match_comm'],
    'user_session_comm'=>$user_result['user_session_comm'],
    'user_share'=>$user_result['user_share'],
    'task_name'=>$user_result['user_type'].'Password updated',
    'creater_id'=>$_SESSION['user_id'],
    'creater_type'=>$_SESSION['user_type'],
    'creater_name'=>$_SESSION['name'],
    'ip'=>ip(),
    'date'=>_date(),
    'date_time'=>_date_time(),
    'user_name'=>$user_result['name']

);  
    $result=insert_array('user_history_log',$task_array,'');
	$_SESSION['notify']=['type'=>'success','msg'=>' password updated successfully'];
	
		header("location:../logout");
	
//header("location:../list.php?list_type=".$page_name."&page_name=".$page_name."");
}
if(isset($_POST['client_password_update']))
{
if(!isset($_POST))
{
	invalid();
}
$post_array=sanatize($_POST['user']);
$user_result=get_user_list(	'',$post_array['id'],'client');
//_dx($user_result);
$task_array=array(
	'client_id'=>$post_array['id'],
    'user_type'=>'client',
    'user_match_comm'=>$user_result['MatchCommissionClient'],
    'user_session_comm'=>$user_result['SessionCommissionClient'],
    'user_share'=>$user_result['MatchShare'],
    'task_name'=>'Client Password updated',
    'creater_id'=>$_SESSION['user_id'],
    'creater_type'=>$_SESSION['user_type'],
    'creater_name'=>$_SESSION['name'],
    'ip'=>ip(),
    'date'=>_date(),
    'date_time'=>_date_time(),
    'user_name'=>$user_result['ClientName']

);  
    $result=insert_array('user_history_log',$task_array,'');
    $data= update_array('client', $post_array,'id='.$post_array['id']);
	$_SESSION['notify']=['type'=>'success','msg'=>''.$page_name.' password updated successfully'];
header("location:../client_list.php?list_type=".$page_name."&page_name=".$page_name."");
}


?>