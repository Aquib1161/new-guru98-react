<?php 
include('include/config.php');
if($_SESSION['user_type']=='owner')
{
include('match_header.php');
}
else
{
include('header.php');    
}
if(isset($_GET['self']))
{
    $_GET['id']=$_SESSION['user_id'];
    //$_GET['page_name']=trim($_SESSION['user_type']);
}
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

   <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <div class="text-center">
                            <h3><i class="fa fa-lock fa-4x"></i></h3>
                            <h2 class="text-center">Change Password?</h2>
                            <p>You can change your password here.</p>
                            <div class="panel-body">

                                <form  role="form" autocomplete="off" action="model/update" class="form" method="post">


                                    <div class="form-group">
                                        <label for="password">Enter Current Password</label>
                                        <input type="password" placeholder="Enter Current Password" id="current_password" class="form-control" name="old_password" required="">
                                        <br>
                                        <div class="input-group">
                                            <input type="text" name="new_password" id="new_password" class="form-control" min="6" minlength="8" maxlength="12" placeholder="Enter New Password" required="">
                                           
                                        </div>
                                        <small class="form-text text-muted">Must be at least 8 characters include
                                            numeric, alphabets and special symbols i.e. Bharat@007# </small>

                                    </div>


                                
                                    <div>
                                      <input type="hidden" name="password_update">
                                        <input type="submit" class="btn btn-primary change_password_btn" value="Save Changes" id="submit">
                                    </div>
<br>
                                    <div class="form-group">
                                        <a href="/" class="btn  btn-lg btn-outline-danger">
                                            Back
                                        </a>
                                    </div>

                                   
                                </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

   
  </div>
<script>

        $(document).ready(function(){
         $("#submit").click(function(){
            var validate=true;
  var new_pass = $("#new_password").val();
  var current_pass = $("#current_password").val();
  if(new_pass=='')
  {
    swal('error','','P')
    validate=false;
  }
  if(current_pass=='')
  {
    swal('error','','P')
    validate=false;
  }
  return validate;
});
        });
</script>

  <?php  include('footer.php');  ?>