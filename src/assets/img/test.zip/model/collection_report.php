<?php
include('include/config.php');
$_GET=sanatize($_GET);
extract($_GET);
$_POST=sanatize($_POST);
include('header.php');
if(isset($market_id))
{
   $where="market_id='".$market_id."'";
}
else
{
   $where="";
}

$where=$where.user_where('','1')." group by client_id";
//$where=$where.' AND '.$_SESSION['user_type']."_id='".$_SESSION['user_id']."' group by client_id";
$played_client=get_data('client',$where,'','id as client_id');
$lena_array=array();
$dena_array=array();
$zero_array=array();
foreach ($played_client as $key => $value) {
   $client_id=$value['client_id'];
   if(isset($market_id))
   {
    $amount=get_client_ledger($client_id,$market_id);   
   }
   else
   {
    $amount=get_client_ledger($client_id);
   }
   $total=$amount['total_balance'];
   $array=array('client_id'=>$client_id,'amount'=>$total);

   if($total>0)
   {
      array_push($dena_array,$array);
   }

   if($total<0)
   {
      array_push($lena_array,$array);
   }
   if($total==0)
   {  
      if(!isset($market_id))
   {
      array_push($zero_array,$array);
   }
      
   }

}
?>

<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>All Client Ledger</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="dashboard?page_name=dashboard">Home</a></li>
              <li class="breadcrumb-item active">All Client Ledger</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">

                        <!-- /.card -->

                        <div class="card">


                            <form action="#" method="post" id="demoForm">


                                <div class="card-header">

                                </div>
                                <!-- /.card-header -->
                                <div class="card-body">

                                    <div class="form-row">
                                        <div class="col-md-6">
                                            <table  class="table table-striped  table-hover table-bordered">
                                                <thead>
                                                <tr>
                                                    <th colspan="5">
                                                        PAYMENT RECEIVING FROM (LENA HE)
                                                    </th>
                                                </tr>
                                                <tr>
                                                    <th>Name</th>
                                                    <th>Contact</th>
                                                    <th>Open. Bal.</th>
                                                    <th>Curr. Bal.</th>
                                                    <th>Cls. Bal.</th>
                                                </tr>
                                                </thead>
                                                <tbody>

                                                   <?php  $total_amount=0; foreach ($lena_array as $key => $lena_value) { extract($lena_value); 

                                                         $client=get_data('client',"id='".$client_id."'",'s','ClientCode,ClientName,ContactNo,total_coins');
                                                      
                                                      $client_name=$client['ClientName'];
                                                      $client_code=$client['ClientCode'];
                                                      $total_amount+=$amount;
                                                      ?>
                                                        

                                                <tr>
                                                    <td><?= ucfirst($client_code); ?> <?= ucfirst($client_name); ?></td>
                                                    <td><?= $client['ContactNo'] ?></td>
                                                    <td><?= abs(round($amount,2)) ?></td>
                                                    <td>0.00</td>
                                                    <td><?= abs(round($amount,2)) ?></td>
                                                </tr>

                                             <?php } ?>

                                             
                                                </tbody>
                                                <tfoot>
                                                <tr>
                                                    <td>Total</td>
                                                    <td></td>
                                                    <th><?= abs($total_amount) ?></th> 
                                                    <th>0.00</th>
                                                    <th><?= abs($total_amount) ?></th> 
                                                </tr>
                                                </tfoot>
                                            </table>
                                        </div>

                                        <div class="col-md-6">
                                            <table id="example12" class="table table-striped  table-hover table-bordered">
                                                <thead>
                                                <tr>
                                                    <th colspan="5">
                                                        PAYMENT PAID TO (DENA HE)
                                                    </th>
                                                </tr>
                                                <tr>
                                                    <th>Name</th>
                                                    <th>Contact</th>
                                                    <th>Open. Bal.</th>
                                                    <th>Curr. Bal.</th>
                                                    <th>Cls. Bal.</th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                   <?php  $total_amount=0; foreach ($dena_array as $key => $lena_value) { extract($lena_value); $client=get_data('client',"id='".$client_id."'",'s','ClientCode,ClientName,ContactNo,total_coins');
                     
                                                      $client_name=$client['ClientName'];
                                                      $client_code=$client['ClientCode'];
                                                      $total_amount+=$amount;

                                                      ?>

                                                <tr>
                                                    <td><?= ucfirst($client_code); ?> <?= ucfirst($client_name); ?></td>
                                                    <td><?= $client['ContactNo'] ?></td>
                                                    <td><?= abs(round($amount,2)) ?></td>
                                                    <td>0.00</td>
                                                    <td><?= abs(round($amount,2)) ?></td>
                                                </tr>
                                             <?php } ?>

                                                </tbody>
                                                <tfoot>
                                                <tr>
                                                    <td>Total</td>
                                                    <td></td>
                                                    <th><?= abs($total_amount) ?></th> 
                                                    <th>0.00</th>
                                                    <th><?= abs($total_amount) ?></th> 
                                                </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    </div>




                                </div>
                                <!-- /.card-body -->


                            </form>
                        </div>
                        <!-- /.card -->


                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </section>

   

   
  </div>
  <!-- /.content-wrapper -->

            
         
<?php include('footer.php'); ?>