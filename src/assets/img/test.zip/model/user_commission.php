<?php 
include('include/config.php');
$_GET=sanatize($_GET);
$_POST=sanatize($_POST);
extract($_GET);

include('header.php');
if($userdata['user_type']!='agent') 
{ 

invalid();

}

$where=user_where('','s').' group by client_id';

if(isset($_GET['id']))
{
    $where='client_id='.$_GET['id'].' AND '.$where;
}

$total_ledger=get_data('md_client_position',$where,'',"sum(client_match_commission) client_match_commission,sum(client_session_commission) client_session_commission,sum(agent_match_commission) agent_match_commission,sum(agent_session_commission) agent_session_commission,client_name,client_code");


?>

    <style type="text/css">th{
   background-color: #322E73 !important;
   color: white !important;

}</style>
 

<style type="text/css">td {
  
   color: black !important;
   font-weight: 80px;
   font-family: Sans-serif ;
}</style> 
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Client Commission</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="dashboard?page_name=dashboard">Home</a></li>
              <li class="breadcrumb-item active">Client Commission</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">

                        <!-- /.card -->

                        <div class="card">


                           
                                <div class="card-header ">

                                    <h4 class="text-capitalize">Select Client</h4>


                                        
                </thead>

          <div class="card-body">
              <table id="example1" class="table table-bordered table-striped">


                <thead>
                <tr>
                 
                  <th>#</th>
                  <th>CODE</th>
                  <th>M Comm.</th>
                  <th>S Comm.</th>
                  <th>Total Comm</th>
                  <th>M Comm.</th>
                  <th>S Comm.</th>
                  <th>Total Comm</th>
                  <th>Comm Bacha</th>
                 
                </tr>
                      <th colspan=1></th>
                      <th colspan=4 style="color:green;"><center>UPER SE MILA</center></th>
                      <th colspan=3 style="color:red;"><center>CLIENT KO DIYA</center></th>
                      <th colspan=1 style="color:blue;">TOTAL BACHA</th>
                  </thead>


                
                <tbody>
                 <?php $s_no=1;  $total_client_match_comm=0;
                    $total_session_comm=0;

                    $total_comm=0;

                    $total_agent_match_comm=0;
                    $total_agent_session_comm=0;

                    $total_agent_comm=0;
                    $super_total_agent_comm=0;
                    $super_total_client_comm=0;
                     foreach ($total_ledger as $key => $data) { extract($data);
                              
                


                     

                    $total_client_match_comm+=$data['client_match_commission'];
                    $total_session_comm+=$data['client_session_commission'];

                    $total_comm=$total_client_match_comm+$total_session_comm;

                    $total_agent_match_comm+=$data['agent_match_commission'];
                    $total_agent_session_comm+=$data['agent_session_commission'];

                    $total_agent_comm=$data['agent_session_commission']+$data['agent_match_commission'];
                    $super_total_agent_comm+=$total_agent_comm;


                    $total_client_comm=$data['client_session_commission']+$data['client_match_commission'];

                    $super_total_client_comm+=$total_client_comm;

 
                  
                  ?>
                  <tr>
                    <td><label><?= $s_no++ ?></label></td>
                  <td><?= $data['client_name'] ?> (<?= $data['client_code'] ?>)</td>

                 
                     
                        <td style="color:green;" ><?= (round(($data['agent_match_commission']),2))?></td>
                        <td style="color:green;" ><?= (round(($data['agent_session_commission']),2))?></td>
                        <td style="color:green;" ><?= (round(($data['agent_session_commission']+$data['agent_match_commission']),2))?></td>



                        <td><?=color(round(-1*($data['client_match_commission']),2))?></td>
                        <td><?=color(round(-1*($data['client_session_commission']),2))?></td>
                        <td><?=color(round(-1*($data['client_session_commission']+$data['client_match_commission']),2))?></td>

                        <td><?=color(round($total_agent_comm-$total_client_comm),2)?></td>
                    </tr>
                
              <?php } ?>
          </tbody>
                
                 <tfoot>


                    <tr style="font-weight:bold; font-size:18px; color:black; background-color:pink;">
                       <td></td>
                        <td> TOTAL</td>
                        <td><?= color(round($total_agent_match_comm),2) ?></td>
                        <td><?= color(round($total_agent_session_comm),2) ?></td>
                        <td><?= color(round($super_total_agent_comm),2) ?></td>
                        
                        <td><?= color(round(-1*$total_client_match_comm),2) ?></td>
                        <td><?= color(round(-1*$total_session_comm),2) ?></td>
                        <td><?= color(round(-1*$total_comm),2) ?></td>



                        <td><?= color(round($super_total_agent_comm-$super_total_client_comm),2) ?></td>
                    </tr>
                       


                  </tfoot>


              </table>
            </div>

                                        


                                    </div>


                                </div>
                                <!-- /.card-header -->
                               

                                


                               


                                <!-- /.card-body -->
                          

                        </div>
                        <!-- /.card -->


                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </section>

   

   
  </div>
  <!-- /.content-wrapper -->

<script type="text/javascript">
    $(document).ready(function call(){
            $(".select").change(function(){
               var client_id = $("#change_id").val();
               var location="user_commission?page_name=client"

              if(client_id=='all')
              { 
                window.location.href =location ;
                //location.href = location.href + "?var1=command_column"
              }
              else
              {
               window.location.href = location+'&id='+client_id;
              }
            });
        });
</script>

  <?php  include('footer.php');  ?>