 <div class="modal fade" id="notification_modal">
        <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header bg-gradient-purple">
                            <h5 class="modal-title" id="exampleModalLongTitle">Notification</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">×</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div id="items">
                                <p class="text-bold text-md">
                                    1.LIMIT UPDATE KARNE PER ENTRY BHI AUTOMATIC UPDATE HO JAYEGI ,KRIPYA WO FUNCTION SAHI SE SAMAJH LE 
                               </p>
                           </div>

                        </div>
                    </div>
                </div>
</div>



<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>Version</b> 2.0.2
    </div>
    <strong>Copyright &copy; 2020-2021 <a href="<?= base_url ?>"><?= domain ?></a>.</strong> All rights
    reserved.
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<script src="plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="plugins/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="dist/js/custom.js"></script>


<!-- daterangepicker -->

<script src="plugins/moment/moment.min.js"></script>
<script src="plugins/daterangepicker/daterangepicker.js"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<!-- Summernote -->
<script src="plugins/summernote/summernote-bs4.min.js"></script>
<!-- overlayScrollbars -->
<script src="plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.js"></script>

<script src="plugins/select2/js/select2.full.min.js"></script>

<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<!-- DataTables -->
<script src="plugins/datatables/jquery.dataTables.min.js"></script>
<script src="plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<!-- SweetAlert2 -->
<script src="plugins/sweetalert2/sweetalert2.min.js"></script>
<!-- Toastr -->
<script src="plugins/toastr/toastr.min.js"></script>

</body>
</html>

<?php if(isset($_SESSION['notify']))
{
   
$msg=$_SESSION['notify']['msg'];
$type=$_SESSION['notify']['type'];
unset($_SESSION['notify']);
    echo "<script>
        $(document).ready(function() {
            setTimeout(function() {
                toastr.options = {
                    closeButton: true,
                    progressBar: true,
                    showMethod: 'slideDown',
                    Position:'Top Right',
                    timeOut:4000
                };
                toastr.".$type."('".$type."', '".$msg."');
            }, 500);
        });
    </script>";
} 
?>

<script>

       function color(value)
    {  
      if(value<0)
      {
      return `<span style="color:red">${value}</span>`;
      }
      else
      {
         return `<span style="color:#007bff">${value}</span>`;
      }
    }

    function get_queyr_data(table_name,where='',single='',specific='')
    {
      sendData={
            'type':'get',
            'table_name':table_name,
            'where':where,
            'single':single,
            'specific':specific,
            };
          
     return  data = sendAjax('ajax/crud_ajax',sendData);
    }


    var page_name="<?= $page_data['page_name']; ?>";
    var user_type="<?= $userdata['user_type']; ?>";

    function notification_modal()
    {
      $('#notification_modal').modal('show');
    }

    if(page_name=='dashboard' && user_type!='superadmin')
    {
      notification_modal()    
    }



      function notify($type,$msg)
         {
            
            setTimeout(function() {
                toastr.options = {
                    closeButton: true,
                    progressBar: true,
                    showMethod: 'slideDown',
                    Position:'Top Right',
                    timeOut: 4000
                };
                if($type=='error')
                {
                toastr.error(''+$type+'', ''+$msg+'');   
                }
                else
                {
                    toastr.success(''+$type+'', ''+$msg+'');
                }

            }, 500);
         }

  $(function () {
    $('.select2').select2()

    //Initialize Select2 Elements
    $('.select2bs4').select2({
      theme: 'bootstrap4'
    })
    
    $("#example1").DataTable({
      "responsive": true,
      "autoWidth": false,
    });
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
</script>

<script type="text/javascript">
       function check_prompt_password()
        {
            var password=prompt("Please enter your password", "Password");
            var pass_check=true;
            if(password==null || password=='')
            {
                pass_check = false;
                return false
            }
            else
            {
                sendData={
              'password':password
                }
              data = sendAjax('ajax/check_password',sendData);
              if(data.status=='error')
              {
                swal("Failed!",data.data.msg,"error");
                pass_check=false;
                return false;
              }

            }
            return pass_check
        }



function update_id_array(update_obj)
{  
    $.each( update_obj, function( key, value ) {
        if(value.is_value==true)
        {
          $('#'+key).val(value.value)
        }
        else
        {
          $('#'+key).html(value.value)
        }
    });
}
</script>