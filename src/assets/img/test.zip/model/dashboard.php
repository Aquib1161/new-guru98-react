<?php
include('include/config.php');
include('header.php');
/*include('permission.php');*/
$downline_name=priority_name($userdata['add_priority']-1);
$inplay_match_data=get_data('upcoming_match',"status='INPLAY'");
?>
<div class="content-wrapper" style="min-height: 879.438px;">
        <br>
        <section class="content">
            <div class="container-fluid">

                <div class="row">
                    <div class="col-lg-3 col-6" onclick="showModel('master_details')">
                        <!-- small box -->
                        <div class="small-box bg-primary">
                            <div class="inner">
                                <h3>1</h3>
                                <p>Master Details</p>


                            </div>
                            <div class="icon">
                                <i class="ion ion-bag"></i>
                            </div>
                            <a href="#" class="small-box-footer">More Info <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>

                    

                    <div class="col-lg-3 col-6" onclick="showModel('game_details')">
                        <!-- small box -->
                        <div class="small-box bg-success">
                            <div class="inner">
                                <h3>2</h3>
                                <p>Games Details</p>


                            </div>
                            <div class="icon">
                                <i class="ion ion-bag"></i>
                            </div>
                            <a href="#" class="small-box-footer">More Info <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>

                    <div class="col-lg-3 col-6" onclick="showModel('cash_transaction')">
                        <!-- small box -->
                        <div class="small-box bg-warning">
                            <div class="inner">
                                <h3>3</h3>
                                <p>Cash Transaction</p>
                            </div>
                            <div class="icon">
                                <i class="ion ion-bag"></i>
                            </div>
                            <a href="#" class="small-box-footer">More Info <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>


                    <div class="col-lg-3 col-6" onclick="showModel('ledger_details')">
                        <!-- small box -->
                        <div class="small-box bg-danger">
                            <div class="inner">
                                <h3>4</h3>
                                <p>Ledger Details</p>
                            </div>
                            <div class="icon">
                                <i class="ion ion-bag"></i>
                            </div>
                            <a href="#" class="small-box-footer">More Info <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>


                </div>

            </div>
        </section>
    </div>

     <div class="modal fade" id="master_details_modal">
        <div class="modal-dialog">
                    <div class="modal-content">
                       
    
                            <div class="modal-body">
                                <div class="row" id="contentModel">
                                 <?php if($_SESSION['user_type']=='superadmin'){?> 

                                    <div class="col-lg-6 col-12" onclick="/master">
                                       <a href="list?list_type=admin&page_no=1&page_name=admin" > 
                                        </a><div class="small-box bg-primary"><a href="list?list_type=admin&page_no=1&page_name=admin" >
                                            <div class="inner" style="padding: 12px">
                                                <h3>1</h3>
                                                <p>Admin</p>
                                            </div>
                                            <div class="icon">
                                                <i class="ion ion-bag"></i>
                                            </div>
                                            </a><a href="list?list_type=admin&page_no=1&page_name=admin"  class="small-box-footer">More Info <i class="fas fa-arrow-circle-right"></i></a>
                                        </div> 
                                    </div> 
                                     <?php }  ?>
                                    <?php if($_SESSION['user_type']=='superadmin' OR $_SESSION['user_type']=='admin'){?>

                                    <div class="col-lg-6 col-12" onclick="/master">
                                       <a href="list?list_type=master&page_no=1&page_name=master"> 
                                        </a><div class="small-box bg-primary"><a href="list?list_type=master&page_no=1&page_name=master">
                                            <div class="inner" style="padding: 12px">
                                                <h3>1</h3>
                                                <p>Master</p>
                                            </div>
                                            <div class="icon">
                                                <i class="ion ion-bag"></i>
                                            </div>
                                            </a><a href="list?list_type=master&page_no=1&page_name=master" class="small-box-footer">More Info <i class="fas fa-arrow-circle-right"></i></a>
                                        </div> 
                                    </div> 
                                     <?php } if($_SESSION['user_type']=='superadmin' OR $_SESSION['user_type']=='admin'  OR $_SESSION['user_type']=='master'){ ?>

                                    <div class="col-lg-6 col-12" onclick="/super">
                                       <a href="list?list_type=superagent&page_no=1&page_name=superagent" > 
                                        </a><div class="small-box bg-success"><a href="list?list_type=superagent&page_no=1&page_name=superagent" >
                                            <div class="inner" style="padding: 12px">
                                                <h3>2</h3>
                                                <p>Super</p>
                                            </div>
                                            <div class="icon">
                                                <i class="ion ion-bag"></i>
                                            </div>
                                            </a><a href="list?list_type=superagent&page_no=1&page_name=superagent"  class="small-box-footer">More Info <i class="fas fa-arrow-circle-right"></i></a>
                                        </div> 
                                    </div> 
                                    <?php }  if($_SESSION['user_type']=='superadmin' OR $_SESSION['user_type']=='admin'  OR $_SESSION['user_type']=='master' OR $_SESSION['user_type']=='superagent') { ?>


                                    <div class="col-lg-6 col-12" onclick="/agent">
                                       <a href="list?list_type=agent&page_no=1&page_name=agent"> 
                                        </a><div class="small-box bg-warning"><a href="list?list_type=agent&page_no=1&page_name=agent">
                                            <div class="inner" style="padding: 12px">
                                                <h3>3</h3>
                                                <p>Agent</p>


                                            </div>
                                            <div class="icon">
                                                <i class="ion ion-bag"></i>
                                            </div>
                                            </a><a href="list?list_type=agent&page_no=1&page_name=agent" class="small-box-footer">More Info <i class="fas fa-arrow-circle-right"></i></a>
                                        </div> 
                                    </div> 

                                     <?php }  ?>

                                    <div class="col-lg-6 col-12" onclick="/client">
                                       <a href="client_list?list_type=client&all=true"> 
                                        </a><div class="small-box bg-danger"><a href="client_list?list_type=client&all=true">
                                            <div class="inner" style="padding: 12px">
                                                <h3>4</h3>
                                                <p>Client</p>


                                            </div>
                                            <div class="icon">
                                                <i class="ion ion-bag"></i>
                                            </div>
                                            </a><a href="client_list?list_type=client&all=true" class="small-box-footer">More Info <i class="fas fa-arrow-circle-right"></i></a>
                                        </div> 
                                    </div> 


                                    <div class="col-lg-6 col-12" onclick="/collection">
                                       <a href="collection?all=true"> 
                                        </a><div class="small-box bg-primary"><a href="collection?all=true">
                                            <div class="inner" style="padding: 12px">
                                                <h3>5</h3>
                                                <p>Collection</p>


                                            </div>
                                            <div class="icon">
                                                <i class="ion ion-bag"></i>
                                            </div>
                                            </a><a href="collection?all=true" class="small-box-footer">More Info <i class="fas fa-arrow-circle-right"></i></a>
                                        </div> 
                                    </div></div>

                            </div>

                        </div>
                    </div>
                </div>
</div>

 <div class="modal fade" id="game_details_modal">
        <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header bg-gradient-purple">
                            <h5 class="modal-title" id="exampleModalLongTitle">Notification</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">×</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="modal-body">

                                <div class="row" id="contentModel"> <div class="col-lg-6 col-12" onclick="/game/inPlay">
                                       <a href="match_list?page_name=inplay&page_no=1"> 
                                        </a><div class="small-box bg-primary"><a href="match_list?page_name=inplay&page_no=1">
                                            <div class="inner" style="padding: 12px">
                                                <h3>1</h3>
                                                <p>InPlay</p>


                                            </div>
                                            <div class="icon">
                                                <i class="ion ion-bag"></i>
                                            </div>
                                            </a><a href="match_list?page_name=inplay&page_no=1" class="small-box-footer">More Info <i class="fas fa-arrow-circle-right"></i></a>
                                        </div> 
                                    </div> <div class="col-lg-6 col-12" onclick="/game/completeGame">
                                       <a href="match_list?page_name=complete_match&page_no=1"> 
                                        </a><div class="small-box bg-success"><a href="match_list?page_name=complete_match&page_no=1">
                                            <div class="inner" style="padding: 12px">
                                                <h3>2</h3>
                                                <p>Complete</p>


                                            </div>
                                            <div class="icon">
                                                <i class="ion ion-bag"></i>
                                            </div>
                                            </a><a href="match_list?page_name=complete_match&page_no=1" class="small-box-footer">More Info <i class="fas fa-arrow-circle-right"></i></a>
                                        </div> 
                                    </div></div>

                            </div>

                        </div>
                    </div>
                </div>
</div>

<div class="modal fade" id="cash_transaction_modal">
        <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header bg-gradient-purple">
                            <h5 class="modal-title" id="exampleModalLongTitle">Notification</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">×</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="modal-body">

                                <div class="row" id="contentModel"> <div class="col-lg-6 col-12" onclick="/ct/client">
                                       <a href="client_ledger?page_name=client"> 
                                        </a><div class="small-box bg-primary"><a href="client_ledger?page_name=client">
                                            <div class="inner" style="padding: 12px">
                                                <h3>1</h3>
                                                <p>Debit/Credit (C)</p>


                                            </div>
                                            <div class="icon">
                                                <i class="ion ion-bag"></i>
                                            </div>
                                            </a><a href="client_ledger?page_name=client" class="small-box-footer">More Info <i class="fas fa-arrow-circle-right"></i></a>
                                        </div> 
                                    </div> 

                                     <?php  if($_SESSION['user_type']=='superadmin' OR $_SESSION['user_type']=='admin'  OR $_SESSION['user_type']=='master' OR $_SESSION['user_type']=='superagent') { ?>

                                    <div class="col-lg-6 col-12" onclick="/ct/agent">
                                       <a href="user_ledger?page_name=agent&ledger_type=agent"> 
                                        </a><div class="small-box bg-success"><a href="user_ledger?page_name=agent&ledger_type=agent">
                                            <div class="inner" style="padding: 12px">
                                                <h3>2</h3>
                                                <p>Debit/Credit (A)</p>


                                            </div>
                                            <div class="icon">
                                                <i class="ion ion-bag"></i>
                                            </div>
                                            </a><a href="user_ledger?page_name=agent&ledger_type=agent" class="small-box-footer">More Info <i class="fas fa-arrow-circle-right"></i></a>
                                        </div> 
                                    </div> 

                                     <?php } if($_SESSION['user_type']=='superadmin' OR $_SESSION['user_type']=='admin'  OR $_SESSION['user_type']=='master'){ ?>


                                    <div class="col-lg-6 col-12" onclick="/ct/super">
                                       <a href="user_ledger?page_name=superagent&ledger_type=superagent"> 
                                        </a><div class="small-box bg-warning"><a href="user_ledger?page_name=superagent&ledger_type=superagent">
                                            <div class="inner" style="padding: 12px">
                                                <h3>3</h3>
                                                <p>Debit/Credit (SA)</p>


                                            </div>
                                            <div class="icon">
                                                <i class="ion ion-bag"></i>
                                            </div>
                                            </a><a href="user_ledger?page_name=superagent&ledger_type=superagent" class="small-box-footer">More Info <i class="fas fa-arrow-circle-right"></i></a>
                                        </div> 
                                    </div> 

                                    <?php } if($_SESSION['user_type']=='superadmin' OR $_SESSION['user_type']=='admin'){?>


                                    <div class="col-lg-6 col-12" onclick="/ct/master">
                                       <a href="user_ledger?page_name=master&ledger_type=master"> 
                                        </a><div class="small-box bg-danger"><a href="user_ledger?page_name=master&ledger_type=master">
                                            <div class="inner" style="padding: 12px">
                                                <h3>4</h3>
                                                <p>Debit/Credit (MA)</p>


                                            </div>
                                            <div class="icon">
                                                <i class="ion ion-bag"></i>
                                            </div>
                                            </a><a href="user_ledger?page_name=master&ledger_type=master" class="small-box-footer">More Info <i class="fas fa-arrow-circle-right"></i></a>
                                        </div> 
                                    </div>

                                     <?php } if($_SESSION['user_type']=='superadmin'){?>

                                        <div class="col-lg-6 col-12" onclick="/ct/master">
                                       <a href="user_ledger?page_name=admin&ledger_type=admin"> 
                                        </a><div class="small-box bg-info"><a href="user_ledger?page_name=admin&ledger_type=admin">
                                            <div class="inner" style="padding: 12px">
                                                <h3>5</h3>
                                                <p>Debit/Credit (SUB)</p>


                                            </div>
                                            <div class="icon">
                                                <i class="ion ion-bag"></i>
                                            </div>
                                            </a><a href="user_ledger?page_name=admin&ledger_type=admin" class="small-box-footer">More Info <i class="fas fa-arrow-circle-right"></i></a>
                                        </div> 
                                    </div>


                                     <?php } ?>




                                </div>

                            </div>

                        </div>
                    </div>
                </div>
</div>

<div class="modal fade" id="ledger_details_modal">
        <div class="modal-dialog">
                    <div class="modal-content">
                    
                            <div class="modal-body">

                                <div class="row" id="contentModel"> <div class="col-lg-6 col-12" onclick="/ledger">
                                       <a href="user_ledger?ledger_type=self&all=true"> 
                                        </a><div class="small-box bg-primary"><a href="user_ledger?ledger_type=self&all=true">
                                            <div class="inner" style="padding: 12px">
                                                <h3>1</h3>
                                                <p>My Ledger</p>


                                            </div>
                                            <div class="icon">
                                                <i class="ion ion-bag"></i>
                                            </div>
                                            </a><a href="user_ledger?ledger_type=self&all=true" class="small-box-footer">More Info <i class="fas fa-arrow-circle-right"></i></a>
                                        </div> 
                                    </div> 

                                    <div class="col-lg-6 col-12" onclick="/ledger/client/pm">
                                       <a href="client_plus_minus?minus_plus=client&all=true"> 
                                        </a><div class="small-box bg-success"><a href="client_plus_minus?minus_plus=client&all=true">
                                            <div class="inner" style="padding: 12px">
                                                <h3>2</h3>
                                                <p>Client Plus/Minus</p>
                                            </div>
                                            <div class="icon">
                                                <i class="ion ion-bag"></i>
                                            </div>
                                            </a><a href="client_plus_minus?minus_plus=client&all=true" class="small-box-footer">More Info <i class="fas fa-arrow-circle-right"></i></a>
                                        </div> 
                                    </div> 


                                    <div class="col-lg-6 col-12" onclick="/ledger/client">
                                       <a href="collection_report?all=true"> 
                                        </a><div class="small-box bg-warning"><a href="collection_report?all=true">
                                            <div class="inner" style="padding: 12px">
                                                <h3>3</h3>
                                                <p>All Client Ledger</p>


                                            </div>
                                            <div class="icon">
                                                <i class="ion ion-bag"></i>
                                            </div>
                                            </a><a href="collection_report?all=true" class="small-box-footer">More Info <i class="fas fa-arrow-circle-right"></i></a>
                                        </div> 
                                    </div> 

                                    <?php  if($user_priority>=priority('agent')){ ?>

                                    <div class="col-lg-6 col-12" onclick="/ledger/agent">
                                       <a href="user_collection_report?collection_type=agent&page_name=report"> 
                                        </a><div class="small-box bg-danger"><a href="user_collection_report?collection_type=agent&page_name=report">
                                            <div class="inner" style="padding: 12px">
                                                <h3>4</h3>
                                                <p>All Agent Ledger</p>

                                            </div>
                                            <div class="icon">
                                                <i class="ion ion-bag"></i>
                                            </div>
                                            </a><a href="user_collection_report?collection_type=agent&page_name=report" class="small-box-footer">More Info <i class="fas fa-arrow-circle-right"></i></a>
                                        </div> 
                                    </div> 
                                    <?php } if($user_priority>=priority('master')){ ?>


                                    <div class="col-lg-6 col-12" onclick="/ledger/super">
                                       <a href="user_collection_report?collection_type=superagent&page_name=report"> 
                                        </a><div class="small-box bg-primary"><a href="user_collection_report?collection_type=superagent&page_name=report">
                                            <div class="inner" style="padding: 12px">
                                                <h3>5</h3>
                                                <p>All Super Ledger</p>


                                            </div>
                                            <div class="icon">
                                                <i class="ion ion-bag"></i>
                                            </div>
                                            </a><a href="user_collection_report?collection_type=superagent&page_name=report" class="small-box-footer">More Info <i class="fas fa-arrow-circle-right"></i></a>
                                        </div> 
                                    </div> 

                                    <?php } if($user_priority>=priority('admin')){ ?>



                                    <div class="col-lg-6 col-12" onclick="/ledger/master">
                                       <a href="user_collection_report?collection_type=master&page_name=report"> 
                                        </a><div class="small-box bg-info"><a href="user_collection_report?collection_type=master&page_name=report">
                                            <div class="inner" style="padding: 12px">
                                                <h3>6</h3>
                                                <p>All Master Ledger</p>


                                            </div>
                                            <div class="icon">
                                                <i class="ion ion-bag"></i>
                                            </div>
                                            </a><a href="user_collection_report?collection_type=master&page_name=report" class="small-box-footer">More Info <i class="fas fa-arrow-circle-right"></i></a>
                                        </div> 
                                    </div>

                                    <?php } if($user_priority>=priority('superadmin')){ ?>

                                        <div class="col-lg-6 col-12" onclick="/ledger/master">
                                       <a href="user_collection_report?collection_type=admin&page_name=report"> 
                                        </a><div class="small-box bg-success"><a href="user_collection_report?collection_type=admin&page_name=report">
                                            <div class="inner" style="padding: 12px">
                                                <h3>7</h3>
                                                <p>All Admin Ledger</p>


                                            </div>
                                            <div class="icon">
                                                <i class="ion ion-bag"></i>
                                            </div>
                                            </a><a href="user_collection_report?collection_type=admin&page_name=report" class="small-box-footer">More Info <i class="fas fa-arrow-circle-right"></i></a>
                                        </div> 
                                    </div>



                                    <?php } ?>


                                </div>

                            </div>

                        </div>
                    </div>
                </div>
</div>

<script type="text/javascript">
    
  
  function showModel(type)
  {

      if(type=='master_details')
      {
        $('#master_details_modal').modal('show');
      }
      else if(type=='cash_transaction')
      {
        $('#cash_transaction_modal').modal('show');
      }
      else if(type=='game_details')
      {
       $('#game_details_modal').modal('show');
      }
      else if(type=='ledger_details')
      {
       $('#ledger_details_modal').modal('show');
      }
  }


</script>

<?php include('footer.php'); ?>

