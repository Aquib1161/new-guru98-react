<?php
include('include/config.php');
$_GET=sanatize($_GET);
$_POST=sanatize($_POST);
$page_name=$_GET['page_name'];
$market_id=$_GET['market_id'];
$client_data=get_data('client',$_SESSION['user_type'].'_id='.$_SESSION['user_id']);
if($market_id=='today')
{
    
}
else
{
    $total_bet_count=count_data('casino_bet_tbl',user_where("game_id='".$market_id."' AND casino_type='".$_GET['game_type']."'"));
    $game_data=get_data('upcoming_match',"market_id='".$market_id."'",'s');
}
include('header.php');
?>

 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class='text-uppercase'><?= $_GET['game_type'] ?> bets list</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="dashboard?page_name=dashboard">Home</a></li>
              <li class="breadcrumb-item active text-uppercase"><?= $_GET['game_type'] ?></li>
            </ol>
          </div>
        </div>
      </div>
    </section>

     <section class="content">
            <div class="container-fluid">

                <div class="row">
                  <div class="card card-default">
                            <div class="card-body">
                                <div class="card-default">
                                    <div class="card-header text-center">
                                        <h5 class="card-title text-center">AGENT PLUS MINUS</h5>
                                    </div>
                                        <div class="row">
			                                 <div class="col-md-12">
			                            	   <select name="client_id" id='client_id' class="select2 form-control select">
			                            	   	<option value="">Select Client</option>
			                            	   	<?php foreach ($client_data as $key => $client) { ?>

			                                        <option value="<?= $client['id']?>"><?= $client['ClientCode']?>  (<?= $client['ClientName']?>)</option>
			                            	     <?php  }  ?>
			                                    </select>
			                                  </div>   
                            			</div>
                                    <div class="card-body">
                                        <table id="data" class="table table-striped table-bordered">
                            <thead>
							    <tr>
							        <th colspan="10">Casino Bet Data</th>
                                    <th></th>
							        
							    </tr>
							    <tr>
							        <th class="text-uppercase">Sr. No.</th>
							        <th class="text-uppercase">Date</th>
                                    
							        <th class="text-uppercase">Client</th>
							        <th class="text-uppercase">Rate</th>
                                    <th class="text-uppercase">Amount</th>
                                    <!-- <th class="text-uppercase">Profit</th>
							        <th class="text-uppercase">Loss</th> -->
                                    <th class="text-uppercase">Player Name</th>
							        <th class="text-uppercase">Decision</th>
                                    <th class="text-uppercase">Status</th>
                                    <th class="text-uppercase">Market Id</th>
							        <th class="text-uppercase">Profit/Loss</th>
                                    <th class="text-uppercase">IP</th>

							    </tr>
							</thead>
							<tbody id="load_data"></tbody>
							<tfoot>
		                        <tr class="text-uppercase" style="background-color: white;">
		                             <td colspan="4" style="color: black; font-weight: bold;">Client Profit Loss Total</td>
		                            <td ></td>
		                            <td ></td>
		                            <td ></td>
		                            <td ></td>
		                            <td ></td>
		                           
                                   
		                          
		                            <th  style="color:black" id="total_user_amount"></th>
		                        </tr>
                     
                   			 </tfoot>
                    </table>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                 
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </section>

</div>
<script type="text/javascript">

    var game_type ="<?= $_GET['game_type']  ?>";
		$(document).ready(function call(){
			$(".select").change(function(){
                load_data()
            });
		});
      function load_data()
        {
                

                $("#load_data tr").remove();
                var check=true;
                var client_id = $("#client_id").val();
                var market_id ='<?php echo $market_id ?>';
                $.ajax({
                    url : "ajax/casino_bet_data",
                    type : "post",
                    dataType: 'json',
                    data : {game_type:game_type,client_id :client_id,market_id:market_id},
                    success : function(res){
                        var data=res.data;
                        var user_amount=0;
                            jQuery.each(data, function(i,bet_data) 
                            {   
                                var decision='';
                                var status='NO';

                               var profit_loss=0;
                               var key=bet_data.key
                               var decision=bet_data.decision

                               if(key==decision)
                               {
                                 profit_loss=bet_data.profit
                               }
                               else
                               {
                                 profit_loss=bet_data.loss
                               }

                                if(profit_loss<0)
                                {
                                    background_color='white';
                                }
                                else if(bet_data.decision=='')
                                {
                                    background_color='blue';
                                }
                                else
                                {
                                  background_color='white';
                                }
                               
                                if(bet_data.decision!='')
                                {   
                                    status='YES';
                                    if(bet_data.decision==1)
                                    {
                                        decision='Player A';
                                    }
                                    else
                                    {
                                        decision='Player B';
                                    }

                                    if(bet_data.casino_type=="DRAGON TIGER")
                                    {
                                        if(bet_data.decision==1)
                                        {
                                            decision='DRAGON';
                                        }
                                        else if(bet_data.decision==2)
                                        {
                                            decision='TIGER';
                                        }
                                        else
                                        {
                                            decision='TIE';
                                        }

                                    }
                                    else if(bet_data.casino_type=="LUCKY7 A")
                                    {   
                                        

                                        if(bet_data.bet_for=='low_high')
                                        {
                                            if(key==bet_data.decision)
                                               {
                                                 profit_loss=bet_data.profit
                                               }
                                               else if(bet_data.decision==0)
                                               {
                                                 profit_loss=-1*(bet_data.amount)/2
                                               }
                                               else
                                               {
                                                profit_loss=bet_data.loss
                                               }

                                               

                                            if(bet_data.decision==1)
                                            {
                                                decision='LOW CARD'
                                            }
                                            else if(bet_data.decision==2)
                                            {
                                                decision='HIGH CARD'
                                            }
                                            else
                                            {
                                                decision='7'
                                            }
                                           

                                               

                                        }
                                        else if(bet_data.bet_for=='color')
                                        {
                                               decision=bet_data.decision
                                               if(trim_string(bet_data.player_name)==trim_string(decision))
                                               {
                                                 profit_loss=bet_data.profit
                                               }
                                               else
                                               {
                                                profit_loss=bet_data.loss
                                               }

                                               


                                        }
                                        else if(bet_data.bet_for=='series')
                                        {
                                            decision=bet_data.decision
                                            if(trim_string(bet_data.player_name)==trim_string(decision))
                                               {
                                                 profit_loss=bet_data.profit
                                               }
                                               else
                                               {
                                                profit_loss=bet_data.loss
                                               }

                                               if(bet_data.player_name=='Card 1')
                                               {
                                                bet_data.player_name='Card A';
                                               }

                                        }
                                        else if(bet_data.bet_for=='odd_even')
                                        {
                                           
                                               decision=bet_data.decision
                                               if(trim_string(bet_data.player_name)==trim_string(decision))
                                               {
                                                 profit_loss=bet_data.profit
                                               }
                                               else
                                               {
                                                profit_loss=bet_data.loss
                                               }
                                              
                                        }
 
                                    }

                                }
                                else
                                {
                                    profit_loss=0;
                                }

                           user_amount+=parseInt(profit_loss)
                           

                          var str=`<tr style="font-weight:bold;background-color:${background_color}"">
                                        <td class='text-uppercase'>${i+1}</td>
                                        <td class='text-uppercase'>${bet_data.date_time}</td>
                                      
                                        <td class='text-uppercase'>${bet_data.client_name}</td>
                                        <td class='text-uppercase'>${bet_data.bhav}</td>
                                  
                                        <td class='text-uppercase'>${bet_data.amount}</td>
                                        <td class='text-uppercase'>${bet_data.player_name}</td>
                                        <td class='text-uppercase'>${decision}</td>
                                        <td class='text-uppercase'>${status}</td>
                                        <td class='text-uppercase'>${bet_data.market_id}</td>
                                        <td class='text-uppercase'>${color(profit_loss)}</td>
                                        <td class='text-uppercase'>${bet_data.ip}</td>
                                   </tr>`;
                          $("#load_data").append(str);
                    });
                             
                            $("#total_user_amount").html(color(user_amount));
                   
                    }
                });
            
        }
        load_data()
        function trim_string(string)
        {
           return string.replace(/^\s+|\s+$/gm,'')
        }

        
</script>
         
<?php include('footer.php'); ?>



