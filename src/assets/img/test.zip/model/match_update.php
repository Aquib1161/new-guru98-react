<?php
include('../include/config.php');
$coins_setting=$_POST['coin_setting'];
unset($_POST['coin_setting']);
$_POST=sanatize($_POST);
$_GET=sanatize($_GET);
extract($_POST);
$_POST['coins_setting']=json_encode($coins_setting);
$update=update_array('upcoming_match',$_POST,"market_id='".$market_id."'");
if($update['error']==0)
{
	$_SESSION['notify']=['type'=>'success','msg'=>'Match update successfully'];	
}
else
{
	$_SESSION['notify']=['type'=>'error','msg'=>'something went wrong'];
}
header("location:../inplay_match_setting?market_id=".$market_id."");
?>