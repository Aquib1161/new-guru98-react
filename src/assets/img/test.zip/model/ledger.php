<?php
include('../include/config.php');
$_POST=sanatize($_POST);
extract($_POST);
if($transaction_type=='D')
{
	$mark='Receive cash';
}
else
{
	$mark='Pay cash';
}

$user_result=get_user_list('',$user_id);
$insert_array=array(
	'transaction_type'=>$transaction_type,
	'amount'=>$amount,
	'note'=>$note,
	'user_id'=>$user_id,
	'match_name'=>$mark,
	'create_date'=>_date_time(),
	'ledger_date'=>_date(),
	'creater_id'=>$_SESSION['user_id'],
	'ledger_type'=>'cash',
	'user_type'=>$user_result['user_type']
);

$insert=insert_array('user_ledger',$insert_array);

$_SESSION['notify']=['type'=>'success','msg'=>''.$page_name.' Ledger updated successfully'];
header("location:../cash?cash_type=".$cash_type."&page_name=".$page_name."&id=".$user_id."");

?>