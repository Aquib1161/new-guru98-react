<?php 
include('include/config.php');
include('header.php');
if(isset($_GET['parent_user_id']))
{
     extract($_GET);
     $count=count_data('users_tbl',user_where("user_id='".$parent_user_id."'"));
     if($count!=1)
     {
      invalid();
     }
     $parent_data=get_data('users_tbl',user_where("user_id='".$parent_user_id."'"),'s','user_type,total_coins');
     $total_coins_given=$parent_data['total_coins'];
     $parent_data['user_type']=$parent_data['user_type']=='superagent'?'sa': $parent_data['user_type'];
     $downline_data=get_data('client',$parent_data['user_type']."_id='".$parent_user_id."'");
}
else
{
    $downline_data=get_data('client',user_where('','s')); 
    $total_coins_given=call_total_coins($_SESSION['user_type'],$_SESSION['user_id']);
}


?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Client Details</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="dashboard?page_name=dashboard">Home</a></li>
              <li class="breadcrumb-item active">Client</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

   <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div>

                        <!-- /.card -->

                        <div class="card">

                            <div class="card-header">
                                <h4>Client Limit Details</h4>
                                <p>Note : 1. LIMIT TYPE नगद/Cash Select करने पर Ledger में एंट्री Add हो जाएगी!</p>
                                <p>Note : 2. LIMIT TYPE उधार/Borrow Select करने पर Ledger में एंट्री Add नहीं
                                    होगी!</p>
                            </div>

                             <div class="card-body">
                               <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                  <tr>
                                    <th>S No</th>
                                    <th><?= ucfirst($_GET['page_name'])?> Name</th>
                                    <th>Limit</th>
                                    <th>Enter Limit</th>
                                    <th>Limit Type</th>
                                    <th>My Limit : <?= round($total_coins_given,1); ?></th>
                                  </tr>
                                </thead>
                                <tbody>
                                  <?php $s_no=1; foreach ($downline_data as $key => $value) { ?>
                                  <tr role="row" class="odd">
                                    <input type="hidden" name="" value="<?= $value['id'] ?>">
                                    <input required="" type="hidden" class="form-control" step="0.01" name="user_limit" value="<?= $value['total_coins'] ?>" id="<?= $value['id'] ?>_current_coins">
                                            <td><?= $s_no++; ?></td>
                                            <td><?= $value['ClientCode'] ?> <?= $value['ClientName'] ?></td>
                                            <td id="show_limit_<?=  $value['id'] ?>"><?= round($value['total_coins'],1) ?></td>
                                            <td class="col-lg-4" style="min-width: 120px">
                                              <input required="" type="number" class="form-control" step="0.01" name="user_limit" id="update_amount_<?= $value['id'] ?>">
                                            </td>
                                            <td style="min-width: 140px"><select name="ltype" class="form-control" required="">
                                                <option value="" disabled="" selected="">Limit Type</option>
                                                <option value="1">नगद/Cash</option>
                                                <option value="2">उधार/Borrow</option>
                                            </select></td>
                                            <td style="min-width: 150px">
                                                <button class="btn-sm btn-primary btn-limit" type="submit" name="type" value="Add" onclick="update_coins_client('<?= $value['id'] ?>','deposit')" >
                                                    Add
                                                </button>
                                                <button class="btn-sm btn-danger btn-limit" type="submit" name="type" value="Minus" onclick="update_coins_client('<?= $value['id'] ?>','withdraw')"> Minus
                                                </button>

                                            </td>
                                    </tr>
                                  <?php } ?>

                                </tbody>
                              </table>
                       
                            </div>
                            <!-- /.card-body -->


                        </div>
                        <!-- /.card -->


                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </section>
  </div>
  <!-- /.content-wrapper -->

  <script type="text/javascript">
    
  function update_coins_client(user_id,operation_type)
{
  $('.btn-limit').attr('disabled', '');
   
    var current_coins=parseInt($('#'+user_id+'_current_coins').val())
    var update_coins=parseInt($('#update_amount_'+user_id).val());
    if(isNaN(update_coins))
    {
      update_coins=0;
    }
      
    var coins_to_updated='';

    if(operation_type=='withdraw')
    {
        coins_to_updated=current_coins-update_coins
    }
    else
    {
        coins_to_updated=current_coins+update_coins
    }

    if(update_coins<0)
    { 
      notify("error",'Something went wrong');
      $('.btn-limit').removeAttr('disabled');
      return false
    }

    if(update_coins==0)
    { 
      notify("error",'Please enter coins');
      $('.btn-limit').removeAttr('disabled');
      return false
    }

              $.ajax({
                    url : "ajax/update_limit",
                    type : "post",
                    dataType: 'json',
                    data : {type:'fix_limit',client_id:user_id,fix_limit:coins_to_updated,update_limit:coins_to_updated,is_client:true,real_update_coins:update_coins,deposit_type:operation_type},
                    success : function(res){
                       var status=res.status;    
                       if(status=='success')
                       {
                        $('#show_limit_'+user_id+'').html(coins_to_updated)
                        $('#update_amount_'+user_id).val('')
                        notify("success",res.data.msg+''+coins_to_updated);
                        window.location.reload()
                        $('.btn-limit').removeAttr('disabled');
                       }
                       else
                       {
                        notify("error",res.data.msg);
                        $('.btn-limit').removeAttr('disabled');
                       }   
                    }
                });        
    
}

  </script>

  <?php  include('footer.php');  ?>