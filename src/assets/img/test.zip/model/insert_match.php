<?php
include('../include/config.php');
//$_POST=sanatize($_POST);
$_GET=sanatize($_GET); 
extract($_POST);
$bookmaker_status=0;
if(isset($_POST['bookmaker']) AND ($_POST['bookmaker']=='Bookmaker Odds' OR $_POST['bookmaker']=='true'))
{
  $bookmaker_status=1;
  unset($_POST['bookmaker']);
}
if(isset($_POST['manual_match_feed']) AND $_POST['manual_match_feed']!='')
{
  unset($_POST['manual_match_feed']);
  $url=betexch_api.$_POST['betexch_id'];
  $betexch_data=api_data_curl_no_header($url);
  $betexch_data=json_decode($betexch_data,true);
  if(empty($betexch_data))
  {
    $_SESSION['notify']=['type'=>'error','msg'=>'match id is not correct']; 
    header("location:../insert_match_manually"); 
    exit();
  }
  $betexch_count=count($betexch_data);
  if($betexch_count==3)
  {
    $match_data=$betexch_data['Match_ODDS'];
    $count=count($match_data);
    $_POST['count']=$count;
    $team1_name=$_POST['team1_name']=$match_data[0]['FavTeam'];
    $_POST['team1_selection_id']=$match_data[0]['id'];
    $team2_name=$_POST['team2_name']=$match_data[1]['FavTeam'];
    $_POST['team2_selection_id']=$match_data[1]['id'];
    if($count==3)
    {
    $_POST['team3_name']=$match_data[2]['FavTeam'];
    $_POST['status']='INPLAY';
    $_POST['team3_selection_id']=$match_data[2]['id'];
    $_POST['score_type']='manual';
    $_POST['match_name']=$_POST['team1_name'].' VS '.$_POST['team2_name'];
    }
  }
}


$count=count_data('upcoming_match',"market_id='".$market_id."'");

if($count!=0)
{
  $query="DELETE FROM match_team_tbl WHERE market_id='".$market_id."'";
  mysqli_query($con,$query);
  $query="DELETE FROM market_price WHERE market_id='".$market_id."'";
  mysqli_query($con,$query);

}
if(isset($count))
{ 
  $count=$_POST['count'];
  unset($_POST['event_date']);
  unset($_POST['event_name']);
  $_POST['match_name']=$team1_name .' VS '. $team2_name;
  $_POST['match_name_id']=$match_name_id = $team1_name.":".$team1_selection_id.";".$team2_name.":".$team2_selection_id;
  if($count==3)
  {

    $_POST['match_name_id']=$_POST['match_name_id'].";The Draw".":".$team3_selection_id."";
  }


  $_POST['uploading_date']=_date();
  $_POST['odds_hits']='api';
  $_POST['position_view']='1';
  $_POST['api_hit']='0';
  $_POST['socket_perm']='1';
  $_POST['session_status']='1';
  extract($_POST);

  $check="SELECT market_id FROM market_price WHERE market_id=$market_id";
  $chk=mysqli_query($con,$check);
  $val=mysqli_num_rows($chk);
  if($val==0)
  {
  $query2 = "INSERT INTO market_price (fav_khai, fav_lgai, api_active, market_id, match_name,is_declare,fav_team_selection_id,non_fav_team_selection_id) VALUES ('0', '0', '1', '$market_id', '$match_name','0','$team1_selection_id','$team2_selection_id')";
  $res = mysqli_query($con, $query2); 
  }
   
if($bookmaker_status==1)
{ 
 $return=worldapi_bookmaker_api($_POST);
 if($return==false)
 {
    $_SESSION['notify']=['type'=>'error','msg'=>'Bookmaker data is not coming hence can not be inserted right now']; 
    header("location:../home"); 
    exit();
 }
 $_POST['odds_type']='bookmaker';
}
else
{
  $check="SELECT market_id FROM match_team_tbl WHERE market_id=$market_id";
  $chk=mysqli_query($con,$check);
  $val=mysqli_num_rows($chk);
    if($val==0)
    {
      $query3="INSERT INTO match_team_tbl (selection_id , runner_name , market_id) VALUES ('$team1_selection_id' , '$team1_name' , '$market_id')";
      $res = mysqli_query($con, $query3);

      $query4="INSERT INTO match_team_tbl (selection_id , runner_name , market_id) VALUES ('$team2_selection_id' , '$team2_name' , '$market_id')";
      $res = mysqli_query($con, $query4); 

      if ($count == 3) 
      {
        //_dx($count);
        $runner_name3='The Draw';
        $selection3_id=$team3_selection_id;
       $query4="INSERT INTO match_team_tbl (selection_id , runner_name , market_id) VALUES ('$selection3_id' , '$runner_name3' , '$market_id')";
         $res = mysqli_query($con, $query4);  
      }
    }
}

  $insert=insert_array('upcoming_match',$_POST);
  $insert_id=$insert['insert_id'];

  $admin_data=get_data('users_tbl',"user_type='admin'");
  foreach ($admin_data as $key => $value) 
  {
    $insert_array=array(
     'market_id'=>$market_id,
     'user_type'=>'admin',
     'user_id'=>$value['user_id']
    );
   insert_array('master_permission',$insert_array);
  }



$master_data=get_data('master');

foreach ($master_data as $key => $value) {
  $insert_array=array(
   'market_id'=>$market_id,
   'user_type'=>'master',
   'master_id'=>$value['id']
  );
 $insert=insert_array('master_permission',$insert_array);

}


  $_SESSION['notify']=['type'=>'success','msg'=>'Match inserted successfully']; 
  header("location:../match_setting?status=upcoming");
  exit(); 
}
else
{
  $_SESSION['notify']=['type'=>'error','msg'=>'Match already inserted']; 
  header("location:../insert_match"); 
  exit();

}

?>