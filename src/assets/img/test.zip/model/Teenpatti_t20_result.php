<?php
$page_id='login';
include('../include/config.php');
$url=teen_patti_t20;
$data = api_data_curl_1($url);
$result_data=json_decode($data,true);
extract($result_data);
if($success==1)
{
	foreach ($data as $key => $result_value)  // market_id_loop
	{   
		$market_id=$result_value['mid'];
		extract($result_value);
		$client_array=get_data('casino_bet_tbl',"market_id='".$mid."' AND casino_type='TEENPATTI T20' AND deleted_status=0 AND decision_status=0 group by client_id",'','client_id');
		$count_client=count($client_array);
		if($result_value['result']==1)
				{
					$result_value['result']=1;
				}
				else
				{
					$result_value['result']=2;
				}
		$update_decision=array('decision'=>$result_value['result']);
		update_array('casino_bet_tbl',$update_decision,"market_id='".$market_id."'");
		if($count_client!=0)
		{
		foreach ($client_array as $key => $client_value) 
		{
			$client_id=$client_value['client_id'];
			$client_bet=get_data('casino_bet_tbl',"market_id='".$mid."' AND casino_type='TEENPATTI T20' AND deleted_status=0 AND decision_status=0 AND client_id='".$client_id."'");
			$update_amount=0;
			$amount_data=0;
			 foreach ($client_bet as $key => $client_bet_data) 
			 {
				$client_data=json_decode($client_bet_data['client_detail_array'],true);
				$share_array=json_decode($client_data['share_array'],true);
				extract($share_array);  // extraction all share array
				$all_array['share_array']=$share_array;



				if($client_bet_data['key']==$result_value['result'])
				{
					$amount_data=$client_bet_data['profit'];
				}
				else
				{
					$amount_data=$client_bet_data['loss'];
				}
				 /*_d($amount_data);*/

				$update_amount+=$amount_data;
		    	
			 }
			 if($update_amount>=0)
			 {
               $transaction_type='C';
               $overall_type='CC';
			 }
			 else
			 {
			 	$transaction_type='D';
			 	$overall_type='CD';
			 }

			 $update_array=array(
	 		  	'amount'=>abs($update_amount),
			  	'transaction_type'=>$transaction_type,
			  	'overall_type'=>$overall_type,
			  	'transaction_for'=>'CASINO',
			  	'share_array'=>json_encode($share_array),
			  	'is_declare'=>1,
 		    );


			
			 $update=update_array('transaction_log',$update_array,"client_id='".$client_id."' AND market_id='".$market_id."' AND casino_type='TEENPATTI T20'");

		}
	  }
	}

	return true;

}
else
{
	return false;
}
?>

