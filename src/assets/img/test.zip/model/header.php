<?php 
$is_casino=true;
if(!isset($_GET['all']))
{
if($_SESSION['user_type']!='superadmin')
{
include('permission.php');        
}    
}
if(isset($_POST['page_name']))
{
    $_GET['page_name']=$_POST['page_name'];
    $_GET['list_type']=$_POST['page_name'];
}
$page_data=get_page_name();
$page_name=$page_data['page_name'];
$user_priority=$_SESSION['user_priority'];
?>
<!DOCTYPE html>
<html>
<meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?= site_name ?></title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <!-- <link rel="stylesheet" href="code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css"> -->
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
    <!-- SweetAlert2 -->
  <link rel="stylesheet" href="plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css">
  <!-- Toastr -->
  <link rel="stylesheet" href="plugins/toastr/toastr.min.css">
  <link rel="stylesheet" href="plugins/select2/css/select2.min.css">
  <link rel="stylesheet" href="plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">
  <script src="dist/js/jquery-3.1.1.min.js"></script>
</head>
<body class="hold-transition sidebar-mini text-sm">
<!-- Site wrapper -->
<div class="wrapper">
  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
     
    </ul>


    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      <li class="nav-item dropdown user-menu">
                <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">
                    <img src="dist/img/user2-160x160.jpg" class="user-image img-circle elevation-2" alt="User Image">
                    <span class="d-none d-md-inline"><?= $userdata['username']?></span>
                </a>
                <ul class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                    <!-- User image -->
                    <li class="user-header bg-primary">
                        <img src="dist/img/user2-160x160.jpg" class="img-circle elevation-2" alt="User Image">
                        <p><?= $userdata['username']?> <?= $userdata['name']?></p>
                    </li>
                    <!-- Menu Footer-->
                    <li class="user-footer">
                        <a href="profile?all=" class="btn btn-default btn-flat">Profile</a>
                        <a href="logout" class="btn btn-default btn-flat float-right">
                            Sign out
                        </a>
                    </li>
                </ul>
            </li>
    </ul>
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <!-- Main Sidebar Container -->
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
        <!-- Brand Logo -->
        <a href="dashboard?page_name=dashboard" class="brand-link">
            <img src="dist/img/AdminLTELogo.png" alt="AdminLTE Logo"
                 class="brand-image img-circle elevation-3" style="opacity: .8">
            <span class="brand-text font-weight-light"><?= site_name ?></span>
        </a>

        <!-- Sidebar -->
        <div class="sidebar">


            <!-- Sidebar Menu -->
            <nav class="mt-2">
                <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                    data-accordion="false">
                    <!-- Add icons to the links using the .nav-icon class
                         with font-awesome or any other icon font library -->


                    <li class="nav-header">MASTER DETAILS</li>
                    <li class="nav-item">
                        <a href="collection?all=true" class="nav-link <?php if($page_name=='collection'){ echo 'active'; }   ?> ">

                            <i class="nav-icon fas fa-rupee-sign"></i>
                            <p>
                                Collection Master
                            </p>
                        </a>

                    </li>

                    

                    <?php if($_SESSION['user_type']=='superadmin'){?>

                    <li class="nav-item">
                        <a href="list?list_type=admin&page_no=1&page_name=admin" class="nav-link <?= active_inctive($page_data,'list_type','admin') ?>">
                            <i class="nav-icon fas fa-address-card"></i>
                            <p>
                                Sub Admin Agent Master
                            </p>
                        </a>

                    </li>
                     <?php }  ?>
                       <?php if($_SESSION['user_type']=='superadmin' OR $_SESSION['user_type']=='admin'){?>


                    <li class="nav-item">
                        <a href="list?list_type=master&page_no=1&page_name=master" class="nav-link  <?= active_inctive($page_data,'list_type','master') ?>">

                            <i class="nav-icon fas fa-address-card"></i>
                            <p>
                                Master Agent Master
                            </p>
                        </a>

                    </li>
                    <?php } if($_SESSION['user_type']=='superadmin' OR $_SESSION['user_type']=='admin'  OR $_SESSION['user_type']=='master'){ ?>

                    <li class="nav-item">
                        <a href="list?list_type=superagent&page_no=1&page_name=superagent" class="nav-link <?= active_inctive($page_data,'list_type','superagent') ?>">

                            <i class="nav-icon fas fa-address-card"></i>
                            <p>
                                Super Agent Master
                            </p>
                        </a>

                    </li>
                     <?php }  if($_SESSION['user_type']=='superadmin' OR $_SESSION['user_type']=='admin'  OR $_SESSION['user_type']=='master' OR $_SESSION['user_type']=='superagent') { ?>

                    <li class="nav-item">
                        <a href="list?list_type=agent&page_no=1&page_name=agent" class="nav-link <?= active_inctive($page_data,'list_type','agent') ?>">

                            <i class="nav-icon fas fa-address-card"></i>
                            <p>
                                Agent Master
                            </p>
                        </a>

                    </li>
                      <?php }  ?>
                    <li class="nav-item">
                        <a href="client_list?list_type=client&all=true" class="nav-link <?= active_inctive($page_data,'list_type','client') ?>">

                            <i class="nav-icon fas fa-address-card"></i>
                            <p>
                                Client Master
                            </p>
                        </a>

                    </li>




                    <li class="nav-header">GAMES</li>
                    <li class="nav-item ">
                        <a href="match_list?page_name=inplay&page_no=1" class="nav-link <?= active_inctive($page_data,'page_name','inplay') ?>">

                            <i class="nav-icon fas fa-play"></i>
                            <p>
                                InPlay Game
                            </p>
                        </a>

                    </li>
                    <li class="nav-item">
                        <a href="match_list?page_name=complete_match&page_no=1" class="nav-link <?= active_inctive($page_data,'page_name','complete_match') ?>">

                            <i class="nav-icon far fa-stop-circle"></i>
                            <p>
                                Complete Game
                            </p>
                        </a>

                    </li>
    <?php if($is_casino==true) { ?>
                    <li class="nav-item <?= active_inctive($page_data,'page_name','casino_list',true) ?>">">
                        <a href="#" class="nav-link">
                            <i class="nav-icon fas fa-chart-pie"></i>
                        <p>
                      CASINO
                        <i class="right fas fa-angle-left"></i>
                        </p>
                        </a>
                    <ul class="nav nav-treeview">
               
                    <li class="nav-item">
                        <a href="casino_list?page_name=casino_list&page_no=1&&game_type=TEENPATTI T20" class="nav-link  <?= active_inctive($page_data,'game_type','TEENPATTI%20T20') ?>">
                            <i class="nav-icon far fa-stop-circle"></i>
                            <p>
                                TeenPatti T20
                            </p>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="casino_list?page_name=casino_list&page_no=1&&game_type=DRAGON TIGER" class="nav-link  <?= active_inctive($page_data,'game_type','DRAGON%20TIGER') ?>">
                            <i class="nav-icon far fa-stop-circle"></i>
                            <p>
                               Dragon Tiger
                            </p>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="casino_list?page_name=casino_list&page_no=1&&game_type=LUCKY7 A" class="nav-link <?= active_inctive($page_data,'game_type','LUCKY7%20A') ?>">
                            <i class="nav-icon far fa-stop-circle"></i>
                            <p>
                               Lucky7 A
                            </p>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="#" onclick="coming_soon()" class="nav-link <?= active_inctive($page_data,'game_type','AMAR AKBAR ANTHONY') ?>">
                            <i class="nav-icon far fa-stop-circle"></i>
                            <p>
                               Amar Akbar Anthony
                            </p>
                        </a>
                    </li>


                    <li class="nav-item">
                        <a href="#" onclick="coming_soon()" class="nav-link <?= active_inctive($page_data,'game_type','ANDAR BAHAR') ?>">
                            <i class="nav-icon far fa-stop-circle"></i>
                            <p>
                              Andar Bahar
                            </p>
                        </a>
                    </li>
             
                    </ul>
                    </li>
            <?php } ?>

                       <?php if($userdata['user_type']=='agent') {?>


                    <li class="nav-header">CLIENT COMMISSION</li>
                    <li class="nav-item ">
                        <a href="user_commission?all=true&page_name=<?= $_SESSION['user_type']; ?>_password&page_name=commission"  class="nav-link <?= active_inctive($page_data,'page_name','commission') ?>">

                            <i class="nav-icon fas fa-play"></i>
                            

                            <p>
                               Total Commission
                            </p>
                        </a>

                    </li>

                     <?php } ?>


                    
                    </li>


                    <li class="nav-header">CASH TRANSACTION</li>

                    <li class="nav-item ">">
                        <a href="client_ledger?page_name=client" class="nav-link <?php if($page_name=='client_ledger'){ echo 'active'; }   ?> ">
                            <i class="fas fa-angle-right nav-icon"></i>
                            <p>Debit/Credit Entry (C)</p>
                        </a>
                    </li>
                    <?php  if($_SESSION['user_type']=='superadmin' OR $_SESSION['user_type']=='admin'  OR $_SESSION['user_type']=='master' OR $_SESSION['user_type']=='superagent') { ?>

                    <li class="nav-item">
                        <a href="user_ledger?page_name=agent&ledger_type=agent" class="nav-link <?= active_inctive($page_data,'ledger_type','agent') ?>">
                            <i class="fas fa-angle-right nav-icon"></i>
                            <p>Debit/Credit Entry (A)</p>
                        </a>
                    </li>
                     <?php } if($_SESSION['user_type']=='superadmin' OR $_SESSION['user_type']=='admin'  OR $_SESSION['user_type']=='master'){ ?>

                    <li class="nav-item">
                        <a href="user_ledger?page_name=superagent&ledger_type=superagent" class="nav-link <?= active_inctive($page_data,'ledger_type','superagent') ?>">
                            <i class="fas fa-angle-right nav-icon"></i>
                            <p>Debit/Credit Entry (S)</p>
                        </a>
                    </li>
                    <?php } if($_SESSION['user_type']=='superadmin' OR $_SESSION['user_type']=='admin'){?>

                    <li class="nav-item">
                        <a href="user_ledger?page_name=master&ledger_type=master" class="nav-link <?= active_inctive($page_data,'ledger_type','master') ?>">
                            <i class="fas fa-angle-right nav-icon"></i>
                            <p>Debit/Credit Entry (M)</p>
                        </a>
                    </li>
                    <?php } if($_SESSION['user_type']=='superadmin'){?>

                    <li class="nav-item">
                        <a href="user_ledger?page_name=admin&ledger_type=admin" class="nav-link <?= active_inctive($page_data,'ledger_type','admin') ?>">
                            <i class="fas fa-angle-right nav-icon"></i>
                            <p>Debit/Credit Entry (AD)</p>
                        </a>
                    </li>
                    <?php }  ?>


                    <li class="nav-header">LEDGER</li>

                    <li class="nav-item">
                        <a href="user_ledger?ledger_type=self&all=true" class="nav-link <?= active_inctive($page_data,'ledger_type','self') ?>">
                            <i class="fas fa-angle-right nav-icon"></i>
                            <p>My Ledger</p>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="client_plus_minus?minus_plus=client&page_name=client" class="nav-link <?= active_inctive($page_data,'minus_plus','client') ?>">
                            <i class="fas fa-angle-right nav-icon"></i>
                            <p>Client Plus/Minus</p>
                        </a>
                    </li>


                    <li class="nav-item">
                        <a href="collection_report?all=true" class="nav-link <?php if($page_name=='collection_report'){ echo 'active'; }   ?>">
                            <i class="fas fa-angle-right nav-icon"></i>
                            <p>All Client Ledger</p>
                        </a>
                    </li>
                    <?php  if($user_priority>=priority('superagent')){ ?>

                    <li class="nav-item">
                        <a href="user_collection_report?collection_type=agent&page_name=report" class="nav-link <?= active_inctive($page_data,'collection_type','agent') ?>">
                            <i class="fas fa-angle-right nav-icon"></i>
                            <p>All Agent Ledger</p>
                        </a>
                    </li>

                   <?php } if($user_priority>=priority('master')){ ?>
                    <li class="nav-item">
                        <a href="user_collection_report?collection_type=superagent&page_name=report" class="nav-link <?= active_inctive($page_data,'collection_type','superagent') ?>">
                            <i class="fas fa-angle-right nav-icon"></i>
                            <p>All Super Ledger</p>
                        </a>
                    </li>
                <?php } if($user_priority>=priority('admin')){ ?>

                    <li class="nav-item">
                       <a href="user_collection_report?collection_type=master&page_name=report" class="nav-link <?= active_inctive($page_data,'collection_type','master') ?>">
                            <i class="fas fa-angle-right nav-icon"></i>
                            <p>All Master Ledger</p>
                        </a>
                    </li>

                    <?php } if($user_priority>=priority('superadmin')){ ?>
                    <li class="nav-item">
                        <a href="user_collection_report?collection_type=admin&page_name=report" class="nav-link <?= active_inctive($page_data,'collection_type','admin') ?>">
                            <i class="fas fa-angle-right nav-icon"></i>
                            <p>All Admin Ledger</p>
                        </a>
                    </li>
                  <?php } ?>


                    <li class="nav-header">REPORTS</li>
                    <?php if($user_priority>=priority('superadmin')){ ?>
                    <li class="nav-item">
                        <a href="report?report_type=admin" class="nav-link <?= active_inctive($page_data,'report_type','admin') ?>">
                            <i class="fas fa-th-list nav-icon"></i>
                            <p>Admin Reports</p>
                        </a>
                    </li>
                <?php } if($user_priority>=priority('admin')){ ?>

                    <li class="nav-item">
                        <a href="report?report_type=master&page_name=master" class="nav-link <?= active_inctive($page_data,'report_type','master') ?>">
                            <i class="fas fa-th-list nav-icon"></i>
                            <p>Master Reports</p>
                        </a>
                    </li>
                <?php } if($user_priority>=priority('master')){ ?>

                    <li class="nav-item">
                        <a href="report?report_type=superagent&page_name=superagent" class="nav-link <?= active_inctive($page_data,'report_type','superagent') ?>">
                            <i class="fas fa-th-list nav-icon"></i>
                            <p>Super Reports</p>
                        </a>
                    </li>
                <?php } if($user_priority>=priority('superagent')){ ?>

                    <li class="nav-item">
                        <a href="report?report_type=agent&page_name=agent" class="nav-link <?= active_inctive($page_data,'report_type','agent') ?>">
                            <i class="fas fa-th-list nav-icon"></i>
                            <p>Agent Reports</p>
                        </a>
                    </li>
                <?php } ?>

                    <li class="nav-item">
                        <a href="report?report_type=client&page_name=client" class="nav-link <?= active_inctive($page_data,'report_type','client') ?>">
                            <i class="fas fa-th-list nav-icon"></i>
                            <p>Clients Reports</p>
                        </a>
                    </li>

                  

                <?php if($user_priority>=priority('superadmin')){ ?>
                    <li class="nav-item">
                        <a href="login_report?login_report_type=admin&page_name=admin" class="nav-link <?= active_inctive($page_data,'login_report_type','admin') ?>">
                            <i class="fas fa-clipboard-list nav-icon"></i>
                            <p>Admin Login Reports</p>
                        </a>
                    </li>

                    <?php } if($user_priority>=priority('admin')){ ?>
                    <li class="nav-item">
                        <a href="login_report?login_report_type=master&page_name=master" class="nav-link <?= active_inctive($page_data,'login_report_type','master') ?>">
                            <i class="fas fa-clipboard-list nav-icon"></i>
                            <p>master Login Reports</p>
                        </a>
                    </li>

                
                    <?php } if($user_priority>=priority('master')){ ?>
                    <li class="nav-item">
                        <a href="login_report?login_report_type=superagent&page_name=superagent" class="nav-link <?= active_inctive($page_data,'login_report_type','superagent') ?>">
                            <i class="fas fa-clipboard-list nav-icon"></i>
                            <p>Super Login Reports</p>
                        </a>
                    </li>
                     <?php } if($user_priority>=priority('superagent')){ ?>

                    <li class="nav-item">
                        <a href="login_report?login_report_type=agent&page_name=agent" class="nav-link <?= active_inctive($page_data,'login_report_type','agent') ?>">
                            <i class="fas fa-clipboard-list nav-icon"></i>
                            <p>Agent Login Reports</p>
                        </a>
                    </li>
                   <?php } ?>

                    <li class="nav-item">
                        <a href="login_report?login_report_type=client&page_name=client" class="nav-link <?= active_inctive($page_data,'login_report_type','client') ?>">
                            <i class="fas fa-clipboard-list nav-icon"></i>
                            <p>Clients Login Reports</p>
                        </a>
                    </li>


                </ul>
            </nav>
            <!-- /.sidebar-menu -->
        </div>
        <!-- /.sidebar -->
    </aside>


<script type="text/javascript">
    
    function coming_soon()
    {
        alert("Coming Soon");
        return false;
    }

</script>