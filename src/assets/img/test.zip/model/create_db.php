<?php
include('../include/config.php');
include('../include/flat_share_function.php');
include('../include/userEditFunction.php');
if(!isset($_POST))
{
    invalid();
}

$post_array=sanatize($_POST['user']);
$page_name=$post_array['page_name'];
$role=$post_array['role'];
unset($post_array['page_name']);
unset($post_array['role']);

if($post_array['user_id']=='')
{
$post_array['user_share_type']='fixed';
$post_user_coins=($_POST['user_coins']);
$post_array['fix_limit']=$_POST['user_coins'];
$post_array['username']=get_code(trim($role));
$post_array['insert_date_time']=_date_time();
$post_array['insert_date']=_date();
$post_array['creater_id']=$_POST['parent_user_id'];
$post_array['last_ip']=ip();
$post_array['add_priority']=priority($post_array['user_type']);
$parent_result=get_user_list('',$post_array['creater_id']);
$post_array['created_by']=$parent_result['user_type'];

if($post_array['user_comm_type']=='No Comm')
{
  $post_array['user_session_comm']=0;  
  $post_array['user_match_comm']=0;  
}
if($post_array['user_comm_type']=='OM')
{
  $post_array['user_session_comm']=$post_array['user_match_comm'];  
}

if(is_casino==false)
{
  $post_array['user_casino_comm']=$post_array['user_match_comm'];
  $post_array['user_casino_share']=$post_array['user_share'];
}

if($post_array['name']==" " ||  $post_array['password']==" " || $post_array["user_share"]==" "  ||  $post_array['user_comm_type']==" " || $post_array['user_mobile_share']=="" || $_POST['user_coins']<0)
            {

                
                $_SESSION['notify']=['type'=>'error','msg'=>'Something went wrong!'];
                header("location:../create.php?role=".$role."&page_name=".$page_name."");
                exit();
            }
  
            if(($post_array['user_share'] > $parent_result['user_share'])  OR ($post_array['user_match_comm'] > $parent_result['user_match_comm']) OR ($post_array['user_session_comm'] > $parent_result['user_session_comm']))
            {
                
                $_SESSION['notify']=['type'=>'error','msg'=>'Something went wrong!'];

                header("location:../create.php?role=".$role."&page_name=".$page_name."");
                exit();
            }
$result=insert_array('users_tbl',$post_array,'');
$insert_id=$result['insert_id'];
$return_post=update_details($insert_id,$post_array,$parent_result);
$data= update_array('users_tbl', $return_post,'user_id='.$insert_id.'');
$task_array=array(
    'user_id'=>$insert_id,
    'user_type'=>$post_array['user_type'],
    'user_match_comm'=>$post_array['user_match_comm'],
    'user_session_comm'=>$post_array['user_session_comm'],
    'user_share'=>$post_array['user_share'],
    'task_name'=>$post_array['user_type'].' created',
    'note'=>$post_array['user_type'].' created',
    'creater_id'=>$_SESSION['user_id'],
    'creater_type'=>$_SESSION['user_type'],
    'creater_name'=>$_SESSION['name'],
    'ip'=>ip(),
    'date'=>_date(),
    'fix_limit'=>$post_array['fix_limit'],
    'date_time'=>_date_time(),
    'user_name'=>$post_array['name'],
    'history_type'=>'user_create'

);
$result=insert_array('user_history_log',$task_array,'');


$update_coins=update_user_coins($_POST['parent_user_id'],$insert_id,$_POST['user_coins'],'deposit');
if($post_array['user_type']=='admin')
{
$admin_config_result=get_data('admin_config_tbl','','single');
$insert_admin_config_array=array(
    'MAX_AMOUNT_MATCH'=>$admin_config_result['MAX_AMOUNT_MATCH'],
    'MAX_AMOUNT_SESSION'=>$admin_config_result['MAX_AMOUNT_SESSION'],
    'MIN_AMOUNT_MATCH'=>$admin_config_result['MIN_AMOUNT_MATCH'],
    'MIN_AMOUNT_SESSION'=>$admin_config_result['MIN_AMOUNT_SESSION'],
    'user_id'=>$insert_id,
    'user_type'=>$post_array['user_type'],
    'admin_id'=>$insert_id,
    'superadmin_id'=>$parent_result['superadmin_id'],
    'insert_date'=>_date_time()
);
$config_result=insert_array('config_tbl',$insert_admin_config_array,'');
$match_list=get_data('upcoming_match',"status='INPLAY' OR status='UPCOMING'");
foreach ($match_list as $key => $match_value) {
$insert_array=array('user_id'=>$insert_id,'user_type'=>$post_array['user_type'],'user_status'=>1,'market_id'=>$match_value['market_id']);
$insert=insert_array('master_permission',$insert_array,'');
}
}
$perm_insert_array=array(
    'cricket_perm'=>1,
    'teenpattin_t20_perm'=>1,
    'teenpatti_oneday_perm'=>1,
    'teenpatti_test_perm'=>1,
    'dragon_tiger'=>1,
    'andar_bahar'=>1,
    'amar_akbar_anthony'=>1,
    'seven_up_down'=>1,
    'dus_ka_dum'=>1,
    'user_id'=>$insert_id,
    'user_type'=>$post_array['user_type'],
);
$perm_insert=insert_array('casino_perm',$perm_insert_array);
$_SESSION['notify']=['type'=>'success','msg'=>''.$page_name.' created successfully'];
header("location:../list?list_type=".$page_name."&page_name=".$page_name."");
}
else
{   

     if($post_array['user_comm_type']=='Bet By Bet')
     {
      $post_array['user_comm_type']='BB';
     }
     
     if($post_array['user_type']=='superagent')
    {
        $show_type='sa';
    }
    else
    {
        $show_type=$post_array['user_type'];
    }
    $post_array['user_casino_comm']=$post_array['user_match_comm'];
    $post_array['user_casino_share']=$post_array['user_share'];

    $check_array=array();
    $check_array['post_array']=$post_array;
    $get_user_data=get_data('users_tbl',"user_id='".$post_array['user_id']."'",'s');
    $parent_result=get_data('users_tbl',"user_id='".$get_user_data['creater_id']."'",'s');
    $check_array['user_data']=$get_user_data;
    $check_array['parent_data']=$parent_result;
    $parent_show_type=$parent_result['user_type']=='superagent'?'sa':$parent_result['user_type'];

    if(isset($post_array['flat_share_on']))
    {

        if($post_array['flat_share_on']!=$get_user_data[$parent_show_type.'_share'])
        {
           $return=change_flat_share($post_array['flat_share_on'],$post_array['user_id'],$post_array['user_type']);
 
        }

    }

    if(($post_array['user_share']>$parent_result['user_share'])  OR ($post_array['user_match_comm'] > $parent_result['user_match_comm']) OR ($post_array['user_session_comm'] > $parent_result['user_session_comm']))
    {
          
                $_SESSION['notify']=['type'=>'error','msg'=>'Something went wrong!'];
                header("location:../create?role=".$role."&page_name=".$page_name."&user_id=".$post_array['user_id']."");
                exit();
    }

    if($post_array['user_share']!=$get_user_data['user_share'] AND $post_array['user_share']<=$parent_result['user_share'])
    {
       $return=change_share($post_array['user_type'],$post_array['user_id'],$post_array['user_share']);
       if($return==false OR $return=='')
       {
    
            header("location:../list?list_type=".$page_name."&page_name=".$page_name."");
            exit();
            die();
       }
       else
       {
         $_SESSION['notify']=['type'=>'success','msg'=>'Share updated successfully'];
       }
               
    }

    if($post_array['user_comm_type']=='No Comm')
    {
        $post_array['user_match_comm']=0;
        $post_array['user_session_comm']=0;
    }

    if($post_array['user_comm_type']=='OM')
    {
        $post_array['user_session_comm']=$post_array['user_match_comm'];
    }

    if($post_array['user_match_comm']!=$get_user_data['user_match_comm'] AND $post_array['user_match_comm']<=$parent_result['user_match_comm'])
    {
       $return=commission_share($post_array['user_type'],$post_array['user_id'],$post_array['user_match_comm'],'match_commission');
       if($return==false OR $return=='')
       {
    
            header("location:../list?list_type=".$page_name."&page_name=".$page_name."");
            exit();
            die();
       }
       else
       {
         $_SESSION['notify']=['type'=>'success','msg'=>'Match Commission updated successfully'];
       }
               
    }

    if($post_array['user_session_comm']!=$get_user_data['user_session_comm'] AND $post_array['user_session_comm']<=$parent_result['user_session_comm'])
    {
       $return=commission_share($post_array['user_type'],$post_array['user_id'],$post_array['user_session_comm'],'session_commission');
       if($return==false OR $return=='')
       {
    
            header("location:../list?list_type=".$page_name."&page_name=".$page_name."");
            exit();
            die();
       }
       else
       {
         $_SESSION['notify']=['type'=>'success','msg'=>'Session Commission updated successfully'];
       }
               
    }

    if($post_array['user_comm_type']!=$get_user_data['user_comm_type'])
    {
       $return=commission_share($post_array['user_type'],$post_array['user_id'],$post_array['user_comm_type'],'commission_type');
       if($return==false OR $return=='')
       {
    
            header("location:../list?list_type=".$page_name."&page_name=".$page_name."");
            exit();
            die();
       }
       else
       {
         $_SESSION['notify']=['type'=>'success','msg'=>'Commission Type updated successfully'];
       }
               
    }

        if(is_casino)
        {
            if($post_array['user_casino_perm']!=$get_user_data['user_casino_perm'])
            {   

                $return=user_casino_bet_status($get_user_data['user_id'],$post_array['user_casino_perm'],$get_user_data,$parent_result);
                $_SESSION['notify']=['type'=>'success','msg'=>'casino permission changed successfully'];
            }
        }

        if(isset($_POST['share_on']))
        {
           if($parent_result['user_share_type']=='change' AND $post_array['user_share']<=$_POST['share_on'])
           {
               $return=overall_change_share($post_array['user_id'],$post_array['user_type'],$_POST['share_on']);

           }

        }
      

          if($get_user_data['no_comm_perm']!=$post_array['no_comm_perm'])
          {
            no_comm_session_perm_update($get_user_data,$post_array['no_comm_perm']);
            $report_type='no_comm_perm';
            user_generate_report($report_type,$get_user_data['no_comm_perm'],$post_array['no_comm_perm'],$get_user_data,$parent_result,$post_array['user_id']);
          }

    
        unset($post_array['user_comm_type']);
        unset($post_array['user_match_comm']);
        unset($post_array['user_session_comm']);
        unset($post_array['user_casino_comm']);
        unset($post_array['user_casino_share']);
        unset($post_array['user_type']);
        unset($post_array['user_share']);
        unset($post_array['share_on']);
        unset($post_array['flat_share_on']);
     $data= update_array('users_tbl', $post_array,'user_id='.$post_array['user_id']);
     
    $_SESSION['notify']=['type'=>'success','msg'=>''.$page_name.' updated successfully'];
    header("location:../list?list_type=".$page_name."&page_name=".$page_name."");
}

?>
