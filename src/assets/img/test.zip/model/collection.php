<?php 
include('include/config.php');
include('header.php');
$table_data=get_data('collection',"creater_id='".$userdata['user_id']."'");  
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Collection Details</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="dashboard?page_name=dashboard">Home</a></li>
              <li class="breadcrumb-item active">Collection</li>
            </ol>
          </div>
        </div>
      </div>
    </section>
    <section class="content">
       <div class="card">
            <div class="card-header">
              <div class="form-group">
                <a href="create_collection?all=true" class="btn btn-primary">
                  New <i class="fa fa-plus-circle"></i>
                </a>
              </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="example1" class="table table-bordered table-striped">


                <thead>
                <tr>
                  <th><input type="checkbox" name="checkbox[]" value=''></th>
                  <th>#</th>
                  <th>CODE</th>
                  <th>Name</th>
                  <th>Reference</th>
                  <th>Contact No.</th>
                  <th>Account No.</th>
                  <th>Collection Type</th>
                  <th>Status</th>
                </tr>
                </thead>
                <tbody>
                 <?php $s_no=1; foreach ($table_data as $key => $table_value) { extract($table_value); ?>
                <tr>
                  <td><input type="checkbox" name="checkbox[]" value=<?= $collection_id  ?>></td>
                  <td>
                      <label><?= $s_no++ ?></label>
                        <div class="btn-group">
                            <button type="button" class="btn btn-xs btn-outline-secondary dropdown-toggle dropdown-hover dropdown-icon" data-toggle="dropdown">
                             <span class="sr-only">Toggle Dropdown</span>
                            </button>
                           <div class="dropdown-menu" role="menu">
                            <a class="dropdown-item" href="create_collection?collection_id=<?= $collection_id ?>">Edit</a>
                              <span>
                                <a class="dropdown-item" href="#">InActive</a>
                              </span>

                            </div>
                        </div>
                    </td>
                  <td><?= $code ?></td>
                  <td><?= $name ?></td>
                  <td><?= $reffrence ?></td>
                  <td><?= $contact_no ?></td>
                  <td><?= $account_no ?></td>
                  <td><?= $collection_type ?></td>
                  <td><div>
                        <span class="float-center badge bg-<?= $status==1?'success':'danger' ?>"><?= $status==1?'Active':'InActive' ?></span>
                      </div>
                  </td>
                </tr>
              <?php } ?>
                
                </tfoot>
              </table>
            </div>
            <!-- /.card-body -->
          </div>

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <?php  include('footer.php');  ?>