<?php 
$page_id='login';
include('include/config.php');
if(isset($_SESSION['is_verify_logged_in']))
{ 
    if($_SESSION['user_type']=='owner')
    {
     header("location:home");
    }
    else
    {
     header("location:dashboard?page_name=dashboard");   
    }
  die;
  exit();
}
else
{
$random_number=rand(1000,9999);
unset($_SESSION['verify_captcha']);
$_SESSION['verify_captcha']=$random_number;
}
$subdomain=subdomain();
if($subdomain=='')
{
  $subdomain='all';
}
?>  


<!DOCTYPE html>
<html>
<meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?= site_name ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="../../../../../code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- icheck bootstrap -->
  <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/adminlte.min.css">

  <link rel="stylesheet" href="dist/css/sky.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">

   <!-- SweetAlert2 -->
  <link rel="stylesheet" href="plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css">
  <!-- Toastr -->
  <link rel="stylesheet" href="plugins/toastr/toastr.min.css">
  <link rel="stylesheet" href="plugins/select2/css/select2.min.css">
  <link rel="stylesheet" href="plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">
  <script src="dist/js/jquery-3.1.1.min.js"></script>
</head>
 <body class="skyexchange">
        <div class='main'>
          <div class="center-div">
            <div class="row row1 no-gutters">
              <div class="col-12 col-sm-6 sk"></div>
              <div class="col-12 col-sm-6 sk-2">
                <div class="skk">
                
                 
                   <?php if(logo){?>
                    <center>
                      <img  style="margin-top: -25px; margin-bottom: 10px;" src="dist/img/gold_logo.png" height="100" width="100" ><br><b class="membar" style="color:#203469;">ADMIN LOGIN</b></center>
          
                    <?php } ?>
          
                  <form action="login" method="POST">
                    <input required type="text" name="username" id='username'  class="form-control bg-white text-uppercase" placeholder="username">
                    <input required type="password" name="password" id='passsword' class="form-control" placeholder="PASSWORD">
                    <!-- <div class="position-relative">
                      <input type="text" name="" placeholder="validation Code" maxLength="4" />
                      <img src="dist/img/sky/verifycode.jpeg" alt="" class="varicode" />
                    </div> -->

                  
                         <div class="social-auth-links text-center mb-3">
                            <button style="background-color:black !important; border-color: #FF911F;" type="submit" name="submit" class="form-control btn btn-info btn-block">Login
                                     </button>
                          </div>
                  </form>
                  <!-- <div class="text-center text-black sk-2 term" >
                    Term's and condition
                  </div> -->
                </div>
              </div>
            </div>
            <div class="browser-wrap text-center text-white note" >
              Our website works best in the newest and last prior version of these browsers:<br />Google Chrome. Firefox
            </div>
          </div>
        </div>
      </body>

      <script src="plugins/jquery/jquery.min.js"></script>
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="dist/js/adminlte.min.js"></script>


<?php   require_once('footer.php') ?>