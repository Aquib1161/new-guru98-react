<?php 
include('include/config.php');
$_GET=sanatize($_GET);
$_POST=sanatize($_POST);
extract($_GET);
include('header.php');
if($ledger_type!='self')
{
    $user_data=get_data('users_tbl',user_where("user_type='".$ledger_type."'"));
} 
?>
  <div class="content-wrapper">
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <?php if($ledger_type=='self'){ ?>
            <h1>My Ledger</h1>
         <?php } else{ ?>
            <h1>Cash Transaction</h1>
         <?php } ?>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="dashboard?page_name=dashboard">Home</a></li>
              <li class="breadcrumb-item active">Cash Transaction</li>
            </ol>
          </div>
        </div>
      </div>
    </section>
    <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">

                        <!-- /.card -->


                        <div class="card">
                        <?php if($ledger_type!='self'){?>
                                <div class="card-header ">

                                    <h4 class="text-capitalize"><?= $_GET['ledger_type']=='self'?$userdata['user_type'] :$_GET['ledger_type'] ?> Ledger</h4>


                                    <div class="form-row col-md-9">
                                        <div class="form-group col-md-4">
                                            <label for="name" class="text-capitalize"><?= $_GET['ledger_type'] ?></label>
                                            <select class="form-control select2 " onchange="change()" name="user_id" id='user_id' >
                                              <option value=''>Select..</option>
                                            <?php foreach ($user_data as $key => $user) { ?>
                                              <option value="<?= $user['user_id']?>"><?= $user['name']?> (<?= $user['username']?>)</option>
                                            <?php  }  ?>
                                            </select>
                                        </div>

                                        <!-- <div class="form-group col-md-4">
                                            <label for="collection">Statement Type</label>
                                            <select onchange="change()" class="form-control custom-select" required="" name="collection_type" id='collection_type' placeholder="Select Collection" name="collection">
                                                <option value="0">ALL</option>
                                                <option value="3">MATCH</option>
                                                <option value="2">CASINO</option>
                                                <option value="1">CASH</option>
                                            </select>
                                        </div> -->

                                        <div class="form-group col-md-4">
                                            <label for="collection">Collection</label>
                                            <select  class="form-control custom-select" required="" name="collection_type" id='collection_type' placeholder="Select Collection" name="collection">
                                                <option value="0">CA1 CASH</option>
                                                
                                            </select>
                                        </div>

                                        <div class="form-group col-md-4">

                                            <label for="amount">Amount</label>
                                            <input  class="form-control " type="number" name="amount" id="amount">

                                        </div>

                                        <div class="form-group col-md-4">

                                            <label for="type">Payment Type</label>
                                            <select class="form-control custom-select" required="" name="transaction_type" id='transaction_type'>
                                                <option value="C">PAYMENT - DENA</option>
                                                <option value="D">RECEIPT - LENA</option>

                                            </select>

                                        </div>


                                        <div class="form-group col-md-4">

                                            <label for="remark">Remark</label>
                                            <input type="text" class="form-control " type="text" name="remark" id="remark">

                                        </div>


                                        <div class="form-group col-md-4">

                                            <label class="control-label text-purple" for="btn">`</label>
                                            <input type="submit" class="form-control btn-primary" id="submit" onclick="submit()">

                                        </div>


                                    </div>


                                </div>
                                <!-- /.card-header -->

                            <?php } ?>

                                <span id="user_data"> </span>


                              
                                <!-- /.card-body -->
                           

                        </div>
                        <!-- /.card -->


                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </section>

   

   
  </div>
  <!-- /.content-wrapper -->
  <script type="text/javascript">

function submit()
{
    var user_id=$("#user_id").val();
    var transaction_type=$("#transaction_type").val();
    var date=$("#date").val();
    var amount=$("#amount").val();
    var collection_type=1;
    var remark=$("#remark").val();
    if(user_id=='')
    {
        alert('Please Select user first');
        return false;
    }
    if(transaction_type=='')
    {
        alert('Please Select transaction type');
        return false;
    }
    if(amount==0 || amount=='')
    {
        alert('Please enter amount');
        return false;
    }


                        sendData={
                          'user_id':user_id,
                          'transaction_type':transaction_type,
                          'date':date,
                          'amount':amount,
                          'collection_type':collection_type,
                          'note':remark
                         }
                       data = sendAjax('ajax/user_ledger_update',sendData);
                       if(data.status=='success')
                       {
                        get_user_data(user_id,false);
                        $("#amount").val('');
                        $("#remark").val('');
                       }
                       swal(data.status,data.data.msg, data.status);




}


  var self="<?= $_GET['ledger_type'] ?>"
  function get_user_data(user_id,self='',statement_type)
  {
     $.ajax({
                    url : "ajax/ajax_user_ledger",
                    type : "post",
                    data : { id:user_id,self:self,statement_type:statement_type},
                    success : function(res){
                        /*alert(res);*/
                        $("#user_data").html(res);
                    }
                });
  }

  function change()
  {
    var user_id=$("#user_id").val();
    var statement_type=$("#collection_type").val();
    if(user_id=='')
    {
        return false;
    }

    get_user_data(user_id,false,statement_type);
    
  }
    
if(self=='self')
{
get_user_data(<?= $_SESSION['user_id'] ?>,true);   
}


  </script>

  <?php  include('footer.php');  ?>