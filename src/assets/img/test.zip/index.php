<?php 
$page_id='login';
include('include/config.php');
if(isset($_SESSION['is_verify_logged_in']))
{ 
  header("location:dashboard?page_name=dashboard");   
  die;
  exit();
}

$login_page=['1ex'=>false,'95'=>true , 'sky'=>false];

if($login_page['1ex'])
{
  header("location:1ex_login");
}
else if($login_page['95'])
{
  header("location:95_login");
}
else if($login_page['sky'])
{
  
  header("location:sky_login");
}
else
{
  _dx('something_went_wrong');
}

?>  
